# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "ac5b1180-2f1b-47d2-b526-dfc3026a771b",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "a7ad27b1-6ad7-440f-bf78-030662ef90fd",
# META       "known_lakehouses": [
# META         {
# META           "id": "ac5b1180-2f1b-47d2-b526-dfc3026a771b"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "known_warehouses": []
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Overview
# This notebook ingests metadata configurations provided through a YAML file and loads them into the metadata control database. It validates the YAML inputs, stages the validated records in an interim table, and then publishes them to the final `meta.task` table.


# CELL ********************

# Type here in the cell editor to add code!
path=f"{notebookutils.nbResPath}/builtin/test.yml"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run nb_load_metadata_config_utility

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## Test JDBC connection with Metadata control db

# CELL ********************

_test_jdbc_connection(jdbc_url,driver)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## Load config file to dataframe

# CELL ********************

df_current = yaml_to_stage_rows(path)
display(df_current)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## Run validation on the loaded configs

# CELL ********************

df_warning=final_validation(df_current)
warning_records = df_warning.count()

if warning_records>0:
    print(f'WARNING.. Issues with {warning_records} records.')
    display(df_warning)
else:
    print('All records passed validations.')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## Load metadata to Control database

# CELL ********************

display(df_current)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(jdbc_url)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

col_list = [
    'task_name','object_name','stage','source_connection_id',
    'source_settings','target_settings','option_settings',
    'template_settings','enabled','file_hash',
    'scheduling_settings','enable_retries','max_retry_attempts'
]

merge_query = build_merge_sql(
    'meta','task','meta','temp_task',
    ['object_name','stage'],
    col_list,
    col_list
)

# ✅ Step 1: staging write (already working)
_load_staging_table(df_current)

# ✅ Step 2: execute merge cleanly
rows = execute_non_query_token(merge_query)

print(f"MERGED {rows} rows successfully into meta.task table")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

rows = execute_query_token("SELECT COUNT(*) FROM meta.task")
print(rows)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

rows = execute_query_token("SELECT TOP 10 * FROM meta.task")
for r in rows:
    print(r)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

execute_query_token("SELECT DB_NAME()")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.createDataFrame(
    execute_query_token("SELECT * FROM meta.task"),
    schema=_load_table_db(jdbc_url, driver, "meta.task").schema
)
display(df)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
