# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "7b7fdebd-4a38-4896-afe1-4e18baae98fa",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "32edd28f-d985-4fcb-a441-5aadb4bde264",
# META       "known_lakehouses": [
# META         {
# META           "id": "7b7fdebd-4a38-4896-afe1-4e18baae98fa"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Welcome to your new notebook
# Type here in the cell editor to add code!


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
