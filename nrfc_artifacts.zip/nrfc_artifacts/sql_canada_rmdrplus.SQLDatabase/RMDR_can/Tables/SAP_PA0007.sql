CREATE TABLE [RMDR_can].[SAP_PA0007] (
    [PERNR]     NVARCHAR (8)   NOT NULL,
    [SUBTY]     NVARCHAR (4)   NOT NULL,
    [BEGDA]     DATETIME       NOT NULL,
    [SEQNR]     NVARCHAR (3)   NOT NULL,
    [ENDDA]     DATETIME       NULL,
    [AEDTM]     DATETIME       NULL,
    [UNAME]     NVARCHAR (12)  NULL,
    [WWEEK]     NCHAR (2)      NULL,
    [ARBST]     DECIMAL (5, 2) NULL,
    [WOSTD]     DECIMAL (5, 2) NULL,
    [MOSTD]     DECIMAL (5, 2) NULL,
    [JRSTD]     DECIMAL (7, 2) NULL,
    [WKWDY]     DECIMAL (4, 2) NULL,
    [EMPCT]     DECIMAL (5, 2) NULL,
    [ZZFTE]     NCHAR (1)      NULL,
    [ZZCFTE]    DECIMAL (5, 2) NULL,
    [ZZPFTE]    DECIMAL (5, 2) NULL,
    [ZZFWKR]    NCHAR (1)      NULL,
    [ZZDUT]     DECIMAL (4, 2) NULL,
    [TIMESTAMP] DATETIME       NULL,
    [SCHKZ]     NVARCHAR (8)   NULL,
    CONSTRAINT [PK_SAP_PA0007] PRIMARY KEY CLUSTERED ([PERNR] ASC, [SUBTY] ASC, [BEGDA] ASC, [SEQNR] ASC)
);


GO

