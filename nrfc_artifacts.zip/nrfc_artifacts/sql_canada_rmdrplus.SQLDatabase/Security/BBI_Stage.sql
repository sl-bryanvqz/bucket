CREATE SCHEMA [BBI_Stage]
    AUTHORIZATION [dbo];


GO

