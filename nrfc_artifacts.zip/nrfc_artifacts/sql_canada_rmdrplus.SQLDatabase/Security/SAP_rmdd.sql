CREATE SCHEMA [SAP_rmdd]
    AUTHORIZATION [dbo];


GO

