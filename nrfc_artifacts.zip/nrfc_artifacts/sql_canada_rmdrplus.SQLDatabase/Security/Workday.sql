CREATE SCHEMA [Workday]
    AUTHORIZATION [dbo];


GO

