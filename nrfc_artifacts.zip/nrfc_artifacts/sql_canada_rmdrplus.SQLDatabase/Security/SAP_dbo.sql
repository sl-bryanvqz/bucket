CREATE SCHEMA [SAP_dbo]
    AUTHORIZATION [dbo];


GO

