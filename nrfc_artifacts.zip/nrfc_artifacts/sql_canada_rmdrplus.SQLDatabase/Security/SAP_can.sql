CREATE SCHEMA [SAP_can]
    AUTHORIZATION [dbo];


GO

