CREATE SCHEMA [RMDR_can]
    AUTHORIZATION [dbo];


GO

