CREATE SCHEMA [RMDR_dbo]
    AUTHORIZATION [dbo];


GO

