CREATE TABLE [SAP_dbo].[SAP_A608_Receiver] (
    [KSCHL]     NCHAR (4)       NOT NULL,
    [WERKS]     NCHAR (4)       NOT NULL,
    [ZZPRGRP]   NCHAR (4)       NOT NULL,
    [ZZACTTY]   NCHAR (4)       NOT NULL,
    [KFRST]     NCHAR (1)       NOT NULL,
    [DATBI]     DATETIME        NOT NULL,
    [DATAB]     DATETIME        NULL,
    [KBETR]     DECIMAL (11, 2) NULL,
    [KONWA]     NVARCHAR (5)    NULL,
    [TIMESTAMP] DATETIME        NULL,
    [LOEVM_KO]  NCHAR (1)       NULL,
    CONSTRAINT [PK_SAP_A608_Receiver] PRIMARY KEY CLUSTERED ([KSCHL] ASC, [WERKS] ASC, [ZZPRGRP] ASC, [ZZACTTY] ASC, [KFRST] ASC, [DATBI] ASC)
);


GO

