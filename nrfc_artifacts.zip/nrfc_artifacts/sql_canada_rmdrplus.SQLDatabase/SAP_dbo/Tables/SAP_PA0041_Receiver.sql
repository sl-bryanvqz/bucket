CREATE TABLE [SAP_dbo].[SAP_PA0041_Receiver] (
    [PERNR]     NVARCHAR (8)  NOT NULL,
    [SUBTY]     NVARCHAR (4)  NOT NULL,
    [BEGDA]     DATETIME      NOT NULL,
    [SEQNR]     NVARCHAR (3)  NOT NULL,
    [ENDDA]     DATETIME      NOT NULL,
    [AEDTM]     DATETIME      NULL,
    [UNAME]     NVARCHAR (12) NULL,
    [DAR01]     NCHAR (2)     NULL,
    [DAT01]     DATETIME      NULL,
    [DAR02]     NCHAR (2)     NULL,
    [DAT02]     DATETIME      NULL,
    [DAR03]     NCHAR (2)     NULL,
    [DAT03]     DATETIME      NULL,
    [DAR04]     NCHAR (2)     NULL,
    [DAT04]     DATETIME      NULL,
    [DAR05]     NCHAR (2)     NULL,
    [DAT05]     DATETIME      NULL,
    [DAR06]     NCHAR (2)     NULL,
    [DAT06]     DATETIME      NULL,
    [DAR07]     NCHAR (2)     NULL,
    [DAT07]     DATETIME      NULL,
    [DAR08]     NCHAR (2)     NULL,
    [DAT08]     DATETIME      NULL,
    [DAR09]     NCHAR (2)     NULL,
    [DAT09]     DATETIME      NULL,
    [DAR10]     NCHAR (2)     NULL,
    [DAT10]     DATETIME      NULL,
    [DAR11]     NCHAR (2)     NULL,
    [DAT11]     DATETIME      NULL,
    [DAR12]     NCHAR (2)     NULL,
    [DAT12]     DATETIME      NULL,
    [TIMESTAMP] DATETIME      NULL,
    CONSTRAINT [PK_SAP_PA0041_Receiver] PRIMARY KEY CLUSTERED ([PERNR] ASC, [SUBTY] ASC, [BEGDA] ASC, [SEQNR] ASC)
);


GO

