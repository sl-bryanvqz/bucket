CREATE TABLE [SAP_dbo].[ZPRS_HD_MAT_CLNT_MAP] (
    [ID]            INT           NULL,
    [SIC_CODE]      NVARCHAR (10) NULL,
    [MATTER_HD]     NVARCHAR (10) NULL,
    [MATTER_IND]    NVARCHAR (10) NULL,
    [MATTER_SUBIND] NVARCHAR (10) NULL,
    [TIMESTAMP]     DATETIME      DEFAULT (getutcdate()) NULL
);


GO

