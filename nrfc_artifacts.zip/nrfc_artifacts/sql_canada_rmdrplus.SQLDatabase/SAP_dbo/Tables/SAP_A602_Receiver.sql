CREATE TABLE [SAP_dbo].[SAP_A602_Receiver] (
    [KSCHL]     NCHAR (4)       NOT NULL,
    [PERNR]     NVARCHAR (8)    NOT NULL,
    [KFRST]     NCHAR (1)       NOT NULL,
    [DATBI]     DATETIME        NOT NULL,
    [DATAB]     DATETIME        NULL,
    [KBETR]     DECIMAL (11, 2) NULL,
    [KONWA]     NVARCHAR (5)    NULL,
    [TIMESTAMP] DATETIME        NULL,
    [LOEVM_KO]  NCHAR (1)       NULL,
    CONSTRAINT [PK_SAP_A602_1] PRIMARY KEY CLUSTERED ([KSCHL] ASC, [PERNR] ASC, [KFRST] ASC, [DATBI] ASC)
);


GO

