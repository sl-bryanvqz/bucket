CREATE TABLE [SAP_dbo].[SAP_PA9007_Receiver] (
    [PERNR]     NVARCHAR (8)  NOT NULL,
    [SUBTY]     NVARCHAR (4)  NOT NULL,
    [BEGDA]     DATETIME      NOT NULL,
    [SEQNR]     NVARCHAR (3)  NOT NULL,
    [ENDDA]     DATETIME      NOT NULL,
    [AEDTM]     DATETIME      NULL,
    [UNAME]     NVARCHAR (12) NULL,
    [ZZBGRP]    NCHAR (2)     NULL,
    [ZZBLVL]    NCHAR (2)     NULL,
    [ZZJOBT]    NVARCHAR (8)  NULL,
    [ZZGLBR]    NCHAR (1)     NULL,
    [ZZTOM]     NCHAR (2)     NULL,
    [TIMESTAMP] DATETIME      NULL,
    [ZZYOE]     NCHAR (4)     NULL,
    CONSTRAINT [PK_SAP_PA9007_Receiver] PRIMARY KEY CLUSTERED ([PERNR] ASC, [SUBTY] ASC, [BEGDA] ASC, [SEQNR] ASC)
);


GO

