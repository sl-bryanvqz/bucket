CREATE TABLE [SAP_dbo].[T542A] (
    [Work_Contract] VARCHAR (100) NULL,
    [Contract_Name] VARCHAR (100) NULL
);


GO

