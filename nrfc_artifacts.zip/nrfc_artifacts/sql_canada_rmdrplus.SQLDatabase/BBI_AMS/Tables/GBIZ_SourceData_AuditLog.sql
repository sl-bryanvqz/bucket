CREATE TABLE [BBI_AMS].[GBIZ_SourceData_AuditLog] (
    [RowID]        INT           IDENTITY (1, 1) NOT NULL,
    [LastUpdateDT] DATETIME      DEFAULT (getdate()) NULL,
    [TableSchema]  VARCHAR (50)  NULL,
    [TableName]    VARCHAR (50)  NULL,
    [MinRows]      INT           NULL,
    [MaxRows]      INT           NULL,
    [Status]       VARCHAR (50)  DEFAULT ('Active') NULL,
    [LoadMethod]   VARCHAR (255) NULL,
    [Domain]       VARCHAR (255) NULL
);


GO

