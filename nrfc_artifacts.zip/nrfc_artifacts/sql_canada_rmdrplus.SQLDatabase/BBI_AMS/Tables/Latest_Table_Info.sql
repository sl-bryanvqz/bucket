CREATE TABLE [BBI_AMS].[Latest_Table_Info] (
    [name]         VARCHAR (100) NULL,
    [rows]         BIGINT        NULL,
    [reserved]     VARCHAR (20)  NULL,
    [data]         VARCHAR (20)  NULL,
    [index_size]   VARCHAR (20)  NULL,
    [unused]       VARCHAR (20)  NULL,
    [LastUpdateDT] DATETIME      NULL
);


GO

