CREATE TABLE [RMDR_dbo].[SAP_LFB1] (
    [LIFNR]     NVARCHAR (10) NOT NULL,
    [BUKRS]     NCHAR (4)     NOT NULL,
    [REPRF]     NCHAR (1)     NULL,
    [ZWELS]     NVARCHAR (10) NULL,
    [ZAHLS]     NVARCHAR (1)  NULL,
    [HBKID]     NVARCHAR (5)  NULL,
    [XPORE]     NCHAR (1)     NULL,
    [MINDK]     NVARCHAR (3)  NULL,
    [QSBGR]     NCHAR (1)     NULL,
    [QLAND]     NVARCHAR (3)  NULL,
    [CERDT]     DATETIME      NULL,
    [SPERR]     NCHAR (1)     NULL,
    [TIMESTAMP] DATETIME      NULL,
    CONSTRAINT [PK_SAP_LFB1] PRIMARY KEY CLUSTERED ([LIFNR] ASC, [BUKRS] ASC)
);


GO

