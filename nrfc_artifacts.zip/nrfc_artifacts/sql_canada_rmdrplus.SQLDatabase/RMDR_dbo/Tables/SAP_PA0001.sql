CREATE TABLE [RMDR_dbo].[SAP_PA0001] (
    [PERNR]     NVARCHAR (8)  NOT NULL,
    [SUBTY]     NVARCHAR (4)  NOT NULL,
    [BEGDA]     DATETIME      NOT NULL,
    [SEQNR]     NVARCHAR (3)  NOT NULL,
    [ENDDA]     DATETIME      NULL,
    [AEDTM]     DATETIME      NULL,
    [UNAME]     NVARCHAR (12) NULL,
    [WERKS]     NCHAR (4)     NULL,
    [KOSTL]     NVARCHAR (10) NULL,
    [BTRTL]     NCHAR (4)     NULL,
    [PERSK]     NCHAR (2)     NULL,
    [PTEXT]     NVARCHAR (20) NULL,
    [BUKRS]     NCHAR (4)     NULL,
    [ZZREG]     NVARCHAR (3)  NULL,
    [ENAME]     NVARCHAR (40) NULL,
    [PERSG]     NCHAR (1)     NULL,
    [ZZTEAM]    NVARCHAR (4)  NULL,
    [ZZPGP]     NCHAR (2)     NULL,
    [ANSVH]     NCHAR (2)     NULL,
    [TIMESTAMP] DATETIME      NULL,
    [MSTBR]     NVARCHAR (8)  NULL,
    CONSTRAINT [PK_SAP_PA0001] PRIMARY KEY CLUSTERED ([PERNR] ASC, [SUBTY] ASC, [BEGDA] ASC, [SEQNR] ASC)
);


GO

