CREATE TABLE [RMDR_dbo].[SAP_ZPRS_TKALOCCLNT] (
    [KUNNR]              NVARCHAR (10)   NOT NULL,
    [PARVW]              NCHAR (2)       NOT NULL,
    [BEGDA]              DATETIME        NOT NULL,
    [ENDDA]              DATETIME        NOT NULL,
    [PERNR]              NVARCHAR (8)    NOT NULL,
    [GUID]               NVARCHAR (32)   NOT NULL,
    [ZZALLOCPERCENT]     DECIMAL (13, 3) NULL,
    [ZZCTSTAMP]          DATETIME        NULL,
    [ERNAM]              NVARCHAR (12)   NULL,
    [ZZCHTSTAMP]         DATETIME        NULL,
    [AENAM]              NVARCHAR (12)   NULL,
    [DELETION_INDICATOR] NCHAR (1)       NULL,
    [TIMESTAMP]          DATETIME        NULL,
    CONSTRAINT [PK_SAP_ZPRS_TKALOCCLNT] PRIMARY KEY CLUSTERED ([KUNNR] ASC, [PARVW] ASC, [BEGDA] ASC, [ENDDA] ASC, [PERNR] ASC, [GUID] ASC)
);


GO

