CREATE TABLE [RMDR_dbo].[SAP_Office_Corr] (
    [WERKS]        NCHAR (4)     NOT NULL,
    [BTEXT]        NVARCHAR (30) NULL,
    [CUSTOM_ALIAS] NVARCHAR (32) NULL
);


GO

