CREATE TABLE [RMDR_dbo].[SAP_ZPRS_TKALOCMATTR] (
    [PSPID]              NVARCHAR (24)   NOT NULL,
    [PARVW]              NCHAR (2)       NOT NULL,
    [BEGDA]              DATETIME        NOT NULL,
    [ENDDA]              DATETIME        NOT NULL,
    [WERKS]              NCHAR (4)       NOT NULL,
    [ZZTEAM]             NCHAR (4)       NOT NULL,
    [PERNR]              NVARCHAR (8)    NOT NULL,
    [GUID]               NVARCHAR (32)   NOT NULL,
    [PERNR_ASSOC]        NVARCHAR (8)    NULL,
    [ZZALLOCPERCET]      DECIMAL (13, 3) NULL,
    [ZZCTSTAMP]          DATETIME        NULL,
    [ERNAM]              NVARCHAR (12)   NULL,
    [ZZCHTSTAMP]         DATETIME        NULL,
    [AENAM]              NVARCHAR (12)   NULL,
    [DELETION_INDICATOR] NCHAR (1)       NULL,
    [TIMESTAMP]          DATETIME        NULL,
    CONSTRAINT [PK_SAP_ZPRS_TKALOCMATTR] PRIMARY KEY CLUSTERED ([PSPID] ASC, [PARVW] ASC, [BEGDA] ASC, [ENDDA] ASC, [WERKS] ASC, [ZZTEAM] ASC, [PERNR] ASC, [GUID] ASC)
);


GO

