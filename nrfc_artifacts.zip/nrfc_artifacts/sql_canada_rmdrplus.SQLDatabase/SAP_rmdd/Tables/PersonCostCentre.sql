CREATE TABLE [SAP_rmdd].[PersonCostCentre] (
    [PersonCostCentreID] INT      IDENTITY (19, 10) NOT FOR REPLICATION NOT NULL,
    [PersonID]           INT      NOT NULL,
    [StartDate]          DATETIME NOT NULL,
    [EndDate]            DATETIME NULL,
    [LastUpdatedDateGMT] DATETIME NULL,
    [CostCentreID]       INT      NULL,
    CONSTRAINT [PK_PersonCostCentre] PRIMARY KEY CLUSTERED ([PersonCostCentreID] ASC)
);


GO

