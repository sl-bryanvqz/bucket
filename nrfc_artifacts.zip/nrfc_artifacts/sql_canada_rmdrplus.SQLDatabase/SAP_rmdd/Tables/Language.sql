CREATE TABLE [SAP_rmdd].[Language] (
    [LanguageID]         INT            IDENTITY (1, 1) NOT FOR REPLICATION NOT NULL,
    [LanguageISOCode]    NVARCHAR (10)  NOT NULL,
    [LanguageName]       NVARCHAR (100) NULL,
    [Active]             BIT            CONSTRAINT [DF_Languages_Active] DEFAULT ((1)) NOT NULL,
    [LastUpdatedDateGMT] DATETIME       NOT NULL,
    [LastUpdatedBy]      NVARCHAR (50)  NOT NULL,
    CONSTRAINT [PK_Language] PRIMARY KEY CLUSTERED ([LanguageID] ASC)
);


GO

