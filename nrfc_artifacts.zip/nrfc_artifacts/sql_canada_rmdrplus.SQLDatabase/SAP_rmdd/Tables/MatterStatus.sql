CREATE TABLE [SAP_rmdd].[MatterStatus] (
    [MatterStatusID]     INT            IDENTITY (19, 10) NOT FOR REPLICATION NOT NULL,
    [MemberFirmCode]     NVARCHAR (5)   NOT NULL,
    [PMSStatusCode]      NVARCHAR (50)  NOT NULL,
    [MatterStatus]       NVARCHAR (100) NOT NULL,
    [Active]             BIT            CONSTRAINT [DF_MatterStatus_Active] DEFAULT ((1)) NOT NULL,
    [LastUpdatedDateGMT] DATETIME       NOT NULL,
    [LastUpdatedBy]      NVARCHAR (30)  NOT NULL,
    [SAPCode]            CHAR (4)       NULL,
    CONSTRAINT [PK_MatterStatus] PRIMARY KEY CLUSTERED ([MatterStatusID] ASC)
);


GO

