CREATE TABLE [SAP_rmdd].[Address] (
    [AddressID]          INT           IDENTITY (19, 10) NOT FOR REPLICATION NOT NULL,
    [EntityID]           INT           NOT NULL,
    [EntityTypeCode]     NVARCHAR (50) NOT NULL,
    [AddressTypeCode]    NVARCHAR (10) NULL,
    [Address1]           NVARCHAR (60) NULL,
    [Address2]           NVARCHAR (60) NULL,
    [Address3]           NVARCHAR (60) NULL,
    [Address4]           NVARCHAR (60) NULL,
    [Address5]           NVARCHAR (60) NULL,
    [Address6]           NVARCHAR (60) NULL,
    [City]               NVARCHAR (50) NULL,
    [Country]            NVARCHAR (50) NULL,
    [CountryID]          INT           NULL,
    [State]              NVARCHAR (50) NULL,
    [PostalCode]         NVARCHAR (12) NULL,
    [SourceSystemID]     INT           NULL,
    [Active]             BIT           CONSTRAINT [DF_EMPLAddresses_Active] DEFAULT ((1)) NOT NULL,
    [LastUpdatedDateGMT] DATETIME      NOT NULL,
    [LastUpdatedBy]      NVARCHAR (30) NOT NULL,
    CONSTRAINT [PK_Address] PRIMARY KEY CLUSTERED ([AddressID] ASC)
);


GO

