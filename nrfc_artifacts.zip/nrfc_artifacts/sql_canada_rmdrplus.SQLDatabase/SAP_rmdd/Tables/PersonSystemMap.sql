CREATE TABLE [SAP_rmdd].[PersonSystemMap] (
    [PersonSystemMapID]      INT            NOT NULL,
    [PersonID]               INT            NOT NULL,
    [MemberFirmCode]         NVARCHAR (5)   NULL,
    [DomainName]             NVARCHAR (100) NULL,
    [WindowsLogin]           NVARCHAR (100) NULL,
    [DMSSystemID]            NVARCHAR (100) NULL,
    [DMSDefaultLibrary]      NVARCHAR (100) NULL,
    [RecordsSystemID]        NVARCHAR (100) NULL,
    [FinancialSystemID]      NVARCHAR (100) NULL,
    [PMSSystemID]            NVARCHAR (100) NULL,
    [PMSSystemCode]          NVARCHAR (100) NULL,
    [PMSSystemNameID]        NVARCHAR (50)  NULL,
    [PMSSystemNameCode]      NVARCHAR (50)  NULL,
    [HumanResourcesSystemID] NVARCHAR (100) NULL,
    [OriginalStaffID]        NVARCHAR (100) NULL,
    [LastUpdatedDateGMT]     DATETIME       NOT NULL,
    [LastUpdatedBy]          NVARCHAR (30)  NOT NULL,
    [GPMSExternalPersonID]   NVARCHAR (20)  NULL,
    [GPMSPersonnelNumber]    NVARCHAR (20)  NULL,
    CONSTRAINT [PK_PersonSystemMap] PRIMARY KEY CLUSTERED ([PersonSystemMapID] ASC)
);


GO

