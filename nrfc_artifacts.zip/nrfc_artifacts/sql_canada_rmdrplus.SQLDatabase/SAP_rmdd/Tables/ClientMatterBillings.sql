CREATE TABLE [SAP_rmdd].[ClientMatterBillings] (
    [CMBID]          INT      IDENTITY (19, 10) NOT FOR REPLICATION NOT NULL,
    [ClientID]       INT      NULL,
    [MatterID]       INT      NULL,
    [Currency]       CHAR (3) NULL,
    [BillingType]    INT      NULL,
    [BillingValue]   MONEY    NULL,
    [Last_Tran_Date] DATETIME NULL,
    CONSTRAINT [PK__ClientMa__18DED3ADC1533139] PRIMARY KEY CLUSTERED ([CMBID] ASC),
    CONSTRAINT [FK__ClientMat__Clien__000AF8CF] FOREIGN KEY ([ClientID]) REFERENCES [SAP_rmdd].[Client] ([ClientID]) NOT FOR REPLICATION,
    CONSTRAINT [FK__ClientMat__Matte__00FF1D08] FOREIGN KEY ([MatterID]) REFERENCES [SAP_rmdd].[Matter] ([MatterID]) NOT FOR REPLICATION
);


GO

