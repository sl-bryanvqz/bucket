CREATE TABLE [SAP_rmdd].[OfficeMemberFirm] (
    [ID]                 INT            IDENTITY (1, 1) NOT FOR REPLICATION NOT NULL,
    [OfficeCode]         NCHAR (4)      NOT NULL,
    [OfficeName]         NVARCHAR (40)  NULL,
    [Country]            NVARCHAR (3)   NULL,
    [LegalEntityCode]    NCHAR (4)      NULL,
    [LegalEntityName]    NVARCHAR (120) NULL,
    [MemberFirm]         NVARCHAR (32)  NULL,
    [LastUpdatedDateGMT] DATETIME       NULL,
    [LastUpdatedBy]      NVARCHAR (50)  NOT NULL,
    CONSTRAINT [PK_OfficeMemberFirm] PRIMARY KEY CLUSTERED ([ID] ASC)
);


GO

