CREATE TABLE [SAP_rmdd].[Person] (
    [PersonID]            INT            NOT NULL,
    [MemberFirmCode]      NVARCHAR (5)   NOT NULL,
    [SystemEmployeeCode]  NVARCHAR (50)  NULL,
    [PersonStatusCode]    NVARCHAR (50)  NOT NULL,
    [Gender]              VARCHAR (1)    NULL,
    [Prefix]              NVARCHAR (50)  NULL,
    [FirstName]           NVARCHAR (50)  NOT NULL,
    [FirstNameKnownAs]    NVARCHAR (50)  NULL,
    [MiddleName]          NVARCHAR (50)  NULL,
    [LastName]            NVARCHAR (50)  NOT NULL,
    [Suffix]              NVARCHAR (50)  NULL,
    [Initials]            NVARCHAR (50)  NULL,
    [PhotoPath]           NVARCHAR (500) NULL,
    [ExternalProfileURL]  NVARCHAR (500) NULL,
    [PersonalMatterCode]  NVARCHAR (50)  NULL,
    [CommencementDateGMT] DATETIME       NULL,
    [DepartureDateGMT]    DATETIME       NULL,
    [LeaveStatus]         NVARCHAR (200) NULL,
    [SubTeamID]           INT            NOT NULL,
    [DeleteFlag]          CHAR (1)       NOT NULL,
    [Source]              NVARCHAR (10)  NOT NULL,
    [LastUpdatedDateGMT]  DATETIME       NOT NULL,
    [LastUpdatedBy]       NVARCHAR (30)  NOT NULL,
    [JobTitle]            NVARCHAR (250) NULL,
    [JobTitlePMS]         NVARCHAR (256) NULL,
    [PracticeGroup]       NVARCHAR (2)   NULL,
    CONSTRAINT [PK_Person] PRIMARY KEY CLUSTERED ([PersonID] ASC)
);


GO

