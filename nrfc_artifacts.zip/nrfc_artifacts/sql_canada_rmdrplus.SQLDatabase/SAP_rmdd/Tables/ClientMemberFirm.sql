CREATE TABLE [SAP_rmdd].[ClientMemberFirm] (
    [ClientMemberFirmID] INT           IDENTITY (19, 10) NOT FOR REPLICATION NOT NULL,
    [ClientID]           INT           NULL,
    [MemberFirmCode]     NVARCHAR (5)  NULL,
    [CompanyCode]        NVARCHAR (10) NULL,
    [LastUpdatedDateGMT] DATETIME      NULL,
    [LastUpdatedBy]      NVARCHAR (30) NULL,
    CONSTRAINT [PK_ClientMemberFirm] PRIMARY KEY CLUSTERED ([ClientMemberFirmID] ASC)
);


GO

