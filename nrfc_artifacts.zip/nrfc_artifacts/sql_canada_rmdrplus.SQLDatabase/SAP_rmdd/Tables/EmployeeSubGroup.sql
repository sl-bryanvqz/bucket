CREATE TABLE [SAP_rmdd].[EmployeeSubGroup] (
    [SubGroupID]          INT           IDENTITY (19, 10) NOT FOR REPLICATION NOT NULL,
    [GroupCode]           NCHAR (1)     NULL,
    [GroupDescription]    NVARCHAR (40) NULL,
    [SubGroupCode]        NCHAR (2)     NULL,
    [SubGroupDescription] NVARCHAR (40) NULL,
    [Active]              BIT           DEFAULT ((1)) NULL,
    [LastUpdatedDateGMT]  DATETIME      DEFAULT (getdate()) NULL,
    CONSTRAINT [PK_EmployeeSubGroup] PRIMARY KEY CLUSTERED ([SubGroupID] ASC)
);


GO

