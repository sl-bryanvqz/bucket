CREATE TABLE [SAP_rmdd].[Team] (
    [TeamID]             INT            IDENTITY (19, 10) NOT FOR REPLICATION NOT NULL,
    [GroupID]            INT            NULL,
    [MemberFirmCode]     NVARCHAR (5)   NOT NULL,
    [EntityTypeCode]     NVARCHAR (3)   NOT NULL,
    [TeamCode]           NVARCHAR (50)  NOT NULL,
    [TeamName]           NVARCHAR (100) NOT NULL,
    [OrgCategoryID]      INT            NULL,
    [ManagerID]          INT            NULL,
    [Active]             BIT            NULL,
    [LastUpdatedDateGMT] DATETIME       NOT NULL,
    [LastUpdatedBy]      NVARCHAR (30)  NOT NULL,
    CONSTRAINT [PK_Team] PRIMARY KEY CLUSTERED ([TeamID] ASC)
);


GO

