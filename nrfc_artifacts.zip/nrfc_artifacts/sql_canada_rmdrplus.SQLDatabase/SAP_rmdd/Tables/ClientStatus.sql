CREATE TABLE [SAP_rmdd].[ClientStatus] (
    [ClientStatusID]     INT            IDENTITY (19, 10) NOT FOR REPLICATION NOT NULL,
    [MemberFirmCode]     NVARCHAR (5)   NOT NULL,
    [PMSStatusCode]      NVARCHAR (50)  NOT NULL,
    [ClientStatus]       NVARCHAR (100) NOT NULL,
    [Active]             BIT            CONSTRAINT [DF_clientStatus_Active] DEFAULT ((1)) NOT NULL,
    [LastUpdatedDateGMT] DATETIME       NOT NULL,
    [LastUpdatedBy]      NVARCHAR (30)  NOT NULL,
    [SAPCode]            NVARCHAR (2)   NULL,
    CONSTRAINT [PK_ClientStatus] PRIMARY KEY CLUSTERED ([ClientStatusID] ASC)
);


GO

