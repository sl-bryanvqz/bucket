CREATE TABLE [SAP_rmdd].[ExchangeRates] (
    [RateID]          INT            IDENTITY (1, 1) NOT FOR REPLICATION NOT NULL,
    [RateType]        NCHAR (4)      NULL,
    [FromCurrency]    NCHAR (5)      NULL,
    [ToCurrency]      NCHAR (5)      NULL,
    [RateDate]        DATETIME       NULL,
    [ExchangeRate]    DECIMAL (9, 5) NULL,
    [FromRatio]       DECIMAL (9, 2) NULL,
    [ToRatio]         DECIMAL (9, 2) NULL,
    [LastUpdatedDate] DATETIME       NULL,
    PRIMARY KEY CLUSTERED ([RateID] ASC)
);


GO

