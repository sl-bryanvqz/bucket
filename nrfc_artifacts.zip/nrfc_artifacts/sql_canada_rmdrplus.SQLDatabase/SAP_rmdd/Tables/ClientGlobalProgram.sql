CREATE TABLE [SAP_rmdd].[ClientGlobalProgram] (
    [ClientGlobalProgramID] INT           IDENTITY (19, 10) NOT FOR REPLICATION NOT NULL,
    [ClientID]              INT           NOT NULL,
    [ProgramCode]           NVARCHAR (50) NOT NULL,
    [StartDate]             DATETIME      NOT NULL,
    [EndDate]               DATETIME      NULL,
    [LastUpdatedDateGMT]    DATETIME      NOT NULL,
    CONSTRAINT [PK_ClientGlobalProgram] PRIMARY KEY CLUSTERED ([ClientGlobalProgramID] ASC)
);


GO

