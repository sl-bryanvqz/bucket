CREATE TABLE [SAP_rmdd].[SubTeam] (
    [SubTeamID]          INT            IDENTITY (19, 10) NOT FOR REPLICATION NOT NULL,
    [TeamID]             INT            NOT NULL,
    [MemberFirmCode]     NVARCHAR (5)   NOT NULL,
    [SubTeamCode]        NVARCHAR (50)  NOT NULL,
    [SubTeamName]        NVARCHAR (100) NOT NULL,
    [OrgCategoryID]      INT            NULL,
    [ManagerID]          INT            NULL,
    [Active]             BIT            CONSTRAINT [DF_SubTeam_Active] DEFAULT ((1)) NOT NULL,
    [LastUpdatedDateGMT] DATETIME       NOT NULL,
    [LastUpdatedBy]      NVARCHAR (30)  NOT NULL,
    [SAPCode]            CHAR (4)       NULL,
    CONSTRAINT [PK_SubTeam] PRIMARY KEY CLUSTERED ([SubTeamID] ASC),
    CONSTRAINT [FK_SubTeam_Team] FOREIGN KEY ([TeamID]) REFERENCES [SAP_rmdd].[Team] ([TeamID])
);


GO

