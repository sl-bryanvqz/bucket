CREATE TABLE [SAP_rmdd].[AddressType] (
    [AddressTypeID]      INT            IDENTITY (1, 1) NOT FOR REPLICATION NOT NULL,
    [AddressTypeCode]    NVARCHAR (10)  NOT NULL,
    [AddressTypeName]    NVARCHAR (100) NOT NULL,
    [Active]             BIT            NOT NULL,
    [LastUpdatedDateGMT] DATETIME       NOT NULL,
    [LastUpdatedBy]      NVARCHAR (50)  NOT NULL,
    CONSTRAINT [PK_AddressType] PRIMARY KEY CLUSTERED ([AddressTypeID] ASC),
    CONSTRAINT [IXU_AddressType_AddressTypeCode] UNIQUE NONCLUSTERED ([AddressTypeCode] ASC)
);


GO

