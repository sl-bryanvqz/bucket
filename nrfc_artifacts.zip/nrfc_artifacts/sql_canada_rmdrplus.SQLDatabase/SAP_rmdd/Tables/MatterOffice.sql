CREATE TABLE [SAP_rmdd].[MatterOffice] (
    [MattOfficeID]    INT          IDENTITY (19, 10) NOT FOR REPLICATION NOT NULL,
    [OfficeID]        INT          NULL,
    [MatterStatusID]  INT          NULL,
    [LastUpdatedDate] DATETIME     NULL,
    [CompanyCode]     NVARCHAR (4) NULL,
    [MemberFirmCode]  NVARCHAR (5) NULL,
    [MatterID]        INT          NULL,
    CONSTRAINT [PK__MatterOf__9C04D90B3FAE90F9] PRIMARY KEY CLUSTERED ([MattOfficeID] ASC)
);


GO

