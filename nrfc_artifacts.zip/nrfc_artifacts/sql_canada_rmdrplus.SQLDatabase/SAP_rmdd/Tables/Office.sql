CREATE TABLE [SAP_rmdd].[Office] (
    [OfficeID]              INT            IDENTITY (19, 10) NOT FOR REPLICATION NOT NULL,
    [MemberFirmCode]        NVARCHAR (5)   NOT NULL,
    [EntityCode]            NVARCHAR (3)   NULL,
    [OfficeCode]            NVARCHAR (10)  NULL,
    [OfficeName]            NVARCHAR (100) NOT NULL,
    [Address1]              NVARCHAR (55)  NULL,
    [Address2]              NVARCHAR (55)  NULL,
    [Address3]              NVARCHAR (55)  NULL,
    [Address4]              NVARCHAR (55)  NULL,
    [Address5]              NVARCHAR (55)  NULL,
    [PhoneNumber]           NVARCHAR (50)  NULL,
    [FaxNumber]             NVARCHAR (50)  NULL,
    [EmailSignatureAddress] NVARCHAR (200) NULL,
    [POBox]                 NVARCHAR (50)  NULL,
    [DXNumber]              NVARCHAR (50)  NULL,
    [ExtensionPrefix]       NVARCHAR (50)  NULL,
    [IntranetURL]           NVARCHAR (250) NULL,
    [ChairmanPersonID]      INT            NULL,
    [LanguageID]            INT            NULL,
    [UTCOffset]             VARCHAR (50)   NULL,
    [WebsiteURL]            NVARCHAR (250) NULL,
    [Active]                BIT            CONSTRAINT [DF_Office_Active] DEFAULT ((1)) NOT NULL,
    [LastUpdatedDateGMT]    DATETIME       NOT NULL,
    [LastUpdatedBy]         NVARCHAR (30)  NOT NULL,
    [SAPCode]               NVARCHAR (8)   NULL,
    CONSTRAINT [PK_Office] PRIMARY KEY CLUSTERED ([OfficeID] ASC)
);


GO

