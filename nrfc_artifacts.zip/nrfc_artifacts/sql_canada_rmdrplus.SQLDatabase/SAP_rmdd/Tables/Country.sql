CREATE TABLE [SAP_rmdd].[Country] (
    [CountryID]            INT            IDENTITY (1, 1) NOT FOR REPLICATION NOT NULL,
    [CountryName]          NVARCHAR (100) NOT NULL,
    [CountryNameTitleCase] NVARCHAR (100) NULL,
    [CountryCode]          NVARCHAR (2)   NOT NULL,
    [CountryCodeLong]      NVARCHAR (3)   NULL,
    CONSTRAINT [PK_Countries] PRIMARY KEY CLUSTERED ([CountryID] ASC) WITH (FILLFACTOR = 90)
);


GO

