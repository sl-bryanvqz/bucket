CREATE TABLE [SAP_rmdd].[CostCenter] (
    [CostCenterId]       INT           IDENTITY (19, 10) NOT FOR REPLICATION NOT NULL,
    [ControllingArea]    NCHAR (4)     NOT NULL,
    [CostCenter]         NVARCHAR (10) NOT NULL,
    [ValidToDate]        DATETIME      NOT NULL,
    [ValidFromDate]      DATETIME      NULL,
    [CompanyCode]        NCHAR (4)     NULL,
    [CostCenterCategory] NCHAR (1)     NULL,
    [CurrencyKey]        NVARCHAR (5)  NULL,
    [ProfitCenter]       NVARCHAR (10) NULL,
    [CreatedOn]          DATETIME      NULL,
    [EnteredBy]          NVARCHAR (12) NULL,
    [Description]        NVARCHAR (20) NULL,
    [LongDescription]    NVARCHAR (40) NULL,
    [TIMESTAMP]          DATETIME      NULL,
    CONSTRAINT [PK_CostCenter] PRIMARY KEY CLUSTERED ([CostCenterId] ASC)
);


GO

