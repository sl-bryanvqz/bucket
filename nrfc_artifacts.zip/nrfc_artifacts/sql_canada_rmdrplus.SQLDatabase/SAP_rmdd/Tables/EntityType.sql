CREATE TABLE [SAP_rmdd].[EntityType] (
    [EntityTypeID]    INT            IDENTITY (1, 1) NOT FOR REPLICATION NOT NULL,
    [EntityTypeCode]  NVARCHAR (3)   NOT NULL,
    [EntityTypeName]  NVARCHAR (100) NOT NULL,
    [EntityTableName] NVARCHAR (50)  NULL,
    [SAPCode]         NVARCHAR (2)   NULL,
    CONSTRAINT [PK_EntityType] PRIMARY KEY CLUSTERED ([EntityTypeID] ASC),
    CONSTRAINT [IXU_EntityType_TypeCode_Unique] UNIQUE NONCLUSTERED ([EntityTypeCode] ASC)
);


GO

