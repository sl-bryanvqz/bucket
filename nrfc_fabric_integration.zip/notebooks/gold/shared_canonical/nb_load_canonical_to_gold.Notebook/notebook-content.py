# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "known_warehouses": []
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Define notebook Parameters
# 
# Pass through th pl_worker

# CELL ********************

# Framework-compatible parameters with manual fallbacks
import json
import uuid

# Basic notebook runtime values
task_id = 50
task_name = "Load canonical to gold"
lineage_id = str(uuid.uuid4())
limit_rows_for_debugging = True
prev_wm = "1900-01-01 00:00:00"
curr_wm = "2026-06-30 00:00:00"
execution_errors = []

# Source settings > what data to read
source_settings = json.dumps(
    {
        "source_name": "CAN_RMDD",
        "source_type": "sql_database",
        "source_location": "CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e",
        "source_schema": "canonical_data_model",
        "table_config": [
            {
                "source_table": "address",
                "target_table": "gold_master_address",
                "target_pk": ["address_id"]
            },
            {
                "source_table": "client",
                "target_table": "gold_master_client",
                "target_pk": ["client_id"]
            },
            {
                "source_table": "client_partner_allocation",
                "target_table": "gold_master_client_partner_allocation",
                "target_pk": ["client_partner_allocation_key"]
            },
            {
                "source_table": "cost_centre",
                "target_table": "gold_master_cost_centre",
                "target_pk": ["cost_centre_key"]
            },
            {
                "source_table": "matter",
                "target_table": "gold_master_matter",
                "target_pk": ["matter_key"]
            },
            {
                "source_table": "matter_partner_allocation",
                "target_table": "gold_master_matter_partner_allocation",
                "target_pk": ["matter_partner_allocation_key"]
            },
            {
                "source_table": "matter_relationship",
                "target_table": "gold_master_matter_relationship",
                "target_pk": ["matter_relationship_key"]
            },
            {
                "source_table": "person",
                "target_table": "gold_master_person",
                "target_pk": ["person_key"]
            }
        ]
    }
)

# Target settings > here/how to write
target_settings = json.dumps(
    {
        "target_workspace": "ws_canada_global_mds_dev",
        "target_lakehouse": "lh_canada_global_mds",
        "target_schema": "gold_master",
        "target_location": "Files/gold/master",
        "target_load_strategy": "overwrite"
    }
)

# Connection settings > how to connect/authenticate
source_connection_settings = json.dumps(
    {
        "server_name": "hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com"
    }
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
