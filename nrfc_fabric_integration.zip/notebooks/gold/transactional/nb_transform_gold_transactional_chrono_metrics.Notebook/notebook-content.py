# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    target_workspace          = "ws_canada_global_mds_dev"
    target_lakehouse          = "lh_canada_global_mds"
    target_table              = "gold_transactional_chrono_metrics"
    map_view                  = f"map_{target_table}"
    target_pk                 = ["chronometrics_key"]
    limit_rows_for_debugging  = True
    watermark_filter          = "1=1"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"map_view: {map_view}")
    print(f"target_workspace: {target_workspace}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT DISTINCT
    CAST(row_number() OVER (ORDER BY s.timecard_id, s.timekeeper_id) AS BIGINT)     AS chronometrics_key,
    s.timecard_id                                                                   AS timecard_id,
    s.client_code                                                                   AS client_number,
    s.client_code                                                                   AS client_key,
    s.matter_code                                                                   AS matter_number,

    -- Canada Chrono Metrics file must use CANADA
    CAST('CANADA' AS STRING)                                                        AS member_firm_code,

    s.matter_code                                                                   AS matter_key,
    s.group_matter_code                                                             AS group_matter_number,
    s.group_matter_region_src                                                       AS group_matter_member_firm_code,
    s.group_matter_code                                                             AS group_matter_key,
    s.matter_company_code                                                           AS matter_company_key,
    s.matter_billable_type_code                                                     AS matter_billable_type_code,
    s.matter_currency_code                                                          AS matter_currency_code,
    s.timekeeper_id                                                                 AS timekeeper_id,
    s.fe_region_src_tran                                                            AS timekeeper_member_firm_code,
    s.timekeeper_id                                                                 AS fe_person_key,
    s.fe_company_code                                                               AS fe_company_key,
    s.fe_office_code                                                                AS fe_office_key,
    s.fe_practice_group_code                                                        AS fe_practice_group_key,
    s.fe_team_code                                                                  AS fe_team_key,
    s.fe_company_code_tran                                                          AS fe_company_tran_key,
    s.fe_office_code_tran                                                           AS fe_office_tran_key,
    s.fe_practice_group_code_tran                                                   AS fe_practice_group_tran_key,
    s.fe_group_code                                                                 AS fe_team_tran_key,
    s.fe_sub_group_code                                                             AS fe_employee_sub_group_key,
    s.fe_band_level_code                                                            AS fe_band_level_key,
    s.timecard_worked_date                                                          AS timecard_worked_date,
    s.timecard_worked_cal_period                                                    AS timecard_worked_cal_period,
    s.timecard_post_date                                                            AS timecard_post_date,
    s.timecard_post_cal_period                                                      AS timecard_post_cal_period,
    s.confidential_flag                                                             AS confidential_flag,
    s.pricing_unit                                                                  AS pricing_unit,
    CAST(NULLIF(TRIM(s.hours_worked), '') AS DOUBLE)                                AS hours_worked,
    s.timecard_narrative                                                            AS timecard_narrative,
    CAST(NULLIF(TRIM(s.worked_standard_rate_dc), '') AS DOUBLE)                     AS worked_standard_rate_dc,
    CAST(NULLIF(TRIM(s.fees_worked_at_standard_dc), '') AS DOUBLE)                  AS fees_worked_at_standard_dc,
    CAST(NULLIF(TRIM(s.worked_agreed_rate_dc), '') AS DOUBLE)                       AS worked_agreed_rate_dc,
    CAST(NULLIF(TRIM(s.fees_worked_at_agreed_dc), '') AS DOUBLE)                    AS fees_worked_at_agreed_dc,
    CAST(NULLIF(TRIM(s.matter_discount_dc), '') AS DOUBLE)                          AS matter_discount_dc,
    CAST(NULLIF(TRIM(s.wip_hours_write_up_down_value_dc), '') AS DOUBLE)            AS wip_hours_write_up_down_value_dc,
    CAST(NULLIF(TRIM(s.fees_worked_at_agreed_net_dc), '') AS DOUBLE)                AS fees_worked_at_agreed_net_dc,
    CAST(NULLIF(TRIM(s.fees_billed_at_standard_dc), '') AS DOUBLE)                  AS fees_billed_at_standard_dc,
    CAST(NULLIF(TRIM(s.fees_billed_at_agreed_dc), '') AS DOUBLE)                    AS fees_billed_at_agreed_dc,
    CAST(NULLIF(TRIM(s.matter_discount_billed_dc), '') AS DOUBLE)                   AS matter_discount_billed_dc,
    CAST(NULLIF(TRIM(s.fees_billed_at_agreed_net_dc), '') AS DOUBLE)                AS fees_billed_at_agreed_net_dc,
    CAST(NULLIF(TRIM(s.fees_write_up_down_dc), '') AS DOUBLE)                       AS fees_write_up_down_dc,
    CAST(NULLIF(TRIM(s.hours_write_up_down_value_dc), '') AS DOUBLE)                AS hours_write_up_down_value_dc,
    CAST(NULLIF(TRIM(s.worked_fees_billed_net_dc), '') AS DOUBLE)                   AS worked_fees_billed_net_dc,
    s.bill_num                                                                      AS bill_num,
    s.cancel_bill_num                                                               AS cancel_bill_num,
    s.bill_type                                                                     AS bill_type_key,
    s.bill_date                                                                     AS bill_date,
    s.bill_cal_period                                                               AS bill_cal_period,
    s.bill_currency_code                                                            AS bill_currency_code,
    CAST(NULLIF(TRIM(s.hours_billed), '') AS DOUBLE)                                AS hours_billed,
    CAST(NULLIF(TRIM(s.fees_billed_dc), '') AS DOUBLE)                              AS fees_billed_dc,
    CAST(NULLIF(TRIM(s.bad_debt_wo_dc), '') AS DOUBLE)                              AS bad_debt_wo_dc,
    s.final_bill_num                                                                AS final_bill_num,
    s.final_bill_flag                                                               AS final_bill_flag,
    s.material_group                                                                AS entry_classification_key,
    s.collected_cal_period                                                          AS collected_cal_period,
    s.collected_date                                                                AS collected_date,
    CAST(NULLIF(TRIM(s.hours_collected), '') AS DOUBLE)                             AS hours_collected,
    CAST(NULLIF(TRIM(s.fees_collected_dc), '') AS DOUBLE)                           AS fees_collected_dc,
    s.phase_set_code                                                                AS phase_set_code,
    s.phase_set_desc                                                                AS phase_set_description,
    s.phase_code                                                                    AS phase_code,
    s.phase_desc                                                                    AS phase_description,
    s.task_code                                                                     AS task_code,
    s.task_desc                                                                     AS task_description,
    s.activity_code                                                                 AS activity_code,
    s.activity_desc                                                                 AS activity_description,
    s.fixed_fee_activity_code                                                       AS fixed_fee_activity_code,
    s.fixed_fee_activity_desc                                                       AS fixed_fee_activity_description,
    COALESCE(
        TO_TIMESTAMP(s.last_update_dt, 'dd/MM/yyyy'),
        TIMESTAMP '1900-01-01 00:00:00'
    )                                                                               AS last_updated_date_utc_at_source
    
FROM {target_workspace}.{target_lakehouse}.silver_transactional.silver_transactional_chrono_metrics s
WHERE {watermark_filter}
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
