# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Define schema tables
# 
# Define the definition schema for each table, run schema if not exists

# CELL ********************

schema_name = "gold_transactional"
location_path = "Files/transactional"

tbl_properties = """
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite'     = 'true',
    'delta.autoOptimize.autoCompact'       = 'true',
    'delta.logRetentionDuration'           = 'interval 30 days',
    'delta.deletedFileRetentionDuration'   = 'interval 7 days')
"""

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tables_definition = [
    {
        "table_name": "gold_transactional_chrono_metrics",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            chronometrics_key                  BIGINT,
            timecard_id                        STRING,
            client_number                      STRING,
            client_key                         STRING,
            matter_number                      STRING,
            member_firm_code                   STRING,
            matter_key                         STRING,
            group_matter_number                STRING,
            group_matter_member_firm_code      STRING,
            group_matter_key                   STRING,
            matter_company_key                 STRING,
            matter_billable_type_code          STRING,
            matter_currency_code               STRING,
            timekeeper_id                      STRING,
            timekeeper_member_firm_code        STRING,
            fe_person_key                      STRING,
            fe_company_key                     STRING,
            fe_office_key                      STRING,
            fe_practice_group_key              STRING,
            fe_team_key                        STRING,
            fe_company_tran_key                STRING,
            fe_office_tran_key                 STRING,
            fe_practice_group_tran_key         STRING,
            fe_team_tran_key                   STRING,
            fe_employee_sub_group_key          STRING,
            fe_band_level_key                  STRING,
            timecard_worked_date               STRING,
            timecard_worked_cal_period         STRING,
            timecard_post_date                 STRING,
            timecard_post_cal_period           STRING,
            confidential_flag                  STRING,
            pricing_unit                       STRING,
            hours_worked                       DOUBLE,
            timecard_narrative                 STRING,
            worked_standard_rate_dc            DOUBLE,
            fees_worked_at_standard_dc         DOUBLE,
            worked_agreed_rate_dc              DOUBLE,
            fees_worked_at_agreed_dc           DOUBLE,
            matter_discount_dc                 DOUBLE,
            wip_hours_write_up_down_value_dc   DOUBLE,
            fees_worked_at_agreed_net_dc       DOUBLE,
            fees_billed_at_standard_dc         DOUBLE,
            fees_billed_at_agreed_dc           DOUBLE,
            matter_discount_billed_dc          DOUBLE,
            fees_billed_at_agreed_net_dc       DOUBLE,
            fees_write_up_down_dc              DOUBLE,
            hours_write_up_down_value_dc       DOUBLE,
            worked_fees_billed_net_dc          DOUBLE,
            bill_num                           STRING,
            cancel_bill_num                    STRING,
            bill_type_key                      STRING,
            bill_date                          STRING,
            bill_cal_period                    STRING,
            bill_currency_code                 STRING,
            hours_billed                       DOUBLE,
            fees_billed_dc                     DOUBLE,
            bad_debt_wo_dc                     DOUBLE,
            final_bill_num                     STRING,
            final_bill_flag                    STRING,
            entry_classification_key           STRING,
            collected_cal_period               STRING,
            collected_date                     STRING,
            hours_collected                    DOUBLE,
            fees_collected_dc                  DOUBLE,
            phase_set_code                     STRING,
            phase_set_description              STRING,
            phase_code                         STRING,
            phase_description                  STRING,
            task_code                          STRING,
            task_description                   STRING,
            activity_code                      STRING,
            activity_description               STRING,
            fixed_fee_activity_code            STRING,
            fixed_fee_activity_description     STRING,
            last_updated_date_utc_at_source    TIMESTAMP,

        -- metadata
            _hashed_pk                         STRING,
            _hashed_row                        STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                     STRING,
            _source_table                      STRING,
            _target_table                      STRING,
            _lineage_id                        STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "gold_transactional_efi",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            efi_key                             BIGINT,
            unit                                STRING,
            company_key                         STRING,
            member_firm_code                    STRING,
            profit_center_code                  STRING,
            cost_center_code                    STRING,
            gl_account_code                     STRING,
            fe_person_number                    STRING,
            fe_practice_group_key               STRING,
            fe_office_key                       STRING,
            fe_team_key                         STRING,
            lead_partner_person_number          STRING,
            lead_partner_practice_group_key     STRING,
            lead_partner_office_key             STRING,
            lead_partner_team_key               STRING,
            matter_number                       STRING,
            vendor_code                         STRING,
            document_text                       STRING,
            document_date                       DATE,
            document_number                     STRING,
            transaction_document_type_key       STRING,
            posting_period                      STRING,
            posting_date                        DATE,
            document_currency_code              STRING,
            actual_amount_dc                    DOUBLE,
            office_currency_code                STRING,
            actual_amount_oc                    DOUBLE,
            group_currency_code                 STRING,
            actual_amount_gc                    DOUBLE,
            budget_amount_gc                    DOUBLE,
            forecast_amount_gc                  DOUBLE,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "gold_transactional_tme",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            tme_key                             BIGINT,
            calendar_day                        DATE,
            timekeeper_id                       STRING,
            member_firm_code                    STRING,
            person_number                       STRING,
            gender                              STRING,
            practice_group_key                  STRING,
            office_key                          STRING,
            team_key                            STRING,
            employee_sub_group_key              STRING,
            band_level_key                      STRING,
            fte                                 DOUBLE,
            employment_status_code              STRING,
            employment_status_description       STRING,
            workday_flag                        STRING,
            weekend_flag                        STRING,
            holiday_flag                        STRING,
            target_hours                        DOUBLE,
            billable_hours                      DOUBLE,
            non_billable_hours                  DOUBLE,
            pro_bono_hours                      DOUBLE,
            firm_related_hours                  DOUBLE,
            leave_hours                         DOUBLE,
            part_time_hours                     DOUBLE,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "gold_transactional_client_financials",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            client_financials_key               BIGINT,
            client_number                       STRING,
            member_firm_code                    STRING,
            total_wip                           DOUBLE,
            last_wip_date                       TIMESTAMP,
            total_ar                            DOUBLE,
            last_bill_date                      TIMESTAMP,
            trust_funds_balance                 DOUBLE,
            unallocated_funds_balance           DOUBLE,
            retainer_funds_balance              DOUBLE,
            client_currency_code                STRING,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "gold_transactional_matter_financials",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            matter_financials_key               BIGINT,
            matter_number                       STRING,
            member_firm_code                    STRING,
            client_number                       STRING,
            total_wip                           DOUBLE,
            last_wip_date                       TIMESTAMP,
            total_ar                            DOUBLE,
            total_fees_billed                   DOUBLE,
            last_bill_date                      TIMESTAMP,
            trust_funds_balance                 DOUBLE,
            unallocated_funds_balance           DOUBLE,
            retainer_funds_balance              DOUBLE,
            matter_currency_code                STRING,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    }
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Create all tables
# 
# Run sql_statement from table_name on config

# CELL ********************

for t in tables_definition:
    table_name = t["table_name"]

    sql = t["sql_statement"].format(
        schema_name=schema_name,
        table_name=table_name,
        location_path=location_path,
        tbl_properties=tbl_properties
    )
    
    print(f"Creating {schema_name}.{table_name}")
    spark.sql(sql)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
