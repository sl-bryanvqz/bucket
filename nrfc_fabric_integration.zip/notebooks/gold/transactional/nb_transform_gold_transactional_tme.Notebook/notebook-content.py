# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    target_workspace          = "ws_canada_global_mds_dev"
    target_lakehouse          = "lh_canada_global_mds"
    target_table              = "gold_transactional_tme"
    map_view                  = f"map_{target_table}"
    target_pk                 = ["tme_key"]
    limit_rows_for_debugging  = True
    watermark_filter          = "1=1"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"map_view: {map_view}")
    print(f"target_workspace: {target_workspace}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT DISTINCT
    CAST(row_number() OVER (ORDER BY s.timekeeper_id) AS BIGINT)             AS tme_key,

    COALESCE(
        TO_DATE(s.calendar_day, 'dd/MM/yyyy'),
        TO_DATE(s.calendar_day),
        DATE '1900-01-01'
    )                                                                        AS calendar_day,

    s.timekeeper_id                                                          AS timekeeper_id,

    -- Canada TME file must use CANADA
    CAST('CANADA' AS STRING)                                                 AS member_firm_code,

    s.timekeeper_id                                                          AS person_number,
    s.gender                                                                 AS gender,
    s.practice_group_code                                                    AS practice_group_key,
    s.office_code                                                            AS office_key,
    s.team_code                                                              AS team_key,
    s.emp_sub_group_code                                                     AS employee_sub_group_key,
    s.band_level_code                                                        AS band_level_key,
    TRY_CAST(NULLIF(TRIM(s.fte), '') AS DOUBLE)                              AS fte,
    s.employment_status_code                                                 AS employment_status_code,
    s.employment_status_desc                                                 AS employment_status_description,
    s.workday_flag                                                           AS workday_flag,
    s.weekend_flag                                                           AS weekend_flag,
    s.holiday_flag                                                           AS holiday_flag,
    TRY_CAST(NULLIF(TRIM(s.target_hours), '') AS DOUBLE)                     AS target_hours,
    TRY_CAST(NULLIF(TRIM(s.billable_hours), '') AS DOUBLE)                   AS billable_hours,
    TRY_CAST(NULLIF(TRIM(s.non_billable_hours), '') AS DOUBLE)               AS non_billable_hours,
    TRY_CAST(NULLIF(TRIM(s.pro_bono_hours), '') AS DOUBLE)                   AS pro_bono_hours,
    TRY_CAST(NULLIF(TRIM(s.firm_related_hours), '') AS DOUBLE)               AS firm_related_hours,
    TRY_CAST(NULLIF(TRIM(s.leave_hours), '') AS DOUBLE)                      AS leave_hours,
    TRY_CAST(NULLIF(TRIM(s.part_time_hours), '') AS DOUBLE)                  AS part_time_hours,

    COALESCE(
        TO_TIMESTAMP(s.last_update_dt, 'dd/MM/yyyy'),
        TO_TIMESTAMP(s.last_update_dt),
        TIMESTAMP '1900-01-01 00:00:00'
    )                                                                        AS last_updated_date_utc_at_source

FROM {target_workspace}.{target_lakehouse}.silver_transactional.silver_transactional_tme s
WHERE {watermark_filter}
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
