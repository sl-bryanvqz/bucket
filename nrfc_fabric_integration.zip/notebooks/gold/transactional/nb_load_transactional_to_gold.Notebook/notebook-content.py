# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Define notebook Parameters
# 
# Pass through th pl_worker

# CELL ********************

# Framework-compatible parameters with manual fallbacks
import json
import uuid

# Basic notebook runtime values
task_id = 50
task_name = "Load transactional to gold"
lineage_id = str(uuid.uuid4())
limit_rows_for_debugging = False
prev_wm = "1900-01-01 00:00:00"
curr_wm = "2027-08-30 00:00:00"
execution_errors = []

# Source settings > what data to read
source_settings = json.dumps(
    {
        "source_name": "silver_transactional",
        "source_type": "lakehouse",
        "source_location": "lh_canada_global_mds",
        "source_schema": "silver_transactional",
        "table_config": [
            # {
            #     "target_table": "gold_transactional_chrono_metrics",
            #     "target_pk": ["chronometrics_key"],
            #     "is_incremental": 0,
            #     "incremental_column": "last_updated_date_utc_at_source",
            #     "transformation_notebook": "nb_transform_gold_transactional_chrono_metrics"
            # },
            {
                "target_table": "gold_transactional_client_financials",
                "target_pk": ["client_number", "member_firm_code"],
                "is_incremental": 1,
                "incremental_column": "last_updated_date_utc_at_source",
                "transformation_notebook": "nb_transform_gold_transactional_client_financials"
            },
            # {
            #     "target_table": "gold_transactional_efi",
            #     "target_pk": ["efi_key"],
            #     "is_incremental": 0,
            #     "incremental_column": "last_update_dt",
            #     "transformation_notebook": "nb_transform_gold_transactional_efi"
            # },
            {
                "target_table": "gold_transactional_matter_financials",
                "target_pk": ["matter_number", "member_firm_code"],
                "is_incremental": 1,
                "incremental_column": "last_updated_date_utc_at_source",
                "transformation_notebook": "nb_transform_gold_transactional_matter_financials"
            # },
            # {
            #     "target_table": "gold_transactional_tme",
            #     "target_pk": ["tme_key"],
            #     "is_incremental": 0,
            #     "incremental_column": "last_update_dt",
            #     "transformation_notebook": "nb_transform_gold_transactional_tme"
            }
        ]
    }
)

# Target settings > here/how to write
target_settings = json.dumps(
    {
        "target_workspace": "ws_canada_global_mds_dev",
        "target_lakehouse": "lh_canada_global_mds",
        "target_schema": "gold_transactional",
        "target_location": "Files/gold/transactional",
        "target_load_strategy": "merge-scd1"
    }
)

# Connection settings > not needed for lakehouse source
source_connection_settings = "{}"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
