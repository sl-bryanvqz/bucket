# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    target_workspace          = "ws_canada_global_mds_dev"
    target_lakehouse          = "lh_canada_global_mds"
    target_table              = "dev_gold_transactional_matter_financials"
    map_view                  = f"map_{target_table}"
    target_pk                 = ["matter_number", "member_firm_code"]
    limit_rows_for_debugging  = True
    watermark_filter          = "1=1"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"map_view: {map_view}")
    print(f"target_workspace: {target_workspace}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT DISTINCT
    matter_financials_key,
    CASE
        WHEN matter_number LIKE '16%' THEN CONCAT('10', SUBSTRING(matter_number, 3, LEN(matter_number)))
        ELSE matter_number
        END AS matter_number,
    member_firm_code,
    client_number,
    total_wip,
    last_wip_date,
    total_ar,
    total_fees_billed,
    last_bill_date,
    trust_funds_balance,
    unallocated_funds_balance,
    retainer_funds_balance,
    matter_currency_code,
    last_updated_date_utc_at_source
FROM {target_workspace}.{target_lakehouse}.silver_transactional.silver_transactional_matter_financials s
WHERE {watermark_filter}
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
