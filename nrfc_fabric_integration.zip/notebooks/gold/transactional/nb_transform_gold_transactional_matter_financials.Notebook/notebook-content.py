# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    target_workspace          = "ws_canada_global_mds_dev"
    target_lakehouse          = "lh_canada_global_mds"
    target_table              = "gold_transactional_matter_financials"
    map_view                  = f"map_{target_table}"
    target_pk                 = ["matter_number", "member_firm_code"]
    limit_rows_for_debugging  = True
    watermark_filter          = "1=1"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"map_view: {map_view}")
    print(f"target_workspace: {target_workspace}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT
    CAST(row_number() OVER (ORDER BY s.matter_number) AS BIGINT)                     AS matter_financials_key,

    -- Mapping source is MatterFinancials.MatterId
    s.matter_number                                                                  AS matter_number,

    -- Canada MatterFinancials file must use CANADA
    s.member_firm_code                                                               AS member_firm_code,

    -- Enrich keys from RMDD when available
    MAX_BY(m.matter_key, s.latest_row_at)                                            AS matter_key,
    MAX_BY(COALESCE(c.client_number, 'Unknown'), s.latest_row_at)                    AS client_number,
    MAX_BY(c.client_key, s.latest_row_at)                                            AS client_key,

    -- Use the latest finance row per matter/member firm
    MAX_BY(s.total_wip, s.latest_row_at)                                             AS total_wip,
    MAX_BY(s.last_wip_date, s.latest_row_at)                                         AS last_wip_date,
    MAX_BY(s.total_ar, s.latest_row_at)                                              AS total_ar,
    MAX_BY(s.total_fees_billed, s.latest_row_at)                                     AS total_fees_billed,
    MAX_BY(s.last_bill_date, s.latest_row_at)                                        AS last_bill_date,
    MAX_BY(s.trust_funds_balance, s.latest_row_at)                                   AS trust_funds_balance,
    MAX_BY(s.unallocated_funds_balance, s.latest_row_at)                             AS unallocated_funds_balance,
    MAX_BY(s.retainer_funds_balance, s.latest_row_at)                                AS retainer_funds_balance,
    MAX_BY(s.matter_currency_code, s.latest_row_at)                                  AS matter_currency_code,
    MAX(s.latest_row_at)                                                             AS last_updated_date_utc_at_source

FROM (
    SELECT
        s.matter_id                                                                  AS matter_number,
        CAST('CANADA' AS STRING)                                                     AS member_firm_code,
        s.total_wip                                                                  AS total_wip,
        s.total_ar                                                                   AS total_ar,
        CAST(NULL AS INT)                                                            AS total_fees_billed,
        s.trust_funds_balance                                                        AS trust_funds_balance,
        s.unallocated_funds_balance                                                  AS unallocated_funds_balance,
        s.retainer_funds_balance                                                     AS retainer_funds_balance,
        s.matter_currency                                                            AS matter_currency_code,

        -- Guard date values that SQL endpoint cannot parse from Parquet
        CASE
            WHEN s.last_wip_date >= TIMESTAMP '1900-01-01 00:00:00' THEN s.last_wip_date
            ELSE TIMESTAMP '1900-01-01 00:00:00'
        END                                                                          AS last_wip_date,

        CASE
            WHEN s.last_bill_date >= TIMESTAMP '1900-01-01 00:00:00' THEN s.last_bill_date
            ELSE TIMESTAMP '1900-01-01 00:00:00'
        END                                                                          AS last_bill_date,

        COALESCE(
            s.process_time_stamp,
            s.load_time_stamp,
            TIMESTAMP '1900-01-01 00:00:00'
        )                                                                            AS latest_row_at

    FROM {target_workspace}.{target_lakehouse}.silver_transactional.silver_transactional_matter_financials s
) s
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_matter m
    ON s.matter_number = m.matter_number
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_client c
    ON m.client_id = c.client_id
    AND m.member_firm_code = c.member_firm_code

WHERE {watermark_filter}
GROUP BY
    s.matter_number,
    s.member_firm_code
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
