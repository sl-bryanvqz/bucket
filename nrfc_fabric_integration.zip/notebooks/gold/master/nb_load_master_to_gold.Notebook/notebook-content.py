# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "known_warehouses": []
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Define notebook Parameters
# 
# Pass through th pl_worker

# CELL ********************

# Framework-compatible parameters with manual fallbacks
import json
import uuid

# Basic notebook runtime values
task_id = 50
task_name = "Load master to gold"
lineage_id = str(uuid.uuid4())
limit_rows_for_debugging = True
prev_wm = "1900-01-01 00:00:00"
curr_wm = "2026-08-31 19:35:00"
execution_errors = []

# Source settings > what data to read
source_settings = json.dumps(
    {
        "source_name": "silver_rmdd",
        "source_type": "lakehouse",
        "source_location": "lh_canada_global_mds",
        "source_schema": "silver_rmdd",
        "table_config": [
            # {
            #     "target_table": "gold_master_address",
            #     "target_pk": ["address_id", "client_number", "member_firm_code"],
            #     "is_incremental": 1,
            #     "incremental_column": "last_updated_date_utc_at_source",
            #     "transformation_notebook": "nb_transform_gold_master_address"
            # },
            # {
            #     "target_table": "gold_master_client",
            #     "target_pk": ["client_number", "member_firm_code"],
            #     "is_incremental": 1,
            #     "incremental_column": "last_updated_date_utc_at_source",
            #     "transformation_notebook": "nb_transform_gold_master_client"
            # },
            # {
            #     "target_table": "gold_master_client_partner_allocation",
            #     "target_pk": ["client_number", "member_firm_code", "person_number", "partner_function_key", "begin_date"],
            #     "is_incremental": 1,
            #     "incremental_column": "last_updated_date_utc_at_source",
            #     "transformation_notebook": "nb_transform_gold_master_client_partner_allocation"
            # },
            # {
            #     "target_table": "gold_master_cost_centre",
            #     "target_pk": ["cost_centre_code", "member_firm_code", "valid_from_date"],
            #     "is_incremental": 1,
            #     "incremental_column": "last_updated_date_utc_at_source",
            #     "transformation_notebook": "nb_transform_gold_master_cost_centre"
            # },
            # {
            #     "target_table": "gold_master_matter",
            #     "target_pk": ["matter_number", "member_firm_code"],
            #     "is_incremental": 1,
            #     "incremental_column": "last_updated_date_utc_at_source",
            #     "transformation_notebook": "nb_transform_gold_master_matter"
            # },
            # {
            #     "target_table": "gold_master_matter_partner_allocation",
            #     "target_pk": ["matter_number", "member_firm_code", "person_number", "partner_function_key", "office_key", "team_key", "begin_date"],
            #     "is_incremental": 1,
            #     "incremental_column": "last_updated_date_utc_at_source",
            #     "transformation_notebook": "nb_transform_gold_master_matter_partner_allocation"
            # },
            {
                "target_table": "gold_master_person",
                "target_pk": ['person_number', 'member_firm_code'],
                "is_incremental": 1,
                "incremental_column": "last_updated_date_utc_at_source",
                "transformation_notebook": "nb_transform_gold_master_person"
            # },
            # {
            #     "target_table": "gold_master_person_relationship",
            #     "target_pk": ["person_number_1", "person_number_2"],
            #     "is_incremental": 0,
            #     "incremental_column": "last_updated_date_utc_at_source",
            #     "transformation_notebook": "nb_transform_gold_master_person_relationship"
            }
        ]
    }
)

# Target settings > here/how to write
target_settings = json.dumps(
    {
        "target_workspace": "ws_canada_global_mds_dev",
        "target_lakehouse": "lh_canada_global_mds",
        "target_schema": "gold_master",
        "target_location": "Files/gold/master",
        "target_load_strategy": "merge-scd1"
    }
)

# Connection settings > not needed for lakehouse source
source_connection_settings = "{}"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
