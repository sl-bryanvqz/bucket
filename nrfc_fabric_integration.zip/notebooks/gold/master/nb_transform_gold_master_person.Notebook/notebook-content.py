# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    target_workspace          = "ws_canada_global_mds_dev"
    target_lakehouse          = "lh_canada_global_mds"
    target_table              = "dev_gold_master_person"
    map_view                  = f"map_{target_table}"
    target_pk                 = ["person_number", "member_firm_code"]
    limit_rows_for_debugging  = True
    watermark_filter          = "1=1"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"map_view: {map_view}")
    print(f"target_workspace: {target_workspace}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT

    -- silver person
    p.person_key,
    p.person_number,
    p.member_firm_code,

    -- Timekeeper id is already standardized in silver person_system_map
    psm.timekeeper_id,

    -- silver person
    p.person_id,
    p.person_status_code,
    p.gender, 
    p.prefix,
    p.first_name,
    p.first_name_known_as,
    p.middle_name,
    p.last_name,
    p.suffix,
    p.initials,
    p.photo_path,
    p.commencement_date_utc,
    p.departure_date_utc,
    p.leave_status,

    -- Team key follows client path: Person > SubTeam > Team
    st.sub_team_id                                                      AS team_key,
    
    -- Job and practice fields from silver person
    p.job_title,
    p.job_title_pms,
    p.practice_group_key,
    p.year_of_call,
    pl.desk_location,

    -- System identifiers from silver person_system_map
    psm.domain_name,
    psm.unified_sap_person_external_id,
    psm.windows_login,
    psm.dms_system_id,
    psm.human_resources_system_id,

    -- Contact fields split by phone/email type per client script
    COALESCE(NULLIF(TRIM(CAST(wp.phone_number AS STRING)), ''), 'Unknown') AS work_phone_number,
    wp.phone_extension  AS work_phone_extension,
    COALESCE(NULLIF(TRIM(CAST(mp.phone_number AS STRING)), ''), 'Unknown') AS mobile_phone_number,
    COALESCE(NULLIF(TRIM(CAST(e.email_address AS STRING)), ''), 'Unknown') AS email_address,

    -- Client reporting name format
    CONCAT(
        COALESCE(NULLIF(TRIM(CAST(p.last_name AS STRING)), ''), 'Unknown'),
        ', ',
        COALESCE(NULLIF(TRIM(CAST(p.first_name_known_as AS STRING)), ''), NULLIF(TRIM(CAST(p.first_name AS STRING)), ''), 'Unknown'),
        ' (',
        COALESCE(NULLIF(TRIM(CAST(psm.unified_sap_person_external_id AS STRING)), ''), NULLIF(TRIM(CAST(psm.timekeeper_id AS STRING)), ''), 'Unknown'),
        ')'
    )                                                                   AS employee_name_reporting,

    -- Additional enrichment keys from silver/taxonomy-prepared tables
    cc.cost_centre_code,
    COALESCE(ap0.company_key, -1) AS company_key,
    o.office_key,
    esg.employee_sub_group_key,
    pa9.band_level_key,

    -- Standard activity and source update fields
    p.is_active,
    p.last_updated_date_utc_at_source

FROM {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_person p

-- PERSON_SYSTEM_MAP AND PA0001 JOIN
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_person_system_map psm 
    ON p.person_id = psm.person_id
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_pa0001 ap0
    ON psm.unified_sap_person_external_id = ap0.pernr

-- EMPLOYEE_SUB_GROUP AND PA9007 JOIN
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_employee_sub_group esg
    ON ap0.persk = esg.sub_group_code
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_pa9007 pa9
    ON ap0.pernr = pa9.pernr

-- TEAM AND SUB_TEAM JOIN
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_sub_team st
    ON p.sub_team_id = st.sub_team_id
    
-- PERSON_LOCALE AND OFFICE JOIN
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_person_locale pl
    ON p.person_id = pl.person_id
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_office o
    ON pl.office_id = o.office_id

-- PHONE AND EMAIL JOIN
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_phone wp
    ON p.person_id = wp.entity_id
    AND wp.phone_type_code = 'W'
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_phone mp
    ON p.person_id = mp.entity_id
    AND mp.phone_type_code = 'M'
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_email e
    ON p.person_id = e.entity_id
    AND e.email_type_code = 'W'

-- COST CENTRE JOIN
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_person_cost_centre pcc
    ON p.person_id = pcc.person_id
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_cost_centre cc
    ON pcc.cost_centre_id = cc.cost_centre_id

-- Client script filters Canada people and excludes undefined person number
WHERE {watermark_filter}
    AND p.member_firm_code = 'NRCAN'
    AND p.person_number <> 'UNDEF'
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(spark.sql(f"""SELECT COUNT(*) FROM {map_view}"""))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
