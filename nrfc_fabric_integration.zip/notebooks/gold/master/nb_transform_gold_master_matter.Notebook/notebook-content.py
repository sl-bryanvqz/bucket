# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    target_workspace          = "ws_canada_global_mds_dev"
    target_lakehouse          = "lh_canada_global_mds"
    target_table              = "dev_gold_master_matter"
    map_view                  = f"map_{target_table}"
    target_pk                 = ["matter_number", "member_firm_code"]
    limit_rows_for_debugging  = True
    watermark_filter          = "1=1"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"map_view: {map_view}")
    print(f"target_workspace: {target_workspace}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT
    s.matter_key                                        AS  matter_key,
 
    s.matter_number                                     AS  matter_number,
    'CANADA'                                            AS  member_firm_code,
    CAST(s.matter_id AS STRING)                         AS  matter_id,
    s.pms_matter_id,
    s.matter_name,
    s.long_matter_name,
    s.alternate_matter_name,
    s.alternate_matter_number,

    -- Client script uses GETUTCDATE; keep stable to avoid merge updates every run
    s.matter_open_date_utc                                                  AS  matter_create_date_utc,

    CAST('' AS STRING)                                                      AS  matter_name_cmi,
    CAST('' AS STRING)                                                      AS  member_firm_code_cmi,
    CAST('' AS STRING)                                                      AS  matter_description_cmi,    
    COALESCE(CAST(o.office_key AS BIGINT), -1)                              AS  billing_office_key,
    s.nature_of_proceeding_key                                              AS  nature_of_proceeding_key,
    COALESCE(ms.curated_matter_status_key, -1)                              AS  matter_status_key,

    -- matter_status_cmi_key doesn't exist in the mapping 
    -- CAST('' AS STRING)                                                   AS  matter_status_cmi_key,

    COALESCE(mo.company_code, 'Unknown')                                    AS  matter_company_code,  
    COALESCE(CAST(c.client_id AS STRING), -1)                               AS  client_number,
    COALESCE(sp.practice_group_key, -1)                                     AS  practice_group_key,
    COALESCE(mc.matter_category_key, -1)                                    AS  matter_category_key,

    s.is_confidential                                                       AS  is_confidential,
    sp.matter_pass_through_flag                                             AS  matter_pass_through_flag,
    s.currency_code                                                         AS  currency_code,

    CAST('' AS STRING)                                                      AS  matter_jurisdiction_code_cmi,    
    -- matter_fee_estimate_cmi and matter_cost_estimate_cmi don't exist in the contract
    -- CAST('' AS STRING)                                                   AS  matter_fee_estimate_cmi,
    -- CAST('' AS STRING)                                                   AS  matter_cost_estimate_cmi,

    COALESCE(sp.matter_billing_frequency_key, -1)                           AS  matter_billing_frequency_key,
    COALESCE(sp.matter_billing_method_key, -1)                              AS  matter_billing_method_key,

    s.matter_open_date_utc                                                  AS  matter_open_date_utc,
    s.matter_close_date_utc                                                 AS  matter_close_date_utc,
    s.matter_billable_flag                                                  AS  matter_billable_flag,
    s.matter_time_unit                                                      AS  matter_time_unit,
    s.matter_sector_key                                                     AS  matter_sector_key,
    COALESCE(st.team_key, -1)                                               AS  team_key,

    COALESCE(sp.matter_purchase_order_number, 'Unknown')                    AS  matter_purchase_order_number,
    COALESCE(sp.ip_matter_number, 'Unknown')                                AS  ip_matter_number,
    COALESCE(sp.matter_entry_type_key, -1)                                  AS  matter_entry_type_key,

    s.comments                                                              AS  comments,
    COALESCE(sp.matter_pricing_group, 'Unknown')                            AS  matter_pricing_group,
    sk.parnr                                                                AS  client_bill_contact_code,
    CASE
        WHEN sk.namev IS NULL OR sk.namev IN ('', 'Unknown') THEN sk.name1
        ELSE CONCAT(sk.namev, '', sk.name1)
    END                                                                     AS  client_bill_contact_name,

    COALESCE(py.parnr, 'Unknown')                                           AS  payer_code,
    COALESCE(pyc.client_name, 'Unknown')                                    AS  payer_name,
    COALESCE(z3.parnr, 'Unknown')                                           AS  z3_payer_code,
    COALESCE(z3c.client_name, 'Unknown')                                    AS  z3_payer_name,

    COALESCE(sp.client_case_number, 'Unknown')                              AS  client_case_number,
    COALESCE(sp.client_case_description, 'Unknown')                         AS  client_case_description,

    s.group_billing                                                         AS  group_billing,
    s.reporting_group                                                       AS  reporting_group,
    CAST(s.is_sanctions_checked AS BOOLEAN)                                 AS  is_sanctions_checked,
    CAST(false AS BOOLEAN)                                                  AS  is_security_wall_created,

    COALESCE(ph.zzphaseset, 'Unknown')                                      AS  matter_phase_set_code,
    s.work_type_key                                                         AS  work_type_key,
    s.is_active                                                             AS  is_active,
    s.last_updated_date_utc_at_source                                       AS  last_updated_date_utc_at_source

FROM {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_matter s
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_client c
    ON s.client_id = c.client_id
    AND s.member_firm_code = c.member_firm_code
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_office o
    ON s.office_id = o.office_id
    AND s.member_firm_code = o.member_firm_code
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_matter_office mo
    ON s.matter_id = mo.matter_id
    AND s.member_firm_code = mo.member_firm_code
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_matter_status ms
    ON s.matter_status_id = ms.matter_status_id
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sub_team st
    ON s.team_id = st.sub_team_id
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_proj sp
    ON s.matter_number = sp.pspid
    --AND m.member_firm_code = 'CANADA'
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_zprs_mattercatt mc
    ON sp.matter_category_code = mc.mattercat
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_zprs_mat_ph_set ph
    ON s.matter_number = ph.zzpspid
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_knvk sk
    ON c.client_number = sk.client_number
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_ihpa py
    ON s.matter_number = py.pspid
    AND py.parvw = 'PY'
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_client pyc
    ON py.parnr = pyc.client_number
    --AND pyc.member_firm_code = 'CANADA'
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_ihpa z3
    ON s.matter_number = z3.pspid
    AND z3.parvw = 'Z3'
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_client z3c
    ON z3.parnr = z3c.client_number
    --AND z3c.member_firm_code = 'CANADA'

WHERE {watermark_filter}
    /*AND m.member_firm_code = 'CANADA'*/
    AND (
        s.matter_status_id IN (3,4,5,6,7)
    )
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#spark.sql("SELECT COUNT(*) FROM map_dev_gold_master_matter").show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
