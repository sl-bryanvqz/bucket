# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    target_workspace          = "ws_canada_global_mds_dev"
    target_lakehouse          = "lh_canada_global_mds"
    target_table              = "dev_gold_master_address"
    map_view                  = f"map_{target_table}"
    target_pk                 = ["address_id", "client_number", "member_firm_code"]
    limit_rows_for_debugging  = True
    watermark_filter = "1=1"
    #watermark_filter          = "s.last_updated_date_utc_at_source > '1900-01-01 00:00:00' AND s.last_updated_date_utc_at_source <= '2026-06-05 00:00:00'"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"map_view: {map_view}")
    print(f"target_workspace: {target_workspace}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT DISTINCT

    -- rmdd_address
    s.address_key,
    s.address_id,

    -- rmdd_client
    c.client_number,
    'CANADA'                                                            AS member_firm_code,
    ''       AS client_key,

    -- rmdd_address
    s.address_type_code,
    s.address_1,
    s.address_2,
    s.address_3,
    s.address_4,
    s.address_5,
    s.city,

    -- rmdd_country
    co.country_code_iso2,

    -- rmdd_address
    s.state,
    s.zip_code,
    s.street_address_check,
    s.is_active,
    s.last_updated_date_utc_at_source
    
FROM {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_address s
INNER JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_client c
    ON s.entity_id = c.client_id
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_country co
    ON s.country_id = co.country_id

WHERE {watermark_filter}
    AND s.entity_type_code = 'CL'
    AND s.address_type_code = 'B'
    --AND co.country_code_iso2 = 'CA'
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
