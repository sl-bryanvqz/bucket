# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Define schema tables
# 
# Define the definition schema for each table, run schema if not exists

# CELL ********************

schema_name = "gold_master"
location_path = "Files/gold/master"

prefix = ''


metadata_columns = """_hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
"""

tbl_properties = """
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite'     = 'true',
    'delta.autoOptimize.autoCompact'       = 'true',
    'delta.logRetentionDuration'           = 'interval 30 days',
    'delta.deletedFileRetentionDuration'   = 'interval 7 days')
"""

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tables_definition = [
    {
        "table_name": "gold_master_address",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            address_key BIGINT,
            address_id STRING                               NOT NULL,
            client_number STRING                            NOT NULL,
            member_firm_code STRING                         NOT NULL,
            client_key STRING,
            address_type_code STRING,
            address_1 STRING,
            address_2 STRING,
            address_3 STRING,
            address_4 STRING,
            address_5 STRING,
            city STRING,
            country_code_iso2 STRING,
            state STRING,
            zip_code STRING,
            street_address_check STRING,
            is_active BOOLEAN                               NOT NULL,
            last_updated_date_utc_at_source TIMESTAMP       NOT NULL,
        -- metadata
            {metadata_columns}
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "gold_master_client",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            client_key BIGINT,
            client_number STRING                            NOT NULL,
            member_firm_code STRING                         NOT NULL,
            client_id INT                                   NOT NULL,
            pms_client_id STRING,
            client_name STRING                              NOT NULL,
            alternate_client_name STRING,
            contact_name STRING,
            open_date_utc TIMESTAMP,
            close_date_utc TIMESTAMP,
            client_e_billing_vendor STRING,
            client_information_barier STRING,
            client_non_consent STRING,
            client_pricing_group STRING,
            customer_account_group STRING,
            client_programme_key BIGINT,
            tax_jurisdiction STRING,
            tax_number_1 STRING,
            tax_number_2 STRING,
            vat_registration_number STRING,
            vat_valid_date TIMESTAMP,
            client_duns STRING,
            client_guduns STRING,
            comments STRING,
            pms_entity_type STRING,
            client_type STRING,
            is_confidential BOOLEAN,
            client_sector_key BIGINT,
            is_sanctions_checked BOOLEAN,
            is_active BOOLEAN                               NOT NULL,
            created_date_utc_at_source TIMESTAMP,
            last_updated_date_utc_at_source TIMESTAMP       NOT NULL,
        -- metadata
            {metadata_columns}
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "gold_master_client_partner_allocation",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            client_number STRING                            NOT NULL,
            member_firm_code STRING                         NOT NULL,
            person_number STRING                            NOT NULL,
            partner_function_key BIGINT                     NOT NULL,
            begin_date TIMESTAMP                            NOT NULL,
            end_date TIMESTAMP                              NOT NULL,
            allocation_percentage DECIMAL(18, 4)            NOT NULL,
            client_key STRING,
            person_key STRING,
            is_active BOOLEAN,
            last_updated_date_utc_at_source TIMESTAMP       NOT NULL,

        -- metadata
            {metadata_columns}
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "gold_master_cost_centre",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            cost_centre_key BIGINT,
            cost_centre_code STRING                         NOT NULL,
            member_firm_code STRING,
            valid_from_date TIMESTAMP,
            valid_to_date TIMESTAMP                         NOT NULL,
            company_key BIGINT,
            currency_code STRING,
            profit_centre STRING,
            cost_centre_description STRING,
            cost_centre_long_description STRING,
            is_active BOOLEAN                               NOT NULL,
            last_updated_date_utc_at_source TIMESTAMP,
        -- metadata
            {metadata_columns}
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "gold_master_matter",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            matter_key BIGINT,
            matter_number STRING                            NOT NULL,
            member_firm_code STRING                         NOT NULL,
            matter_id STRING                                NOT NULL,
            pms_matter_id STRING,
            matter_name STRING                              NOT NULL,
            long_matter_name STRING,
            alternate_matter_name STRING,
            alternate_matter_number STRING,
            matter_create_date_utc TIMESTAMP,
            matter_name_cmi STRING,
            member_firm_code_cmi STRING,
            matter_description_cmi STRING,
            billing_office_key BIGINT,
            nature_of_proceeding_key BIGINT,
            matter_status_key BIGINT,
            matter_company_code STRING,
            client_number STRING,
            practice_group_key BIGINT,
            matter_category_key BIGINT                      NOT NULL,
            is_confidential BOOLEAN,
            matter_pass_through_flag BOOLEAN,
            currency_code STRING,
            matter_jurisdiction_code_cmi STRING,
            matter_billing_frequency_key BIGINT,
            matter_billing_method_key BIGINT,
            matter_open_date_utc TIMESTAMP,
            matter_close_date_utc TIMESTAMP,
            matter_billable_flag INT,
            matter_time_unit STRING,
            matter_sector_key BIGINT,
            team_key BIGINT,
            matter_purchase_order_number STRING,
            ip_matter_number STRING,
            matter_entry_type_key BIGINT,
            comments STRING,
            matter_pricing_group STRING,
            client_bill_contact_code STRING,
            client_bill_contact_name STRING,
            payer_code STRING,
            payer_name STRING,
            z3_payer_code STRING,
            z3_payer_name STRING,
            client_case_number STRING,
            client_case_description STRING,
            group_billing STRING,
            reporting_group STRING,
            is_sanctions_checked BOOLEAN,
            is_security_wall_created BOOLEAN                    NOT NULL,
            matter_phase_set_code STRING,
            work_type_key BIGINT,
            is_active BOOLEAN                                   NOT NULL,
            last_updated_date_utc_at_source TIMESTAMP           NOT NULL,
        -- metadata
            {metadata_columns}

        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "gold_master_matter_partner_allocation",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            matter_number STRING                            NOT NULL,
            member_firm_code STRING                         NOT NULL,
            person_number STRING                            NOT NULL,
            partner_function_key BIGINT                     NOT NULL,
            office_key BIGINT,
            team_key BIGINT,
            begin_date TIMESTAMP                            NOT NULL,
            end_date TIMESTAMP                              NOT NULL,
            associate_person_number STRING                  NOT NULL,
            allocation_percentage DECIMAL(18, 4)            NOT NULL,
            is_active BOOLEAN,
            last_updated_date_utc_at_source TIMESTAMP       NOT NULL,

        -- metadata
           {metadata_columns}
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "gold_master_person",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            person_key BIGINT,
            person_number STRING                                NOT NULL,
            member_firm_code STRING                             NOT NULL,
            timekeeper_id STRING,
            person_id STRING                                    NOT NULL,
            alternative_language_job_title STRING,
            person_status_code STRING                           NOT NULL,
            gender STRING,
            prefix STRING,
            first_name STRING                                   NOT NULL,
            first_name_known_as STRING,
            middle_name STRING,
            last_name STRING                                    NOT NULL,
            suffix STRING,
            initials STRING,
            photo_path STRING,
            commencement_date_utc TIMESTAMP,
            departure_date_utc TIMESTAMP,
            leave_status STRING,
            team_key BIGINT,
            job_title STRING,
            job_title_pms STRING,
            practice_group_key BIGINT,
            year_of_call STRING,
            desk_location STRING,
            domain_name STRING,
            unified_sap_person_external_id STRING,
            windows_login STRING,
            dms_system_id STRING,
            human_resources_system_id STRING,
            work_phone_number STRING                            NOT NULL,
            work_phone_extension STRING,
            mobile_phone_number STRING                          NOT NULL,
            email_address STRING                                NOT NULL,
            employee_name_reporting STRING                      NOT NULL,
            cost_centre_code STRING,
            company_key BIGINT,
            office_key BIGINT,
            employee_sub_group_key BIGINT,
            band_level_key BIGINT,
            is_active BOOLEAN,
            last_updated_date_utc_at_source TIMESTAMP           NOT NULL,
        -- metadata
            {metadata_columns}
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "gold_master_person_relationship",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(

            person_number_1             STRING          NOT NULL,
            member_firm_code_1          STRING          NOT NULL,
            person_number_2             STRING          NOT NULL,
            member_firm_code_2          STRING          NOT NULL,
            relationship_description    STRING          NOT NULL,
            primary_flag                BOOLEAN         NOT NULL,
            is_active                   BOOLEAN         NOT NULL,
            last_updated_date_utc_at_source TIMESTAMP   NOT NULL,

    -- metadata
            {metadata_columns}
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """

    }
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Create all tables
# 
# Run sql_statement from table_name on config

# CELL ********************

for t in tables_definition:
    table_name = t["table_name"]

    table_name = f"{prefix}{table_name}"

    sql = t["sql_statement"].format(
        schema_name=schema_name,
        table_name=table_name,
        metadata_columns = metadata_columns,
        location_path=location_path,
        tbl_properties=tbl_properties
    )
    
    print(f"Creating lh_canada_global_mds.{schema_name}.{table_name}")
    #print(sql)
    spark.sql(sql)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
