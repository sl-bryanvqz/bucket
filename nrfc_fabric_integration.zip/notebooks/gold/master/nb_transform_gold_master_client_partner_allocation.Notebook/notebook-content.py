# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    target_workspace          = "ws_canada_global_mds_dev"
    target_lakehouse          = "lh_canada_global_mds"
    target_table              = "gold_master_client_partner_allocation"
    map_view                  = f"map_{target_table}"
    target_pk                 = ["client_number", "member_firm_code", "person_number", "partner_function_key", "begin_date"]
    limit_rows_for_debugging  = True
    watermark_filter          = "1=1"

# Framework values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"map_view: {map_view}")
    print(f"target_workspace: {target_workspace}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT DISTINCT

    s.client_number,
    'CANADA'                                                AS member_firm_code,
    s.person_number,
    s.partner_function_key,
    s.begin_date,
    s.end_date,
    s.allocation_percentage,

    -- silver surrogate keys
    '' AS client_key,
    '' AS person_key,

    -- gmdr_sap_zprs_tkalocclnt
    CAST(s.is_active AS STRING)                             AS  is_active,
    CAST(s.last_updated_date_utc_at_source AS BIGINT)       AS  last_updated_date_utc_at_source

FROM {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_zprs_tkalocclnt s

INNER JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_client c
    ON s.client_number = c.client_number
    --AND c.member_firm_code = 'GPMS'

INNER JOIN (
    SELECT
        gp.person_number,
        gp.person_id_external
    FROM (
        SELECT
            p9.person_number,
            p9.person_id_external,

            -- Client script: one mastered GMDR person per PERSONID_EXT
            RANK() OVER (
                PARTITION BY p9.person_id_external
                ORDER BY
                    p0.employment_status_code DESC,
                    p0.begin_date DESC,
                    p0.changed_date DESC,
                    p0.last_updated_date_utc_at_source DESC
            ) AS x_rank

        FROM {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_pa0709 p9
        INNER JOIN {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_pa0000 p0
            ON p9.person_number = p0.person_number
    ) gp
    WHERE gp.x_rank = 1
) gp
    ON s.person_number = gp.person_number

INNER JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_person_system_map psm
    ON gp.person_id_external = psm.unified_sap_person_external_id
    AND LENGTH(psm.unified_sap_person_external_id) = 6

INNER JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_person p
    ON psm.person_id = p.person_id

WHERE {watermark_filter}
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
