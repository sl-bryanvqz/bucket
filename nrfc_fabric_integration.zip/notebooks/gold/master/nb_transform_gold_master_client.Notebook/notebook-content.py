# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    target_workspace          = "ws_canada_global_mds_dev"
    target_lakehouse          = "lh_canada_global_mds"
    target_table              = "dev_gold_master_client"
    map_view                  = f"map_{target_table}"
    target_pk                 = ["client_number", "member_firm_code"]
    limit_rows_for_debugging  = True
    watermark_filter          = "1=1"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"map_view: {map_view}")
    print(f"target_workspace: {target_workspace}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT DISTINCT

    -- rmdd_client
    s.client_key,
    s.client_number,
    'CANADA'                                                            AS member_firm_code,
    s.client_id,
    s.pms_client_id,
    s.client_name,
    s.alternate_client_name,
    s.contact_name,

    -- mapping logic
    COALESCE(s.open_date_utc, k.open_date)  AS open_date_utc,
    COALESCE(s.close_date_utc)              AS close_date_utc,

    -- gmdr_sap_kna1
    k.client_e_billing_vendor,
    k.client_information_barier,

    -- cmidb not available yet
    --'' AS client_name_cmi,
    --'' AS member_firm_code_cmi,
    --'' AS client_status_cmi,

    -- gmdr_sap_kna1
    k.client_non_consent,
    k.client_pricing_group,
    k.customer_account_group,
    k.client_programme_key,
    k.tax_jurisdiction,
    k.tax_number_1,
    k.tax_number_2,
    k.vat_registration_number,
    k.vat_valid_date,

    -- rmdd_client
    s.client_duns,
    s.client_guduns,
    s.comments,

    --Australia only field
    'Unknown'                                               AS pms_entity_type,

    s.client_type,
    TRY_CAST(s.is_confidential AS BOOLEAN)                  AS is_confidential,

    -- Client script uses COALESCE(MDS.SICCode, GMDR.ZZSICCD)
    COALESCE(s.client_sector_key, k.client_sector_key, -1)  AS client_sector_key,
    s.is_sanctions_checked,
    s.is_active,
    s.created_date_utc_at_source,

    -- Mapping asks for max across RMDD and GMDR update dates
    GREATEST(
        s.last_updated_date_utc_at_source,
        k.last_updated_date_utc_at_source
    )                                    AS last_updated_date_utc_at_source

FROM {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_client s
LEFT JOIN {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_kna1 k
    ON s.client_number = k.kunnr

WHERE {watermark_filter}
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(spark.sql(f"""
select count(*) from {map_view}"""))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
