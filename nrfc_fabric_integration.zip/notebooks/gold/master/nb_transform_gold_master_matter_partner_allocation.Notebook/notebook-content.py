# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    target_workspace          = "ws_canada_global_mds_dev"
    target_lakehouse          = "lh_canada_global_mds"
    target_table              = "dev_gold_master_matter_partner_allocation"
    map_view                  = f"map_{target_table}"
    target_pk                 = ["matter_number", "member_firm_code", "person_number", "partner_function_key", "office_key", "team_key", "begin_date"]
    limit_rows_for_debugging  = True
    watermark_filter          = "1=1"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"map_view: {map_view}")
    print(f"target_workspace: {target_workspace}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT
    zt.gmdr_sap_zprs_tkalocmattr_key                              AS matter_partner_allocation_key,
    zt.matter_number                                              AS matter_number,
    CAST('CANADA' AS STRING)                                      AS member_firm_code,
    zt.person_number                                              AS person_number,
    zt.partner_function_key                                       AS partner_function_key,
    zt.office_key                                                 AS office_key,
    zt.team_key                                                   AS team_key,
    zt.begin_date                                                 AS begin_date,
    zt.end_date                                                   AS end_date,
    zt.associate_person_number                                    AS associate_person_number,
    zt.allocation_percentage                                      AS allocation_percentage,
    zt.is_active                                                  AS is_active,
    zt.last_updated_date_utc_at_source                            AS last_updated_date_utc_at_source

FROM {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_zprs_tkalocmattr zt
WHERE {watermark_filter}
    AND zt.is_active = True
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
