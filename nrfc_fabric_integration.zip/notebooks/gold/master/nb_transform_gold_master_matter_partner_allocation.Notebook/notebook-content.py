# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    target_workspace          = "ws_canada_global_mds_dev"
    target_lakehouse          = "lh_canada_global_mds"
    target_table              = "gold_master_matter_partner_allocation"
    map_view                  = f"map_{target_table}"
    target_pk                 = ["matter_number", "member_firm_code", "person_number","partner_function_key","office_key","team_key","begin_date"]
    limit_rows_for_debugging  = True
    watermark_filter          = "1=1"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"map_view: {map_view}")
    print(f"target_workspace: {target_workspace}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
    WITH gmdr_person_mastered (
        SELECT DISTINCT RANK() OVER (PARTITION BY P9.person_id_external ORDER BY P0.employment_status_code desc, P0.begin_date desc, P0.changed_date desc, P0.last_updated_date_utc_at_source desc) AS xRank           
        ,P9.person_id_external, P9.person_number, P0.begin_date, P0.end_date, P0.changed_date, P0.employment_status_code, P0.last_updated_date_utc_at_source
        FROM {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_pa0709 P9
        JOIN {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_pa0000 P0 ON P9.person_number = P0.person_number
        WHERE P0.end_date = '9999-12-31'
    ) 
    SELECT
        CASE
            WHEN gmdr_sap_ihpa.pspid LIKE '16%'
                THEN CONCAT('10', SUBSTRING(gmdr_sap_ihpa.pspid, 3, LEN(gmdr_sap_ihpa.pspid)))
            ELSE gmdr_sap_ihpa.pspid
        END                                                           AS matter_number,
        'CANADA'                                                      AS member_firm_code,
        gmdr_sap_ihpa.parnr                                           AS person_number,
        COALESCE(partner_function.partner_function_key,-1)            AS partner_function_key,
        COALESCE(c_office.office_key,-1)                              AS office_key,
        COALESCE(c_team.team_key ,-1)                                 AS team_key,
        CAST('1900-01-01 00:00:00' AS TIMESTAMP)                      AS begin_date,
        CAST('9999-12-31 00:00:00' AS TIMESTAMP)                      AS end_date,
        'Unknown'                                                     AS associate_person_number,
        CAST(100 AS DECIMAL)                                          AS allocation_percentage,
        gmdr_sap_ihpa.is_active                                       AS is_active,
        gmdr_sap_ihpa.last_updated_date_utc_at_source                 AS last_updated_date_utc_at_source

    FROM {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_ihpa gmdr_sap_ihpa
    LEFT JOIN  {target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_partner_function partner_function
    ON gmdr_sap_ihpa.parvw = partner_function.sap_code
    INNER JOIN gmdr_person_mastered
    ON gmdr_sap_ihpa.parnr = gmdr_person_mastered.person_number AND gmdr_person_mastered.xRank = 1
    INNER JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_person_system_map mds_personsystemmap 
    ON gmdr_person_mastered.person_id_external = COALESCE(mds_personsystemmap.gpms_external_person_id, mds_personsystemmap.gpms_personnel_number)
    LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_person mds_person 
    ON mds_personsystemmap.person_id = mds_person.person_id  
    LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_person_locale c_person
    ON mds_person.person_id = c_person.person_id
    LEFT JOIN  {target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_office c_office
    ON c_person.office_id = TRY_CAST(c_office.office_id AS INT)
    LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_sub_team st
    ON mds_person.sub_team_id = st.sub_team_id
    LEFT JOIN  {target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_team c_team
    ON  st.sub_team_id = c_team.team_key 
    UNION
    SELECT
        CASE
            WHEN s.matter_number LIKE '16%'
                THEN CONCAT('10', SUBSTRING(s.matter_number, 3, LEN(s.matter_number)))
            ELSE s.matter_number
        END                                                           AS matter_number,
        'CANADA'                                                     AS member_firm_code,
        s.person_number                                              AS person_number,
        COALESCE(s.partner_function_key,-1)                          AS partner_function_key,
        COALESCE(s.office_key ,-1)                                   AS office_key,
        COALESCE(s.team_key ,-1)                                     AS team_key,
        s.begin_date                                                 AS begin_date,
        s.end_date                                                   AS end_date,
        COALESCE(s.associate_person_number,'Unknown')                AS associate_person_number,
        s.allocation_percentage                                      AS allocation_percentage,
        s.is_active                                                  AS is_active,
        s.last_updated_date_utc_at_source                            AS last_updated_date_utc_at_source

    FROM {target_workspace}.{target_lakehouse}.silver_gmdr.silver_gmdr_sap_zprs_tkalocmattr s
    WHERE {watermark_filter}
        AND s.is_active = True




""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
