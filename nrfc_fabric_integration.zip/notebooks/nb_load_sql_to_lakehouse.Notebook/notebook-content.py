# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "known_warehouses": []
# META     }
# META   }
# META }

# CELL ********************

# MAGIC %%configure
# MAGIC {
# MAGIC   "defaultLakehouse": {
# MAGIC     "name": "lh_canada_global_mds",
# MAGIC     "id": {
# MAGIC       "variableName": "$(/**/vl_guids/lakehouse_id)"
# MAGIC     },
# MAGIC     "workspaceId": {
# MAGIC       "variableName": "$(/**/vl_guids/workspace_id)"
# MAGIC     }
# MAGIC   }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### YAML file table parameters
# 
# To locally test create the YAML file definition in the nb_load_entity_to_schema

# CELL ********************

#%run nb_load_taxonomy_to_stage

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#%run nb_load_rmdd_to_silver

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#%run nb_load_transactional_to_silver

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#%run nb_load_gmdr_to_silver

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#%run nb_load_master_to_gold

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#%run nb_load_transactional_to_gold

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#%run nb_load_canonical_to_gold

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Define functions and logging
# 
# Used for import functions

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Set up standard framework logging
setup_logging()
logger = logging.getLogger("LoadSQLToLakehouse")
logger.setLevel(logging.INFO)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Define variables or parameters
# 
# Can manually run or be through worker

# CELL ********************

# Accept JSON strings from pipeline or dicts from manual runs
execution_errors = []

source_settings = json.loads(source_settings) if isinstance(source_settings, str) else source_settings
target_settings = json.loads(target_settings) if isinstance(target_settings, str) else target_settings
source_connection_settings = json.loads(source_connection_settings) if isinstance(source_connection_settings, str) else source_connection_settings

source_settings = source_settings or {}
target_settings = target_settings or {}
source_connection_settings = source_connection_settings or {}

# Source connection values come from meta.connections; source_settings comes from YAML
source_runtime_settings = {**source_connection_settings, **source_settings}

# Source configuration
source_name = source_runtime_settings.get("source_name")
source_type = source_runtime_settings.get("source_type")
source_location = source_runtime_settings.get("source_location")
source_schema = source_runtime_settings.get("source_schema")
table_config = source_settings.get("table_config", [])

# SQL source server
server_name = (
    source_connection_settings.get("server_name")
    or source_connection_settings.get("jdbc_hostname")
    or source_connection_settings.get("server")
)

# Target ids come from pipeline parameters; names are fallback for manual runs
target_workspace_id = globals().get("target_workspace_id") or target_settings.get("target_workspace_id")
target_lakehouse_id = globals().get("target_lakehouse_id") or target_settings.get("target_lakehouse_id")

target_workspace = target_settings.get("target_workspace")
target_lakehouse = target_settings.get("target_lakehouse")

# Resolve target names from ids for Spark SQL references
if target_workspace_id:
    fabric_token = notebookutils.credentials.getToken("pbi")
    fabric_headers = {"Authorization": f"Bearer {fabric_token}"}

    workspace_response = requests.get(
        f"https://api.fabric.microsoft.com/v1/workspaces/{target_workspace_id}",
        headers=fabric_headers
    )
    workspace_response.raise_for_status()
    target_workspace = workspace_response.json().get("displayName")

    if target_lakehouse_id:
        lakehouse_response = requests.get(
            f"https://api.fabric.microsoft.com/v1/workspaces/{target_workspace_id}/items/{target_lakehouse_id}",
            headers=fabric_headers
        )
        lakehouse_response.raise_for_status()
        target_lakehouse = lakehouse_response.json().get("displayName")

# Target configuration
target_schema = target_settings.get("target_schema")
target_location = target_settings.get("target_location")
target_load_strategy = target_settings.get("target_load_strategy")

# Debug output
if limit_rows_for_debugging:
    print(f"source_name: {source_name}")
    print(f"source_type: {source_type}")
    print(f"source_location: {source_location}")
    print(f"source_schema: {source_schema}")
    print(f"server_name: {server_name}")
    print(f"target_workspace_id: {target_workspace_id}")
    print(f"target_workspace: {target_workspace}")
    print(f"target_lakehouse_id: {target_lakehouse_id}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_schema: {target_schema}")
    print(f"target_location: {target_location}")
    print(f"target_load_strategy: {target_load_strategy}")
    display(table_config)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Build source connection
# 
# Creates connection to get source data. Connection is only 

# CELL ********************

# Build source connection if this source needs one
jdbc_url = None
connection_properties = None

if source_type == "sql_database":
    jdbc_url, connection_properties = build_source_connection(
        source_type=source_type,
        source_location=source_location,
        source_connection_settings=source_connection_settings
    )

# Default to the account running the notebook
runtime_context = notebookutils.runtime.context
sql_current_user = (
    runtime_context.get("userName")
    or runtime_context.get("userId")
    or "Unknown notebook runner"
)

# SQL sources can confirm the database execution user
if jdbc_url and connection_properties:
    auth_check_query = """
    (
        SELECT CAST(CURRENT_USER AS VARCHAR(256)) AS sql_current_user
    ) auth_check
    """

    sql_current_user = (
        spark.read.jdbc(
            jdbc_url,
            auth_check_query,
            properties=connection_properties
        )
        .first()["sql_current_user"]
    )

# Use configured service principal name when SPN auth is enabled
vl_authentication = notebookutils.variableLibrary.getLibrary("vl_authentication")

if vl_authentication.use_db_spn_authentication:
    sql_current_user = vl_authentication.client_secret_name

# Debug output
if True:
    print("source_type:", source_type)
    print("jdbc_url_exists:", jdbc_url is not None)
    print("sql_current_user:", sql_current_user)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Ingest source table
# 
# Read and dedup clean source

# CELL ********************

# Read source tables and create src_* temp views
source_dfs = {}
watermark_filters = {}

for cfg in table_config:
    # Read table-level config
    source_table = cfg.get("source_table")
    target_table = cfg.get("target_table")
    watermark_column = cfg.get("incremental_column")
    is_incremental = int(cfg.get("is_incremental") or 0)

    # Default filter for non-incremental loads
    watermark_filter = "1 = 1"

    # Build incremental filter only when enabled
    if is_incremental == 1 and watermark_column:
        effective_prev_wm = (
            datetime.strptime(prev_wm, "%Y-%m-%d %H:%M:%S")
            - timedelta(hours=12)
        ).strftime("%Y-%m-%d %H:%M:%S")

        watermark_filter = f"s.{watermark_column} >= '{effective_prev_wm}' AND s.{watermark_column} <= '{curr_wm}'"

    # Save filter by target table for transform step
    watermark_filters[target_table] = watermark_filter

    # Gold transform rows do not need source ingestion
    if not source_table:
        continue

    # Avoid reading the same source table more than once
    if source_table in source_dfs:
        continue

    # Build temp view name for source data
    source_view = f"src_{to_snake_case(source_table)}"

    try:
        # Read source data and create temp source view
        df_source = create_source_view(
            source_view=source_view,
            source_schema=source_schema,
            source_table=source_table,
            source_type=source_type,
            source_location=source_location,
            source_connection_settings=source_connection_settings,
            jdbc_url=jdbc_url,
            connection_properties=connection_properties,
            source_watermark_filter=watermark_filter
        )

        # Store source DataFrame for downstream steps
        source_dfs[source_table] = df_source

        # Debug output
        if limit_rows_for_debugging:
            print(f"Source preview for {source_view}")
            display(df_source.limit(3))

    except Exception as error:
        # Log ingestion error and skip this table
        add_execution_error(
            execution_errors=execution_errors,
            task_id=task_id,
            task_name=task_name,
            lineage_id=lineage_id,
            source_table=source_table,
            target_table=target_table,
            step="Failed at <Ingest source table> cell",
            error_type="ERROR",
            message=error
        )

        continue

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Transform source table
# 
# Applies mapping and transformation as needed

# CELL ********************

# Transform source tables into target shape
mapped_dfs = {}

for cfg in table_config:
    # Read table-level config
    source_table = cfg.get("source_table")
    target_table = cfg.get("target_table")
    transformation_notebook = cfg.get("transformation_notebook")

    # Skip when source ingestion was expected but failed
    if source_table and source_table not in source_dfs:
        continue

    # Build source and target temp view names
    source_view = f"src_{to_snake_case(source_table)}" if source_table else ""
    map_view = f"map_{to_snake_case(target_table)}"

    # Get filter created during ingestion setup
    table_watermark_filter = watermark_filters.get(target_table, "1 = 1")

    try:
        # Run table-specific transformation notebook when provided
        if transformation_notebook:
            mssparkutils.notebook.run(
                transformation_notebook,
                1800, # 30 minute timeout
                {
                    "useRootDefaultLakehouse": True,
                    "source_view": source_view,
                    "map_view": map_view,
                    "target_workspace": target_workspace,
                    "target_lakehouse": target_lakehouse,
                    "target_table": target_table,
                    "target_pk": json.dumps(cfg.get("target_pk", [])),
                    "limit_rows_for_debugging": limit_rows_for_debugging,
                    "watermark_filter": table_watermark_filter,
                    "run_mode": "framework"
                }
            )

            # Read mapped temp view created by transform notebook
            mapped_dfs[target_table] = spark.table(map_view)

        else:
            # Use source data directly when no transform notebook exists
            mapped_dfs[target_table] = source_dfs[source_table]

        # Debug output
        if limit_rows_for_debugging:
            print(f"Mapped preview for {target_table}")
            display(mapped_dfs[target_table].limit(3))

    except Exception as error:
        # Log transformation error and skip this table
        add_execution_error(
            execution_errors=execution_errors,
            task_id=task_id,
            task_name=task_name,
            lineage_id=lineage_id,
            source_table=source_table,
            target_table=target_table,
            step="Failed at <Transform source table> cell",
            error_type="ERROR",
            message=error
        )

        continue

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Add metadata to source table
# 
# Applies metadata and _hashed_pk

# CELL ********************

# Add metadata to final target data
target_dfs = {}

for cfg in table_config:
    # Get source and target details
    source_table = cfg.get("source_table")
    target_table = cfg.get("target_table")
    target_pk = cfg.get("target_pk", [])
    transformation_notebook = cfg.get("transformation_notebook")

    # Skip only when source_table was expected and failed ingestion
    if source_table and source_table not in source_dfs:
        continue

    # Skip this table if transformation failed
    if target_table not in mapped_dfs:
        continue

    try:
        # Use transformed data when it exists
        df_target = mapped_dfs[target_table]

        # Add framework hash columns when business keys are defined
        if target_pk:
            df_target = add_hash_columns(
                df_target,
                target_pk,
                cfg.get("incremental_column")
            )

        # Use source table when present, otherwise use the transform notebook as lineage source
        if source_table:
            metadata_source_table = f"{source_schema}/{source_table}.csv" if source_type == "csv" else f"{source_schema}.{source_table}"
        else:
            metadata_source_table = transformation_notebook

        # Add standard framework metadata columns
        df_target = add_metadata(
            df=df_target,
            source_system=source_name,
            source_table=metadata_source_table,
            target_table=target_table,
            lineage_id=lineage_id
        )

        # Save final DataFrame for validation and load
        target_dfs[target_table] = df_target

        # Debug output
        if limit_rows_for_debugging:
            print(f"Target preview for {target_table}")
            display(df_target.limit(3))

    except Exception as error:
        # Keep the notebook running and skip only the failed table
        add_execution_error(
            execution_errors=execution_errors,
            task_id=task_id,
            task_name=task_name,
            lineage_id=lineage_id,
            source_table=source_table,
            target_table=target_table,
            step="Failed at <Metadata to source table> cell",
            error_type="ERROR",
            message=error
        )

        continue

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Check null pk
# 
# alidates there is no null pk values before load_to_target 

# CELL ********************

# Check null business keys before duplicate check and load
for cfg in table_config:
    # Get table definition from source_settings
    source_table = cfg.get("source_table")
    target_table = cfg.get("target_table")
    target_pk = cfg.get("target_pk")

    # Skip only when source_table was expected and failed ingestion
    if source_table and source_table not in source_dfs:
        continue

    # Skip this table if metadata failed
    if target_table not in target_dfs:
        continue

    # Skip null check when no business key is defined
    if not target_pk:
        continue

    try:
        # Call nb_transformation_shared_functions
        null_count = validate_null_business_keys(
            target_dfs[target_table],
            target_pk,
            target_table
        )

        # Stop this table from loading when null business keys exist
        if null_count > 0:
            target_dfs.pop(target_table, None)
            raise ValueError(
                f"Null business keys found for {target_table}: {null_count} rows"
            )

    except Exception as error:
        # Keep the notebook running and skip only the failed table
        target_dfs.pop(target_table, None)

        add_execution_error(
            execution_errors=execution_errors,
            task_id=task_id,
            task_name=task_name,
            lineage_id=lineage_id,
            source_table=source_table,
            target_table=target_table,
            step="Failed at <check null pk> cell",
            error_type="ERROR",
            message=error
        )

        continue

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Check duplicates
# 
# Return duplicates before load_to_target 

# CELL ********************

# Check duplicate business keys before load
for cfg in table_config:
    # Get table definition from source_settings
    source_table = cfg.get("source_table")
    target_table = cfg.get("target_table")
    target_pk = cfg.get("target_pk")

    # Skip only when source_table was expected and failed ingestion
    if source_table and source_table not in source_dfs:
        continue

    # Skip this table if metadata failed
    if target_table not in target_dfs:
        continue

    # Skip duplicate check when no business key is defined
    if not target_pk:
        continue

    try:
        # Call nb_transformation_shared_functions
        duplicate_count = validate_duplicates(
            target_dfs[target_table],
            target_pk,
            target_table
        )

        # Stop this table from loading when duplicate business keys exist
        if duplicate_count > 0:
            target_dfs.pop(target_table, None)
            raise ValueError(
                f"Duplicate business keys found for {target_table}: {duplicate_count} duplicate groups"
            )

    except Exception as error:
        # Keep the notebook running and skip only the failed table
        target_dfs.pop(target_table, None)

        add_execution_error(
            execution_errors=execution_errors,
            task_id=task_id,
            task_name=task_name,
            lineage_id=lineage_id,
            source_table=source_table,
            target_table=target_table,
            step="Failed at <check duplicates> cell",
            error_type="ERROR",
            message=error
        )

        continue

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Load to target
# 
# Runs load to target based on load_strategy

# CELL ********************

# Load final DataFrames to target tables
log_data = []

for cfg in table_config:
    # Get table definition from source_settings
    source_table = cfg.get("source_table")
    target_table = cfg.get("target_table")

    # Skip this table if metadata or validation failed
    if target_table not in target_dfs:
        continue

    try:
        # Set target table and location
        target_full_name = f"{target_schema}.{target_table}"
        target_location_path = f"{target_location}/{target_table}"

        # Lookup target table on target_dfs
        df_target = target_dfs[target_table]

        # Call nb_transformation_shared_functions
        result = load_to_target(df_target, target_full_name, target_load_strategy, target_location_path)
        
        # Save metrics for pipeline
        log_data.append({
            "target_table": target_table,
            "watermark_from": datetime.strptime((prev_wm or "1900-01-01 00:00:00")[:19], "%Y-%m-%d %H:%M:%S").strftime("%Y-%m-%d %H:%M"),
            "watermark_to": datetime.strptime((curr_wm or datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))[:19], "%Y-%m-%d %H:%M:%S").strftime("%Y-%m-%d %H:%M"),
            "rows_read": result["rows_read"],
            "rows_inserted": result["rows_inserted"],
            "rows_updated": result["rows_updated"],
            "rows_unchanged": result["rows_unchanged"]
        })

    except Exception as error:
        # Keep the notebook running and skip only the failed table
        add_execution_error(
            execution_errors=execution_errors,
            task_id=task_id,
            task_name=task_name,
            lineage_id=lineage_id,
            source_table=source_table,
            target_table=target_table,
            step="Failed at <load to target> cell",
            error_type="ERROR",
            message=error
        )

        continue

print("Execution results:")
display(log_data)

if execution_errors:
    print("Execution errors:")
    display(execution_errors)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Fail the notebook if any step added an execution error
if execution_errors:
    first_error = execution_errors[0]

    result = {
        "error_step": first_error.get("step"),
        "error_message": first_error.get("message"),
        "target_table": first_error.get("target_table"),
        "sql_current_user": sql_current_user
    }

    print("Execution failed:")
    print(json.dumps(result, indent=2, default=str))

    raise RuntimeError(json.dumps(result, default=str))

# Only reach this when the task fully succeeded
result = {
    "sql_current_user": sql_current_user,
    "log_data": log_data
}

print("Execution succeeded:")
print(json.dumps(result, indent=2, default=str))

mssparkutils.notebook.exit(json.dumps(result, default=str))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
