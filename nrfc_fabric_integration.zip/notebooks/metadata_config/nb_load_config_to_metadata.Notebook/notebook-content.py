# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "known_warehouses": []
# META     },
# META     "mirrored_db": {
# META       "known_mirrored_dbs": []
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Metadata config load
# 
# This notebook reads the YAML metadata task config, converts each stage into metadata task rows, validates the result, stages valid rows in `meta.temp_task`, and merges them into `meta.task`.

# CELL ********************

# Upload metadata task config file to Resources tab in your notebook explorer.
#path = f"{notebookutils.nbResPath}/builtin/meta_task_table_config.yml"
path = "/lakehouse/default/Files/metadata_config/meta_task_table_config.yml"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run nb_metadata_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Load YAML config to dataframe
# 
# This section reads the YAML metadata config file, converts each enabled stage into a task row, and displays the resulting dataframe before validation.

# CELL ********************

# Convert YAML config to dataframe
df_current = yaml_to_stage_rows(path)
display(df_current)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Validate metadata config
# 
# This section checks the loaded metadata rows for missing or invalid settings before loading them into the metadata control database.

# CELL ********************

# Run metadata config validations and count warning records
df_warning = final_validation(df_current)
warning_records = df_warning.count()

# Display validation results
if warning_records > 0:
    print(f"WARNING.. Issues with {warning_records} records.")
    display(df_warning)
else:
    print("All records passed validations.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Load metadata to control database
# 
# This section loads validated metadata rows into the staging table `meta.temp_task`, then merges those staged rows into the final metadata table `meta.task`.

# CELL ********************

# Define columns used by the metadata merge
col_list = [
    "task_name", "object_name", "stage", "source_connection_id",
    "source_settings", "target_settings", "option_settings",
    "template_settings", "enabled", "file_hash",
    "scheduling_settings", "enable_retries", "max_retry_attempts"
]

# Build merge statement from staging table to final metadata table
merge_query = build_merge_sql(
    "meta", "task", "meta", "temp_task",
    ["object_name", "stage"],
    col_list,
    col_list
)

# Load validated metadata rows into staging table
load_staging_table(df_current)

# Merge staged metadata rows into final metadata table
merge_metadata_task(merge_query)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # This code use Key Vault and Service Principal
# metadata_config = get_metadata_control_db_connection_info('meta')
# 
# jdbc_hostname = metadata_config['server']
# jdbc_database = metadata_config['database']
# jdbc_url = (
#   f"jdbc:sqlserver://{jdbc_hostname}:1433;"
#   f"database={jdbc_database};"
#   f"authentication=ActiveDirectoryServicePrincipal;"
#   f"aadSecurePrincipalId={metadata_config['client_id']};"
#   f"aadSecurePrincipalSecret={metadata_config['client_secret']};"
#   f"aadAuthority=https://login.microsoftonline.com/{metadata_config['tenant_id']}"
# )
# driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
# 
# def _test_jdbc_connection(jdbc_url,driver):
# 
#     try:
#         (spark.read.format("jdbc")
#         .option("url", jdbc_url)
#         .option("dbtable", "(SELECT 'Successfull' AS Result) t")
#         .option("driver", driver)
#         .load()
#         ).show()
#     except Exception as e:
#         logging.error(f"Failed to retrieve database connection information: {str(e)}")
#         raise
# 
# _test_jdbc_connection(jdbc_url,driver)


# MARKDOWN ********************

# ## Load config file to dataframe


# MARKDOWN ********************

# Make sure you have created the connections specified inside the .YML file by running the following scrips
# 
# 
# 
# exec meta.usp_upsert_con_settings
#      @connection_name = 'conn_fabric_sql_can_rmdd',
#      @connection_settings = '{"fabric_connection_id":"7c9005a5-6f9c-4ac9-872e-6968b69d72fd","server":"hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com","database":"CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e"}',
#      @passphrase = 'temp-passphrase'; 
# 
# 
# exec meta.usp_upsert_con_settings
#      @connection_name = 'conn_fabric_sql_nrfc_people',
#      @connection_settings = '{"fabric_connection_id":"44f6f64e-5592-4f74-9976-36ac0e6d920f"}',
#      @passphrase = 'temp-passphrase'; 
