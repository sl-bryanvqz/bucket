# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# MARKDOWN ********************

# ##### Metadata database shared functions
# 
# This notebook contains helper functions used by `nb_load_metadata_config`.
# 
# It reads YAML metadata config, validates it, stages valid records into `meta.temp_task`, and merges staged records into `meta.task`.

# CELL ********************

import sys
import json
import yaml
import time
import struct
import urllib
import logging
import urllib.parse
import notebookutils

from typing import Dict, Any, Optional, List
from sqlalchemy import create_engine, text
from pyspark.sql import SparkSession, Row, functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, LongType, ArrayType

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Logging and file maintenance functions
# 
# This section contains shared logging and file maintenance helpers.

# CELL ********************

# Define a function for logging
def setup_logging():
    FORMAT = "%(asctime)s UTC - %(levelname)s - %(message)s (%(name)s)"
    formatter = logging.Formatter(fmt=FORMAT)

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.WARNING)

    if not root_logger.handlers:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)
        root_logger.addHandler(console_handler)
    else:
        for handler in root_logger.handlers:
            handler.setFormatter(formatter)


logger = logging.getLogger("MetadataConfig")


# Define a helper class to delete empty directories
class DirectoryMaintenance:
    def __init__(self):
        pass

    def _ls(self, path):
        try:
            return notebookutils.fs.ls(path)
        except Exception:
            return []

    def _is_dir(self, entry):
        return getattr(entry, "isDir", False)

    def _depth(self, path: str) -> int:
        return path.strip("/").count("/")

    def delete_empty_directories(self, root: str, protect_root: bool = True) -> None:
        stack = [root]
        directories = set()

        while stack:
            current = stack.pop()
            entries = self._ls(current)

            for entry in entries:
                if self._is_dir(entry):
                    directories.add(entry.path)
                    stack.append(entry.path)

        directories = list(directories | {root})
        directories.sort(key=self._depth, reverse=True)

        for directory in directories:
            if protect_root and directory.rstrip("/") == root.rstrip("/"):
                continue

            if len(self._ls(directory)) == 0:
                try:
                    notebookutils.fs.rm(directory, True)
                    file_path = f"Files/{directory.split('/Files/')[1]}"
                    logger.info(f"Deleted empty dir: {file_path}")
                except Exception:
                    pass

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Metadata control database connection functions
# 
# This section keeps the service principal and token-based metadata database connection logic.

# CELL ********************

# Get service principal authentication values from variable library and Key Vault
def get_sp_authentication_info():
    try:
        vl_authentication = notebookutils.variableLibrary.getLibrary("vl_authentication")
        vl_guids = notebookutils.variableLibrary.getLibrary("vl_guids")

        akv_uri = vl_authentication.akv_uri
        tenant_id_secret_name = vl_authentication.tenant_id_secret_name
        client_id_secret_name = vl_authentication.client_id_secret_name
        client_secret_name = vl_authentication.client_secret_name

        tenant_id = notebookutils.credentials.getSecret(akv_uri, tenant_id_secret_name)
        client_id = notebookutils.credentials.getSecret(akv_uri, client_id_secret_name)
        client_secret = notebookutils.credentials.getSecret(akv_uri, client_secret_name)

        if not all([tenant_id, client_id, client_secret]):
            raise ValueError("One or more secrets could not be retrieved from Key Vault")

        return {
            "tenant_id": tenant_id,
            "client_id": client_id,
            "client_secret": client_secret
        }

    except Exception as e:
        logging.error(f"Failed to retrieve authentication information: {str(e)}")
        raise


# Get metadata control database info for service principal connections
def get_metadata_control_db_connection_info(schema_name):
    try:
        vl_authentication = notebookutils.variableLibrary.getLibrary("vl_authentication")
        vl_guids = notebookutils.variableLibrary.getLibrary("vl_guids")

        akv_uri = vl_authentication.akv_uri
        tenant_id_secret_name = vl_authentication.tenant_id_secret_name
        client_id_secret_name = vl_authentication.client_id_secret_name
        client_secret_name = vl_authentication.client_secret_name

        tenant_id = notebookutils.credentials.getSecret(akv_uri, tenant_id_secret_name)
        client_id = notebookutils.credentials.getSecret(akv_uri, client_id_secret_name)
        client_secret = notebookutils.credentials.getSecret(akv_uri, client_secret_name)

        if not all([tenant_id, client_id, client_secret]):
            raise ValueError("One or more secrets could not be retrieved from Key Vault")

        # Get metadata control SQL endpoint values
        server = vl_guids.metadata_control_sql_endpoint_server
        database = vl_guids.metadata_control_sql_endpoint_database

        return {
            "tenant_id": tenant_id,
            "client_id": client_id,
            "client_secret": client_secret,
            "server": server,
            "database": database,
            "schema_name": schema_name
        }

    except Exception as e:
        logging.error(f"Failed to retrieve database connection information: {str(e)}")
        raise


# Get metadata control database server and database for token connections
def get_metadata_control_db_connection_server_db_info():
    try:
        vl_guids = notebookutils.variableLibrary.getLibrary("vl_guids")

        # Get metadata control SQL endpoint values
        server = vl_guids.metadata_control_sql_endpoint_server
        database = vl_guids.metadata_control_sql_endpoint_database

        return {
            "server": server,
            "database": database
        }

    except Exception as e:
        logging.error(f"Failed to retrieve database connection information: {str(e)}")
        raise


# Get generic database info with service principal credentials
def get_db_connection_info(server, database, schema_name):
    try:
        auth_info = get_sp_authentication_info()

        tenant_id = auth_info.get("tenant_id")
        client_id = auth_info.get("client_id")
        client_secret = auth_info.get("client_secret")

        if not all([tenant_id, client_id, client_secret]):
            raise ValueError("One or more secrets could not be retrieved from Key Vault")

        return {
            "tenant_id": tenant_id,
            "client_id": client_id,
            "client_secret": client_secret,
            "server": server,
            "database": database,
            "schema_name": schema_name
        }

    except Exception as e:
        logging.error(f"Failed to retrieve database connection information: {str(e)}")
        raise


# Get connection settings from meta.connections
def connection_info(metadata_db, connection_id):
    conn = metadata_db.execute_query(f"SELECT * FROM meta.connections WHERE connection_id = {connection_id}")
    connection_settings = json.loads(conn[0].get("connection_settings"))

    server = connection_settings.get("server")
    database = connection_settings.get("database")

    return {
        "server": server,
        "database": database
    }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### SQL database class
# 
# This section defines the SQL helper class used to execute queries, non-query statements, and stored procedures.

# CELL ********************

class SQLDatabase:
    def __init__(self, server: str, database: str, client_id: str, client_secret: str, schema_name: str):
        match client_id:
            case None:
                self.server = server
                self.database = database
                self.engine = None
                self._create_engine_token()

            case _:
                self.server = server
                self.database = database
                self.client_id = client_id
                self.client_secret = client_secret
                self.schema_name = schema_name
                self.engine = None
                self._create_engine()

    def _create_engine(self):
        connection_string = (
            f"DRIVER={{ODBC Driver 18 for SQL Server}};"
            f"SERVER={self.server};"
            f"DATABASE={self.database};"
            f"UID={self.client_id};"
            f"PWD={self.client_secret};"
            f"Authentication=ActiveDirectoryServicePrincipal;"
            f"DefaultSchema={self.schema_name};"
            f"Encrypt=yes;"
        )

        params = urllib.parse.quote_plus(connection_string)
        self.engine = create_engine(f"mssql+pyodbc:///?odbc_connect={params}")

    def _create_engine_token(self):
        token = notebookutils.credentials.getToken("https://database.windows.net/.default")

        token_bytes = token.encode("utf-16-le")
        token_struct = struct.pack(f"<I{len(token_bytes)}s", len(token_bytes), token_bytes)

        connection_string = (
            f"DRIVER={{ODBC Driver 18 for SQL Server}};"
            f"SERVER={self.server};"
            f"DATABASE={self.database};"
            f"Encrypt=yes;"
            f"TrustServerCertificate=no;"
        )

        params = urllib.parse.quote_plus(connection_string)

        self.engine = create_engine(
            f"mssql+pyodbc:///?odbc_connect={params}",
            connect_args={"attrs_before": {1256: token_struct}}
        )

    def execute_query(self, query: str, params: Optional[Dict[str, Any]] = None) -> List[Dict]:
        try:
            with self.engine.connect() as conn:
                if params:
                    result = conn.execute(text(query), params)
                else:
                    result = conn.execute(text(query))

                columns = result.keys()
                return [dict(zip(columns, row)) for row in result.fetchall()]

        except Exception as e:
            logging.error(f"Error executing query: {e}")
            raise

    def execute_non_query(self, query: str, params: Optional[Dict[str, Any]] = None) -> int:
        try:
            with self.engine.connect() as conn:
                if params:
                    result = conn.execute(text(query), params)
                else:
                    result = conn.execute(text(query))

                conn.commit()
                return result.rowcount

        except Exception as e:
            logging.error(f"Error executing non-query: {e}")
            raise

    def execute_stored_procedure(self, proc_name: str, show_query: bool = False, return_results: bool = False, **params) -> Any:
        exec_statement = self._build_exec_statement(proc_name, **params)

        if show_query:
            print(exec_statement)

        if return_results:
            return self.execute_query(exec_statement)
        else:
            return self.execute_non_query(exec_statement)

    def _build_exec_statement(self, proc_name: str, **params) -> str:
        param_strs = []

        for key, value in params.items():
            if value is not None:
                if isinstance(value, str):
                    param_strs.append(f"@{key}='{value}'")
                else:
                    param_strs.append(f"@{key}={value}")

        if param_strs:
            return f"EXEC {proc_name} " + ", ".join(param_strs)
        else:
            return f"EXEC {proc_name}"

    def test_connection(self) -> bool:
        try:
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
                return True

        except Exception as e:
            logging.error(f"Connection test failed: {e}")
            return False

    def close(self):
        if self.engine:
            self.engine.dispose()

    @classmethod
    def from_metadata_control_db(cls, schema_name: str):
        connection_info = get_metadata_control_db_connection_info(schema_name)

        server = connection_info.get("server")
        database = connection_info.get("database")
        client_id = connection_info.get("client_id")
        client_secret = connection_info.get("client_secret")
        schema_name = connection_info.get("schema_name")

        return cls(server, database, client_id, client_secret, schema_name)

    @classmethod
    def from_metadata_control_db_token(cls, schema_name: str = "meta"):
        connection_info = get_metadata_control_db_connection_server_db_info()

        server = connection_info.get("server")
        database = connection_info.get("database")

        return cls(server, database, None, None, schema_name)

    @classmethod
    def from_generic_db(cls, server: str, database: str, schema_name: str = "dbo"):
        connection_info = get_db_connection_info(server, database, schema_name)

        server = connection_info.get("server")
        database = connection_info.get("database")
        client_id = connection_info.get("client_id")
        client_secret = connection_info.get("client_secret")
        schema_name = connection_info.get("schema_name")

        return cls(server, database, client_id, client_secret, schema_name)

    @classmethod
    def from_generic_db_token(cls, server: str, database: str, schema_name: str = "dbo"):
        return cls(server, database, None, None, schema_name)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### YAML config helper functions
# 
# This section reads the YAML metadata config and converts it into one metadata row per object/stage.

# CELL ********************

# Load one database table using service principal JDBC settings
def load_db_table_sp(jdbc_url: str, driver: str, table_name: str):
    df_table = (
        spark.read.format("jdbc")
        .option("url", jdbc_url)
        .option("dbtable", table_name)
        .option("driver", driver)
        .load()
    )

    return df_table


# Load one database table using Fabric token authentication
def load_db_table(table_name: str):
    connection_info = get_metadata_control_db_connection_server_db_info()
    server = connection_info.get("server")
    database = connection_info.get("database")

    token = notebookutils.credentials.getToken("https://database.windows.net/.default")

    spark_df = (
        spark.read.format("jdbc")
        .option("url", f"jdbc:sqlserver://{server}:1433;database={database};encrypt=true;")
        .option("dbtable", table_name)
        .option("accessToken", token)
        .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
        .load()
    )

    return spark_df


# Define dataframe schema before source_connection_id is added
def define_task_schema():
    schema = StructType([
        StructField("task_id", IntegerType(), True),
        StructField("task_name", StringType(), True),
        StructField("object_name", StringType(), True),
        StructField("stage", StringType(), True),
        StructField("source_connection_name", StringType(), True),
        StructField("source_settings", StringType(), True),
        StructField("target_settings", StringType(), True),
        StructField("option_settings", StringType(), True),
        StructField("template_settings", StringType(), True),
        StructField("enabled", IntegerType(), True),
        StructField("file_hash", StringType(), True),
        StructField("scheduling_settings", StringType(), True),
        StructField("enable_retries", IntegerType(), True),
        StructField("max_retry_attempts", IntegerType(), True)
    ])

    return schema


# Read YAML file from notebook resources
def read_yaml_file(path: str) -> str:
    with open(path) as data:
        config = yaml.safe_load(data)

    return config


# Normalize stage names for matching YAML sections
def normalize_stage(name: str) -> str:
    stage_name = (name or "").strip().lower()
    stage_name = stage_name.replace(" ", "_")

    return stage_name


# Get stage list from explicit stage property or infer it from settings
def get_table_stages(tbl: dict) -> list:
    stages = tbl.get("stage")

    if isinstance(stages, str):
        stages = [stages]

    if isinstance(stages, list) and stages:
        return [normalize_stage(stage) for stage in stages]

    found = []

    for sect in ("source_settings", "target_settings"):
        for item in tbl.get(sect, []) or []:
            for key in item.keys():
                stage_name = normalize_stage(key)

                if stage_name and stage_name not in found:
                    found.append(stage_name)

    return found


# Merge dictionaries for one stage into one dictionary
def get_stage_settings(items: list, stage_name: str) -> dict:
    merged = {}

    for item in items or []:
        for key, value in item.items():
            if normalize_stage(key) == stage_name and isinstance(value, dict):
                merged.update(value)

    return merged


# Convert dictionary values to JSON strings
def to_json_or_none(obj: dict) -> str:
    if not obj:
        return None

    try:
        return json.dumps(obj, ensure_ascii=False)

    except Exception:
        return json.dumps({key: str(value) for key, value in obj.items()}, ensure_ascii=False)


# Convert YAML config into one dataframe row per object/stage
def yaml_to_stage_rows(yaml_path: str):
    cfg = read_yaml_file(yaml_path)
    tables = cfg.get("tables") or []

    rows = []

    for tbl in tables:
        object_name = tbl.get("object_name")
        stages = get_table_stages(tbl)

        # Convert YAML boolean values to metadata integer flags
        enabled_val = 1 if str(tbl.get("enabled")).strip().lower() in ["1", "true", "yes", "y"] else 0
        enable_retries_val = 1 if str(tbl.get("enable_retries")).strip().lower() in ["1", "true", "yes", "y"] else 0
        max_retry_attempts_val = int(tbl.get("max_retry_attempts") or 0)

        file_hash_val = tbl.get("file_hash")
        file_hash_val = str(file_hash_val) if file_hash_val not in (None, "", []) else None

        src_items = tbl.get("source_settings") or []
        tgt_items = tbl.get("target_settings") or []
        scheduling_items = tbl.get("scheduling_settings") or []
        source_conn_items = tbl.get("source_connections") or []
        template_set_items = tbl.get("template_settings") or []
        option_set_items = tbl.get("option_settings") or []

        for i, stage_name in enumerate(stages):
            src_det = get_stage_settings(src_items, stage_name)
            tgt_det = get_stage_settings(tgt_items, stage_name)
            scheduling_det = get_stage_settings(scheduling_items, stage_name)
            source_connection_det = get_stage_settings(source_conn_items, stage_name)
            template_set_det = get_stage_settings(template_set_items, stage_name)
            option_set_det = get_stage_settings(option_set_items, stage_name)

            det = dict(src_det)

            for key, value in tgt_det.items():
                det.setdefault(key, value)

            task_name = det.get("task_name")

            src_det = {key: value for key, value in src_det.items() if key != "task_name"}
            tgt_det = {key: value for key, value in tgt_det.items() if key != "task_name"}

            src_json = to_json_or_none(src_det)
            tgt_json = to_json_or_none(tgt_det)
            schd_json = to_json_or_none(scheduling_det)
            temp_json = to_json_or_none(template_set_det)
            option_json = to_json_or_none(option_set_det)

            rows.append(Row(
                task_id=None,
                task_name=task_name,
                object_name=str(object_name) if object_name is not None else None,
                stage=tbl.get("stage")[i],
                source_connection_name=source_connection_det.get("source_connection_name", None),
                source_settings=src_json,
                target_settings=tgt_json,
                option_settings=option_json,
                template_settings=temp_json,
                enabled=enabled_val,
                file_hash=file_hash_val,
                scheduling_settings=schd_json,
                enable_retries=enable_retries_val,
                max_retry_attempts=max_retry_attempts_val
            ))

        print(f"Successfully loaded config to dataframe for object:{object_name}")

    schema = define_task_schema()
    df = spark.createDataFrame(rows, schema=schema)

    df_con = load_db_table("meta.connections").select("connection_id", "connection_name")

    df = df.join(df_con, (df.source_connection_name == df_con.connection_name), how="left")
    df = df.withColumnRenamed("connection_id", "source_connection_id")

    columns_seq = load_db_table("meta.task").columns

    return df.select(columns_seq)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Metadata config validation functions
# 
# This section validates metadata config rows before loading them into the metadata control database.

# CELL ********************

# Define validation constants
_allowed_stages = ["Extract", "Load to bronze", "Load to silver", "Silver Transform"]
_extract_source_keys = ["schema_name", "table_name", "is_incremental"]
_to_bronze_source_keys = ["target_file_path", "target_file_name", "target_file_type"]
_to_silver_source_keys = ["schema_name", "table_name"]
_extract_target_keys = ["target_file_path", "target_file_name"]
_to_bronze_target_keys = ["schema_name", "table_name", "load_strategy"]
_to_silver_target_keys = ["schema_name", "table_name", "load_strategy", "primary_keys"]
_valid_scheduled_types = ["interval", "time_of_day", "monthly", "yearly", "weekly"]

time_pattern = r"^(?:[01]\d|2[0-3]):[0-5]\d$"
time_pattern_arr = r"^(?:[01][0-9]|2[0-3]):[0-5][0-9]$"


# Define scheduling validation rules
_scheduling_rules = [
    (
        (F.col("schedule_type").isNull()) | F.col("schedule_type").isin(_valid_scheduled_types),
        f"schedule_type must be one of {_valid_scheduled_types} "
    ),
    (
        (F.col("schedule_type") != "interval") | (F.col("frequency_minutes").isNotNull() & (F.col("frequency_minutes") > 0)),
        "interval: frequency_minutes must be > 0 and not null"
    ),
    (
        (F.col("schedule_type") != "time_of_day") | (
            F.col("scheduled_times").isNotNull()
            & (F.size("scheduled_times") > 0)
            & F.expr(f"forall(scheduled_times, t -> lpad(t, 5, '0') rlike '{time_pattern_arr}')")
        ),
        "time_of_day: scheduled_times must be non-empty array of HH:mm"
    ),
    (
        (F.col("schedule_type") != "monthly") | (
            F.coalesce(F.col("day_of_month"), F.lit(0)).cast("int").between(1, 31)
            & F.col("time").isNotNull()
            & F.col("time").rlike(time_pattern)
        ),
        "monthly: day_of_month 1-31 and time HH:mm required (no multiple times)"
    ),
    (
        (F.col("schedule_type") != "yearly") | (
            F.col("day").cast("int").isNotNull()
            & F.col("month").cast("int").between(1, 12)
            & F.to_date(
                F.concat_ws("-", F.lit(F.year(F.current_timestamp())), F.col("month").cast("int"), F.col("day").cast("int")),
                "yyyy-M-d"
            ).isNotNull()
            & F.col("time").isNotNull()
            & F.col("time").rlike(time_pattern)
        ),
        "yearly: valid year-month-day (incl. leap years) and time HH:mm required"
    ),
    (
        (F.col("schedule_type") != "weekly") | (
            (F.size("days_of_week") > 0)
            & F.expr("forall(days_of_week, x -> x >= 1 AND x <= 7)")
            & F.col("time").isNotNull()
            & F.col("time").rlike(time_pattern)
        ),
        "Weekly: days_of_week (values 1-7) and time HH:mm required"
    )
]


# Append validation warning to dataframe
def append_error(df, new_err_col):
    if "warning" not in df.columns:
        return df.withColumn("warning_code", F.lit("")).withColumn("warning", F.lit(None))

    df = df.withColumn(
        "warning",
        F.when(
            df.warning.isNotNull() & new_err_col.isNotNull(),
            F.concat_ws(" | ", df.warning, new_err_col)
        ).otherwise(
            F.when(new_err_col.isNotNull(), new_err_col).otherwise(df.warning)
        )
    )

    df = df.withColumn(
        "warning_code",
        F.when(
            df.warning != "",
            F.lit("E")
        ).otherwise(
            F.when(new_err_col.isNotNull(), new_err_col).otherwise(df.warning_code)
        )
    )

    return df


# Validate stage values
def add_stage_validation(df):
    allowed = _allowed_stages

    new_err = F.when(
        ~F.col("stage").isin(allowed),
        F.format_string(
            "Invalid stage '%s'. Allowed values: %s",
            F.col("stage"),
            F.lit(", ".join(allowed))
        )
    )

    return append_error(df, new_err)


# Validate source_settings and target_settings JSON keys
def settings_validation(df, field_validating_for, extract_source_keys, to_bronze_source_keys, to_silver_source_keys):
    src = F.col(field_validating_for)

    def j(key):
        return F.get_json_object(src, f"$.{key}")

    stage = F.col("stage")

    if field_validating_for == "source_settings":
        is_incr_raw = F.lower(F.trim(j("is_incremental")))
        is_incr_true = is_incr_raw.isin("1", "true", "yes", "y")

    extract = stage == "Extract"
    bronze = stage == "Load to bronze"
    silver = stage == "Load to silver"

    error_parts = []

    for key in extract_source_keys:
        error_parts.append(
            F.when(
                extract & (j(key).isNull() | (F.trim(j(key)) == "")),
                F.lit(f"Extract: {field_validating_for} .{key} is required")
            ).otherwise(F.lit(None))
        )

    if field_validating_for == "source_settings":
        for key in ["incremental_column", "incremental_col_data_type"]:
            error_parts.append(
                F.when(
                    extract & is_incr_true & (j(key).isNull() | (F.trim(j(key)) == "")),
                    F.lit(f"Extract: {field_validating_for}.{key} is required when is_incremental is 1/true")
                )
            )

    for key in to_bronze_source_keys:
        error_parts.append(
            F.when(
                bronze & (j(key).isNull() | (F.trim(j(key)) == "")),
                F.lit(f"Load to bronze: {field_validating_for}.{key} is required")
            )
        )

    for key in to_silver_source_keys:
        error_parts.append(
            F.when(
                silver & (j(key).isNull() | (F.trim(j(key)) == "")),
                F.lit(f"Load to bronze: {field_validating_for}.{key} is required")
            )
        )

    if len(error_parts) > 0:
        new_err = F.concat_ws(" | ", *error_parts)

    return append_error(df, new_err)


# Validate source connection id for Extract stage
def source_connection_validation(df):
    new_err = F.when(
        (F.col("stage") == "Extract")
        & (
            F.col("source_connection_id").isNull()
            | (F.trim(F.col("source_connection_id")) == "")
        ),
        F.lit("Extract: source_connection_id is required")
    ).otherwise(F.lit(None))

    return append_error(df, new_err)


# Validate scheduling JSON
def validate_scheduling(df, col="scheduling_settings"):
    scheduling_schema = StructType([
        StructField("schedule_type", StringType()),
        StructField("frequency_minutes", IntegerType()),
        StructField("scheduled_times", ArrayType(StringType())),
        StructField("day_of_month", StringType()),
        StructField("day", StringType()),
        StructField("month", StringType()),
        StructField("time", StringType()),
        StructField("days_of_week", ArrayType(IntegerType()))
    ])

    df1 = (
        df.withColumn("sched", F.from_json(F.col(col), scheduling_schema))
        .select("*", "sched.*")
        .drop("sched")
    )

    for cond, message in _scheduling_rules:
        new_err = F.when(~cond, F.lit(message)).otherwise(F.lit(None))
        df1 = append_error(df1, new_err)

    return df1


# Run all metadata config validations
def final_validation(df):
    df_new = settings_validation(df, "source_settings", _extract_source_keys, _to_bronze_source_keys, _to_silver_source_keys)
    df_new = settings_validation(df_new, "target_settings", _extract_target_keys, _to_bronze_target_keys, _to_silver_target_keys)
    df_new = source_connection_validation(df_new)
    df_new = validate_scheduling(df_new)

    return df_new.filter("warning_code=='E'").drop("warning_code")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Metadata control database load functions
# 
# This section stages validated metadata rows into `meta.temp_task` and merges them into `meta.task`.

# CELL ********************

# Load metadata rows into staging table using service principal JDBC settings
def load_staging_table_sp(df_current):
    df_current = df_current.drop("task_id")

    writer = (
        df_current.write.format("jdbc")
        .option("url", jdbc_url)
        .option("dbtable", "meta.temp_task")
        .option("driver", driver)
        .mode("overwrite")
    )

    writer.save()


# Load metadata rows into staging table using Fabric token authentication
def load_staging_table(df_current):
    connection_info = get_metadata_control_db_connection_server_db_info()
    server = connection_info.get("server")
    database = connection_info.get("database")

    df_current = df_current.drop("task_id")

    token = notebookutils.credentials.getToken("https://database.windows.net/.default")

    writer = (
        df_current.write.format("jdbc")
        .option("url", f"jdbc:sqlserver://{server}:1433;database={database};encrypt=true;")
        .option("dbtable", "meta.temp_task")
        .option("accessToken", token)
        .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
        .mode("overwrite")
    )

    writer.save()


# Build SQL Server merge statement
def build_merge_sql(
    target_schema: str,
    target_table: str,
    staging_schema: str,
    staging_table: str,
    keys: List[str],
    update_cols: List[str],
    insert_cols: List[str],
) -> str:
    t_full = f"{target_schema}.{target_table}"
    s_full = f"{staging_schema}.{staging_table}"

    on_clause = " AND ".join([f"t.{key} = s.{key}" for key in keys])
    set_clause = ",\n        ".join([f"t.{column} = s.{column}" for column in update_cols])
    insert_cols_list = ", ".join([column for column in insert_cols])
    insert_vals_list = ", ".join([f"s.{column}" for column in insert_cols])

    sql = f"""
MERGE {t_full} AS t
USING {s_full} AS s
    ON {on_clause}
WHEN MATCHED THEN
    UPDATE SET
        {set_clause}
WHEN NOT MATCHED BY TARGET THEN
    INSERT ({insert_cols_list})
    VALUES ({insert_vals_list});
"""

    return sql.strip()


# Execute merge using service principal connection
def merge_metadata_task_sp(merge_query):
    metadata_db = SQLDatabase.from_metadata_control_db(schema_name="meta")

    rows = metadata_db.execute_non_query(merge_query)

    print(f"MERGED {rows} rows successfully into meta.task table")

    return rows


# Execute merge using Fabric token connection
def merge_metadata_task(merge_query):
    metadata_db_token = SQLDatabase.from_metadata_control_db_token()

    rows = metadata_db_token.execute_non_query(merge_query)

    print(f"MERGED {rows} rows successfully into meta.task table")

    return rows

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
