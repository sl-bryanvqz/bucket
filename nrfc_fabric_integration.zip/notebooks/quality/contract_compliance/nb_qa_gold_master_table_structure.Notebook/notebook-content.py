# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

from pyspark.sql.types import *
import pandas as pd
import json
from typing import Dict, List, Tuple
from datetime import datetime

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Recive as parameter - Update these paths as needed

#json_schema_path = "/lakehouse/default/Files/contract/address.json"

#delta_table_name = "lh_canada_global_mds.gold_master.gold_master_address"  # The delta table name in the lakehouse

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Load and parse the JSON schema definition
try:
    with open(json_schema_path, 'r') as f:
        json_schema = json.load(f)
    
    print(f"✓ JSON schema loaded successfully from: {json_schema_path}")
    print(f"\nSchema Details:")
    print(f"  - Entity Code: {json_schema.get('code')}")
    print(f"  - Entity Name: {json_schema.get('name')}")
    print(f"  - Description: {json_schema.get('description')}")
    print(f"  - Type: {json_schema.get('type')}")
    print(f"  - Total Columns Defined: {len(json_schema.get('columns', []))}")
    
except FileNotFoundError:
    print(f"✗ JSON file not found at: {json_schema_path}")
    print("Please update the json_schema_path variable with the correct file location.")
except json.JSONDecodeError as e:
    print(f"✗ Error parsing JSON file: {e}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Read the delta table
try:
    delta_df = spark.table(delta_table_name)
    
    print(f"✓ Delta table '{delta_table_name}' loaded successfully")
    print(f"\nDelta Table Schema:")
    print(f"  - Total Columns: {len(delta_df.columns)}")
    print(f"  - Row Count: {delta_df.count()}")    
    
except Exception as e:
    print(f"✗ Error reading delta table '{delta_table_name}': {e}")
    print("Please ensure the table name is correct and exists in the lakehouse.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def parse_json_schema(schema_dict: Dict) -> pd.DataFrame:
    """
    Parse JSON schema into a structured DataFrame for comparison.
    
    Args:
        schema_dict: The parsed JSON schema dictionary
        
    Returns:
        DataFrame with parsed column definitions
    """
    columns_data = []
    
    for col in schema_dict.get('columns', []):
        col_info = {
            'Sort Order': col.get('sortOrder'),
            'Column Name': col.get('columnName'),
            'Data Type': col.get('dataType', {}).get('name'),
            'Type Length': col.get('dataType', {}).get('length'),
            'Is Nullable': col.get('dataType', {}).get('isNullable'),
            'Is Primary Key': col.get('isPrimaryKey'),
            'Is Natural Key': col.get('isNaturalKey'),
            'Classification': col.get('dataClassification', {}).get('classification')
        }
        columns_data.append(col_info)
    
    return pd.DataFrame(columns_data)

# Parse the JSON schema
json_columns_df = parse_json_schema(json_schema)

print("✓ JSON schema parsed successfully\n")
print("JSON Schema Column Definitions:")
print(json_columns_df.to_string(index=False))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.types import StructType

def map_pyspark_type_to_sql(pyspark_type: DataType) -> str:
    """
    Map PySpark data types to SQL-like type strings for comparison.
    
    Args:
        pyspark_type: PySpark DataType
        
    Returns:
        String representation of the data type
    """
    type_mapping = {
        'IntegerType': 'int',
        'LongType': 'bigint',
        'ShortType': 'smallint',
        'ByteType': 'tinyint',
        'FloatType': 'float',
        'DoubleType': 'double',
        'DecimalType': 'decimal',
        'StringType': 'nvarchar',
        'BinaryType': 'binary',
        'BooleanType': 'bit',
        'TimestampType': 'datetime',
        'DateType': 'date',
        'ArrayType': 'array',
        'MapType': 'map',
        'StructType': 'struct'
    }
    
    pyspark_type_str = str(type(pyspark_type).__name__)
    return type_mapping.get(pyspark_type_str, pyspark_type_str)

def get_delta_schema_info(delta_df) -> pd.DataFrame:
    """
    Extract schema information from a PySpark DataFrame.
    
    Args:
        delta_df: PySpark DataFrame
        
    Returns:
        DataFrame with delta table schema information
    """
    schema_data = []
    
    for field in delta_df.schema.fields:
        schema_info = {
            'Column Name': field.name,
            'Data Type': map_pyspark_type_to_sql(field.dataType),
            'Is Nullable': field.nullable
        }
        schema_data.append(schema_info)
    
    return pd.DataFrame(schema_data)

# Get delta table schema information
delta_columns_df = get_delta_schema_info(delta_df)

print("✓ Delta table schema extracted\n")
#print("Delta Table Column Definitions:")
#print(delta_columns_df.to_string(index=False))

# Perform comparison
print("\n" + "="*80)
print("COLUMN COMPARISON ANALYSIS")
print("="*80)

# Extract column names for comparison
json_column_names = set(json_columns_df['Column Name'].tolist())
delta_column_names = set(delta_columns_df['Column Name'].tolist())

# Identify differences
matching_columns = json_column_names.intersection(delta_column_names)
missing_from_delta = json_column_names - delta_column_names
extra_in_delta = delta_column_names - json_column_names

# print(f"\n✓ Matching Columns: {len(matching_columns)}")
# print(f"✗ Missing from Delta: {len(missing_from_delta)}")
# print(f"⚠ Extra in Delta: {len(extra_in_delta)}")

# Store results for later use
comparison_results = {
    'matching': matching_columns,
    'missing': missing_from_delta,
    'extra': extra_in_delta
}

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def generate_comparison_report(json_df: pd.DataFrame, 
                               delta_df_schema: pd.DataFrame,
                               json_columns: set,
                               delta_columns: set) -> Dict:
    """
    Generate a comprehensive comparison report.
    
    Args:
        json_df: DataFrame with JSON schema columns
        delta_df_schema: DataFrame with delta table schema
        json_columns: Set of JSON column names
        delta_columns: Set of delta table column names
        
    Returns:
        Dictionary with detailed comparison report
    """
    report = {
        'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'summary': {},
        'matching_columns': [],
        'missing_columns': [],
        'extra_columns': [],
        'type_mismatches': [],
        'nullable_mismatches': []
    }
    
    # Matching columns with type comparison
    matching_cols = json_columns.intersection(delta_columns)
    
    for col_name in sorted(matching_cols):
        json_row = json_df[json_df['Column Name'] == col_name].iloc[0]
        delta_row = delta_df_schema[delta_df_schema['Column Name'] == col_name].iloc[0]
        
        json_type = json_row['Data Type']
        delta_type = delta_row['Data Type']
        
        match_info = {
            'column_name': col_name,
            'json_type': json_type,
            'delta_type': delta_type,
            'json_nullable': json_row['Is Nullable'],
            'delta_nullable': delta_row['Is Nullable'],
            'type_match': (json_type.lower() == delta_type.lower() or delta_type.lower() == json_type.lower()) or (json_type.lower() == 'float' and delta_type.lower() == 'double') 
             or (json_type.lower() == 'nvarchar' and delta_type.lower() == 'varchar') or (json_type.lower() == 'varchar' and delta_type.lower() == 'nvarchar'),
            'nullable_match': json_row['Is Nullable'] == delta_row['Is Nullable']   
        }
        
        report['matching_columns'].append(match_info)
        
        # Check for type mismatches
        if not match_info['type_match']:
            report['type_mismatches'].append(match_info)

        # Check for Nullable mismatches
        if not match_info['nullable_match']:
            report['nullable_mismatches'].append(match_info)
    
    # Missing columns (in JSON but not in Delta)
    missing_cols = json_columns - delta_columns
    for col_name in sorted(missing_cols):
        json_row = json_df[json_df['Column Name'] == col_name].iloc[0]
        report['missing_columns'].append({
            'column_name': col_name,
            'json_type': json_row['Data Type'],
            'json_nullable': json_row['Is Nullable']
        })
    
    # Extra columns (in Delta but not in JSON)
    extra_cols = delta_columns - json_columns
    for col_name in sorted(extra_cols):
        delta_row = delta_df_schema[delta_df_schema['Column Name'] == col_name].iloc[0]
        report['extra_columns'].append({
            'column_name': col_name,
            'delta_type': delta_row['Data Type'],
            'delta_nullable': delta_row['Is Nullable']
        })
    
    # Summary statistics
    report['summary'] = {
        'total_json_columns': len(json_columns),
        'total_delta_columns': len(delta_columns),
        'matching_count': len(matching_cols),
        'missing_count': len(missing_cols),
        'extra_count': len(extra_cols),
        'type_mismatch_count': len(report['type_mismatches']),
        'nullable_mismatch_count': len(report['nullable_mismatches']),
        'schema_status': 'COMPLIANT' if len(missing_cols) == 0 and len(report['type_mismatches']) == 0 else 'NON-COMPLIANT'
    }
    
    return report

# Generate the comparison report
report = generate_comparison_report(json_columns_df, 
                                    delta_columns_df,
                                    json_column_names,
                                    delta_column_names)

print("✓ Comparison report generated\n")
print("="*80)
print("COMPARISON REPORT SUMMARY")
print("="*80)
print(f"\nGenerated: {report['timestamp']}")
print(f"\nSchema Status: {report['summary']['schema_status']}")
print(f"\nStatistics:")
print(f"  • Total JSON Columns: {report['summary']['total_json_columns']}")
print(f"  • Total Delta Columns: {report['summary']['total_delta_columns']}")
print(f"  • Matching Columns: {report['summary']['matching_count']}")
print(f"  • Missing Columns: {report['summary']['missing_count']}")
print(f"  • Extra Columns: {report['summary']['extra_count']}")
print(f"  • Type Mismatches: {report['summary']['type_mismatch_count']}")
print(f"  • Nullable Mismatches: {report['summary']['nullable_mismatch_count']}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print("\n" + "="*80)
print("DETAILED DIFFERENCE ANALYSIS")
print("="*80)

# Section 1: Matching Columns
print(f"\n✓ MATCHING - DATA TYPE COLUMNS ({len(report['matching_columns'])} columns)")
print("-" * 80)

if report['matching_columns']:
    matching_df = pd.DataFrame(report['matching_columns'])
    matching_df = matching_df[['column_name', 'json_type', 'delta_type', 'type_match']]
    matching_df.columns = ['Column Name', 'JSON Type', 'Delta Type', 'Type Match']
    print(matching_df.to_string(index=False))
else:
    print("No matching columns found.")


# Section 1: Matching Columns
print(f"\n✓ MATCHING - NULLABLE COLUMNS ({len(report['matching_columns'])} columns)")
print("-" * 80)

if report['matching_columns']:
    matching_df = pd.DataFrame(report['matching_columns'])
    matching_df = matching_df[['column_name', 'json_nullable', 'delta_nullable','nullable_match']]
    matching_df.columns = ['Column Name', 'JSON Nullable', 'Delta Nullable','Nullable Match']
    print(matching_df.to_string(index=False))
else:
    print("No matching columns found.")

# Section 2: Missing Columns
print(f"\n\n✗ MISSING COLUMNS ({len(report['missing_columns'])} columns)")
print("Columns defined in JSON but NOT present in Delta table:")
print("-" * 80)

if report['missing_columns']:
    missing_df = pd.DataFrame(report['missing_columns'])
    missing_df.columns = ['Column Name', 'Expected Type', 'Expected Nullable']
    print(missing_df.to_string(index=False))
    print("\n⚠ ACTION REQUIRED: Add these columns to the delta table")
else:
    print("No missing columns found.")

# Section 3: Extra Columns
print(f"\n\n⚠ EXTRA COLUMNS ({len(report['extra_columns'])} columns)")
print("Columns present in Delta table but NOT defined in JSON:")
print("-" * 80)

if report['extra_columns']:
    extra_df = pd.DataFrame(report['extra_columns'])
    extra_df.columns = ['Column Name', 'Actual Type', 'Actual Nullable']
    print(extra_df.to_string(index=False))
    print("\n⚠ ACTION REQUIRED: Review if these columns should be in JSON definition")
else:
    print("No extra columns found.")

# Section 4: Data Type Mismatches
print(f"\n\n⚠ DATA TYPE MISMATCHES ({len(report['type_mismatches'])} columns)")
print("Columns with different data types between JSON and Delta:")
print("-" * 80)

if report['type_mismatches']:
    mismatch_df = pd.DataFrame(report['type_mismatches'])
    mismatch_df = mismatch_df[['column_name', 'json_type', 'delta_type', 'json_nullable', 'delta_nullable']]
    mismatch_df.columns = ['Column Name', 'JSON Type', 'Delta Type', 'JSON Nullable', 'Delta Nullable']
    print(mismatch_df.to_string(index=False))
    print("\n⚠ ACTION REQUIRED: Resolve data type differences")
else:
    print("No data type mismatches found.")


# Section 5: Data Nullable Mismatches
print(f"\n\n⚠ DATA NULLABLE MISMATCHES ({len(report['nullable_mismatches'])} columns)")
print("Columns with different nullable column between JSON and Delta:")
print("-" * 80)

if report['nullable_mismatches']:
    mismatch_df = pd.DataFrame(report['nullable_mismatches'])
    mismatch_df = mismatch_df[['column_name', 'json_nullable', 'delta_nullable']]
    mismatch_df.columns = ['Column Name', 'JSON Nullable', 'Delta Nullable']
    print(mismatch_df.to_string(index=False))
    print("\n⚠ ACTION REQUIRED: Resolve nullable differences")
else:
    print("No Nullable mismatches found.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import unittest
results = []

class TestDataValidation(unittest.TestCase):

    validation_result = None

    def test_no_missing_columns_from_delta(self):
        self.assertEqual(
            self.validation_result["missing_count"], 0
        )

    def test_no_type_mismatches(self):
        self.assertEqual(
            self.validation_result["type_mismatch_count"], 0
        )
    
    def test_no_nullable_mismatches(self):
        self.assertEqual(
            self.validation_result["nullable_mismatch_count"], 0
        )


class FabricTestResult(unittest.TestResult):

    def addSuccess(self, test):
        results.append({
            "test_name": test._testMethodName,
            "result": "PASSED"
        })

    def addFailure(self, test, err):
        results.append({
            "test_name": test._testMethodName,
            "result": "FAILED"
        })

    def addError(self, test, err):
        results.append({
            "test_name": test._testMethodName,
            "result": "ERROR"
        })

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

TestDataValidation.validation_result = report['summary']

suite = unittest.TestLoader().loadTestsFromTestCase(TestDataValidation)
suite.run(FabricTestResult())

print("="*80)
print("\n⚠ TEST RESULTS: ")
print("="*80)

df_results = pd.DataFrame(results)
display(df_results)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
