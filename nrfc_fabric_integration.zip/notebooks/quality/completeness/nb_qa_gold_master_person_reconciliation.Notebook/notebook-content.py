# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Data Quality Validation
# This notebook performs Canonical tables queries against Development tables to evaluate:
# - Missing Records Validation
# - Reconciliation

# CELL ********************

from pyspark.sql import functions as F
from datetime import datetime
import unittest
import pandas as pd

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

lakehouse_name = 'lh_canada_global_mds'
schema_name = 'gold_master'
dev_prefix = 'dev_'
table_name = "gold_master_person"

source_table = f"{lakehouse_name}.{schema_name}.{dev_prefix}{table_name}"

target_table = f"{lakehouse_name}.{schema_name}.{table_name}"

join_keys = ['person_id']


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# 5. Reconciliation Validation
def validate_reconciliation(source_table, target_table, join_keys):
    """
    Validate data reconciliation between source and target tables
    
    Args:
        source_table: Name of the source Delta table
        target_table: Name of the target Delta table
        join_keys: List of column names to join on
        comparison_columns: List of columns to compare
    
    Returns:
        Dictionary with validation results
    """
    try:
        join_condition = " AND ".join([f"src.{key} = tgt.{key}" for key in join_keys])
        
        # Count records
        source_count = spark.sql(f"SELECT COUNT(*) as cnt FROM {source_table}").collect()[0]['cnt']
        target_count = spark.sql(f"SELECT COUNT(*) as cnt FROM {target_table}").collect()[0]['cnt']
        
        # Find missing in target
        missing_query = f"""
        SELECT COUNT(*) as cnt FROM {source_table} src
        LEFT JOIN {target_table} tgt ON {join_condition}
        WHERE tgt.{join_keys[0]} IS NULL
        """
        missing_in_target = spark.sql(missing_query).collect()[0]['cnt']
        
        # Find missing in source
        missing_query_src = f"""
        SELECT COUNT(*) as cnt FROM {target_table} tgt
        LEFT JOIN {source_table} src ON {join_condition}
        WHERE src.{join_keys[0]} IS NULL
        """
        missing_in_source = spark.sql(missing_query_src).collect()[0]['cnt']
        
        return {
            'validation_type': 'Reconciliation',
            'source_table': source_table,
            'target_table': target_table,
            'source_record_count': source_count,
            'target_record_count': target_count,
            'missing_in_target': missing_in_target,
            'missing_in_source': missing_in_source,
            'record_count_match': source_count == target_count,
            'timestamp': datetime.now().isoformat()
        }
    except Exception as e:
        return {
            'validation_type': 'Reconciliation',
            'source_table': source_table,
            'target_table': target_table,
            'status': 'ERROR',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

validation_result = validate_reconciliation(source_table, target_table, join_keys)

validation_result

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

results = []

class TestDataValidation(unittest.TestCase):

    validation_result = None

    def test_record_count_match(self):
        self.assertEqual(
            self.validation_result["source_record_count"],
            self.validation_result["target_record_count"]
        )

    def test_source_count_positive(self):
        self.assertGreater(
            self.validation_result["source_record_count"], 0
        )


class FabricTestResult(unittest.TestResult):

    def addSuccess(self, test):
        results.append({
            "test_name": test._testMethodName,
            "result": "PASSED"
        })

    def addFailure(self, test, err):
        results.append({
            "test_name": test._testMethodName,
            "result": "FAILED"
        })

    def addError(self, test, err):
        results.append({
            "test_name": test._testMethodName,
            "result": "ERROR"
        })



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

TestDataValidation.validation_result = validation_result

suite = unittest.TestLoader().loadTestsFromTestCase(TestDataValidation)
suite.run(FabricTestResult())

df_results = pd.DataFrame(results)
display(df_results)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
