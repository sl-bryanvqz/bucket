# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

from pyspark.sql import functions as F
from datetime import datetime
import unittest
import pandas as pd

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# 5. Reconciliation Validation
def validate_reconciliation(source_table, target_table, join_keys):
    """
    Validate data reconciliation between source and target tables
    
    Args:
        source_table: Name of the source Delta table
        target_table: Name of the target Delta table
        join_keys: List of tuple with column names to join on. ex:  bronze_silver_target_pk  = [("MatterNumber","matter_number")]

    
    Returns:
        Dictionary with validation results
    """
    try:
        join_condition = " AND ".join([f"src.{tup[0]} = tgt.{tup[1]}" for tup in join_keys])
        
        # Count records
        source_count = spark.sql(f"SELECT COUNT(*) as cnt FROM {source_table}").collect()[0]['cnt']
        target_count = spark.sql(f"SELECT COUNT(*) as cnt FROM {target_table}").collect()[0]['cnt']
        
        # Find missing in target
        missing_query = f"""
        SELECT COUNT(*) as cnt FROM {source_table} src
        LEFT JOIN {target_table} tgt ON {join_condition}
        WHERE tgt.{join_keys[0][1]} IS NULL
        """
        missing_in_target = spark.sql(missing_query).collect()[0]['cnt']
        
        # Find missing in source
        missing_query_src = f"""
        SELECT COUNT(*) as cnt FROM {target_table} tgt
        LEFT JOIN {source_table} src ON {join_condition}
        WHERE src.{join_keys[0][0]} IS NULL
        """
        missing_in_source = spark.sql(missing_query_src).collect()[0]['cnt']
        
        return {
            'validation_type': 'Reconciliation',
            'source_table': source_table,
            'target_table': target_table,
            'source_record_count': source_count,
            'target_record_count': target_count,
            'missing_in_target': missing_in_target,
            'missing_in_source': missing_in_source,
            'record_count_match': source_count == target_count,
            'timestamp': datetime.now().isoformat()
        }
    except Exception as e:
        return {
            'validation_type': 'Reconciliation',
            'source_table': source_table,
            'target_table': target_table,
            'status': 'ERROR',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def validate_data_completeness(table_name, columns):
        """
        Validate data completeness by checking for NULL values in critical columns
        
        Args:
            table_name: Name of the Delta table
            columns: List of column names to check for completeness
        
        Returns:
            Dictionary with validation results
        """
        try:
            # Build the query dynamically
            null_checks = ", ".join([f"SUM(CASE WHEN {col} IS NULL OR {col} = '-1' OR {col} = 'Unknown' THEN 1 ELSE 0 END) as null_count_{col}" 
                                      for col in columns])
            
            query = f"""
            SELECT 
                COUNT(*) as total_records,
                {null_checks}
            FROM {table_name}
            """
            
            result = spark.sql(query).collect()[0]
            result_dict = result.asDict()
            
            completeness_pct = {}
            total = result_dict['total_records']
            
            for col in columns:
                null_count = result_dict.get(f'null_count_{col}', 0)
                completeness_pct[col] = ((total - null_count) / total * 100) if total > 0 else 0
            
            min_completeness = min(completeness_pct.values()) if completeness_pct else 100
            
            return {
                'validation_type': 'Data Completeness',
                'table': table_name,
                'status': 'PASS' if min_completeness == 100 else 'WARN',
                'total_records': total,
                'completeness_by_column': completeness_pct,
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            return {
                'validation_type': 'Data Completeness',
                'table': table_name,
                'status': 'ERROR',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

class TestDataValidation(unittest.TestCase):

    validation_result = None

    def test_record_count_match(self):
        self.assertEqual(
            self.validation_result["source_record_count"],
            self.validation_result["target_record_count"]
        )

    def test_source_count_positive(self):
        self.assertGreater(
            self.validation_result["source_record_count"], 0
        )


class FabricTestResult(unittest.TestResult):

    def __init__(self):
        super().__init__()
        self.results = []

    def addSuccess(self, test):
        self.results.append({
            "test_name": test._testMethodName,
            "result": "PASSED"
        })

    def addFailure(self, test, err):
        self.results.append({
            "test_name": test._testMethodName,
            "result": "FAILED"
        })

    def addError(self, test, err):
        self.results.append({
            "test_name": test._testMethodName,
            "result": "ERROR"
        })



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
