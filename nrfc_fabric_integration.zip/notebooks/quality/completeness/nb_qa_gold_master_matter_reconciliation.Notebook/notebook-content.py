# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run nb_qa_gold_master_reconciliation

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    source_table             = "matter"
    source_view              = f"src_{to_snake_case(source_table)}"
    map_view                 = f"map_{to_snake_case(source_table)}"
    target_workspace         = "ws_canada_global_mds_dev"
    target_lakehouse         = "lh_canada_global_mds"
    silver_schema            = "silver_rmdd"
    gold_schema              = "gold_master"
    silver_target_table      = f"{silver_schema}.silver_rmdd_{source_table}"
    gold_target_table        = f"{gold_schema}.gold_master_{source_table}"
    bronze_silver_target_pk  = [("MatterNumber","matter_id")]
    silver_gold_target_pk    = [("matter_id","matter_id")]
    gold_not_null_columns    = ["matter_number","member_firm_code","matter_name","is_security_wall_created","is_active","last_updated_date_utc_at_source"]
    limit_rows_for_debugging = True
    watermark_filter = "s.TIMESTAMP > '1900-01-01 00:00:00' AND s.TIMESTAMP <= '2026-08-03 02:45:12'"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"source_view: {source_view}")
    print(f"map_view: {map_view}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

gold_completeness_result = validate_data_completeness(gold_target_table, gold_not_null_columns)

print("="*80)
print("⚠ GOLD - NOT NULL DATA COMPLETENESS: ")
print("="*80)
gold_completeness_result

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create source view when running this transform notebook alone
if not spark.catalog.tableExists(source_view):
    create_source_view(
        source_view=source_view,
        source_schema="dbo",
        source_table=source_table,
        source_type="sql_database",
        source_location="CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e",
        source_connection_settings={
            "server_name": "hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com"
        }
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

bronze_silver_validation_result = validate_reconciliation(source_view, silver_target_table, bronze_silver_target_pk)


print("="*80)
print("⚠ BRONZE - SILVER RECONCILIATION: ")
print("="*80)
bronze_silver_validation_result

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

silver_gold_validation_result = validate_reconciliation(silver_target_table, gold_target_table, silver_gold_target_pk)

print("="*80)
print("⚠ SILVER - GOLD RECONCILIATION: ")
print("="*80)
silver_gold_validation_result

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

TestDataValidation.validation_result = bronze_silver_validation_result

suite = unittest.TestLoader().loadTestsFromTestCase(TestDataValidation)
tr = FabricTestResult()
suite.run(tr)

print("="*80)
print("⚠ SILVER TEST RESULTS: ")
print("="*80)

display(pd.DataFrame(tr.results))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

TestDataValidation.validation_result = silver_gold_validation_result

suite = unittest.TestLoader().loadTestsFromTestCase(TestDataValidation)
tr = FabricTestResult()
suite.run(tr)

print("="*80)
print("⚠ GOLD TEST RESULTS: ")
print("="*80)
display(pd.DataFrame(tr.results))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
