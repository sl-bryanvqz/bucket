# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "known_warehouses": []
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Define notebook Parameters
# 
# Pass through th pl_worker

# CELL ********************

# Framework-compatible parameters with manual fallbacks
import json
import uuid

# Basic notebook runtime values
task_id = 50
task_name = "Load taxonomy to silver"
lineage_id = str(uuid.uuid4())
limit_rows_for_debugging = False
prev_wm = None
curr_wm = None
execution_errors = []

# Source settings > what data to read
source_settings = json.dumps(
    {
        "source_name": "taxonomy",
        "source_type": "shortcut",
        "source_location": "external_curated_taxonomy",
        "source_schema": "external_curated_taxonomy",
        "table_config": [
            {
                "source_table": "curated_band_level",
                "target_table": "stage_taxonomy_curated_band_level",
                "target_pk": ["band_level_code"]
            },
            {
                "source_table": "curated_bill_type",
                "target_table": "stage_taxonomy_curated_bill_type",
                "target_pk": ["bill_type_code"]
            },
            {
                "source_table": "curated_client_programme",
                "target_table": "stage_taxonomy_curated_client_programme",
                "target_pk": ["client_programme_code"]
            },
            {
                "source_table": "curated_client_sector",
                "target_table": "stage_taxonomy_curated_client_sector",
                "target_pk": ["sic_code"]
            },
            {
                "source_table": "curated_company",
                "target_table": "stage_taxonomy_curated_company",
                "target_pk": ["company_code"]
            },
            {
                "source_table": "curated_country",
                "target_table": "stage_taxonomy_curated_country",
                "target_pk": ["country_code_iso2"]
            },
            {
                "source_table": "curated_currency",
                "target_table": "stage_taxonomy_curated_currency",
                "target_pk": ["currency_code"]
            },
            {
                "source_table": "curated_employee_sub_group",
                "target_table": "stage_taxonomy_curated_employee_sub_group",
                "target_pk": ["employee_sub_group_code"]
            },
            {
                "source_table": "curated_entry_classification",
                "target_table": "stage_taxonomy_curated_entry_classification",
                "target_pk": ["entry_classification_code"]
            },
            {
                "source_table": "curated_exchange_rate",
                "target_table": "stage_taxonomy_curated_exchange_rate",
                "target_pk": ["from_currency_code", "to_currency_code", "rate_date", "rate_type"]
            },
            {
                "source_table": "curated_global_strategic_initiative",
                "target_table": "stage_taxonomy_curated_global_strategic_initiative",
                "target_pk": ["global_strategic_initiative_code"]
            },
            {
                "source_table": "curated_matter_billing_frequency",
                "target_table": "stage_taxonomy_curated_matter_billing_frequency",
                "target_pk": ["matter_billing_frequency_code"]
            },
            {
                "source_table": "curated_matter_billing_method",
                "target_table": "stage_taxonomy_curated_matter_billing_method",
                "target_pk": ["matter_billing_method_code"]
            },
            {
                "source_table": "curated_matter_category",
                "target_table": "stage_taxonomy_curated_matter_category",
                "target_pk": ["matter_category_code"]
            },
            {
                "source_table": "curated_matter_entry_type",
                "target_table": "stage_taxonomy_curated_matter_entry_type",
                "target_pk": ["matter_entry_type_code"]
            },
            {
                "source_table": "curated_matter_sector",
                "target_table": "stage_taxonomy_curated_matter_sector",
                "target_pk": ["sic_code"]
            },
            {
                "source_table": "curated_matter_status",
                "target_table": "stage_taxonomy_curated_matter_status",
                "target_pk": ["matter_status_code"]
            },
            {
                "source_table": "curated_nature_of_proceeding",
                "target_table": "stage_taxonomy_curated_nature_of_proceeding",
                "target_pk": ["nature_of_proceeding_code"]
            },
            {
                "source_table": "curated_office",
                "target_table": "stage_taxonomy_curated_office",
                "target_pk": ["office_code"]
            },
            {
                "source_table": "curated_partner_function",
                "target_table": "stage_taxonomy_curated_partner_function",
                "target_pk": ["partner_function_code"]
            },
            {
                "source_table": "curated_practice_group",
                "target_table": "stage_taxonomy_curated_practice_group",
                "target_pk": ["practice_group_code"]
            },
            {
                "source_table": "curated_team",
                "target_table": "stage_taxonomy_curated_team",
                "target_pk": ["team_code", "member_firm_code"]
            },
            {
                "source_table": "curated_transaction_document_type",
                "target_table": "stage_taxonomy_curated_transaction_document_type",
                "target_pk": ["transaction_document_type_code"]
            },
            {
                "source_table": "curated_work_type",
                "target_table": "stage_taxonomy_curated_work_type",
                "target_pk": ["technical_area_code"]
            }
        ]
    }
)

# Target settings > here/how to write
target_settings = json.dumps(
    {
        "target_workspace": "ws_canada_global_mds_dev",
        "target_lakehouse": "lh_canada_global_mds",
        "target_schema": "stage_taxonomy",
        "target_location": "Files/stage/taxonomy",
        "target_load_strategy": "overwrite"
    }
)

# Connection settings > how to connect/authenticate
source_connection_settings  = "{}"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run nb_load_sql_to_lakehouse

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
