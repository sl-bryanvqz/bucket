# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# MARKDOWN ********************

# ##### Configuration and imports

# CELL ********************

import ast
import uuid
import json
from delta.tables import DeltaTable
import re
import logging
import requests
import pyspark.sql.functions as F # import when, col, lit, to_date, to_timestamp, trim
from pyspark.sql import DataFrame
from pyspark.sql import Window
from datetime import date, datetime, timedelta
import sys
from notebookutils import mssparkutils
import notebookutils
spark.conf.set("spark.sql.session.timeZone", "UTC")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

logger = logging.getLogger("TransactionalSharedFunctions")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### setup_logging() function
# 
# INsert a comment

# CELL ********************

#1. Define a function for logging
def setup_logging():
    '''
    Set up logging configuration for Fabric notebooks.
    '''
    # Create formatter
    FORMAT = "%(asctime)s UTC - %(levelname)s - %(message)s (%(name)s)"
    formatter = logging.Formatter(fmt=FORMAT)

    # Get root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.WARNING)

    # Check if handlers exist, if not add console handler
    if not root_logger.handlers:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)
        root_logger.addHandler(console_handler)
    else:
        # Apply formatter to existing handlers
        for handler in root_logger.handlers:
            handler.setFormatter(formatter)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Build source connection
# 
# insert comment

# CELL ********************

#1. Define a function that builds a connection to source db
def build_source_connection(source_type, source_location, source_connection_settings):
    # Only SQL database sources need a JDBC connection
    if source_type != "sql_database":
        return None, None

    # Get the SQL server name from the connection settings
    server_name = (
        source_connection_settings.get("server_name")
        or source_connection_settings.get("jdbc_hostname")
        or source_connection_settings.get("server")
    )

    if not server_name:
        raise ValueError("server_name is required for sql_database sources")

    # Read authentication flag from variable library
    vl_authentication = notebookutils.variableLibrary.getLibrary("vl_authentication")
    use_db_spn_authentication = vl_authentication.use_db_spn_authentication
    driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

    # Build source connection using service principal authentication
    if use_db_spn_authentication:
        print("Using Service Principal as source auth method...")

        akv_uri = vl_authentication.akv_uri
        tenant_id = notebookutils.credentials.getSecret(akv_uri, vl_authentication.tenant_id_secret_name)
        client_id = notebookutils.credentials.getSecret(akv_uri, vl_authentication.client_id_secret_name)
        client_secret = notebookutils.credentials.getSecret(akv_uri, vl_authentication.client_secret_name)

        jdbc_url = (
            f"jdbc:sqlserver://{server_name}:1433;"
            f"database={source_location};"
            "encrypt=true;"
            "authentication=ActiveDirectoryServicePrincipal;"
            f"aadSecurePrincipalId={client_id};"
            f"aadSecurePrincipalSecret={client_secret};"
            f"aadAuthority=https://login.microsoftonline.com/{tenant_id};"
        )

        connection_properties = {
            "driver": driver
        }

    # Build source connection using Fabric token authentication
    else:
        print("Using Token as source auth method...")

        token = notebookutils.credentials.getToken("https://database.windows.net/.default")

        jdbc_url = (
            f"jdbc:sqlserver://{server_name}:1433;"
            f"database={source_location};"
            "encrypt=true;"
        )

        connection_properties = {
            "accessToken": token,
            "driver": driver
        }

    return jdbc_url, connection_properties

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Error handling

# CELL ********************

#1. Add one error to the execution error list
def add_execution_error(execution_errors, task_id, task_name, lineage_id, source_table, target_table, step, error_type, message):
    execution_errors.append({
        "task_id": str(task_id),
        "task_name": str(task_name),
        "lineage_id": str(lineage_id),
        "source_table": str(source_table),
        "target_table": str(target_table),
        "step": str(step),
        "error_type": str(error_type),
        "message": str(message)[:4000],
        "execution_timestamp": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    })

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Ingestion data helpers

# CELL ********************

#1. Convert a string(column Names) to snake_case. Purpose: Standardize column naming > framework source: nb_load_to_silver
def to_snake_case(string):
    string = re.sub(r'([a-z])([A-Z0-9])', r'\1_\2', string)
    string = re.sub(r'([A-Z])([A-Z][a-z])', r'\1_\2', string)
    string = string.lower().strip()
    return string





#2. Remove leading/trailing spaces from all string column values. input: Spark DataFrame > nb_load_to_silver: nb_load_to_silver
def trim_all_string_columns(df):
    string_columns = [field.name for field in df.schema.fields if field.dataType.typeName() == 'string']
    df = df.select(
        *[F.trim(F.col(c)).alias(c) if c in string_columns else F.col(c) for c in df.columns]
    )
    return df





#3. Replace old dates: If date ≤ 1900-01-01 → replace with 1900-01-01. Input:DataFrame > nb_load_to_silver: nb_load_to_silver
def replace_old_dates(df):
    date_columns = [field.name for field in df.schema.fields if field.dataType.typeName() in('date','timestamp','timestamp_ntz')]
    for date_column in date_columns:
        df = df.withColumn(
            date_column,
            F.when(
                F.col(f"`{date_column}`") <= F.lit('1900-01-01').cast(df.schema[date_column].dataType),
                F.lit('1900-01-01').cast(df.schema[date_column].dataType)
            )
            .otherwise(
                F.col(f"`{date_column}`")
            )
        )
    return df





#4. Define parent function that applies all cleaning steps to the DataFrame > nb_load_to_silver: nb_load_to_silver
def clean_bronze_table(df, limit_rows_for_debugging=False):
    if limit_rows_for_debugging:
        df = df.limit(3)
    snake_case_column_names = [to_snake_case(col) for col in df.columns]
    df = df.toDF(*snake_case_column_names)
    df = replace_old_dates(df)
    df = trim_all_string_columns(df)
    return df





#5. Add metadata columns to dataframe > nb_load_to_silver: nb_load_to_delta_table
def add_metadata(df, source_system, source_table, target_table, lineage_id):
    return (
        df
        .withColumn("_process_timestamp", F.current_timestamp())
        .withColumn("_source_system", F.lit(source_system))
        .withColumn("_source_table", F.lit(source_table))
        .withColumn("_target_table", F.lit(target_table))
        .withColumn("_lineage_id", F.lit(lineage_id))
    )





#6. Drop framework metadata columns from previous layers
def drop_framework_metadata(df):
    metadata_columns = [
        "_process_timestamp",
        "_source_system",
        "_source_table",
        "_target_table",
        "_lineage_id",
        "_hashed_pk",
        "_hashed_row"
    ]

    return df.drop(*[col for col in metadata_columns if col in df.columns])





#7. Removes duplicates from dataframe > new function
def remove_exact_duplicates(df):
    return df.dropDuplicates(df.columns)





#8. Read one source table from SQL or lakehouse/shortcut
def read_source_table(source_full_name, jdbc_url=None, connection_properties=None, source_watermark_filter="1 = 1"):
    if jdbc_url:
        source_query = f"(SELECT * FROM {source_full_name} s WHERE {source_watermark_filter}) AS src"
        return spark.read.jdbc(jdbc_url, source_query, properties=connection_properties)

    return spark.table(source_full_name).alias("s").where(source_watermark_filter)





#9. Create source temp view from source settings
def create_source_view(source_view, source_schema, source_table, source_type, source_location, source_connection_settings, jdbc_url=None, connection_properties=None, source_watermark_filter="1 = 1"):
    # Reuse the view when it already exists
    if source_view in [table.name for table in spark.catalog.listTables()]:
        return spark.table(source_view)

    # Read CSV files from a lakehouse Files folder
    if source_type == "csv":
        source_lakehouse_path = notebookutils.lakehouse.get(source_location).properties["abfsPath"]
        source_file_path = f"{source_lakehouse_path}/{source_schema}/{source_table}.csv"

        df_source = (
            spark.read.format("csv")
            .option("header", "true")
            .option("inferSchema", "true")
            .option("delimiter", ",")
            .load(source_file_path)
        )

        df_source = clean_bronze_table(df_source)
        df_source = df_source.where(source_watermark_filter)
        df_source = remove_exact_duplicates(df_source)
        df_source.createOrReplaceTempView(source_view)

        return df_source

    # Build source name from schema and table
    source_full_name = f"{source_schema}.{source_table}"

    # Build source connection when one was not provided
    if jdbc_url is None:
        jdbc_url, connection_properties = build_source_connection(
            source_type=source_type,
            source_location=source_location,
            source_connection_settings=source_connection_settings
        )

    # Read source data and create the temp view
    df_source = read_source_table(
        source_full_name=source_full_name,
        jdbc_url=jdbc_url,
        connection_properties=connection_properties,
        source_watermark_filter=source_watermark_filter
    )

    df_source = remove_exact_duplicates(df_source)
    df_source = replace_old_dates(df_source)
    df_source.createOrReplaceTempView(source_view)

    return df_source

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Lookup function

# CELL ********************

# Adds backticks to each part of a Fabric/Spark table name
# Example: workspace.lakehouse.schema.table -> `workspace`.`lakehouse`.`schema`.`table`
def sql_identifier(name):
    return ".".join([f"`{part}`" for part in name.split(".")])


def lookup_function(table_lookup, key_mapping, return_column):
    # Wraps one key pair in a list so one-key and multi-key lookups use the same logic
    if isinstance(key_mapping, tuple):
        key_mapping = [key_mapping]

    # Builds the SQL match condition between source columns and lookup table columns
    where_clause = " AND ".join([
        f"{source_expression} = {lookup_expression}"
        for source_expression, lookup_expression in key_mapping
    ])
    
    # Looks up the requested column value and returns NULL when no match is found
    return f"""
        (
            SELECT MAX(lkp.`{return_column}`)
            FROM {sql_identifier(table_lookup)} lkp
            WHERE {where_clause}
            AND CAST(lkp.`is_active` AS BOOLEAN) = true
        )
    """

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Load data helpers

# CELL ********************

#1. Adds hash columns used by merge-scd1 loads
def add_hash_columns(df, target_pk, incremental_column):
    if not target_pk:
        raise ValueError("target_pk is required to add hash columns")

    # Build one hash from the target primary key columns
    df = df.withColumn("_hashed_pk", F.md5(F.concat_ws("|", *[F.coalesce(F.col(col).cast("string"), F.lit("<NULL>")) for col in target_pk])))

    # Build one hash from the non-key business columns
    row_hash_cols = [col for col in df.columns if col not in target_pk + ["_hashed_pk", incremental_column]]

    df = df.withColumn("_hashed_row", F.md5(F.concat_ws("|", *[F.coalesce(F.col(col).cast("string"), F.lit("<NULL>")) for col in row_hash_cols])))

    return df





#2. Framework-aligned target load helper >  nb_load_to_silver: nb_load_to_silver
def load_to_target(df, target_full_name, target_load_strategy, target_location_path=""):
    # Get schema and table name from target_table_path
    target_schema, target_table = target_full_name.split(".")

    # Set load metrics
    rows_inserted = 0
    rows_updated = 0
    rows_read = 0
    rows_unchanged = 0

    # If target path does not exist, create delta files and table
    if not DeltaTable.isDeltaTable(spark, target_location_path):

        #  Merge loads require the target schema/table to be created first
        if "gold" in target_schema.lower():
            raise ValueError(
                f"Target table must exist before merge-scd1 load: {target_full_name}."
            )

        # Create schema
        logger.info(f'Creating new schema if not exists {target_schema}')
        spark.sql(f"CREATE SCHEMA IF NOT EXISTS {target_schema}")
        
        # Create delta files 
        logger.info(f'Creating new delta files at {target_location_path}')
        df.write.format("delta").mode("overwrite").save(target_location_path)

        # Create delta table 
        logger.info(f'Creating new delta table {target_full_name}')
        spark.sql(f"CREATE TABLE IF NOT EXISTS {target_full_name} USING DELTA LOCATION '{target_location_path}'")

        # Update row metrics
        rows_read = df.count()
        rows_inserted = rows_read
        rows_updated = 0
        rows_unchanged = 0

    else:
        match target_load_strategy:
            
            case "merge-scd1":
                # Merge inserted and changed rows
                logger.info(f"Running merge-scd1 into {target_full_name}")
                
                # Look for existing delta files
                delta_table = DeltaTable.forPath(spark, target_location_path)
                df_target = spark.read.format("delta").load(target_location_path)

                # Update row metrics
                rows_read = df.count()
                rows_inserted = df.alias("s").join(df_target.alias("t"), "_hashed_pk", "left_anti").count()
                rows_updated = df.alias("s").join(df_target.alias("t"), "_hashed_pk", "inner").filter("NOT (t._hashed_row <=> s._hashed_row)").count()
                rows_unchanged = rows_read - rows_inserted - rows_updated

                if rows_inserted == 0 and rows_updated == 0:
                    logger.info(f"Skipping {target_full_name}: no changes")

                # Run merge-scd1
                else:
                    (
                        delta_table.alias("t")
                        .merge(df.alias("s"), "t._hashed_pk = s._hashed_pk")
                        .whenMatchedUpdateAll(condition="NOT (t._hashed_row <=> s._hashed_row)")
                        .whenNotMatchedInsertAll()
                        .execute()
                    )

            case "overwrite":
                # Replace all target data
                logger.info(f"Overwriting records in {target_full_name}")
                
                # Update row metrics
                rows_read = df.count()
                rows_inserted = rows_read
                rows_updated = 0
                rows_unchanged = 0

                # Run overwrite
                df.write.mode("overwrite").format("delta").option("overwriteSchema", "false").save(target_location_path)

            case "append":
                # Append all source rows
                logger.info(f"Appending new records to {target_full_name}")
                
                # Update row metrics
                rows_read = df.count()
                rows_inserted = rows_read
                rows_updated = 0
                rows_unchanged = 0

                # Run append
                df.write.mode("append").format("delta").save(target_location_path)

            case _:
                raise ValueError(f"Unsupported target_load_strategy: {target_load_strategy}")

    # Return load metrics
    return {
        "rows_inserted": rows_inserted,
        "rows_updated": rows_updated,
        "rows_read": rows_read,
        "rows_unchanged": rows_unchanged
    }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Data quality helpers

# CELL ********************

#1. Check whether business key columns contain nulls and display samples
def validate_null_business_keys(df, key_col, target_table=None):
    # Convert notebook parameter JSON string into a list
    if isinstance(key_col, str) and key_col.strip().startswith("["):
        key_col = json.loads(key_col)

    # Accept either one key column or a list of key columns
    group_cols = key_col if isinstance(key_col, list) else [key_col]

    # Fail when a configured key column does not exist in the DataFrame
    missing_cols = [col for col in group_cols if col not in df.columns]

    if missing_cols:
        raise ValueError(f"Missing business key columns: {missing_cols}")

    # Build null condition across all key columns
    null_condition = None

    for col in group_cols:
        col_condition = F.col(col).isNull()
        null_condition = col_condition if null_condition is None else null_condition | col_condition

    # Get rows with any null business key value
    null_rows_df = df.filter(null_condition)

    # Count rows with null business keys
    total_null_rows = null_rows_df.count()

    # Add target table name to the message when provided
    table_message = f" for {target_table}" if target_table else ""

    print(f"Total null {group_cols} business key rows{table_message}: {total_null_rows}")

    # Stop when there are no nulls
    if total_null_rows == 0:
        return 0

    print("Null business key rows")
    display(null_rows_df.select(*group_cols).limit(100))

    return total_null_rows





#2. Check whether a business key has duplicates and display samples > new function
def validate_duplicates(df, key_col="_hashed_pk", target_table=None):
    # Convert notebook parameter JSON string into a list
    if isinstance(key_col, str) and key_col.strip().startswith("["):
        key_col = json.loads(key_col)

    # Accept either one key column or a list of key columns
    group_cols = key_col if isinstance(key_col, list) else [key_col]

    # Add duplicate count per key group
    duplicate_rows_df = (
        df.withColumn(
            "_duplicate_count",
            F.count("*").over(Window.partitionBy(*group_cols))
        )
        .filter(F.col("_duplicate_count") > 1)
    )

    # Get one row per duplicate key group
    dup_keys_df = (
        duplicate_rows_df
        .select(*group_cols, "_duplicate_count")
        .distinct()
        .orderBy(F.col("_duplicate_count").desc())
    )

    # Count duplicate key groups
    total_dup_groups = dup_keys_df.count()

    # Add target table name to the message when provided
    table_message = f" for {target_table}" if target_table else ""

    print(f"Total duplicate {group_cols} groups{table_message}: {total_dup_groups}")

    # Stop when there are no duplicates
    if total_dup_groups == 0:
        return 0

    # Show duplicate sample rows
    print("Duplicate rows")
    display(duplicate_rows_df.drop("_duplicate_count"))

    return total_dup_groups

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
