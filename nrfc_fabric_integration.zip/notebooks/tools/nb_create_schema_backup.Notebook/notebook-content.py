# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

schema_name = "gold_master"
location_path = "Files/gold/master"

tables = spark.sql(f"SHOW TABLES IN `{schema_name}`").collect()

for table in tables:
    source_table = table.tableName

    # Skip existing backup tables
    if source_table.startswith("backup_"):
        continue

    # Skip dev tables
    if source_table.startswith("dev_"):
        continue

    # Backup only gold_master_* tables
    if not source_table.startswith("gold_master_"):
        continue

    target_table = f"backup_{source_table}"
    target_location_path = f"{location_path}/backup/{target_table}"

    # Read source table
    df_source = spark.table(f"`{schema_name}`.`{source_table}`")

    # Write Delta backup files
    df_source.write.format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(target_location_path)

    # Register backup table
    spark.sql(f"""
        CREATE TABLE IF NOT EXISTS `{schema_name}`.`{target_table}`
        USING DELTA
        LOCATION '{target_location_path}'
    """)

    print(f"Created backup: {schema_name}.{target_table} at {target_location_path}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
