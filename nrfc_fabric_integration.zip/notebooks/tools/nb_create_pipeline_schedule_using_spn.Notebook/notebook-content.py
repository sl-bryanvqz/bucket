# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

from notebookutils import mssparkutils
import notebookutils
import requests
import json
import base64

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Read service principal secrets from Key Vault
akv_uri = "https://kv-can-non-prod-fms-cc.vault.azure.net/"

tenant_id = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-CICD-NonProd-tenant-id")
client_id = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-CICD-NonProd-client-id")
client_secret = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-CICD-NonProd-client-secret")

# Create Fabric API access token using service principal
token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"

token_payload = {
    "grant_type": "client_credentials",
    "client_id": client_id,
    "client_secret": client_secret,
    "scope": "https://api.fabric.microsoft.com/.default"
}

token_response = requests.post(token_url, data=token_payload)
token_response.raise_for_status()

access_token = token_response.json()["access_token"]

headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

print("Service principal token created")

# Confirm the identity used by the token
payload = access_token.split(".")[1] + "=="
claims = json.loads(base64.urlsafe_b64decode(payload))

print("name:", claims.get("name"))
print("appid:", claims.get("appid"))
print("oid:", claims.get("oid"))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Select workspace and pipeline
workspace_id = "d940d8ab-6c2e-4088-85b8-3335f3287cbc"
selected_pipeline_name = "pl_controller"

# Get active data pipelines from the workspace
items_url = (
    f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}"
    f"/items?type=DataPipeline"
)

items_response = requests.get(items_url, headers=headers)

print("Pipeline list status code:", items_response.status_code)
print(items_response.text)

items_response.raise_for_status()

pipelines = items_response.json().get("value", [])
display(pipelines)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Select pipeline by name
selected_pipeline = next(
    (
        pipeline for pipeline in pipelines
        if pipeline["displayName"].lower() == selected_pipeline_name.lower()
    ),
    None
)

if not selected_pipeline:
    available_pipelines = [pipeline["displayName"] for pipeline in pipelines]
    raise ValueError(f"Pipeline '{selected_pipeline_name}' was not found. Available pipelines: {available_pipelines}")

pipeline_id = selected_pipeline["id"]
schedule_url = (
    f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}"
    f"/items/{pipeline_id}/jobs/Pipeline/schedules"
)


print("Selected pipeline:", selected_pipeline["displayName"])
print("Pipeline id:", pipeline_id)
print(schedule_url)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# List existing schedules
list_response = requests.get(schedule_url, headers=headers)

print("List status code:", list_response.status_code)
print(list_response.text)

list_response.raise_for_status()

existing_schedules = list_response.json().get("value", [])
display(existing_schedules)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Define schedule payload
schedule_payload = {
    "enabled": True,
    "configuration": {
        "startDateTime": "2026-09-03T06:00:00Z",
        "endDateTime": "2099-01-01T23:59:00Z",
        "localTimeZoneId": "Eastern Standard Time",
        "type": "Cron",
        "interval": 90
    },
    "executionData": {
        "parameters": {
            "stage": "testing-silver",
            "task_name": "",
            "limit_rows_for_debugging": False,
            "users_to_notify": "mary.sarafraz@nortonrosefulbright.com"
        }
    }
}

print(json.dumps(schedule_payload, indent=2))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Update existing schedule, or create one if none exists
if existing_schedules:
    schedule_id = existing_schedules[0]["id"]

    schedule_response = requests.patch(
        f"{schedule_url}/{schedule_id}",
        headers=headers,
        json=schedule_payload
    )

    action = "updated"

else:
    schedule_response = requests.post(
        schedule_url,
        headers=headers,
        json=schedule_payload
    )

    action = "created"

print(f"Schedule {action} status code:", schedule_response.status_code)
print(schedule_response.text)

schedule_response.raise_for_status()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Confirm final schedule
confirm_response = requests.get(schedule_url, headers=headers)

print("Confirm status code:", confirm_response.status_code)
print(confirm_response.text)

confirm_response.raise_for_status()

display(confirm_response.json())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
