# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": "",
# META       "known_lakehouses": []
# META     },
# META     "warehouse": {
# META       "default_warehouse": "34c74d17-d820-4060-abb2-47f0d6b6561e",
# META       "known_warehouses": [
# META         {
# META           "id": "34c74d17-d820-4060-abb2-47f0d6b6561e",
# META           "type": "Lakewarehouse"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# ### This notebook create the lakehouse folder structure

# CELL ********************

from notebookutils import mssparkutils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

vl_guids = notebookutils.variableLibrary.getLibrary("vl_guids")

workspace_id = vl_guids.getVariable("workspace_id")
lakehouse_id = vl_guids.getVariable("lakehouse_id")



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# #### Assign correct workspace and lakehouse 

# CELL ********************

base_path = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}/Files"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

folders = [
    "contract",
    "metadata_config"
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for folder in folders:
    path = f"{base_path}/{folder}"
    
    try:
        # Check if folder exists
        if not mssparkutils.fs.exists(path):
            mssparkutils.fs.mkdirs(path)
            print(f"Created: {path}")
        else:
            print(f"Already exists: {path}")
    
    except Exception as e:
        print(f"Error for {path}: {str(e)}")

print("Process completed.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
