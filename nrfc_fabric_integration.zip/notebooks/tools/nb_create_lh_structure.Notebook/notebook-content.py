# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": "",
# META       "known_lakehouses": []
# META     }
# META   }
# META }

# MARKDOWN ********************

# # This notebook create the lakehouse schema

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC   "defaultLakehouse": {
# MAGIC     "name": {
# MAGIC         "variableName": "$(/**/vl_guids/lakehouse_name)"
# MAGIC     },
# MAGIC     "id": {
# MAGIC       "variableName": "$(/**/vl_guids/lakehouse_id)"
# MAGIC     },
# MAGIC     "workspaceId": {
# MAGIC       "variableName": "$(/**/vl_guids/workspace_id)"
# MAGIC     }
# MAGIC   }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col
from pyspark.sql import functions as sf

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# from notebookutils import mssparkutils

# lakehouse_name = "lh_test_"

# definition = {
#     "enableSchemas": True
# }

# lakehouse = notebookutils.lakehouse.create(
#     name=lakehouse_name,
#     description="Test Lakehouse",
#     definition=definition
# )

# print(lakehouse)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#List current schemas
schemas = spark.sql("SHOW SCHEMAS")
schemas.show(truncate=False)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

schema_name = "external_curated_canonical"

if(schemas.filter(col('namespace').contains(schema_name)).count() == 1):
    print(f"The {schema_name} schema already exist")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")

schemas = spark.sql("SHOW SCHEMAS")

assert schemas.filter(col('namespace').contains(schema_name)).count() == 1, f"Error creating {schema_name} schema"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

schema_name = "external_curated_taxonomy"

if(schemas.filter(col('namespace').contains(schema_name)).count() == 1):
    print(f"The {schema_name} schema already exist")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")

schemas = spark.sql("SHOW SCHEMAS")

assert schemas.filter(col('namespace').contains(schema_name)).count() == 1, f"Error creating {schema_name} schema"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

schema_name = "gold_transactional"

if(schemas.filter(col('namespace').contains(schema_name)).count() == 1):
    print(f"The {schema_name} schema already exist")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")

schemas = spark.sql("SHOW SCHEMAS")

assert schemas.filter(col('namespace').contains(schema_name)).count() == 1, f"Error creating {schema_name} schema"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

schema_name = "gold_master"

if(schemas.filter(col('namespace').contains(schema_name)).count() == 1):
    print(f"The {schema_name} schema already exist")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")

schemas = spark.sql("SHOW SCHEMAS")

assert schemas.filter(col('namespace').contains(schema_name)).count() == 1, f"Error creating {schema_name} schema"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

schema_name = "stage_taxonomy"

if(schemas.filter(col('namespace').contains(schema_name)).count() == 1):
    print(f"The {schema_name} schema already exist")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")

schemas = spark.sql("SHOW SCHEMAS")

assert schemas.filter(col('namespace').contains(schema_name)).count() == 1, f"Error creating {schema_name} schema"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run nb_create_gold_master_lh_schema

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run nb_create_gold_transactional_lh_schema

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run nb_create_lh_files_folder

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
