# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": "",
# META       "known_lakehouses": []
# META     }
# META   }
# META }

# CELL ********************

from notebookutils import mssparkutils
import requests
import json

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

akv_uri = 'https://kv-can-non-prod-fms-cc.vault.azure.net/'

tenant_id = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-CICD-NonProd-tenant-id")
client_id = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-CICD-NonProd-client-id")
client_secret = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-CICD-NonProd-client-secret")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ==========================================
# STEP 1 - GET ENTRA ID TOKEN
# ==========================================

token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"

payload = {
    "grant_type": "client_credentials",
    "client_id": client_id,
    "client_secret": client_secret,
    "scope": "https://api.fabric.microsoft.com/.default"
}

response = requests.post(token_url, data=payload)
response.raise_for_status()

access_token = response.json()["access_token"]

print("Access token obtained successfully")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# ==========================================
# CONFIGURATION
# ==========================================

vl_guids = notebookutils.variableLibrary.getLibrary("vl_guids")

workspace_id = vl_guids.getVariable("workspace_id")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#pl_controller
#pipeline_id = vl_guids.getVariable("pl_controller_id")
#new_pipeline_name = "pl_controller"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#pl_worker
pipeline_id = vl_guids.getVariable("pl_worker_id")
new_pipeline_name = "pl_worker"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Check if SP app has access to workspace 

url = f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}"

resp = requests.get(
    url,
    headers={"Authorization": f"Bearer {access_token}"}
)

print(resp.status_code)
print(resp.text)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Get the pipeline definition


url = f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}/items/{pipeline_id}/getDefinition"

resp = requests.post(
    url,
    headers={
        "Authorization": f"Bearer {access_token}"
    }
)

resp.raise_for_status()

definition = resp.json()

print(definition)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# ==========================================
#Create a new pipeline using the Service Principal

create_payload = {
    "displayName": new_pipeline_name,
    "type": "DataPipeline"
}

create_url = f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}/items"

resp = requests.post(
    create_url,
    headers={
        "Authorization": f"Bearer {access_token}"
    },
    json=create_payload
)

resp.raise_for_status()

new_pipeline = resp.json()

new_pipeline_id = new_pipeline["id"]

print(new_pipeline_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Apply the exported definition

update_url = (
    f"https://api.fabric.microsoft.com/v1/workspaces/"
    f"{workspace_id}/items/{new_pipeline_id}/updateDefinition"
)

resp = requests.post(
    update_url,
    headers ={
        "Authorization": f"Bearer {access_token}"
    },
    json=definition
)

resp.raise_for_status()

print("Definition imported")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
