# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

import requests
import json
import notebookutils

# Get Fabric API token from the notebook runner
access_token = notebookutils.credentials.getToken("https://api.fabric.microsoft.com/.default")

headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

# Define service principal and connections to assign
service_principal_object_id = "8ddcf3d0-0eec-4d51-ab7b-2ab90fb89f6a"
connection_role = "User"
connection_names = [
    "conn_fabric_pipeline",
    "conn_fabric_sql_metadata_control_db"
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# List connections visible to the current notebook runner
connections_response = requests.get(
    "https://api.fabric.microsoft.com/v1/connections",
    headers=headers
)
print("Connections status code:", connections_response.status_code)

connections_response.raise_for_status()
connections = connections_response.json().get("value", [])
print(f"Visible connections: {len(connections)}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Assign service principal to each connection
for connection_name in connection_names:
    connection_id = None

    for connection in connections:
        if connection.get("displayName") == connection_name:
            connection_id = connection.get("id")
            break

    if connection_id is None:
        print(f"Connection not found or not visible: {connection_name}")
        continue

    role_payload = {
        "principal": {
            "id": service_principal_object_id,
            "type": "ServicePrincipal"
        },
        "role": connection_role
    }

    role_response = requests.post(
        f"https://api.fabric.microsoft.com/v1/connections/{connection_id}/roleAssignments",
        headers=headers,
        json=role_payload
    )

    print(f"\nConnection: {connection_name}")
    print("connection_id:", connection_id)
    print("Status code:", role_response.status_code)
    print(role_response.text)

    if role_response.status_code == 409:
        print("Role assignment already exists.")
    else:
        role_response.raise_for_status()
        print("Role assignment created.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Confirm connection role assignments
for connection_name in connection_names:
    connection_id = None

    for connection in connections:
        if connection.get("displayName") == connection_name:
            connection_id = connection.get("id")
            break

    if connection_id is None:
        continue

    confirm_response = requests.get(
        f"https://api.fabric.microsoft.com/v1/connections/{connection_id}/roleAssignments",
        headers=headers
    )

    print(f"\nRole assignments for {connection_name}")
    print("Status code:", confirm_response.status_code)
    print(confirm_response.text)

    confirm_response.raise_for_status()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
