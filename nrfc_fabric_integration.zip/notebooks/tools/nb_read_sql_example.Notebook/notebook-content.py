# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

%run nb_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Metadata db engine using Token without Service Principal

# CELL ********************

metadata_db_token = SQLDatabase.from_metadata_control_db_token()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

metadata_db_token.execute_query('SELECT * FROM meta.connections')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Create metadata db engine

# CELL ********************

metadata_db = SQLDatabase.from_metadata_control_db()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Execute a SPROC of the metadata db

# MARKDOWN ********************


# CELL ********************

metadata_db.execute_stored_procedure(
                'meta.usp_get_tasks_due_for_execution', 
                True,True
            )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

metadata_db.execute_query('SELECT * FROM meta.connections')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # New connection  __ws_canada_mds_dev__ - CAN_RMDD


# CELL ********************

# MAGIC %%html
# MAGIC server = 'hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com'
# MAGIC database = 'CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e'  

# METADATA ********************

# META {
# META   "language": "html",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

metadata_db = SQLDatabase.from_metadata_control_db()

conn_1 = connection_info(metadata_db,1)
server = conn_1.get('server')
database = conn_1.get('database')

canrdrr_db = SQLDatabase.from_generic_db(server,database)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

canrdrr_db.execute_query('SELECT TOP 2 * FROM dbo.address')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Query Using spark - jdbc

# CELL ********************

from pyspark.sql import SparkSession

akv_uri = 'https://kv-can-non-prod-fms-cc.vault.azure.net/'

# Azure AD details
tenant_id = 'f8a46a38-2d3d-4672-ae57-34e8f266feb4'
client_id = 'ed123509-1f6d-4796-8edc-ad8f5ebc264a'
client_secret = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-SQL-NonProd")

# JDBC URL
jdbc_url = "jdbc:sqlserver://hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com:1433;database=CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e"

# Table or query
dbtable = "dbo.address"

# Build connection properties with OAuth
connection_properties = {
    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
    "encrypt": "true",
    "trustServerCertificate": "false",
    "hostNameInCertificate": "*.database.windows.net",
    "authentication": "ActiveDirectoryServicePrincipal",
    "aadSecurePrincipalId": client_id,
    "aadSecurePrincipalSecret": client_secret,
    "aadTenantId": tenant_id
}

# Read data
df = spark.read \
    .format("jdbc") \
    .option("url", jdbc_url) \
    .option("dbtable", dbtable) \
    .options(**connection_properties) \
    .load()

df.show()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Query using spark - token - jdbc

# CELL ********************

def get_access_token(tenant_id, client_id, client_secret):
    import requests
    
    
    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"
    
    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
        "resource": "https://database.windows.net/"
    }
    
    response = requests.post(token_url, data=payload)
    response.raise_for_status()
    
    return response.json()["access_token"]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

akv_uri = 'https://kv-can-non-prod-fms-cc.vault.azure.net/'
tenant_id = 'f8a46a38-2d3d-4672-ae57-34e8f266feb4'
client_id = 'ed123509-1f6d-4796-8edc-ad8f5ebc264a'
client_secret = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-SQL-NonProd")


access_token = get_access_token(tenant_id, client_id, client_secret)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


jdbc_url = "jdbc:sqlserver://hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com:1433;database=CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e"


# You can use table OR query
query = """
(SELECT TOP 2 *
 FROM dbo.address
 ) AS t
"""

df = spark.read \
    .format("jdbc") \
    .option("url", jdbc_url) \
    .option("dbtable", query) \
    .option("accessToken", access_token) \
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
    .load()

df.show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
