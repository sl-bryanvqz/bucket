# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# ### This notebook create the lakehouse folder structure

# MARKDOWN ********************


# CELL ********************

schema_name = 'asb_processing_log'
row = spark.sql(f"SHOW TABLES IN {schema_name}").first()
print(row['namespace'].split(".")[0])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from notebookutils import mssparkutils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# #### Assign correct workspace and lakehouse 

# CELL ********************

workspace_id = mssparkutils.variables.get("workspace-id")
lakehouse_id =  mssparkutils.variables.get("lakehouse-id")

base_path = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}/Files"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

folders = [
    "asb_processing_log/global_payor_messages",
    "asb_processing_log/global_client_messages",
    "asb_processing_log/global_matter_messages",
    "asb_processing_log/global_messages_processed",
    "csv_data",
    "metadata_control_db_config"
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for folder in folders:
    path = f"{base_path}/{folder}"
    
    try:
        # Check if folder exists
        if not mssparkutils.fs.exists(path):
            mssparkutils.fs.mkdirs(path)
            print(f"Created: {path}")
        else:
            print(f"Already exists: {path}")
    
    except Exception as e:
        print(f"Error for {path}: {str(e)}")

print("Process completed.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
