# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Delete all tables in a schema

# CELL ********************

def delete_all_tables_of_schema(schema_name, location_path, delete_only_table_with_prefix):
    rows = spark.sql(f"SHOW TABLES IN {schema_name}").collect()

    i = 0
    for row in rows:
        table_name = row["tableName"]

        # Keep dev backup tables and files
        if table_name.startswith("backup_"):
            print(f"Skipped table: {schema_name}.{table_name}")
            continue

        if table_name.startswith(delete_only_table_with_prefix):

            full_table = f"{schema_name}.{table_name}"
            table_path = f"{location_path}/{table_name}"

            print(f"Dropping table: {full_table}")
            spark.sql(f"DROP TABLE IF EXISTS {full_table}")

            print(f"Deleting Delta files at: {table_path}")
            try:
               mssparkutils.fs.rm(table_path, recurse=True)
            except Exception:
               print(f"Path not found or already deleted: {table_path}")

            i += 1
        
        else:
            print(f"Skipped table: {schema_name}.{table_name}")

    print(f"{i} tables were deleted.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

schema_name = 'gold_master'
location_path = "Files/gold/master"
delete_only_table_with_prefix = ''

delete_all_tables_of_schema(schema_name,location_path, delete_only_table_with_prefix)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # If you want to delete the schema and main folder

# CELL ********************

#spark.sql(f"DROP SCHEMA {schema_name}")
#mssparkutils.fs.rm(location_path, recurse=True)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
