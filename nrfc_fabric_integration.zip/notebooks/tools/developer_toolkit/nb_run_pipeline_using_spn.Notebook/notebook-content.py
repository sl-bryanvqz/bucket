# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

from notebookutils import mssparkutils
import notebookutils
import requests
import json
import base64
import time

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Service principal authentication
akv_uri = "https://kv-can-non-prod-fms-cc.vault.azure.net/"

tenant_id = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-CICD-NonProd-tenant-id")
client_id = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-CICD-NonProd-client-id")
client_secret = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-CICD-NonProd-client-secret")

token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"

token_payload = {
    "grant_type": "client_credentials",
    "client_id": client_id,
    "client_secret": client_secret,
    "scope": "https://api.fabric.microsoft.com/.default"
}

token_response = requests.post(token_url, data=token_payload)
token_response.raise_for_status()

access_token = token_response.json()["access_token"]

headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

print("Service principal token created")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Workspace and pipeline parameters
workspace_id = "d940d8ab-6c2e-4088-85b8-3335f3287cbc"
selected_pipeline_name = "pl_controller"

# List active pipelines
items_url = (
    f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}"
    f"/items?type=DataPipeline"
)

items_response = requests.get(items_url, headers=headers)

print("List status code:", items_response.status_code)
print(items_response.text)

items_response.raise_for_status()

items = items_response.json().get("value", [])

pipelines = [
    {
        "id": item["id"],
        "displayName": item["displayName"],
        "type": item["type"]
    }
    for item in items
    if item.get("type") == "DataPipeline"
]

display(pipelines)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Select pipeline by name
selected_pipeline = next(
    (
        pipeline for pipeline in pipelines
        if pipeline["displayName"].lower() == selected_pipeline_name.lower()
    ),
    None
)

if not selected_pipeline:
    available_pipelines = [pipeline["displayName"] for pipeline in pipelines]
    raise ValueError(
        f"Pipeline '{selected_pipeline_name}' was not found. Available pipelines: {available_pipelines}"
    )

pipeline_id = selected_pipeline["id"]

print("Selected pipeline:", selected_pipeline["displayName"])
print("Pipeline id:", pipeline_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Run selected pipeline
run_url = (
    f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}"
    f"/items/{pipeline_id}/jobs/Pipeline/instances"
)

run_payload = {
    "executionData": {
        "parameters": {
            "stage": "",
            "task_name": "",
            "limit_rows_for_debugging": True,
            "users_to_notify": "mary.sarafraz@nortonrosefulbright.com"
        }
    }
}

run_response = requests.post(
    run_url,
    headers=headers,
    json=run_payload
)

print("Run status code:", run_response.status_code)
print(run_response.text)
print("Location:", run_response.headers.get("Location"))

run_response.raise_for_status()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
