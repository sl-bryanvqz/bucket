# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Tables definition

# CELL ********************

schema_name = "silver_transactional"
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

location_path = "Files/silver/transactional"

tbl_properties = """
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite'     = 'true',
    'delta.autoOptimize.autoCompact'       = 'true',
    'delta.logRetentionDuration'           = 'interval 30 days',
    'delta.deletedFileRetentionDuration'   = 'interval 7 days'
)
"""

tables_definition = [
    {
        "table_name" : f"{schema_name}_chrono_metrics",
        "sql_statement" : """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            LAST_UPDATE_DT                      TIMESTAMP,
            TIMECARD_ID                         STRING,
            CLIENT_CODE                         STRING,
            MATTER_CODE                         STRING,
            MATTER_REGION_SRC                   STRING,
            GROUP_MATTER_CODE                   STRING,
            GROUP_MATTER_REGION_SRC             STRING,
            MATTER_COMPANY_CODE                 STRING,
            MATTER_BILLABLE_TYPE_CODE           STRING,
            MATTER_CURRENCY_CODE                STRING,
            TIMEKEEPER_ID                       STRING,
            FE_COMPANY_CODE                     STRING,
            FE_OFFICE_CODE                      STRING,
            FE_PRACTICE_GROUP_CODE              STRING,
            FE_TEAM_CODE                        STRING,
            FE_REGION_SRC_TRAN                  STRING,
            FE_COMPANY_CODE_TRAN                STRING,
            FE_OFFICE_CODE_TRAN                 STRING,
            FE_PRACTICE_GROUP_CODE_TRAN         STRING,
            FE_GROUP_CODE                       STRING,
            FE_SUB_GROUP_CODE                   STRING,
            FE_BAND_GROUP_CODE                  STRING,
            FE_BAND_LEVEL_CODE                  STRING,
            TIMECARD_WORKED_DATE                STRING,
            TIMECARD_WORKED_CAL_PERIOD          STRING,
            TIMECARD_POST_DATE                  STRING,
            TIMECARD_POST_CAL_PERIOD            STRING,
            CONFIDENTIAL_FLAG                   STRING,
            PRICING_UNIT                        STRING,
            HOURS_WORKED                        FLOAT,
            TIMECARD_NARRATIVE                  STRING,
            WORKED_STANDARD_RATE_DC             FLOAT,
            FEES_WORKED_AT_STANDARD_DC          FLOAT,
            WORKED_AGREED_RATE_DC               FLOAT,
            FEES_WORKED_AT_AGREED_DC            FLOAT,
            MATTER_DISCOUNT_DC                  FLOAT,
            WIP_HOURS_WRITE_UP_DOWN_VALUE_DC    FLOAT,
            FEES_WORKED_AT_AGREED_NET_DC        FLOAT,
            FEES_BILLED_AT_STANDARD_DC          FLOAT,
            FEES_BILLED_AT_AGREED_DC            FLOAT,
            MATTER_DISCOUNT_BILLED_DC           FLOAT,
            FEES_BILLED_AT_AGREED_NET_DC        FLOAT,
            FEES_WRITE_UP_DOWN_DC               FLOAT,
            HOURS_WRITE_UP_DOWN_VALUE_DC        FLOAT,
            WORKED_FEES_BILLED_NET_DC           FLOAT,
            BILL_NUM                            STRING,
            CANCEL_BILL_NUM                     STRING,
            BILL_TYPE                           STRING,
            BILL_DATE                           STRING,
            BILL_CAL_PERIOD                     STRING,
            BILL_CURRENCY_CODE                  STRING,
            HOURS_BILLED                        FLOAT,
            FEES_BILLED_DC                      FLOAT,
            BAD_DEBT_WO_DC                      FLOAT,
            FINAL_BILL_NUM                      STRING,
            FINAL_BILL_FLAG                     INT,
            MATERIAL_GROUP                      STRING,
            COLLECTED_CAL_PERIOD                STRING,
            COLLECTED_DATE                      STRING,
            HOURS_COLLECTED                     FLOAT,
            FEES_COLLECTED_DC                   FLOAT,
            PHASE_SET_CODE                      STRING,
            PHASE_SET_DESC                      STRING,
            PHASE_CODE                          STRING,
            PHASE_DESC                          STRING,
            TASK_CODE                           STRING,
            TASK_DESC                           STRING,
            ACTIVITY_CODE                       STRING,
            ACTIVITY_DESC                       STRING,
            FIXED_FEE_ACTIVITY_CODE             STRING,
            FIXED_FEE_ACTIVITY_DESC             STRING,

        --metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name" : f"{schema_name}_efi",
        "sql_statement" : """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            LAST_UPDATE_DT                      STRING,
            UNIT                                STRING,
            COMPANY_CODE                        STRING,
            COMPANY_REGION_SRC                  STRING,
            PROFIT_CENTER_CODE                  STRING,
            COST_CENTER_CODE                    STRING,
            GL_ACCOUNT_CODE                     STRING,
            FE_CODE                             STRING,
            FE_PRACTICE_GROUP_CODE              STRING,
            FE_OFFICE_CODE                      STRING,
            FE_TEAM_CODE                        STRING,
            LEAD_PARTNER_CODE                   STRING,
            LEAD_PARTNER_PRACTICE_GROUP_CODE    STRING,
            LEAD_PARTNER_OFFICE_CODE            STRING,
            LEAD_PARTNER_TEAM_CODE              STRING,
            MATTER_CODE                         STRING,
            VENDOR_CODE                         STRING,
            DOCUMENT_TEXT                       STRING,
            DOCUMENT_DATE                       STRING,
            DOCUMENT_NUMBER                     STRING,
            DOCUMENT_TYPE_CODE                  STRING,
            POSTING_PERIOD                      STRING,
            POSTING_DATE                        STRING,
            DOCUMENT_CURRENCY_CODE              STRING,
            ACTUAL_AMOUNT_DC                    FLOAT,
            OFFICE_CURRENCY_CODE                STRING,
            ACTUAL_AMOUNT_OC                    FLOAT,
            GROUP_CURRENCY_CODE                 STRING,
            ACTUAL_AMOUNT_GC                    FLOAT,
            BUDGET_AMOUNT_GC                    FLOAT,
            FORECAST_AMOUNT_GC                  FLOAT,


        --metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name" : f"{schema_name}_tme",
        "sql_statement" : """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            LAST_UPDATE_DT                      TIMESTAMP,
            CALENDAR_DAY                        TIMESTAMP,
            CALENDAR_DAY_STRING                 STRING,
            REGION_SRC                          STRING,
            TIMEKEEPER_ID                       STRING,
            GENDER                              STRING,
            PRACTICE_GROUP_CODE                 STRING,
            OFFICE_CODE                         STRING,
            TEAM_CODE                           STRING,
            EMP_GROUP_CODE                      STRING,
            EMP_SUB_GROUP_CODE                  STRING,
            BAND_GROUP_CODE                     STRING,
            BAND_LEVEL_CODE                     STRING,
            FTE                                 FLOAT,
            EMPLOYMENT_STATUS_CODE              STRING,
            EMPLOYMENT_STATUS_DESC              STRING,
            WORKDAY_FLAG                        INT,
            WEEKEND_FLAG                        INT,
            HOLIDAY_FLAG                        INT,
            CAL_YEAR                            STRING,
            CAL_PERIOD                          STRING,
            TARGET_HOURS                        FLOAT,
            BILLABLE_HOURS                      FLOAT,
            NON_BILLABLE_HOURS                  FLOAT,
            PRO_BONO_HOURS                      FLOAT,
            FIRM_RELATED_HOURS                  FLOAT,
            LEAVE_HOURS                         FLOAT,
            PART_TIME_HOURS                     FLOAT,

        --metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name" : f"{schema_name}_client_financials",
        "sql_statement" : """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            CLIENTID                            STRING,
            MEMBERFIRMCODE                      STRING,
            TOTALWIP                            FLOAT,
            LASTWIPDATE                         TIMESTAMP,
            TOTALAR                             FLOAT,
            LASTBILLDATE                        TIMESTAMP,
            TRUSTFUNDSBALANCE                   FLOAT,
            UNALLOCATEDFUNDSBALANCE             FLOAT,
            RETAINERFUNDSBALANCE                FLOAT,
            CLIENTCURRENCY                      STRING,
            PROCESSTIMESTAMP                    TIMESTAMP,

        --metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name" : f"{schema_name}_matter_financials",
        "sql_statement" : """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            MATTERID                            STRING,
            MEMBERFIRMCODE                      STRING,
            CLIENTNUMBER                        STRING,
            TOTALWIP                            FLOAT,
            LASTWIPDATE                         TIMESTAMP,
            TOTALAR                             FLOAT,
            TOTALFEESBILLED                     FLOAT,
            LASTBILLDATE                        TIMESTAMP,
            TRUSTFUNDSBALANCE                   FLOAT,
            UNALLOCATEDFUNDSBALANCE             FLOAT,
            RETAINERFUNDSBALANCE                FLOAT,
            MATTERCURRENCY                      STRING,
            PROCESSTIMESTAMP                    TIMESTAMP,

        --metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    }
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Create all tables 

# CELL ********************

for t in tables_definition:
    table_name = t["table_name"]

    sql = t["sql_statement"].format(
        schema_name=schema_name,
        table_name=table_name,
        location_path=location_path,
        tbl_properties=tbl_properties   
    )

    spark.sql(sql)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
