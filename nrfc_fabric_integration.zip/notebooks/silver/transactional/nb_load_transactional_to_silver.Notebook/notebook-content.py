# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "known_warehouses": []
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Define notebook Parameters
# 
# Pass through th pl_worker

# CELL ********************

# Framework-compatible parameters with manual fallbacks
import json
import uuid

# Basic notebook runtime values
task_id = 50
task_name = "Load transactional to silver"
lineage_id = str(uuid.uuid4())
limit_rows_for_debugging = False
prev_wm = None
curr_wm = None
execution_errors = []

# Source settings > what data to read
source_settings = json.dumps(
    {
        "source_name": "lh_canada_global_mds",
        "source_type": "csv",
        "source_location": "lh_canada_global_mds",
        "source_schema": "Files/csv_data",
        "table_config": [
            {   
                "source_table": "EFI",
                "target_table": "silver_transactional_efi",
                "target_pk": ["unit", "company_code", "profit_center_code", "cost_center_code", "gl_account_code", "fe_practice_group_code", "fe_office_code", "fe_team_code", "document_type_code", "posting_period", "document_number", "budget_amount_gc", "forecast_amount_gc", "actual_amount_gc"]
            },
            {
                "source_table": "TME",
                "target_table": "silver_transactional_tme",
                "target_pk": ["calendar_day", "timekeeper_id", "region_src", "practice_group_code", "office_code", "team_code", "emp_sub_group_code", "band_level_code", "employment_status_code", "cal_period"]
            },
            {
                "source_table": "ChronoMetrics",
                "target_table": "silver_transactional_chrono_metrics",
                "target_pk": ["timecard_id", "client_code", "matter_code", "matter_region_src", "timekeeper_id", "timecard_worked_date", "timecard_post_date", "bill_num", "final_bill_num", "phase_code", "task_code", "hours_worked", "fees_worked_at_standard_dc", "hours_collected"]
            },
            {
                "source_table": "MatterFinancials",
                "target_table": "silver_transactional_matter_financials",
                "target_pk": ["id"]
            },
            {
                "source_table": "ClientFinancials",
                "target_table": "silver_transactional_client_financials",
                "target_pk": ["id"]
            }
        ]
    }
)

# Target settings > here/how to write
target_settings = json.dumps(
    {
        "target_workspace": "ws_canada_global_mds_dev",
        "target_lakehouse": "lh_canada_global_mds",
        "target_schema": "silver_transactional",
        "target_location": "Files/silver/transactional",
        "target_load_strategy": "overwrite"
    }
)

# Connection settings > how to connect/authenticate
source_connection_settings  = "{}"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
