# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    source_table             = "CostCenter"
    source_view              = f"src_{to_snake_case(source_table)}"
    map_view                 = f"map_{to_snake_case(source_table)}"
    target_workspace         = "ws_canada_global_mds_dev"
    target_lakehouse         = "lh_canada_global_mds"
    target_table             = f"silver_rmdd_{source_table}"
    target_pk                = ["cost_centre_code", "member_firm_code", "valid_from_date"]
    limit_rows_for_debugging = True
    watermark_filter         = "s.TIMESTAMP > '1900-01-01 00:00:00' AND s.TIMESTAMP <= '2027-08-30 00:00:00'"
    
# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"source_view: {source_view}")
    print(f"map_view: {map_view}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create source view when running this transform notebook alone
if not spark.catalog.tableExists(source_view):
    create_source_view(
        source_view=source_view,
        source_schema="dbo",
        source_table=source_table,
        source_type="sql_database",
        source_location="CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e",
        source_connection_settings={
            "server_name": "hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com"
        }
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT 
    CAST(row_number() OVER (ORDER BY s.CostCenter) AS BIGINT)                 AS cost_centre_key,
    COALESCE(NULLIF(TRIM(CAST(s.CostCenter AS STRING)), ''), 'Unknown')       AS cost_centre_code,
    COALESCE(s.CostCenterId, -1)                                              AS cost_centre_id,
    CAST('GPMS' AS STRING)                                                    AS member_firm_code,
    CAST(s.ValidFromDate AS TIMESTAMP)                                        AS valid_from_date,
    CAST(COALESCE(s.ValidToDate, '1900-01-01') AS TIMESTAMP)                  AS valid_to_date,
    COALESCE(NULLIF(TRIM(CAST(s.CompanyCode AS STRING)), ''), 'Unknown')      AS company_code,

    -- Get company_key from stage_taxonomy_curated_company using s.CompanyCode = lkp.company_code
    COALESCE(CAST({lookup_function(
        table_lookup    =   f"{target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_company",
        key_mapping     =   ("s.CompanyCode", "lkp.company_code"),
        return_column   =   "company_key")} AS INT), -1)                      AS company_key,

    COALESCE(NULLIF(TRIM(CAST(s.CurrencyKey AS STRING)), ''), 'Unknown')      AS currency_code,

    -- Get currency_key from stage_taxonomy_curated_currency using s.CurrencyKey = lkp.currency_code
    COALESCE(CAST({lookup_function(
        table_lookup    =   f"{target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_currency",
        key_mapping     =   ("s.CurrencyKey", "lkp.currency_code"),
        return_column   =   "currency_key")} AS INT), -1)                     AS currency_key,

    COALESCE(NULLIF(TRIM(CAST(s.ProfitCenter AS STRING)), ''), 'Unknown')     AS profit_centre,
    COALESCE(NULLIF(TRIM(CAST(s.Description AS STRING)), ''), 'Unknown')      AS cost_centre_description,
    COALESCE(NULLIF(TRIM(CAST(s.LongDescription AS STRING)), ''), 'Unknown')  AS cost_centre_long_description,

    -- Mark cost_center active when valid_to_date is 9999-12-31
    CASE
        WHEN TO_DATE(CAST(s.ValidToDate AS STRING)) = TO_DATE('9999-12-31') THEN true
        ELSE false
    END                                                                       AS is_active,
    
    CAST(COALESCE(s.TIMESTAMP, '1900-01-01') AS TIMESTAMP)                    AS last_updated_date_utc_at_source
FROM {source_view} s
WHERE {watermark_filter}
    AND TO_DATE(CAST(s.ValidToDate AS STRING)) = TO_DATE('9999-12-31') --active flag
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(spark.sql(f"""
SELECT count(*) from {map_view}
"""))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
