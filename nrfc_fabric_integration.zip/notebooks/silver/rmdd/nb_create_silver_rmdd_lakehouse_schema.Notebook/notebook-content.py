# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Define schema tables
# 
# Define the definition schema for each table, run schema if not exists

# CELL ********************

schema_name = "silver_rmdd"
location_path = "Files/silver/rmdd"

tbl_properties = """
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite'     = 'true',
    'delta.autoOptimize.autoCompact'       = 'true',
    'delta.logRetentionDuration'           = 'interval 30 days',
    'delta.deletedFileRetentionDuration'   = 'interval 7 days')
"""

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tables_definition = [
    {
        "table_name": "silver_rmdd_address",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            address_key                         BIGINT,
            address_id                          INT,
            entity_id                           INT,
            entity_type_code                    STRING,
            source_system_id                    INT,
            address_type_code                   STRING,
            address_1                           STRING,
            address_2                           STRING,
            address_3                           STRING,
            address_4                           STRING,
            address_5                           STRING,
            city                                STRING,
            country_id                          INT,
            state                               STRING,
            zip_code                            STRING,
            street_address_check                STRING,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_client",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            client_key                          BIGINT,
            client_number                       STRING,
            member_firm_code                    STRING,
            client_id                           INT,
            client_status_id                    INT,
            pms_client_id                       INT,
            client_name                         STRING,
            alternate_client_name               STRING,
            contact_name                        STRING,
            open_date_utc                       TIMESTAMP,
            close_date_utc                      TIMESTAMP,
            client_duns                         STRING,
            client_guduns                       STRING,
            comments                            STRING,
            pms_entity_type                     STRING,
            client_type                         STRING,
            is_confidential                     STRING,
            sic_code                            STRING,
            client_sector_key                   INT,
            is_sanctions_checked                STRING,
            is_active                           BOOLEAN,
            created_date_utc_at_source          TIMESTAMP,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_cost_centre",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            cost_centre_key                     BIGINT,
            cost_centre_code                    STRING,
            cost_centre_id                      INT,
            member_firm_code                    STRING,
            valid_from_date                     TIMESTAMP,
            valid_to_date                       TIMESTAMP,
            company_code                        STRING,
            company_key                         INT,
            currency_code                       STRING,
            currency_key                        INT,
            profit_centre                       STRING,
            cost_centre_description             STRING,
            cost_centre_long_description        STRING,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_country",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            country_key                         BIGINT,
            country_id                          INT,
            country_code                        STRING,
            country_code_long                   STRING,
            country_name                        STRING,
            country_name_title_case             STRING,
            country_code_iso2                   STRING,
            country_code_iso3                   STRING,
            country_code_iso4                   STRING,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_email",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            email_key                           BIGINT,
            entity_id                           STRING,
            email_address                       STRING,
            email_type_code                     STRING,
            entity_type_code                    STRING,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_employee_sub_group",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            employee_sub_group_surr_key         BIGINT,
            sub_group_id                        INT,
            group_code                          STRING,
            group_description                   STRING,
            sub_group_code                      STRING,
            sub_group_description               STRING,
            employee_sub_group_key              BIGINT,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_matter",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            matter_key                          BIGINT,
            matter_number                       STRING,
            member_firm_code                    STRING,
            matter_id                           INT,
            pms_matter_id                       INT,
            matter_status_id                    INT,
            matter_name                         STRING,
            long_matter_name                    STRING,
            alternate_matter_name               STRING,
            alternate_matter_number             STRING,
            office_id                           INT,
            nature_of_proceeding_code           STRING,
            nature_of_proceeding_key            BIGINT,
            client_id                           INT,
            is_confidential                     BOOLEAN,
            currency_code                       STRING,
            matter_open_date_utc                TIMESTAMP,
            matter_close_date_utc               TIMESTAMP,
            matter_billable_flag                INT,
            matter_time_unit                    STRING,
            sub_industry                        STRING,
            matter_sector_key                   BIGINT,
            team_id                             INT,
            comments                            STRING,
            group_billing                       STRING,
            reporting_group                     STRING,
            is_sanctions_checked                BOOLEAN,
            technical_area_code                 STRING,
            work_type_key                       BIGINT,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_matter_office",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            matter_office_key                   BIGINT,
            office_id                           STRING,
            matter_id                           INT,
            company_code                        STRING,
            member_firm_code                    STRING,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_matter_status",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            matter_status_key                   BIGINT,
            matter_status_id                    INT,
            pms_status_code                     STRING,
            sap_code                            STRING,
            matter_status_code                  STRING,
            curated_matter_status_key           BIGINT,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_office",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            office_surr_key                     BIGINT,
            office_id                           INT,
            office_code                         STRING,
            sap_code                            STRING,
            member_firm_code                    STRING,
            office_name                         STRING,
            office_key                          BIGINT,
            company_key                         BIGINT,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_person",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            person_key                          BIGINT,
            person_number                       STRING,
            member_firm_code                    STRING,
            person_id                           INT,
            person_status_code                  STRING,
            gender                              STRING,
            prefix                              STRING,
            first_name                          STRING,
            first_name_known_as                 STRING,
            middle_name                         STRING,
            last_name                           STRING,
            suffix                              STRING,
            initials                            STRING,
            photo_path                          STRING,
            commencement_date_utc               TIMESTAMP,
            departure_date_utc                  TIMESTAMP,
            leave_status                        STRING,
            sub_team_id                         INT,
            job_title                           STRING,
            job_title_pms                       STRING,
            practice_group_code                 STRING,
            practice_group_key                  BIGINT,
            year_of_call                        STRING,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_person_cost_centre",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            person_cost_centre_key              BIGINT,
            person_cost_centre_id               INT,
            person_id                           INT,
            cost_centre_id                      INT,
            start_date                          TIMESTAMP,
            end_date                            TIMESTAMP,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_person_locale",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            personlocale_key                    BIGINT,
            member_firm_code                    STRING,
            person_id                           INT,
            office_id                           INT,
            desk_location                       STRING,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_person_relationship",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            person_relationship_key             BIGINT,
            person_id_1                         INT,
            person_id_2                         INT,
            person_relationship_id              INT,
            relationship_type_id                INT,
            primary_flag                        STRING,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_person_system_map",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            person_system_map_key               BIGINT,
            member_firm_code                    STRING,
            person_id                           INT,
            timekeeper_id                       STRING,
            domain_name                         STRING,
            gpms_external_person_id             STRING,
            gpms_personnel_number               STRING,
            unified_sap_person_external_id      STRING,
            windows_login                       STRING,
            dms_system_id                       STRING,
            human_resources_system_id           STRING,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_phone",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            phone_key                           BIGINT,
            entity_id                           INT,
            entity_type_code                    STRING,
            phone_number                        STRING,
            phone_extension                     STRING,
            phone_type_code                     STRING,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_relationship_type",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            relationship_type_key               BIGINT,
            relationship_type_id                INT,
            relationship_description            STRING,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_sub_team",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            sub_team_key                        BIGINT,
            sub_team_id                         INT,
            team_id                             INT,
            member_firm_code                    STRING,
            sub_team_code                       STRING,
            sub_team_name                       STRING,
            team_key                            BIGINT,
            sap_code                            STRING,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_rmdd_team",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            sub_team_key                        BIGINT,
            team_id                             INT,
            group_id                            INT,
            member_firm_code                    STRING,
            entity_type_code                    STRING,
            team_code                           STRING,
            team_name                           STRING,
            team_key                            BIGINT,
            is_active                           BOOLEAN,
            last_updated_date_utc_at_source     TIMESTAMP,

        -- metadata
            _hashed_pk                          STRING,
            _hashed_row                         STRING,
            _process_timestamp                   TIMESTAMP,
            _source_system                      STRING,
            _source_table                       STRING,
            _target_table                       STRING,
            _lineage_id                         STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    }
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Create all tables
# 
# Run sql_statement from table_name on config

# CELL ********************

for t in tables_definition:
    table_name = t["table_name"]

    sql = t["sql_statement"].format(
        schema_name=schema_name,
        table_name=table_name,
        location_path=location_path,
        tbl_properties=tbl_properties
    )
    
    print(f"Creating {schema_name}.{table_name}")
    spark.sql(sql)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
