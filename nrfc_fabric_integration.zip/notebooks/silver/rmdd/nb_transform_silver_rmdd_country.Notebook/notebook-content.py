# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    source_table             = "Country"
    source_view              = f"src_{to_snake_case(source_table)}"
    map_view                 = f"map_{to_snake_case(source_table)}"
    target_workspace         = "ws_canada_global_mds_dev"
    target_lakehouse         = "lh_canada_global_mds"
    target_table             = f"silver_rmdd_{to_snake_case(source_table)}"
    target_pk                = ["country_id"]
    limit_rows_for_debugging = True
    watermark_filter         = "1=1"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"source_view: {source_view}")
    print(f"map_view: {map_view}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create source view when running this transform notebook alone
if not spark.catalog.tableExists(source_view):
    create_source_view(
        source_view=source_view,
        source_schema="dbo",
        source_table=source_table,
        source_type="sql_database",
        source_location="CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e",
        source_connection_settings={
            "server_name": "hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com"
        }
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT DISTINCT
    CAST(row_number() OVER (ORDER BY s.CountryID) AS BIGINT)                                      AS country_key,
    COALESCE(s.CountryID, -1)                                                                     AS country_id,

    -- RMDD country source values
    COALESCE(NULLIF(UPPER(TRIM(s.CountryCode)), ''), 'Unknown')                                   AS country_code,
    COALESCE(NULLIF(UPPER(TRIM(s.CountryCodeLong)), ''), 'Unknown')                               AS country_code_long,
    COALESCE(NULLIF(TRIM(s.CountryName), ''), 'Unknown')                                          AS country_name,
    COALESCE(NULLIF(TRIM(s.CountryNameTitleCase), ''), 'Unknown')                                 AS country_name_title_case,

    -- Script path: RMDD Country.CountryCode -> taxonomy country_code_iso2
    COALESCE(NULLIF(UPPER(TRIM({lookup_function(
        table_lookup    =   f"{target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_country",
        key_mapping     =   ("UPPER(TRIM(s.CountryCode))", "UPPER(TRIM(lkp.country_code_iso2))"),
        return_column   =   "country_code_iso2")})), ''), 'Unknown')                              AS country_code_iso2,

    COALESCE(NULLIF(UPPER(TRIM({lookup_function(
        table_lookup    =   f"{target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_country",
        key_mapping     =   ("UPPER(TRIM(s.CountryCode))", "UPPER(TRIM(lkp.country_code_iso2))"),
        return_column   =   "country_code_iso3")})), ''), 'Unknown')                              AS country_code_iso3,

    COALESCE(NULLIF(TRIM({lookup_function(
        table_lookup    =   f"{target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_country",
        key_mapping     =   ("UPPER(TRIM(s.CountryCode))", "UPPER(TRIM(lkp.country_code_iso2))"),
        return_column   =   "country_code_iso4")}), ''), 'Unknown')                               AS country_code_iso4,

    CAST(true AS BOOLEAN)                                                                         AS is_active,
    current_timestamp()                                                                           AS last_updated_date_utc_at_source

FROM {source_view} s
WHERE {watermark_filter}
    AND s.CountryID IS NOT NULL
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
