# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    source_table             = "Client"
    source_view              = f"src_{to_snake_case(source_table)}"
    map_view                 = f"map_{to_snake_case(source_table)}"
    target_workspace         = "ws_canada_global_mds_dev"
    target_lakehouse         = "lh_canada_global_mds"
    target_table             = f"silver_rmdd_{source_table}"
    target_pk                = ["client_number", "member_firm_code"]
    limit_rows_for_debugging = True
    watermark_filter         = "s.LastUpdatedDateGMT > '1900-01-01 00:00:00' AND s.LastUpdatedDateGMT <= '2027-06-30 00:00:00'"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"source_view: {source_view}")
    print(f"map_view: {map_view}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create source view when running this transform notebook alone
if not spark.catalog.tableExists(source_view):
    create_source_view(
        source_view=source_view,
        source_schema="dbo",
        source_table=source_table,
        source_type="sql_database",
        source_location="CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e",
        source_connection_settings={
            "server_name": "hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com"
        }
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT DISTINCT

    CAST(row_number() OVER (ORDER BY s.ClientID) AS BIGINT)                                              AS client_key,
    COALESCE(NULLIF(TRIM(s.ClientNumber), ''), 'Unknown')                                                AS client_number,
    COALESCE(NULLIF(TRIM(s.MemberFirmCode), ''), 'Unknown')                                              AS member_firm_code,
    COALESCE(s.ClientID, -1)                                                                             AS client_id,

    -- Needed by gold client/client-to-migrate logic
    s.ClientStatusID                                                                                     AS client_status_id,

    COALESCE(CAST(s.PMSClientID AS STRING), '-1')                                                        AS pms_client_id,
    COALESCE(NULLIF(TRIM(s.ClientName), ''), 'Unknown')                                                  AS client_name,
    COALESCE(NULLIF(TRIM(s.AlternateClientName), ''), 'Unknown')                                         AS alternate_client_name,
    COALESCE(NULLIF(REGEXP_REPLACE(s.ContactName, '[\\t\\n\\f\\r\\x16\\xA0\\xFF ]', ''), ''), 'Unknown') AS contact_name,
    COALESCE(s.OpenDateGMT, TIMESTAMP '1900-01-01 00:00:00')                                             AS open_date_utc,
    COALESCE(s.CloseDateGMT, TIMESTAMP '9999-12-31 00:00:00')                                            AS close_date_utc,
    COALESCE(NULLIF(TRIM(s.ClientDUNS), ''), 'Unknown')                                                  AS client_duns,
    COALESCE(NULLIF(TRIM(s.ClientGUDUNS), ''), 'Unknown')                                                AS client_guduns,
    COALESCE(NULLIF(REGEXP_REPLACE(s.Comments, '[\\x01\\t\\n\\f\\r\\x16 ]', ''), ''), 'Unknown')         AS comments,
    COALESCE(NULLIF(TRIM(s.PMSEntityType), ''), 'Unknown')                                               AS pms_entity_type,

    CASE
        WHEN (s.ClientType IS NULL OR TRIM(s.ClientType) = '') AND TRIM(s.MemberFirmCode) = 'GPMS' THEN 'O'
        WHEN TRIM(s.ClientType) = 'O' THEN 'O'
        WHEN TRIM(s.ClientType) IN ('X', 'P', 'I') THEN 'P'
        ELSE COALESCE(NULLIF(TRIM(s.ClientType), ''), 'Unknown')
    END                                                                                                  AS client_type,

    
    COALESCE(TRY_CAST(TRIM(s.IsConfidential) AS BOOLEAN), false)                                         AS is_confidential,
    COALESCE(NULLIF(TRIM(s.SICCode), ''), 'Unknown')                                                     AS sic_code,

    -- Get client_sector_key from stage_taxonomy_curated_client_sector using s.SICCode = lkp.sic_code
    COALESCE(CAST({lookup_function(
        table_lookup    =   f"{target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_client_sector",
        key_mapping     =   ("s.SICCode", "lkp.sic_code"),
        return_column   =   "client_sector_key")} AS INT), -1)                                           AS client_sector_key,

    COALESCE(TRY_CAST(TRIM(s.SanctionsChecked_YN) AS BOOLEAN), false)                                    AS is_sanctions_checked,
    COALESCE(CAST(s.Active AS BOOLEAN), false)                                                           AS is_active,
    COALESCE(s.CreatedDateGMT, TIMESTAMP '1900-01-01 00:00:00')                                          AS created_date_utc_at_source,

    GREATEST(
        COALESCE(CAST(s.LastUpdatedDateGMT AS TIMESTAMP), current_timestamp()),
        COALESCE(CAST(s.PMSLastModifiedGMT AS TIMESTAMP), current_timestamp())
    )                                                                                                    AS last_updated_date_utc_at_source

FROM {source_view} s
WHERE {watermark_filter}
    AND s.Active = True
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
