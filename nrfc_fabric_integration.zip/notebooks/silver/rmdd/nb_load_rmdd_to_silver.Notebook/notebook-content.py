# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "known_warehouses": []
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Define notebook Parameters
# 
# Pass through th pl_worker

# CELL ********************

# Framework-compatible parameters with manual fallbacks
import json
import uuid

# Basic notebook runtime values
task_id = 50
task_name = "Load RMDD to silver"
lineage_id = str(uuid.uuid4())
limit_rows_for_debugging = True
prev_wm = "1900-01-01 00:00:00"
curr_wm = "2026-08-30 00:00:00"
execution_errors = []

# Source settings > what data to read
source_settings = json.dumps(
    {
        "source_name": "CAN_RMDD",
        "source_type": "sql_database",
        "source_location": "CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e",
        "source_schema": "dbo",
        "table_config": [
            # {
            #     "source_table": "Address",
            #     "target_table": "silver_rmdd_address",
            #     "target_pk": ["address_id"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_address"
            # },
            # {
            #     "source_table": "Client",
            #     "target_table": "silver_rmdd_client",
            #     "target_pk": ["client_number", "member_firm_code"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_client"
            # },
            # {
            #     "source_table": "CostCenter",
            #     "target_table": "silver_rmdd_cost_centre",
            #     "target_pk": ["cost_centre_code", "member_firm_code", "valid_from_date"],
            #     "is_incremental": 0,
            #     "transformation_notebook": "nb_transform_silver_rmdd_cost_centre"
            # },
            # {
            #     "source_table": "Country",
            #     "target_table": "silver_rmdd_country",
            #     "target_pk": ["country_id"],
            #     "is_incremental": 0,
            #     "incremental_column": "",
            #     "transformation_notebook": "nb_transform_silver_rmdd_country"
            # },
            # {
            #     "source_table": "Email",
            #     "target_table": "silver_rmdd_email",
            #     "target_pk": ["entity_id"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_email"
            # },
            # {
            #     "source_table": "EmployeeSubGroup",
            #     "target_table": "silver_rmdd_employee_sub_group",
            #     "target_pk": ["sub_group_id"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_employee_sub_group"
            # },
            # {
            #     "source_table": "Matter",
            #     "target_table": "silver_rmdd_matter",
            #     "target_pk": ["matter_number", "member_firm_code"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_matter"
            # },
            # {
            #     "source_table": "MatterOffice",
            #     "target_table": "silver_rmdd_matter_office",
            #     "target_pk": ["office_id", "matter_id"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDate",
            #     "transformation_notebook": "nb_transform_silver_rmdd_matter_office"
            # },
            # {
            #     "source_table": "MatterStatus",
            #     "target_table": "silver_rmdd_matter_status",
            #     "target_pk": ["matter_status_id"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_matter_status"
            # },
            # {
            #     "source_table": "Office_RMDD",
            #     "target_table": "silver_rmdd_office",
            #     "target_pk": ["office_id"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_office"
            # },
            {
                "source_table": "Person",
                "target_table": "silver_rmdd_person",
                "target_pk": ["person_number", "member_firm_code"],
                "is_incremental": 1,
                "incremental_column": "LastUpdatedDateGMT",
                "transformation_notebook": "nb_transform_silver_rmdd_person"
            #},
            # {
            #     "source_table": "PersonCostCentre",
            #     "target_table": "silver_rmdd_person_cost_centre",
            #     "target_pk": ["person_cost_centre_id"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_person_cost_centre"
            # },
            # {
            #     "source_table": "PersonLocale",
            #     "target_table": "silver_rmdd_person_locale",
            #     "target_pk": ["person_id"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_person_locale"
            # },
            # {
            #     "source_table": "PersonRelationship",
            #     "target_table": "silver_rmdd_person_relationship",
            #     "target_pk": ["person_relationship_id"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_person_relationship"
            #  },
            # {
            #     "source_table": "PersonSystemMap",
            #     "target_table": "silver_rmdd_person_system_map",
            #     "target_pk": ["person_id"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_person_system_map"
            # },
            # {
            #     "source_table": "Phone",
            #     "target_table": "silver_rmdd_phone",
            #     "target_pk": ["entity_id", "entity_type_code", "phone_type_code"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_phone"
            # },
            # {
            #     "source_table": "RelationshipType",
            #     "target_table": "silver_rmdd_relationship_type",
            #     "target_pk": ["relationship_type_id"],
            #     "is_incremental": 0,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_relationship_type"
            # },
            # {
            #     "source_table": "SubTeam_RMDD",
            #     "target_table": "silver_rmdd_sub_team",
            #     "target_pk": ["sub_team_id"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_sub_team"
            # },
            # {
            #     "source_table": "Team_RMDD",
            #     "target_table": "silver_rmdd_team",
            #     "target_pk": ["team_id"],
            #     "is_incremental": 1,
            #     "incremental_column": "LastUpdatedDateGMT",
            #     "transformation_notebook": "nb_transform_silver_rmdd_team"
            }
        ]
    }
)

# Target settings > here/how to write
target_settings = json.dumps(
    {
        "target_workspace": "ws_canada_global_mds_dev",
        "target_lakehouse": "lh_canada_global_mds",
        "target_schema": "silver_rmdd",
        "target_location": "Files/silver/rmdd",
        "target_load_strategy": "merge-scd1"
    }
)

# Connection settings > how to connect/authenticate
source_connection_settings = json.dumps(
    {
        "server_name": "hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com"
    }
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
