# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    source_table             = "Address"
    source_view              = f"src_{to_snake_case(source_table)}"
    map_view                 = f"map_{to_snake_case(source_table)}"
    target_workspace         = "ws_canada_global_mds_dev"
    target_lakehouse         = "lh_canada_global_mds"
    target_table             = f"silver_rmdd_{source_table}"
    target_pk                = ["address_id"]
    limit_rows_for_debugging = True
    watermark_filter         = "s.LastUpdatedDateGMT > '1900-01-01 00:00:00' AND s.LastUpdatedDateGMT <= '2026-08-30 00:00:00'"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"source_view: {source_view}")
    print(f"map_view: {map_view}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create source view when running this transform notebook alone
if not spark.catalog.tableExists(source_view):
    create_source_view(
        source_view=source_view,
        source_schema="dbo",
        source_table=source_table,
        source_type="sql_database",
        source_location="CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e",
        source_connection_settings={
            "server_name": "hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com"
        }
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT DISTINCT
    CAST(row_number() OVER (ORDER BY s.AddressID) AS BIGINT)                                      AS address_key,
    COALESCE(CAST(s.AddressID AS STRING) , '-1')                                                  AS address_id,
    COALESCE(s.EntityID, -1)                                                                      AS entity_id,

    -- Needed by gold address filters and latest-address rule
    COALESCE(NULLIF(UPPER(TRIM(CAST(s.EntityTypeCode AS STRING))), ''), 'Unknown')                AS entity_type_code,
    COALESCE(NULLIF(UPPER(TRIM(CAST(s.AddressTypeCode AS STRING))), ''), 'Unknown')               AS address_type_code,

    -- Remove CHAR(9), CHAR(10), CHAR(12), CHAR(13), CHAR(22), and spaces
    COALESCE(NULLIF(REGEXP_REPLACE(CAST(s.Address1 AS STRING), '[\\t\\n\\f\\r\\x16 ]', ''), ''), 'Unknown') AS address_1,
    COALESCE(NULLIF(REGEXP_REPLACE(CAST(s.Address2 AS STRING), '[\\t\\n\\f\\r\\x16 ]', ''), ''), 'Unknown') AS address_2,
    COALESCE(NULLIF(REGEXP_REPLACE(CAST(s.Address3 AS STRING), '[\\t\\n\\f\\r\\x16 ]', ''), ''), 'Unknown') AS address_3,
    COALESCE(NULLIF(REGEXP_REPLACE(CAST(s.Address4 AS STRING), '[\\t\\n\\f\\r\\x16 ]', ''), ''), 'Unknown') AS address_4,
    COALESCE(NULLIF(REGEXP_REPLACE(CAST(s.Address5 AS STRING), '[\\t\\n\\f\\r\\x16 ]', ''), ''), 'Unknown') AS address_5,

    COALESCE(NULLIF(TRIM(CAST(s.City AS STRING)), ''), 'Unknown')                                 AS city,
    COALESCE(s.CountryID, -1)                                                                     AS country_id,
    COALESCE(NULLIF(TRIM(CAST(s.State AS STRING)), ''), 'Unknown')                                AS state,
    COALESCE(NULLIF(TRIM(CAST(s.PostalCode AS STRING)), ''), 'Unknown')                           AS zip_code,

    -- Moving street_address_check to silver since it is used for more than one gold table
    COALESCE(NULLIF(TRIM(
        CONCAT_WS(
            ' ',
            NULLIF(REGEXP_REPLACE(CAST(s.Address1 AS STRING), '[\\t\\n\\f\\r\\x16 ]', ''), ''),
            NULLIF(REGEXP_REPLACE(CAST(s.Address2 AS STRING), '[\\t\\n\\f\\r\\x16 ]', ''), ''),
            NULLIF(REGEXP_REPLACE(CAST(s.Address3 AS STRING), '[\\t\\n\\f\\r\\x16 ]', ''), ''),
            NULLIF(REGEXP_REPLACE(CAST(s.Address4 AS STRING), '[\\t\\n\\f\\r\\x16 ]', ''), ''),
            NULLIF(REGEXP_REPLACE(CAST(s.Address5 AS STRING), '[\\t\\n\\f\\r\\x16 ]', ''), '')
        )
    ), ''), 'Unknown')                                                                            AS street_address_check,
        
    COALESCE(CAST(s.Active AS BOOLEAN), false)                                                    AS is_active,
    COALESCE(CAST(s.LastUpdatedDateGMT AS TIMESTAMP), current_timestamp())                        AS last_updated_date_utc_at_source

FROM {source_view} s
WHERE {watermark_filter}
    AND COALESCE(CAST(s.Active AS BOOLEAN), false) = true
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
