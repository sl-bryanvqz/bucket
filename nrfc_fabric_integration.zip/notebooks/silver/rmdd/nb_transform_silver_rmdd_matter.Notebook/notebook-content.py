# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    source_table             = "Matter"
    source_view              = f"src_{to_snake_case(source_table)}"
    map_view                 = f"map_{to_snake_case(source_table)}"
    target_workspace         = "ws_canada_global_mds_dev"
    target_lakehouse         = "lh_canada_global_mds"
    target_table             = f"silver_rmdd_{source_table}"
    target_pk                = ["matter_number", "member_firm_code"]
    limit_rows_for_debugging = True
    watermark_filter         = "s.LastUpdatedDateGMT > '1900-01-01 00:00:00' AND s.LastUpdatedDateGMT <= '2025-06-30 00:00:00'"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"source_view: {source_view}")
    print(f"map_view: {map_view}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create source view when running this transform notebook alone
if not spark.catalog.tableExists(source_view):
    create_source_view(
        source_view=source_view,
        source_schema="dbo",
        source_table=source_table,
        source_type="sql_database",
        source_location="CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e",
        source_connection_settings={
            "server_name": "hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com"
        }
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT DISTINCT
    CAST(row_number() OVER (ORDER BY s.MatterID) AS BIGINT)                                           AS matter_key,
    TRIM(s.MatterNumber)                                                                              AS matter_number,
    COALESCE(TRIM(s.MemberFirmCode), 'Unknown')                                                       AS member_firm_code,
    COALESCE(s.MatterID, -1)                                                                          AS matter_id,
    COALESCE(CAST(s.PMSMatterID AS STRING), '-1')                                                     AS pms_matter_id,

    -- Needed by gold matter join to silver_rmdd_matter_status
    s.MatterStatusID                                                                                  AS matter_status_id,

    COALESCE(NULLIF(TRIM(s.MatterName), ''), 'Unknown')                                               AS matter_name,
    COALESCE(NULLIF(TRIM(s.LongMatterName), ''), 'Unknown')                                           AS long_matter_name,
    COALESCE(NULLIF(TRIM(s.AlternateMatterName), ''), 'Unknown')                                      AS alternate_matter_name,
    COALESCE(NULLIF(TRIM(s.AlternateMatterNumber), ''), 'Unknown')                                    AS alternate_matter_number,

    -- Needed by gold matter join to silver_rmdd_office
    s.OfficeID                                                                                        AS office_id,

    TRIM(s.NatureOfProceeding)                                                                        AS nature_of_proceeding_code,

    -- Get nature_of_proceeding_key from stage_taxonomy_curated_nature_of_proceeding using s.NatureOfProceeding = lkp.nature_of_proceeding_code
    COALESCE(CAST({lookup_function(
        table_lookup    =   f"{target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_nature_of_proceeding",
        key_mapping     =   ("s.NatureOfProceeding", "lkp.nature_of_proceeding_code"),
        return_column   =   "nature_of_proceeding_key")} AS BIGINT), -1)                              AS nature_of_proceeding_key,

    -- Needed by gold matter join to silver_rmdd_client
    s.ClientID                                                                                        AS client_id,

    -- Client script treats blank, N, and X as false
    CASE
        WHEN COALESCE(UPPER(TRIM(s.Confidential)), '') IN ('', 'N', 'X') THEN false
        WHEN UPPER(TRIM(s.Confidential)) = 'Y' THEN true
        ELSE false
    END                                                                                               AS is_confidential,

    COALESCE(NULLIF(TRIM(s.CurrencyCode), ''), 'Unknown')                                             AS currency_code,
    COALESCE(s.MatterOpenDateGMT, TIMESTAMP '1900-01-01 00:00:00')                                    AS matter_open_date_utc,
    COALESCE(s.MatterCloseDateGMT, TIMESTAMP '9999-12-31 00:00:00')                                   AS matter_close_date_utc,
    COALESCE(s.MatterBillableFlag, -1)                                                                AS matter_billable_flag,
    COALESCE(NULLIF(TRIM(s.MatterTimeUnit), ''), 'Unknown')                                           AS matter_time_unit,
    TRIM(s.SubIndustry)                                                                               AS sub_industry,

    -- Get matter_sector_key from stage_taxonomy_curated_matter_sector using s.SubIndustry = lkp.sic_code
    COALESCE(CAST({lookup_function(
        table_lookup    =   f"{target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_matter_sector",
        key_mapping     =   ("s.SubIndustry", "lkp.sic_code"),
        return_column   =   "matter_sector_key")} AS BIGINT), -1)                                     AS matter_sector_key,

    -- Needed by gold matter join to silver_rmdd_team/sub_team logic
    s.TeamID                                                                                          AS team_id,

    COALESCE(NULLIF(REGEXP_REPLACE(s.Comments, '[\\x01\\t\\n\\f\\r\\x16\\x1B ]', ''), ''), 'Unknown') AS comments,
    COALESCE(NULLIF(TRIM(s.GPMSGroupBilling), ''), 'Unknown')                                         AS group_billing,
    COALESCE(NULLIF(TRIM(s.GPMSReportingGroup), ''), 'Unknown')                                       AS reporting_group,
    TRY_CAST(NULLIF(TRIM(s.SanctionsChecked_YN), '') AS BOOLEAN)                                      AS is_sanctions_checked,
    TRIM(s.TechnicalArea)                                                                             AS technical_area_code,

    -- Get work_type_key from stage_taxonomy_curated_work_type using s.TechnicalArea = lkp.technical_area_code
    COALESCE(CAST({lookup_function(
        table_lookup    =   f"{target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_work_type",
        key_mapping     =   ("s.TechnicalArea", "lkp.technical_area_code"),
        return_column   =   "work_type_key")} AS BIGINT), -1)                                         AS work_type_key,

    COALESCE(CAST(s.Active AS BOOLEAN), false)                                                        AS is_active,
    COALESCE(CAST(s.LastUpdatedDateGMT AS TIMESTAMP), current_timestamp())                            AS last_updated_date_utc_at_source

FROM {source_view} s
WHERE {watermark_filter}
--AND s.Active = True
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
