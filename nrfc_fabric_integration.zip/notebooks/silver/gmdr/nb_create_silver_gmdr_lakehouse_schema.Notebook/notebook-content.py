# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Define schema tables
# 
# Define the definition schema for each table, run schema if not exists

# CELL ********************

schema_name = "silver_gmdr"
location_path = "Files/silver/gmdr"

tbl_properties = """
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite'     = 'true',
    'delta.autoOptimize.autoCompact'       = 'true',
    'delta.logRetentionDuration'           = 'interval 30 days',
    'delta.deletedFileRetentionDuration'   = 'interval 7 days')
"""

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tables_definition = [
    {
        "table_name": "silver_gmdr_sap_ihpa",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            pspid                              BIGINT,
            parnr                              STRING,
            kzloesch                           STRING,
            counter                            STRING,
            parvw                              STRING,
            last_updated_date_utc_at_source    TIMESTAMP,

        -- metadata
            _hashed_pk                         STRING,
            _hashed_row                        STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                     STRING,
            _source_table                      STRING,
            _target_table                      STRING,
            _lineage_id                        STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_gmdr_sap_kna1",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            sap_kna1_key                       BIGINT,
            kunnr                              STRING,
            client_e_billing_vendor            STRING,
            client_information_barier          STRING,
            client_non_consent                 STRING,
            client_pricing_group               STRING,
            customer_account_group             STRING,
            client_programme_key               BIGINT,
            client_sector_key                  BIGINT,
            tax_jurisdiction                   STRING,
            tax_number_1                       STRING,
            tax_number_2                       STRING,
            vat_registration_number            STRING,
            vat_valid_date                     TIMESTAMP,
            last_updated_date_utc_at_source    TIMESTAMP,

        -- metadata
            _hashed_pk                         STRING,
            _hashed_row                        STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                     STRING,
            _source_table                      STRING,
            _target_table                      STRING,
            _lineage_id                        STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_gmdr_sap_knvk",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            gmdr_sap_knvk_key                  BIGINT,
            parnr                              STRING,
            client_number                      STRING,
            name1                              STRING,
            namev                              STRING,
            last_updated_date_utc_at_source    TIMESTAMP,

        -- metadata
            _hashed_pk                         STRING,
            _hashed_row                        STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                     STRING,
            _source_table                      STRING,
            _target_table                      STRING,
            _lineage_id                        STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_gmdr_sap_pa0000",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            gmdr_sap_pa0000_key                BIGINT,
            person_number                      STRING,
            begin_date                         TIMESTAMP,
            end_date                           TIMESTAMP,
            changed_date                       TIMESTAMP,
            employment_status_code             STRING,
            last_updated_date_utc_at_source    TIMESTAMP,

        -- metadata
            _hashed_pk                         STRING,
            _hashed_row                        STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                     STRING,
            _source_table                      STRING,
            _target_table                      STRING,
            _lineage_id                        STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_gmdr_sap_pa0001",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            gmdr_sap_pa0001_key                BIGINT,
            pernr                              STRING,
            persk                              STRING,
            zzteam                             STRING,
            bukrs                              STRING,
            zzpgp                              STRING,
            company_key                        BIGINT,
            begda                              TIMESTAMP,
            endda                              TIMESTAMP,
            is_active                          INT,
            last_updated_date_utc_at_source    TIMESTAMP,

        -- metadata
            _hashed_pk                         STRING,
            _hashed_row                        STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                     STRING,
            _source_table                      STRING,
            _target_table                      STRING,
            _lineage_id                        STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_gmdr_sap_pa0709",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            gmdr_sap_pa0709_key                BIGINT,
            person_number                      STRING,
            person_id_external                 STRING,
            begin_date                         TIMESTAMP,
            last_updated_date_utc_at_source    TIMESTAMP,

        -- metadata
            _hashed_pk                         STRING,
            _hashed_row                        STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                     STRING,
            _source_table                      STRING,
            _target_table                      STRING,
            _lineage_id                        STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_gmdr_sap_pa9007",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            sap_pa9007_key                     BIGINT,
            pernr                              STRING,
            zz_blvl                            STRING,
            band_level_key                     STRING,
            begda                              TIMESTAMP,
            endda                              TIMESTAMP,
            is_active                          INT,
            last_updated_date_utc_at_source    STRING,

        -- metadata
            _hashed_pk                         STRING,
            _hashed_row                        STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                     STRING,
            _source_table                      STRING,
            _target_table                      STRING,
            _lineage_id                        STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_gmdr_sap_proj",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            sap_proj_key                       BIGINT,
            pspid                              STRING,
            matter_pass_through_flag           STRING,
            matter_purchase_order_number       STRING,
            ip_matter_number                   STRING,
            matter_pricing_group               STRING,
            client_case_number                 STRING,
            client_case_description            STRING,
            last_updated_date_utc_at_source    TIMESTAMP,

        -- metadata
            _hashed_pk                         STRING,
            _hashed_row                        STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                     STRING,
            _source_table                      STRING,
            _target_table                      STRING,
            _lineage_id                        STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_gmdr_sap_zprs_mat_ph_set",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            gmdr_sap_zprs_mat_ph_set_key       BIGINT,
            zzpspid                            STRING,
            zzphaseset                         STRING,
            begda                              TIMESTAMP,
            endda                              TIMESTAMP,
            is_active                          INT,
            last_updated_date_utc_at_source    TIMESTAMP,

        -- metadata
            _hashed_pk                         STRING,
            _hashed_row                        STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                     STRING,
            _source_table                      STRING,
            _target_table                      STRING,
            _lineage_id                        STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_gmdr_sap_zprs_mattercatt",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            sap_zprs_mattercatt_key            BIGINT,
            mattercat                          STRING,
            matter_category_key                STRING,
            last_updated_date_utc_at_source    TIMESTAMP,

        -- metadata
            _hashed_pk                         STRING,
            _hashed_row                        STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                     STRING,
            _source_table                      STRING,
            _target_table                      STRING,
            _lineage_id                        STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_gmdr_sap_zprs_tkalocclnt",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            gmdr_sap_zprs_tkalocclnt_key       BIGINT,
            client_number                      STRING,
            person_number                      STRING,
            partner_function_code              STRING,
            partner_function_key               BIGINT,
            allocation_percentage              DECIMAL(18, 4),
            begin_date                         TIMESTAMP,
            end_date                           TIMESTAMP,
            is_active                          BOOLEAN,
            last_updated_date_utc_at_source    TIMESTAMP,

        -- metadata
            _hashed_pk                         STRING,
            _hashed_row                        STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                     STRING,
            _source_table                      STRING,
            _target_table                      STRING,
            _lineage_id                        STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name": "silver_gmdr_sap_zprs_tkalocmattr",
        "sql_statement": """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            gmdr_sap_zprs_tkalocmattr_key      BIGINT,
            matter_number                      STRING,
            member_firm_code                   STRING,
            person_number                      STRING,
            begin_date                         TIMESTAMP,
            partner_function_code              STRING,
            partner_function_key               BIGINT,
            office_code                        STRING,
            office_key                         BIGINT,
            team_code                          STRING,
            team_key                           BIGINT,
            end_date                           TIMESTAMP,
            associate_person_number            STRING,
            allocation_percentage              DECIMAL(18, 4),
            is_active                          INT,
            last_updated_date_utc_at_source    TIMESTAMP,

        -- metadata
            _hashed_pk                         STRING,
            _hashed_row                        STRING,
            _process_timestamp                  TIMESTAMP,
            _source_system                     STRING,
            _source_table                      STRING,
            _target_table                      STRING,
            _lineage_id                        STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    }
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Create all tables
# 
# Run sql_statement from table_name on config

# CELL ********************

for t in tables_definition:
    table_name = t["table_name"]

    sql = t["sql_statement"].format(
        schema_name=schema_name,
        table_name=table_name,
        location_path=location_path,
        tbl_properties=tbl_properties
    )
    
    print(f"Creating {schema_name}.{table_name}")
    spark.sql(sql)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
