# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "known_warehouses": []
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Define notebook Parameters
# 
# Pass through th pl_worker

# CELL ********************

# Framework-compatible parameters with manual fallbacks
import json
import uuid

# Basic notebook runtime values
task_id = 50
task_name = "Load GMDR to silver"
lineage_id = str(uuid.uuid4())
limit_rows_for_debugging = False
prev_wm = "1900-01-01 00:00:00"
curr_wm = "2026-08-05 00:00:00"
execution_errors = []

# Source settings > what data to read
source_settings = json.dumps(
    {
        "source_name": "CAN_RMDD",
        "source_type": "sql_database",
        "source_location": "CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e",
        "source_schema": "dbo",
        "table_config": [
            {
                "source_table": "sap_ihpa",
                "target_table": "silver_gmdr_sap_ihpa",
                "target_pk": ["pspid", "parvw"],
                "is_incremental": 1,
                "incremental_column": "TIMESTAMP",
                "transformation_notebook": "nb_transform_silver_gmdr_sap_ihpa"
            },
            {
                "source_table": "sap_kna1",
                "target_table": "silver_gmdr_sap_kna1",
                "target_pk": ["kunnr"],
                "is_incremental": 1,
                "incremental_column": "TIMESTAMP",
                "transformation_notebook": "nb_transform_silver_gmdr_sap_kna1"
            },
            {
                "source_table": "sap_knvk",
                "target_table": "silver_gmdr_sap_knvk",
                "target_pk": ["parnr", "client_number"],
                "is_incremental": 1,
                "incremental_column": "TIMESTAMP",
                "transformation_notebook": "nb_transform_silver_gmdr_sap_knvk"
            },
            {
                "source_table": "sap_pa0000",
                "target_table": "silver_gmdr_sap_pa0000",
                "target_pk": ["person_number"],
                "is_incremental": 1,
                "incremental_column": "TIMESTAMP",
                "transformation_notebook": "nb_transform_silver_gmdr_sap_pa0000"
            },
            {
                "source_table": "sap_pa0001",
                "target_table": "silver_gmdr_sap_pa0001",
                "target_pk": ["pernr"],
                "is_incremental": 1,
                "incremental_column": "TIMESTAMP",
                "transformation_notebook": "nb_transform_silver_gmdr_sap_pa0001"
            },
            {
                "source_table": "sap_pa9007",
                "target_table": "silver_gmdr_sap_pa9007",
                "target_pk": ["pernr"],
                "is_incremental": 1,
                "incremental_column": "TIMESTAMP",
                "transformation_notebook": "nb_transform_silver_gmdr_sap_pa9007"
            },
            {
                "source_table": "sap_pa0709",
                "target_table": "silver_gmdr_sap_pa0709",
                "target_pk": ["person_number"],
                "is_incremental": 1,
                "incremental_column": "TIMESTAMP",
                "transformation_notebook": "nb_transform_silver_gmdr_sap_pa0709"
            },
            {
                "source_table": "sap_proj",
                "target_table": "silver_gmdr_sap_proj",
                "target_pk": ["pspid"],
                "is_incremental": 1,
                "incremental_column": "TIMESTAMP",
                "transformation_notebook": "nb_transform_silver_gmdr_sap_proj"
            },
            {
                "source_table": "sap_zprs_mat_ph_set",
                "target_table": "silver_gmdr_sap_zprs_mat_ph_set",
                "target_pk": ["zzpspid"],
                "is_incremental": 1,
                "incremental_column": "TIMESTAMP",
                "transformation_notebook": "nb_transform_silver_gmdr_sap_zprs_mat_ph_set"
            },
            {
                "source_table": "sap_zprs_mattercatt",
                "target_table": "silver_gmdr_sap_zprs_mattercatt",
                "target_pk": ["mattercat"],
                "is_incremental": 1,
                "incremental_column": "TIMESTAMP",
                "transformation_notebook": "nb_transform_silver_gmdr_sap_zprs_mattercatt"
            },
            {
                "source_table": "sap_zprs_tkalocclnt",
                "target_table": "silver_gmdr_sap_zprs_tkalocclnt",
                "target_pk": ["client_number", "person_number", "begin_date"],
                "is_incremental": 1,
                "incremental_column": "TIMESTAMP",
                "transformation_notebook": "nb_transform_silver_gmdr_sap_zprs_tkalocclnt"
            },
            {
                "source_table": "sap_zprs_tkalocmattr",
                "target_table": "silver_gmdr_sap_zprs_tkalocmattr",
                "target_pk": ["matter_number", "member_firm_code", "person_number", "begin_date", "partner_function_code", "office_code", "team_code"],
                "is_incremental": 1,
                "incremental_column": "TIMESTAMP",
                "transformation_notebook": "nb_transform_silver_gmdr_sap_zprs_tkalocmattr"
            },
            {
                "source_table": "Office",
                "target_table": "silver_gmdr_office",
                "target_pk": ["office_id"],
                "is_incremental": 1,
                "incremental_column": "LastUpdatedDateGMT",
                "transformation_notebook": "nb_transform_silver_gmdr_office"
            },
            {
                "source_table": "SubTeam",
                "target_table": "silver_gmdr_sub_team",
                "target_pk": ["sub_team_id"],
                "is_incremental": 1,
                "incremental_column": "LastUpdatedDateGMT",
                "transformation_notebook": "nb_transform_silver_gmdr_sub_team"
            },
            {
                "source_table": "Team",
                "target_table": "silver_gmdr_team",
                "target_pk": ["team_id"],
                "is_incremental": 1,
                "incremental_column": "LastUpdatedDateGMT",
                "transformation_notebook": "nb_transform_silver_gmdr_team"
            }          
        ]
    }
)


# Target settings > here/how to write
target_settings = json.dumps(
    {
        "target_workspace": "ws_canada_global_mds_dev",
        "target_lakehouse": "lh_canada_global_mds",
        "target_schema": "silver_gmdr",
        "target_location": "Files/silver/gmdr",
        "target_load_strategy": "merge-scd1"
    }
)

# Connection settings > how to connect/authenticate
source_connection_settings = json.dumps(
    {
        "server_name": "hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com"
    }
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
