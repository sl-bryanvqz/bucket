# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    source_table             = "sap_proj"
    source_view              = f"src_{to_snake_case(source_table)}"
    map_view                 = f"map_{to_snake_case(source_table)}"
    target_workspace         = "ws_canada_global_mds_dev"
    target_lakehouse         = "lh_canada_global_mds"
    target_table             = f"silver_gmdr_{source_table}"
    target_pk                = ["pspid"]
    limit_rows_for_debugging = True
    watermark_filter         = "s.TIMESTAMP > '1900-01-01 00:00:00' AND s.TIMESTAMP <= '2026-08-30 00:00:00'"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"source_view: {source_view}")
    print(f"map_view: {map_view}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create source view when running this transform notebook alone
if not spark.catalog.tableExists(source_view):
    create_source_view(
        source_view=source_view,
        source_schema="dbo",
        source_table=source_table,
        source_type="sql_database",
        source_location="CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e",
        source_connection_settings={
            "server_name": "hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com"
        }
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT DISTINCT
    CAST(row_number() OVER (ORDER BY s.PSPID) AS BIGINT)                                             AS sap_proj_key,
    COALESCE(NULLIF(TRIM(CAST(s.PSPID AS STRING)), ''), 'Unknown')                                   AS pspid,

    CASE
        WHEN TRIM(s.ZZPASSTHRU) = 'X' THEN TRUE
        ELSE FALSE
    END                                                                AS matter_pass_through_flag,  --This field is boolean in gold
    
    COALESCE(NULLIF(TRIM(CAST(s.ZZIPPONUM AS STRING)), ''), 'Unknown')                               AS matter_purchase_order_number,
    COALESCE(NULLIF(TRIM(CAST(s.ZZIP_REF_NUM AS STRING)), ''), 'Unknown')                            AS ip_matter_number,
    COALESCE(NULLIF(TRIM(CAST(s.ZZMPRGRP AS STRING)), ''), 'Unknown')                                AS matter_pricing_group,
    COALESCE(NULLIF(TRIM(CAST(s.ZZCLCASENBR AS STRING)), ''), 'Unknown')                             AS client_case_number,
    COALESCE(NULLIF(TRIM(CAST(s.ZZCLCASENAME AS STRING)), ''), 'Unknown')                            AS client_case_description,

    -- Client script: SAP_PROJ.ZZMATTERCAT -> SAP_ZPRS_MATTERCATT.MATTERCAT
    COALESCE(NULLIF(TRIM(CAST(s.ZZMATTERCAT AS STRING)), ''), 'Unknown')                             AS matter_category_code,

    -- Client script: SAP_PROJ.ZZBILLFREQ = RIGHT('00' + matter_billing_frequency_code, 2)
    COALESCE(NULLIF(TRIM(CAST(s.ZZBILLFREQ AS STRING)), ''), 'Unknown')                              AS matter_billing_frequency_code,

    COALESCE(CAST({lookup_function(
        table_lookup    =   f"{target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_matter_billing_frequency",
        key_mapping     =   ("TRIM(CAST(s.ZZBILLFREQ AS STRING))", "LPAD(TRIM(CAST(lkp.matter_billing_frequency_code AS STRING)), 2, '0')"),
        return_column   =   "matter_billing_frequency_key")} AS BIGINT), -1)                         AS matter_billing_frequency_key,

    -- Client script: SAP_PROJ.ZZBILLMTHD = RIGHT('00' + matter_billing_method_code, 2)
    COALESCE(NULLIF(TRIM(CAST(s.ZZBILLMTHD AS STRING)), ''), 'Unknown')                              AS matter_billing_method_code,

    COALESCE(CAST({lookup_function(
        table_lookup    =   f"{target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_matter_billing_method",
        key_mapping     =   ("TRIM(CAST(s.ZZBILLMTHD AS STRING))", "LPAD(TRIM(CAST(lkp.matter_billing_method_code AS STRING)), 2, '0')"),
        return_column   =   "matter_billing_method_key")} AS BIGINT), -1)                            AS matter_billing_method_key,

    -- Client script: REPLACE(SAP_PROJ.ZZENTTYPE, '0', '') = matter_entry_type_code
    COALESCE(NULLIF(REPLACE(TRIM(CAST(s.ZZENTTYPE AS STRING)), '0', ''), ''), 'Unknown')             AS matter_entry_type_code,

    COALESCE(CAST({lookup_function(
        table_lookup    =   f"{target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_matter_entry_type",
        key_mapping     =   ("TRIM(CAST(s.ZZENTTYPE AS STRING))", "TRIM(CAST(lkp.matter_entry_type_code AS STRING))"),
        return_column   =   "matter_entry_type_key")} AS BIGINT), -1)                                AS matter_entry_type_key,

    -- Client script: SAP_PROJ.ZZPRACTICEGROUP = practice_group_code
    COALESCE(NULLIF(TRIM(CAST(s.ZZPRACTICEGROUP AS STRING)), ''), 'Unknown')                         AS practice_group_code,

    COALESCE(CAST({lookup_function(
        table_lookup    =   f"{target_workspace}.{target_lakehouse}.stage_taxonomy.stage_taxonomy_curated_practice_group",
        key_mapping     =   ("TRIM(CAST(s.ZZPRACTICEGROUP AS STRING))", "TRIM(CAST(lkp.practice_group_code AS STRING))"),
        return_column   =   "practice_group_key")} AS BIGINT), -1)                                   AS practice_group_key,

    COALESCE(CAST(s.TIMESTAMP AS TIMESTAMP), current_timestamp())                                    AS last_updated_date_utc_at_source

FROM {source_view} s
WHERE {watermark_filter}
    AND NULLIF(TRIM(CAST(s.PSPID AS STRING)), '') IS NOT NULL
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
