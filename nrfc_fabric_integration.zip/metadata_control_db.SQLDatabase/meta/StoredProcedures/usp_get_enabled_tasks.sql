CREATE   PROCEDURE [meta].[usp_get_enabled_tasks]
    @stage VARCHAR(500) = NULL,
    @task_id VARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SET @stage = LOWER(NULLIF(LTRIM(RTRIM(@stage)), ''));
    SET @task_id = NULLIF(LTRIM(RTRIM(@task_id)), '');

    WITH stage_filter AS (
        SELECT LOWER(LTRIM(RTRIM(value))) AS stage
        FROM STRING_SPLIT(@stage, ',')
        WHERE @stage IS NOT NULL
    ),
    task_id_filter AS (
        SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) AS task_id
        FROM STRING_SPLIT(@task_id, ',')
        WHERE @task_id IS NOT NULL
          AND TRY_CAST(LTRIM(RTRIM(value)) AS INT) IS NOT NULL
    )
    SELECT
        NEWID() AS task_executions_id,
        NEWID() AS lineage_id,
        tm.*
    FROM meta.task_metadata tm
    WHERE tm.enabled = 1
      AND (
            @stage IS NULL
            OR LOWER(tm.stage) IN (SELECT stage FROM stage_filter)
      )
      AND (
            @task_id IS NULL
            OR tm.task_id IN (SELECT task_id FROM task_id_filter)
      )
    ORDER BY
        CASE LOWER(tm.stage)
            WHEN 'taxonomy' THEN 1
            WHEN 'silver' THEN 2
            WHEN 'gold' THEN 3
            ELSE 4
        END,
        tm.task_id;
END;

GO

