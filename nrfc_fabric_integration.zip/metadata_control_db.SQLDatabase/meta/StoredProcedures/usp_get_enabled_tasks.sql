
CREATE PROCEDURE [meta].[usp_get_enabled_tasks]
    @stage VARCHAR(100) = NULL,
    @task_name VARCHAR(100) = NULL
    
AS
BEGIN
    IF @stage = '' 
        SET @stage = NULL

    IF @task_name = '' 
        SET @task_name = NULL


    IF @stage IS NULL AND @task_name IS NULL
        SELECT NEWID() AS task_executions_id, NEWID() AS lineage_id, *
        FROM
            meta.task_metadata
        WHERE
            enabled = 1
    ELSE 
        IF @task_name IS NOT NULL AND @stage IS NOT NULL
            SELECT NEWID() AS task_executions_id, NEWID() AS lineage_id, *
            FROM
                meta.task_metadata
            WHERE
                enabled = 1
                AND UPPER(task_name) = UPPER(@task_name)
                AND UPPER(stage) = UPPER(@stage)        
        ELSE        
            IF @task_name IS NOT NULL
                SELECT NEWID() AS task_executions_id, NEWID() AS lineage_id, *
                FROM
                    meta.task_metadata
                WHERE
                    enabled = 1
                    AND UPPER(task_name) = UPPER(@task_name)
            
            IF @stage IS NOT NULL
                SELECT NEWID() AS task_executions_id, NEWID() AS lineage_id, *
                FROM
                    meta.task_metadata
                WHERE
                    enabled = 1
                    AND UPPER(stage) = UPPER(@stage)

END;

GO

