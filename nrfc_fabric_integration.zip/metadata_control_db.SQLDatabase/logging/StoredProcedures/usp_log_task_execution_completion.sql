CREATE   PROCEDURE logging.usp_log_task_execution_completion
    @task_executions_id UNIQUEIDENTIFIER,
    @status VARCHAR(50),
    @next_stage_status VARCHAR(20),
    @log_data VARCHAR(MAX) = NULL,
    @error_details VARCHAR(MAX) = NULL
AS
BEGIN
    DECLARE @end_datetime DATETIME2(0) = CAST(SYSUTCDATETIME() AS DATETIME2(0));

    DECLARE @log_json VARCHAR(MAX) =
        CASE
            WHEN ISJSON(@log_data) = 1 THEN @log_data
            ELSE '{"log_data":[]}'
        END;

    DECLARE @error_json VARCHAR(MAX) =
        CASE
            WHEN ISJSON(@error_details) = 1 THEN @error_details
            ELSE '{}'
        END;

    DECLARE @error_text VARCHAR(MAX) = REPLACE(ISNULL(@error_details, ''), '\"', '"');

    DECLARE @error_target_table VARCHAR(200) =
        TRY_CAST(JSON_VALUE(@error_json, '$.target_table') AS VARCHAR(200));

    DECLARE @error_sql_current_user VARCHAR(256) =
        TRY_CAST(JSON_VALUE(@error_json, '$.sql_current_user') AS VARCHAR(256));

    IF @error_target_table IS NULL AND CHARINDEX('"target_table"', @error_text) > 0
    BEGIN
        DECLARE @target_key INT = CHARINDEX('"target_table"', @error_text);
        DECLARE @target_colon INT = CHARINDEX(':', @error_text, @target_key);
        DECLARE @target_start INT = CHARINDEX('"', @error_text, @target_colon + 1) + 1;
        DECLARE @target_end INT = CHARINDEX('"', @error_text, @target_start);

        IF @target_start > 1 AND @target_end > @target_start
            SET @error_target_table = SUBSTRING(@error_text, @target_start, @target_end - @target_start);
    END;

    IF @error_sql_current_user IS NULL AND CHARINDEX('"sql_current_user"', @error_text) > 0
    BEGIN
        DECLARE @user_key INT = CHARINDEX('"sql_current_user"', @error_text);
        DECLARE @user_colon INT = CHARINDEX(':', @error_text, @user_key);
        DECLARE @user_start INT = CHARINDEX('"', @error_text, @user_colon + 1) + 1;
        DECLARE @user_end INT = CHARINDEX('"', @error_text, @user_start);

        IF @user_start > 1 AND @user_end > @user_start
            SET @error_sql_current_user = SUBSTRING(@error_text, @user_start, @user_end - @user_start);
    END;

    ;WITH log_summary AS (
        SELECT
            COUNT(*) AS table_count,
            MIN(TRY_CAST(JSON_VALUE(value, '$.watermark_from') AS DATETIME2(0))) AS watermark_from,
            MAX(TRY_CAST(JSON_VALUE(value, '$.watermark_to') AS DATETIME2(0))) AS watermark_to,
            SUM(TRY_CAST(JSON_VALUE(value, '$.rows_read') AS BIGINT)) AS rows_read,
            SUM(TRY_CAST(JSON_VALUE(value, '$.rows_inserted') AS BIGINT)) AS rows_inserted,
            SUM(TRY_CAST(JSON_VALUE(value, '$.rows_updated') AS BIGINT)) AS rows_updated,
            SUM(TRY_CAST(JSON_VALUE(value, '$.rows_unchanged') AS BIGINT)) AS rows_unchanged
        FROM OPENJSON(@log_json, '$.log_data')
    ),
    first_table AS (
        SELECT TOP (1)
            TRY_CAST(JSON_VALUE(value, '$.target_table') AS VARCHAR(200)) AS target_table
        FROM OPENJSON(@log_json, '$.log_data')
        ORDER BY TRY_CAST([key] AS INT)
    )
    UPDATE te
    SET
        status = @status,
        next_stage_status = @next_stage_status,
        end_datetime = @end_datetime,
        duration_min = DATEDIFF(SECOND, start_datetime, @end_datetime) / 60.0,
        log_data = @log_data,
        error_details = @error_details,
        target_table = COALESCE(
            CASE
                WHEN ls.table_count = 1 THEN ft.target_table
                WHEN ls.table_count > 1 THEN te.stage
                ELSE NULL
            END,
            @error_target_table
        ),
        watermark_from = ls.watermark_from,
        watermark_to = ls.watermark_to,
        rows_read = ls.rows_read,
        rows_inserted = ls.rows_inserted,
        rows_updated = ls.rows_updated,
        rows_unchanged = ls.rows_unchanged,
        sql_current_user = COALESCE(
            TRY_CAST(JSON_VALUE(@log_json, '$.sql_current_user') AS VARCHAR(256)),
            @error_sql_current_user
        )
    FROM logging.task_executions te
    CROSS JOIN log_summary ls
    OUTER APPLY (
        SELECT target_table
        FROM first_table
    ) ft
    WHERE
        te.task_executions_id = @task_executions_id
        AND te.end_datetime IS NULL;
END;

GO

