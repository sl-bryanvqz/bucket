
CREATE PROCEDURE logging.usp_log_task_execution_completion
    @task_executions_id UNIQUEIDENTIFIER,
    @status VARCHAR(50),
    @next_stage_status VARCHAR(20),
    @log_data VARCHAR(8000) = NULL,
    @error_details VARCHAR(8000) = NULL
AS
BEGIN
    DECLARE @end_datetime DATETIME2(0) = CAST(SYSUTCDATETIME() AS DATETIME2(0));

    UPDATE [logging].[task_executions]
    SET
        [status] = @status,
        [next_stage_status] = @next_stage_status,
        [end_datetime] = @end_datetime,
        [duration_min] = DATEDIFF(SECOND, [start_datetime], @end_datetime) / 60.0,
        [log_data] = @log_data,
        [error_details] = @error_details,
        [target_table] = TRY_CAST(JSON_VALUE(@log_data, '$.log_data[0].target_table') AS VARCHAR(8000)),
        [watermark_from] = TRY_CAST(JSON_VALUE(@log_data, '$.log_data[0].watermark_from') AS DATETIME2(0)),
        [watermark_to] = TRY_CAST(JSON_VALUE(@log_data, '$.log_data[0].watermark_to') AS DATETIME2(0)),
        [rows_read] = TRY_CAST(JSON_VALUE(@log_data, '$.log_data[0].rows_read') AS BIGINT),
        [rows_inserted] = TRY_CAST(JSON_VALUE(@log_data, '$.log_data[0].rows_inserted') AS BIGINT),
        [rows_updated] = TRY_CAST(JSON_VALUE(@log_data, '$.log_data[0].rows_updated') AS BIGINT),
        [rows_unchanged] = TRY_CAST(JSON_VALUE(@log_data, '$.log_data[0].rows_unchanged') AS BIGINT)
    WHERE
        [task_executions_id] = @task_executions_id
        AND [end_datetime] IS NULL
END

GO

