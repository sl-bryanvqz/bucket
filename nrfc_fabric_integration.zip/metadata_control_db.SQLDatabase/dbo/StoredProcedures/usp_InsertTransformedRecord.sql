CREATE PROCEDURE dbo.usp_InsertTransformedRecord
    @correlationId    NVARCHAR(36),
    @sourceRecordKey  NVARCHAR(200),
    @transformedAt    DATETIME2,
    @validationStatus NVARCHAR(50),
    @epochPayload     NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.transformed_records (
        correlation_id, source_record_key, transformed_at, validation_status, epoch_payload)
    VALUES (
        @correlationId, @sourceRecordKey, @transformedAt, @validationStatus, @epochPayload);
END;

GO

