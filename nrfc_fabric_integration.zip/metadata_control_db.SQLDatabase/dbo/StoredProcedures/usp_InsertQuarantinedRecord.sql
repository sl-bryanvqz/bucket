CREATE PROCEDURE dbo.usp_InsertQuarantinedRecord
    @correlationId    NVARCHAR(36),
    @sourceRecordKey  NVARCHAR(200),
    @quarantineReason NVARCHAR(MAX),
    @failureStage     NVARCHAR(50),
    @rawPayload       NVARCHAR(MAX),
    @quarantinedAt    DATETIME2
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.quarantined_records (
        correlation_id, source_record_key, quarantine_reason, failure_stage, raw_payload, quarantined_at)
    VALUES (
        @correlationId, @sourceRecordKey, @quarantineReason, @failureStage, @rawPayload, @quarantinedAt);
END;

GO

