CREATE PROCEDURE dbo.usp_TransformedRecordExists
    @sourceRecordKey NVARCHAR(200),
    @correlationId   NVARCHAR(36)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT COUNT(1) FROM dbo.transformed_records
    WHERE source_record_key = @sourceRecordKey AND correlation_id = @correlationId;
END;

GO

