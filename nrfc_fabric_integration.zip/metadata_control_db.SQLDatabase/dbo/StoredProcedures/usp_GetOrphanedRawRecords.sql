CREATE PROCEDURE dbo.usp_GetOrphanedRawRecords
    @maxAgeHours INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT r.correlation_id, r.source_record_key, r.modified_since, r.extracted_at, r.payload
    FROM dbo.raw_records r
    LEFT JOIN dbo.epoch_responses e ON e.source_record_key = r.source_record_key
    WHERE e.source_record_key IS NULL
      AND r.extracted_at > DATEADD(HOUR, -@maxAgeHours, GETUTCDATE());
END;

GO

