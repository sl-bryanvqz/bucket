CREATE   PROCEDURE dbo.usp_InsertTransformedRecordsBatch
    @recordsJson NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.transformed_records (
        correlation_id, source_record_key, transformed_at, validation_status, epoch_payload)
    SELECT correlation_id, source_record_key, transformed_at, validation_status, epoch_payload
    FROM OPENJSON(@recordsJson)
    WITH (
        correlation_id    NVARCHAR(36)  '$.correlationId',
        source_record_key NVARCHAR(200) '$.sourceRecordKey',
        transformed_at    DATETIME2     '$.transformedAt',
        validation_status NVARCHAR(50)  '$.validationStatus',
        epoch_payload     NVARCHAR(MAX) '$.epochPayload'
    );
END;

GO

