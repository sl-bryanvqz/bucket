CREATE   PROCEDURE dbo.usp_GetRecordsPendingValidation
    @delayMinutes            INT,
    @maxValidationWaitMinutes INT,
    @maxResults              INT = 500
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP(@maxResults)
        er.epoch_record_id,
        er.source_record_key,
        er.correlation_id,
        er.delivered_at,
        COALESCE(evr.first_polled_at, GETUTCDATE()) AS first_polled_at,
        COALESCE(evr.poll_attempts, 0)              AS poll_attempts
    FROM dbo.epoch_responses er
    LEFT JOIN dbo.epoch_validation_results evr ON er.epoch_record_id = evr.epoch_record_id
    WHERE er.delivery_status = 'Delivered'
      AND er.epoch_record_id IS NOT NULL
      AND er.delivered_at <= DATEADD(MINUTE, -@delayMinutes, GETUTCDATE())
      AND (evr.validation_status IS NULL OR evr.validation_status = 'PendingValidation')
    ORDER BY er.delivered_at ASC;
END;

GO

