CREATE PROCEDURE dbo.usp_UpdateEpochResponseStatus
    @responseId       NVARCHAR(36),
    @deliveryStatus   NVARCHAR(50),
    @failureReason    NVARCHAR(MAX),
    @deliveredAt      DATETIME2,
    @attemptNumber    INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.epoch_responses
    SET
        delivery_status = @deliveryStatus,
        failure_reason  = @failureReason,
        delivered_at    = @deliveredAt,
        attempt_number  = @attemptNumber
    WHERE response_id = @responseId;
END;

GO

