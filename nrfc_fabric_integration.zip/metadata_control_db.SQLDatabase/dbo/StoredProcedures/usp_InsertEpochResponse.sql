CREATE   PROCEDURE dbo.usp_InsertEpochResponse
    @responseId           NVARCHAR(36),
    @correlationId        NVARCHAR(36),
    @sourceRecordKey      NVARCHAR(200),
    @httpStatusCode       INT,
    @responseBody         NVARCHAR(MAX),
    @attemptNumber        INT,
    @deliveredAt          DATETIME2,
    @deliveryStatus       NVARCHAR(50),
    @failureReason        NVARCHAR(MAX),
    @deliveryAttemptedAt  DATETIME2,
    @epochRecordId        INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.epoch_responses (
        response_id, correlation_id, source_record_key, http_status_code, response_body,
        attempt_number, delivered_at, delivery_status, failure_reason, delivery_attempted_at,
        epoch_record_id)
    VALUES (
        @responseId, @correlationId, @sourceRecordKey, @httpStatusCode, @responseBody,
        @attemptNumber, @deliveredAt, @deliveryStatus, @failureReason, @deliveryAttemptedAt,
        @epochRecordId);
END;

GO

