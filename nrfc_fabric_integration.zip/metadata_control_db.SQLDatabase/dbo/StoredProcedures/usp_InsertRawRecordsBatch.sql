CREATE   PROCEDURE dbo.usp_InsertRawRecordsBatch
    @recordsJson NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    MERGE dbo.raw_records AS tgt
    USING (
        SELECT correlation_id, source_record_key, modified_since, extracted_at, payload
        FROM OPENJSON(@recordsJson)
        WITH (
            correlation_id    NVARCHAR(36)  '$.correlationId',
            source_record_key NVARCHAR(200) '$.sourceRecordKey',
            modified_since    DATETIME2     '$.modifiedSince',
            extracted_at      DATETIME2     '$.extractedAt',
            payload           NVARCHAR(MAX) '$.payload'
        )
    ) AS src
        ON tgt.source_record_key = src.source_record_key
       AND tgt.modified_since    = src.modified_since
    WHEN NOT MATCHED THEN
        INSERT (correlation_id, source_record_key, modified_since, extracted_at, payload)
        VALUES (src.correlation_id, src.source_record_key, src.modified_since, src.extracted_at, src.payload);
END;

GO

