CREATE PROCEDURE dbo.usp_RawRecordExists
    @sourceRecordKey  NVARCHAR(200),
    @modifiedSince    DATETIME2
AS
BEGIN
    SET NOCOUNT ON;
    SELECT COUNT(1) FROM dbo.raw_records
    WHERE source_record_key = @sourceRecordKey AND modified_since = @modifiedSince;
END;

GO

