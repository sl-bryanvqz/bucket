CREATE PROCEDURE dbo.usp_UpsertEpochValidationResult
    @epochRecordId         INT,
    @sourceRecordKey       NVARCHAR(200),
    @deliveryCorrelationId NVARCHAR(36),
    @validationStatus      NVARCHAR(50),
    @validationErrors      NVARCHAR(MAX),
    @parsedErrorCodes      NVARCHAR(MAX),
    @firstPolledAt         DATETIME2,
    @lastPolledAt          DATETIME2,
    @pollAttempts          INT
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM dbo.epoch_validation_results WHERE epoch_record_id = @epochRecordId)
        UPDATE dbo.epoch_validation_results
        SET validation_status  = @validationStatus,
            validation_errors  = @validationErrors,
            parsed_error_codes = @parsedErrorCodes,
            last_polled_at     = @lastPolledAt,
            poll_attempts      = @pollAttempts
        WHERE epoch_record_id = @epochRecordId;
    ELSE
        INSERT INTO dbo.epoch_validation_results (
            epoch_record_id, source_record_key, delivery_correlation_id,
            validation_status, validation_errors, parsed_error_codes,
            first_polled_at, last_polled_at, poll_attempts)
        VALUES (
            @epochRecordId, @sourceRecordKey, @deliveryCorrelationId,
            @validationStatus, @validationErrors, @parsedErrorCodes,
            @firstPolledAt, @lastPolledAt, @pollAttempts);
END;

GO

