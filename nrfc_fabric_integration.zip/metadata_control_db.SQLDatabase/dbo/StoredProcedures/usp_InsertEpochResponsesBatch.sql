CREATE   PROCEDURE dbo.usp_InsertEpochResponsesBatch
    @responsesJson NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.epoch_responses (
        response_id, correlation_id, source_record_key, http_status_code, response_body,
        attempt_number, delivered_at, delivery_status, failure_reason, delivery_attempted_at,
        epoch_record_id)
    SELECT response_id, correlation_id, source_record_key, http_status_code, response_body,
        attempt_number, delivered_at, delivery_status, failure_reason, delivery_attempted_at,
        epoch_record_id
    FROM OPENJSON(@responsesJson)
    WITH (
        response_id           NVARCHAR(36)  '$.responseId',
        correlation_id        NVARCHAR(36)  '$.correlationId',
        source_record_key     NVARCHAR(200) '$.sourceRecordKey',
        http_status_code      INT           '$.httpStatusCode',
        response_body         NVARCHAR(MAX) '$.responseBody',
        attempt_number        INT           '$.attemptNumber',
        delivered_at          DATETIME2     '$.deliveredAt',
        delivery_status       NVARCHAR(50)  '$.deliveryStatus',
        failure_reason        NVARCHAR(MAX) '$.failureReason',
        delivery_attempted_at DATETIME2     '$.deliveryAttemptedAt',
        epoch_record_id       INT           '$.epochRecordId'
    );
END;

GO

