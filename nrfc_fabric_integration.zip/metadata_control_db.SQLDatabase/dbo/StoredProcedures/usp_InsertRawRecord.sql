CREATE PROCEDURE dbo.usp_InsertRawRecord
    @correlationId    NVARCHAR(36),
    @sourceRecordKey  NVARCHAR(200),
    @modifiedSince    DATETIME2,
    @extractedAt      DATETIME2,
    @payload          NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.raw_records (correlation_id, source_record_key, modified_since, extracted_at, payload)
    VALUES (@correlationId, @sourceRecordKey, @modifiedSince, @extractedAt, @payload);
END;

GO

