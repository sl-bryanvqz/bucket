CREATE PROCEDURE dbo.usp_GetEpochPayload
    @sourceRecordKey NVARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP 1 epoch_payload
    FROM dbo.transformed_records
    WHERE source_record_key = @sourceRecordKey
    ORDER BY id DESC;
END;

GO

