CREATE PROCEDURE dbo.usp_GetPendingRetryRecords
    @maxAgeHours    INT,
    @maxBatchSize   INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (@maxBatchSize)
        id,
        response_id,
        correlation_id,
        source_record_key,
        http_status_code,
        response_body,
        attempt_number,
        delivered_at,
        delivery_status,
        failure_reason,
        delivery_attempted_at
    FROM dbo.epoch_responses
    WHERE delivery_status = 'PendingRetry'
      AND delivered_at > DATEADD(HOUR, -@maxAgeHours, GETUTCDATE())
    ORDER BY delivered_at ASC;
END;

GO

