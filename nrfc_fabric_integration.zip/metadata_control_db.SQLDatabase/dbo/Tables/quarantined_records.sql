CREATE TABLE [dbo].[quarantined_records] (
    [id]                BIGINT         IDENTITY (1, 1) NOT NULL,
    [correlation_id]    NVARCHAR (36)  NOT NULL,
    [source_record_key] NVARCHAR (200) NOT NULL,
    [quarantine_reason] NVARCHAR (MAX) NOT NULL,
    [failure_stage]     NVARCHAR (50)  NOT NULL,
    [raw_payload]       NVARCHAR (MAX) NOT NULL,
    [quarantined_at]    DATETIME2 (7)  NOT NULL,
    CONSTRAINT [PK_quarantined_records] PRIMARY KEY CLUSTERED ([id] ASC)
);


GO

CREATE NONCLUSTERED INDEX [IX_quarantined_records_correlation_id]
    ON [dbo].[quarantined_records]([correlation_id] ASC);


GO

