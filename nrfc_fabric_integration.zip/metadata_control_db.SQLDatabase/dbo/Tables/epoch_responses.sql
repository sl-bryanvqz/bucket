CREATE TABLE [dbo].[epoch_responses] (
    [id]                    BIGINT         IDENTITY (1, 1) NOT NULL,
    [response_id]           NVARCHAR (36)  NOT NULL,
    [correlation_id]        NVARCHAR (36)  NOT NULL,
    [source_record_key]     NVARCHAR (200) NOT NULL,
    [http_status_code]      INT            NOT NULL,
    [response_body]         NVARCHAR (MAX) NULL,
    [attempt_number]        INT            NOT NULL,
    [delivered_at]          DATETIME2 (7)  NOT NULL,
    [delivery_status]       NVARCHAR (50)  NOT NULL,
    [failure_reason]        NVARCHAR (MAX) NULL,
    [delivery_attempted_at] DATETIME2 (7)  NOT NULL,
    [epoch_record_id]       INT            NULL,
    CONSTRAINT [PK_epoch_responses] PRIMARY KEY CLUSTERED ([id] ASC)
);


GO

CREATE NONCLUSTERED INDEX [IX_epoch_responses_correlation_id]
    ON [dbo].[epoch_responses]([correlation_id] ASC);


GO

CREATE NONCLUSTERED INDEX [IX_epoch_responses_delivery_status]
    ON [dbo].[epoch_responses]([delivery_status] ASC);


GO

CREATE NONCLUSTERED INDEX [IX_epoch_responses_epoch_record_id]
    ON [dbo].[epoch_responses]([epoch_record_id] ASC);


GO

CREATE NONCLUSTERED INDEX [IX_epoch_responses_source_key]
    ON [dbo].[epoch_responses]([source_record_key] ASC);


GO

