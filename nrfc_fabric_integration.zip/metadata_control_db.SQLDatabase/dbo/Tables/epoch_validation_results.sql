CREATE TABLE [dbo].[epoch_validation_results] (
    [id]                      BIGINT         IDENTITY (1, 1) NOT NULL,
    [epoch_record_id]         INT            NOT NULL,
    [source_record_key]       NVARCHAR (200) NOT NULL,
    [delivery_correlation_id] NVARCHAR (36)  NOT NULL,
    [validation_status]       NVARCHAR (50)  NOT NULL,
    [validation_errors]       NVARCHAR (MAX) NULL,
    [parsed_error_codes]      NVARCHAR (MAX) NULL,
    [first_polled_at]         DATETIME2 (7)  NOT NULL,
    [last_polled_at]          DATETIME2 (7)  NOT NULL,
    [poll_attempts]           INT            DEFAULT ((1)) NOT NULL,
    CONSTRAINT [PK_epoch_validation_results] PRIMARY KEY CLUSTERED ([id] ASC),
    CONSTRAINT [UQ_epoch_validation_epoch_record_id] UNIQUE NONCLUSTERED ([epoch_record_id] ASC)
);


GO

CREATE NONCLUSTERED INDEX [IX_epoch_validation_source_key]
    ON [dbo].[epoch_validation_results]([source_record_key] ASC);


GO

CREATE NONCLUSTERED INDEX [IX_epoch_validation_status]
    ON [dbo].[epoch_validation_results]([validation_status] ASC);


GO

