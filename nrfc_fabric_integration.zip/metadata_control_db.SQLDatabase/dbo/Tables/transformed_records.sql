CREATE TABLE [dbo].[transformed_records] (
    [id]                BIGINT         IDENTITY (1, 1) NOT NULL,
    [correlation_id]    NVARCHAR (36)  NOT NULL,
    [source_record_key] NVARCHAR (200) NOT NULL,
    [transformed_at]    DATETIME2 (7)  NOT NULL,
    [validation_status] NVARCHAR (50)  NOT NULL,
    [epoch_payload]     NVARCHAR (MAX) NOT NULL,
    CONSTRAINT [PK_transformed_records] PRIMARY KEY CLUSTERED ([id] ASC)
);


GO

CREATE NONCLUSTERED INDEX [IX_transformed_records_correlation_id]
    ON [dbo].[transformed_records]([correlation_id] ASC);


GO

CREATE NONCLUSTERED INDEX [IX_transformed_records_source_key]
    ON [dbo].[transformed_records]([source_record_key] ASC);


GO

