CREATE TABLE [dbo].[raw_records] (
    [id]                BIGINT         IDENTITY (1, 1) NOT NULL,
    [correlation_id]    NVARCHAR (36)  NOT NULL,
    [source_record_key] NVARCHAR (200) NOT NULL,
    [modified_since]    DATETIME2 (7)  NOT NULL,
    [extracted_at]      DATETIME2 (7)  NOT NULL,
    [payload]           NVARCHAR (MAX) NOT NULL,
    CONSTRAINT [PK_raw_records] PRIMARY KEY CLUSTERED ([id] ASC)
);


GO

CREATE NONCLUSTERED INDEX [IX_raw_records_correlation_id]
    ON [dbo].[raw_records]([correlation_id] ASC);


GO

CREATE NONCLUSTERED INDEX [IX_raw_records_source_key]
    ON [dbo].[raw_records]([source_record_key] ASC);


GO

