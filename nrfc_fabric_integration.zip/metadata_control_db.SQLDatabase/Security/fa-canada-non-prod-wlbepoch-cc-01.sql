CREATE USER [fa-canada-non-prod-wlbepoch-cc-01]
    WITH SID = 0xA1DDA369E43B5D43A1C0000534832CEA, TYPE = E;


GO

