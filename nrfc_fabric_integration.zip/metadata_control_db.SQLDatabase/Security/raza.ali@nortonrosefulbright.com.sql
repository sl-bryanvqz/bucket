CREATE USER [raza.ali@nortonrosefulbright.com]
    WITH SID = 0x35A525C83797D749B6892176297129F9, TYPE = E;


GO

