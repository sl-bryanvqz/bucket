ALTER ROLE [db_datareader] ADD MEMBER [fa-canada-non-prod-wlbepoch-cc-01];


GO

