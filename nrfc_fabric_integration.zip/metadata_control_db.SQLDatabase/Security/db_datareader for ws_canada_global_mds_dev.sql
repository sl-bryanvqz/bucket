ALTER ROLE [db_datareader] ADD MEMBER [ws_canada_global_mds_dev];


GO

