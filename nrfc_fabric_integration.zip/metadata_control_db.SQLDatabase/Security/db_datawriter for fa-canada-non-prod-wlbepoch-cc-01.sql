ALTER ROLE [db_datawriter] ADD MEMBER [fa-canada-non-prod-wlbepoch-cc-01];


GO

