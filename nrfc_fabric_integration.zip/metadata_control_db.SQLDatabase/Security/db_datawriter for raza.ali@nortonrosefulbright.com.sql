ALTER ROLE [db_datawriter] ADD MEMBER [raza.ali@nortonrosefulbright.com];


GO

