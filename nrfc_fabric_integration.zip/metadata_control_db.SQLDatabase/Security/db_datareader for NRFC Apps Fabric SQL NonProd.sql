ALTER ROLE [db_datareader] ADD MEMBER [NRFC Apps Fabric SQL NonProd];


GO

