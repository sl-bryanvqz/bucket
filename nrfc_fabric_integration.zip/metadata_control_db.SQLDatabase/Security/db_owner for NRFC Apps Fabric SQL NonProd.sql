ALTER ROLE [db_owner] ADD MEMBER [NRFC Apps Fabric SQL NonProd];


GO

