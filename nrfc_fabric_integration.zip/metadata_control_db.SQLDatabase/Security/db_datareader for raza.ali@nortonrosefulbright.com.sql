ALTER ROLE [db_datareader] ADD MEMBER [raza.ali@nortonrosefulbright.com];


GO

