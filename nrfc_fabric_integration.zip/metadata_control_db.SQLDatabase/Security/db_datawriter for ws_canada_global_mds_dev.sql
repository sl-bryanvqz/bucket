ALTER ROLE [db_datawriter] ADD MEMBER [ws_canada_global_mds_dev];


GO

