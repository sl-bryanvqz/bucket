ALTER ROLE [db_datawriter] ADD MEMBER [NRFC Apps Fabric SQL NonProd];


GO

