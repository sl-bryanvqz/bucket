SELECT * --name, type_desc
FROM sys.database_principals
WHERE name = 'NRFC Apps Fabric SQL NonProd';
 