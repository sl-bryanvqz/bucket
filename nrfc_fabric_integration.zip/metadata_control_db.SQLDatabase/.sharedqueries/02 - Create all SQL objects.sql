---------------------------------------------------------------
-- 00 - Initialize metadata control DB
---------------------------------------------------------------

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'meta')
    EXEC('CREATE SCHEMA meta');

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'logging')
    EXEC('CREATE SCHEMA logging');
GO


---------------------------------------------------------------
-- Remove unused legacy procedures
---------------------------------------------------------------

DROP PROCEDURE IF EXISTS meta.usp_get_tasks_due_for_execution;
DROP PROCEDURE IF EXISTS logging.usp_update_processed_flag;
DROP PROCEDURE IF EXISTS logging.usp_set_custom_log__extract_sql;

IF OBJECT_ID('integration.usp_get_previous_watermark_date', 'P') IS NOT NULL
    DROP PROCEDURE integration.usp_get_previous_watermark_date;

IF OBJECT_ID('integration.usp_get_files_to_load_to_bronze', 'P') IS NOT NULL
    DROP PROCEDURE integration.usp_get_files_to_load_to_bronze;

IF OBJECT_ID('integration.usp_get_run_ids_to_load_to_silver', 'P') IS NOT NULL
    DROP PROCEDURE integration.usp_get_run_ids_to_load_to_silver;

IF OBJECT_ID('integration.usp_generate_html_table_of_failed_runs', 'P') IS NOT NULL
    DROP PROCEDURE integration.usp_generate_html_table_of_failed_runs;
GO


---------------------------------------------------------------
-- meta.connections
---------------------------------------------------------------

IF OBJECT_ID('meta.connections', 'U') IS NULL
BEGIN
    CREATE TABLE meta.connections (
        connection_id INT IDENTITY(1,1),
        connection_name VARCHAR(200),
        connection_settings VARCHAR(MAX),
        uses_fabric_connection BIT,
        created_at DATETIME2(0),
        updated_at DATETIME2(0)
    );
END;
GO


---------------------------------------------------------------
-- meta.task
---------------------------------------------------------------

IF OBJECT_ID('meta.task', 'U') IS NULL
BEGIN
    CREATE TABLE meta.task (
        task_id INT IDENTITY(1,1),
        task_name VARCHAR(200),
        object_name VARCHAR(200),
        stage VARCHAR(100),
        source_connection_id INT,
        source_settings VARCHAR(MAX),
        target_settings VARCHAR(MAX),
        option_settings VARCHAR(MAX),
        template_settings VARCHAR(MAX),
        scheduling_settings VARCHAR(MAX),
        enabled BIT,
        file_hash VARCHAR(200),
        enable_retries BIT,
        max_retry_attempts INT
    );
END;
GO


---------------------------------------------------------------
-- logging.task_executions
---------------------------------------------------------------

IF OBJECT_ID('logging.task_executions', 'U') IS NULL
BEGIN
    CREATE TABLE logging.task_executions (
        task_executions_id UNIQUEIDENTIFIER,
        lineage_id UNIQUEIDENTIFIER,
        run_id VARCHAR(200),
        parent_run_id VARCHAR(200),
        task_id INT,
        task_name VARCHAR(200),
        object_name VARCHAR(200),
        stage VARCHAR(100),
        status VARCHAR(50),
        num_retries INT,
        start_date DATE,
        start_datetime DATETIME2(0),
        end_datetime DATETIME2(0),
        duration_min DECIMAL(18,2),
        template_name VARCHAR(200),
        workspace_id VARCHAR(200),
        log_data VARCHAR(MAX),
        target_table VARCHAR(200),
        watermark_from DATETIME2(0),
        watermark_to DATETIME2(0),
        rows_read BIGINT,
        rows_inserted BIGINT,
        rows_updated BIGINT,
        rows_unchanged BIGINT,
        sql_current_user VARCHAR(256),
        monitoring_url VARCHAR(8000),
        next_stage_status VARCHAR(20),
        error_details VARCHAR(MAX)
    );
END;
GO


---------------------------------------------------------------
-- logging.execution_watermark
---------------------------------------------------------------

IF OBJECT_ID('logging.execution_watermark', 'U') IS NULL
BEGIN
    CREATE TABLE logging.execution_watermark (
        task_id VARCHAR(50),
        source_table VARCHAR(200),
        incremental_column VARCHAR(200),
        watermark_value VARCHAR(200),
        parent_run_id VARCHAR(200),
        ingestion_timestamp DATETIME2(0)
    );
END;
GO


---------------------------------------------------------------
-- meta.task_metadata
---------------------------------------------------------------

CREATE OR ALTER VIEW meta.task_metadata AS
SELECT
    t.task_id,
    t.task_name,
    t.object_name,
    t.stage,
    t.source_connection_id,
    c.uses_fabric_connection AS source_uses_fabric_connection,
    c.connection_settings AS source_connection_settings,
    t.source_settings,
    t.target_settings,
    t.option_settings,
    t.template_settings,
    t.scheduling_settings,
    t.enabled,
    t.file_hash,
    t.enable_retries,
    t.max_retry_attempts
FROM meta.task t
LEFT JOIN meta.connections c
    ON t.source_connection_id = c.connection_id;
GO


---------------------------------------------------------------
-- meta.usp_get_enabled_tasks
---------------------------------------------------------------

CREATE OR ALTER PROCEDURE [meta].[usp_get_enabled_tasks]
    @stage VARCHAR(500) = NULL,
    @task_id VARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SET @stage = LOWER(NULLIF(LTRIM(RTRIM(@stage)), ''));
    SET @task_id = NULLIF(LTRIM(RTRIM(@task_id)), '');

    WITH stage_filter AS (
        SELECT LTRIM(RTRIM(value)) AS stage
        FROM STRING_SPLIT(@stage, ',')
        WHERE @stage IS NOT NULL
    ),
    task_id_filter AS (
        SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) AS task_id
        FROM STRING_SPLIT(@task_id, ',')
        WHERE @task_id IS NOT NULL
    )
    SELECT
        NEWID() AS task_executions_id,
        NEWID() AS lineage_id,
        tm.*
    FROM meta.task_metadata tm
    WHERE tm.enabled = 1
      AND (
            @stage IS NULL
            OR LOWER(tm.stage) IN (SELECT stage FROM stage_filter)
      )
      AND (
            @task_id IS NULL
            OR tm.task_id IN (SELECT task_id FROM task_id_filter)
      )
    ORDER BY
        CASE LOWER(tm.stage)
            WHEN 'taxonomy' THEN 1
            WHEN 'silver' THEN 2
            WHEN 'gold' THEN 3
            ELSE 4
        END,
        tm.task_id;
END;
GO


---------------------------------------------------------------
-- logging.usp_log_task_execution
---------------------------------------------------------------

CREATE OR ALTER PROCEDURE logging.usp_log_task_execution
    @task_executions_id UNIQUEIDENTIFIER,
    @lineage_id UNIQUEIDENTIFIER,
    @run_id VARCHAR(200),
    @parent_run_id VARCHAR(200),
    @task_id INT,
    @num_retries INT = 0,
    @executing_object_type VARCHAR(50) = 'Notebook',
    @executing_object_id VARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE
        @task_name VARCHAR(200),
        @object_name VARCHAR(200),
        @stage VARCHAR(100),
        @template_name VARCHAR(200),
        @workspace_id VARCHAR(200),
        @monitoring_url VARCHAR(8000);

    SELECT
        @task_name = task_name,
        @object_name = object_name,
        @stage = stage,
        @template_name = JSON_VALUE(template_settings, '$.template_name')
    FROM meta.task
    WHERE task_id = @task_id;

    SET @workspace_id = @parent_run_id;

    SET @monitoring_url =
        CASE
            WHEN @executing_object_type = 'Notebook' THEN
                CONCAT('https://app.fabric.microsoft.com/workloads/de-ds/sparkmonitor/', @executing_object_id, '/', @run_id)
            ELSE
                NULL
        END;

    INSERT INTO logging.task_executions (
        task_executions_id,
        lineage_id,
        run_id,
        parent_run_id,
        task_id,
        task_name,
        object_name,
        stage,
        num_retries,
        start_date,
        start_datetime,
        template_name,
        workspace_id,
        monitoring_url
    )
    VALUES (
        @task_executions_id,
        @lineage_id,
        @run_id,
        @parent_run_id,
        @task_id,
        @task_name,
        @object_name,
        @stage,
        @num_retries,
        CAST(SYSUTCDATETIME() AS DATE),
        CAST(SYSUTCDATETIME() AS DATETIME2(0)),
        @template_name,
        @workspace_id,
        @monitoring_url
    );
END;
GO


---------------------------------------------------------------
-- logging.usp_log_task_execution_completion
---------------------------------------------------------------

CREATE OR ALTER PROCEDURE logging.usp_log_task_execution_completion
    @task_executions_id UNIQUEIDENTIFIER,
    @status VARCHAR(50),
    @next_stage_status VARCHAR(20),
    @log_data VARCHAR(MAX) = NULL,
    @error_details VARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @end_datetime DATETIME2(0) = CAST(SYSUTCDATETIME() AS DATETIME2(0));

    DECLARE @log_json VARCHAR(MAX) =
        CASE
            WHEN ISJSON(@log_data) = 1 THEN @log_data
            ELSE '{"log_data":[]}'
        END;

    DECLARE @error_json VARCHAR(MAX) =
        CASE
            WHEN ISJSON(@error_details) = 1 THEN @error_details
            ELSE '{}'
        END;

    ;WITH log_summary AS (
        SELECT
            COUNT(*) AS table_count,
            MIN(TRY_CAST(JSON_VALUE(value, '$.watermark_from') AS DATETIME2(0))) AS watermark_from,
            MAX(TRY_CAST(JSON_VALUE(value, '$.watermark_to') AS DATETIME2(0))) AS watermark_to,
            SUM(TRY_CAST(JSON_VALUE(value, '$.rows_read') AS BIGINT)) AS rows_read,
            SUM(TRY_CAST(JSON_VALUE(value, '$.rows_inserted') AS BIGINT)) AS rows_inserted,
            SUM(TRY_CAST(JSON_VALUE(value, '$.rows_updated') AS BIGINT)) AS rows_updated,
            SUM(TRY_CAST(JSON_VALUE(value, '$.rows_unchanged') AS BIGINT)) AS rows_unchanged
        FROM OPENJSON(@log_json, '$.log_data')
    ),
    first_table AS (
        SELECT TOP (1)
            TRY_CAST(JSON_VALUE(value, '$.target_table') AS VARCHAR(200)) AS target_table,
            TRY_CAST(JSON_VALUE(value, '$.sql_current_user') AS VARCHAR(256)) AS sql_current_user
        FROM OPENJSON(@log_json, '$.log_data')
        ORDER BY TRY_CAST([key] AS INT)
    )
    UPDATE te
    SET
        status = @status,
        next_stage_status = @next_stage_status,
        end_datetime = @end_datetime,
        duration_min = DATEDIFF(SECOND, start_datetime, @end_datetime) / 60.0,
        log_data = @log_data,
        error_details = @error_details,
        target_table = COALESCE(
            CASE
                WHEN ls.table_count = 1 THEN ft.target_table
                WHEN ls.table_count > 1 THEN te.stage
                ELSE NULL
            END,
            TRY_CAST(JSON_VALUE(@error_json, '$.target_table') AS VARCHAR(200))
        ),
        watermark_from = ls.watermark_from,
        watermark_to = ls.watermark_to,
        rows_read = ls.rows_read,
        rows_inserted = ls.rows_inserted,
        rows_updated = ls.rows_updated,
        rows_unchanged = ls.rows_unchanged,
        sql_current_user = COALESCE(
            TRY_CAST(JSON_VALUE(@log_json, '$.sql_current_user') AS VARCHAR(256)),
            ft.sql_current_user,
            TRY_CAST(JSON_VALUE(@error_json, '$.sql_current_user') AS VARCHAR(256))
        )
    FROM logging.task_executions te
    CROSS JOIN log_summary ls
    OUTER APPLY (
        SELECT target_table, sql_current_user
        FROM first_table
    ) ft
    WHERE te.task_executions_id = @task_executions_id
      AND te.end_datetime IS NULL;
END;
GO


---------------------------------------------------------------
-- logging.usp_get_previous_watermark_val
---------------------------------------------------------------

CREATE OR ALTER PROCEDURE logging.usp_get_previous_watermark_val
    @task_id VARCHAR(50),
    @source_table VARCHAR(200),
    @incremental_column VARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;

    SET @source_table = NULLIF(LTRIM(RTRIM(@source_table)), '');
    SET @incremental_column = NULLIF(LTRIM(RTRIM(@incremental_column)), '');

    SELECT
        COALESCE(MAX(watermark_value), '1900-01-01 00:00:00') AS watermark_value
    FROM logging.execution_watermark
    WHERE task_id = @task_id
      AND source_table = @source_table
      AND incremental_column = @incremental_column;
END;
GO


---------------------------------------------------------------
-- logging.usp_update_watermark_val
---------------------------------------------------------------

CREATE OR ALTER PROCEDURE logging.usp_update_watermark_val
    @task_id VARCHAR(50),
    @source_table VARCHAR(200),
    @incremental_column VARCHAR(200),
    @watermark_value VARCHAR(200),
    @parent_run_id VARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;

    SET @source_table = NULLIF(LTRIM(RTRIM(@source_table)), '');
    SET @incremental_column = NULLIF(LTRIM(RTRIM(@incremental_column)), '');
    SET @watermark_value = NULLIF(LTRIM(RTRIM(@watermark_value)), '');

    IF @incremental_column IS NULL
        OR LOWER(@incremental_column) = 'no_incremental_column'
        OR @watermark_value IS NULL
    BEGIN
        RETURN;
    END;

    MERGE logging.execution_watermark AS target
    USING (
        SELECT
            @task_id AS task_id,
            @source_table AS source_table,
            @incremental_column AS incremental_column,
            @watermark_value AS watermark_value,
            @parent_run_id AS parent_run_id,
            CAST(SYSUTCDATETIME() AS DATETIME2(0)) AS ingestion_timestamp
    ) AS source
        ON target.task_id = source.task_id
       AND target.source_table = source.source_table
       AND target.incremental_column = source.incremental_column
    WHEN MATCHED THEN
        UPDATE SET
            watermark_value = source.watermark_value,
            parent_run_id = source.parent_run_id,
            ingestion_timestamp = source.ingestion_timestamp
    WHEN NOT MATCHED THEN
        INSERT (
            task_id,
            source_table,
            incremental_column,
            watermark_value,
            parent_run_id,
            ingestion_timestamp
        )
        VALUES (
            source.task_id,
            source.source_table,
            source.incremental_column,
            source.watermark_value,
            source.parent_run_id,
            source.ingestion_timestamp
        );
END;
GO