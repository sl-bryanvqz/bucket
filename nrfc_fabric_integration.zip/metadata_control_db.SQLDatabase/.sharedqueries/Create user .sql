--- Create  workspace identity


CREATE USER [ws_canada_global_mds_dev] FROM EXTERNAL PROVIDER;
ALTER ROLE db_datareader ADD MEMBER [ws_canada_global_mds_dev];
ALTER ROLE db_datawriter ADD MEMBER [ws_canada_global_mds_dev];
GRANT EXECUTE TO [ws_canada_global_mds_dev];


--- Create  spn identity

CREATE USER [NRFC Apps Fabric SQL NonProd] FROM EXTERNAL PROVIDER;
ALTER ROLE db_datareader ADD MEMBER [NRFC Apps Fabric SQL NonProd];
ALTER ROLE db_datawriter ADD MEMBER [NRFC Apps Fabric SQL NonProd];
GRANT EXECUTE TO [NRFC Apps Fabric SQL NonProd];



--- drop USER ws_canada_global_mds_dev




