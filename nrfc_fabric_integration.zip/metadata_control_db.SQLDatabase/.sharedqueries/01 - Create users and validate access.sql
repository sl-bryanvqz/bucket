---------------------------------------------------------------
-- Create database users and grant permissions
---------------------------------------------------------------

-- Workspace identity
IF NOT EXISTS (
    SELECT 1
    FROM sys.database_principals
    WHERE name = 'ws_canada_global_mds_dev'
)
BEGIN
    CREATE USER [ws_canada_global_mds_dev] FROM EXTERNAL PROVIDER;
END;
GO

ALTER ROLE db_datareader ADD MEMBER [ws_canada_global_mds_dev];
ALTER ROLE db_datawriter ADD MEMBER [ws_canada_global_mds_dev];
GRANT EXECUTE TO [ws_canada_global_mds_dev];
GO


-- Service principal identity
IF NOT EXISTS (
    SELECT 1
    FROM sys.database_principals
    WHERE name = 'NRFC Apps Fabric SQL NonProd'
)
BEGIN
    CREATE USER [NRFC Apps Fabric SQL NonProd] FROM EXTERNAL PROVIDER;
END;
GO

ALTER ROLE db_datareader ADD MEMBER [NRFC Apps Fabric SQL NonProd];
ALTER ROLE db_datawriter ADD MEMBER [NRFC Apps Fabric SQL NonProd];
GRANT EXECUTE TO [NRFC Apps Fabric SQL NonProd];
GO


---------------------------------------------------------------
-- Validate users
---------------------------------------------------------------

SELECT
    name,
    type_desc,
    create_date,
    modify_date
FROM sys.database_principals
WHERE name IN (
    'ws_canada_global_mds_dev',
    'NRFC Apps Fabric SQL NonProd'
);
GO