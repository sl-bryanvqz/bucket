CREATE USER [ws_canada_parallel_slow_integration_dev1] FROM EXTERNAL PROVIDER;
ALTER ROLE db_datareader ADD MEMBER [ws_canada_parallel_slow_integration_dev1];
ALTER ROLE db_datawriter ADD MEMBER [ws_canada_parallel_slow_integration_dev1];
GRANT EXECUTE TO [ws_canada_parallel_slow_integration_dev1];

DROP USER IF EXISTS [NRFC Apps Fabric CICD NonProd];



SELECT name, type_desc
FROM sys.database_principals
WHERE name = 'ws_canada_parallel_slow_integration_dev3'
ALTER ROLE db_datareader ADD MEMBER [ws_canada_parallel_slow_integration_dev1];

/*GRANT PERMISSION TO PIM Group*/
CREATE USER [NRFC Apps Fabric CICD NonProd] FROM EXTERNAL PROVIDER;
ALTER ROLE db_datareader ADD MEMBER [NRFC-PIMGroup-Fabric-DevAdmin];
--ALTER ROLE db_datawriter ADD MEMBER [ws_canada_parallel_slow_integration_dev1];
GRANT EXECUTE TO [NRFC-PIMGroup-Fabric-DevAdmin];