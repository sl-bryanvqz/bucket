---------------------------------------------------------------
-- 03 - Seed metadata connections
---------------------------------------------------------------

DECLARE @passphrase NVARCHAR(256) = 'temp-passphrase';

---------------------------------------------------------------
-- SQL database source: CAN_RMDD
---------------------------------------------------------------
EXEC meta.usp_upsert_con_settings
    @connection_name = 'conn_fabric_sql_can_rmdd',
    @connection_settings = '{
        "connection_type": "sql_database",
        "source_name": "CAN_RMDD",
        "source_type": "sql_database",
        "source_location": "CAN_RMDD-236c5edd-b846-437b-b99b-39e8e56a0a5e",
        "source_schema": "dbo",
        "fabric_connection_id": "7c9005a5-6f9c-4ac9-872e-6968b69d72fd",
        "server_name": "hbvkj6b5fvzenlsxgtupezx6wq-4qzy5g26bakuhffkkiyl64azc4.database.fabric.microsoft.com"
    }',
    @passphrase = @passphrase;

---------------------------------------------------------------
-- Lakehouse source: silver to gold
---------------------------------------------------------------
EXEC meta.usp_upsert_con_settings
    @connection_name = 'conn_lakehouse_lh_canada_global_mds',
    @connection_settings = '{
        "connection_type": "lakehouse",
        "source_name": "lh_canada_global_mds",
        "source_type": "lakehouse",
        "workspace_name": "ws_canada_global_mds_dev",
        "lakehouse_name": "lh_canada_global_mds"
    }',
    @passphrase = @passphrase;

---------------------------------------------------------------
-- Shortcut source: taxonomy
---------------------------------------------------------------
EXEC meta.usp_upsert_con_settings
    @connection_name = 'conn_shortcut_external_curated_taxonomy',
    @connection_settings = '{
        "connection_type": "shortcut",
        "source_type": "shortcut",
        "source_location": "external_curated_taxonomy"
    }',
    @passphrase = @passphrase;

---------------------------------------------------------------
-- CSV source: lakehouse files
---------------------------------------------------------------
EXEC meta.usp_upsert_con_settings
    @connection_name = 'conn_csv_lakehouse_files',
    @connection_settings = '{
        "connection_type": "csv",
        "source_type": "csv"
    }',
    @passphrase = @passphrase;

---------------------------------------------------------------
-- Verify seeded connections
---------------------------------------------------------------
SELECT
    connection_id,
    connection_name
FROM meta.connections
WHERE connection_name IN (
    'conn_fabric_sql_can_rmdd',
    'conn_lakehouse_lh_canada_global_mds',
    'conn_shortcut_external_curated_taxonomy',
    'conn_csv_lakehouse_files'
)
ORDER BY connection_name;