# Development Standards

This section defines development standards for the Foundation framework across:

- Python code in Fabric notebooks
- Fabric Data Pipelines
- SQL code in the metadata Control Database (`metadata_control_db.sqlproj`)

The goals are to:

- Keep code readable, consistent, and reviewable
- Make it easy to onboard new engineers
- Support safe refactoring as Foundation evolves
- Enable future reuse via shared Python libraries and template pipelines

## Python & Notebook Standards

Python code in Foundation is primarily authored in Fabric notebooks (e.g. `nb_load_to_bronze`, `nb_load_to_silver`, `nb_base_template`). These notebooks are treated as production code, not scratchpads.

We align to PEP 8 for Python style and naming. [Python Enhancement Proposals (PEPs)](https://peps.python.org/pep-0008/)

### General coding conventions (PEP 8 + Foundation rules)

- Naming
  - Functions, variables, module-level constants: `snake_case`
    - `run_id`, `source_settings`, `load_to_bronze`, `get_watermark`
  - Classes (if used): `PascalCase`
  - Avoid abbreviations unless they are widely understood (`sql`, `id`, `utc`).
- Layout
  - 4 spaces per indentation level; no tabs.
  - Max line length 88–100 characters (soft rule; break lines early when it helps readability).
  - Use blank lines to separate logical sections/blocks.
- Imports
  - Standard library -> third-party -> project-specific, in that order.
  - Do not use `from module import *`; import explicitly.
- Docstrings & comments
  - Use [PEP 257-style](https://peps.python.org/pep-0257/) docstrings for functions that encapsulate logic (even inside notebooks).
  - Prefer *why* comments over *what* comments when something isn’t obvious.

### Notebook structure

All production notebooks should follow a consistent structure, using the existing `nb_base_template` as the baseline:

1. Parameters cell
   - Parameters passed from pipelines (e.g. `task_id`, `source_settings`, `target_settings`, `option_settings`, `template_settings`, `stage`) are declared in a dedicated cell.
   - Provide safe defaults for local execution, e.g.:

     ```python
     task_id = task_id or 0
     source_settings = source_settings or "{}"
     target_settings = target_settings or "{}"
     ```

2. Configuration & imports
   - All imports in one place at the top: `uuid`, `json`, `pyspark.sql`, `semPy`, helper modules, etc.
   - Set up any global constants (e.g. default Spark configs) here.
3. Helper functions
   - Encapsulate reusable logic into small, testable functions:
     - `load_settings_from_json()`
     - `get_watermark()`
     - `update_watermark()`
     - `log_task_start()` / `log_task_end()`
   - These are the first targets to move into a shared library (wheel) later.
4. Main execution logic
   - A single main block / function (`main()` or clearly delimited code cell) that:
     1. Reads settings and metadata.
     2. Extracts / transforms / loads data.
     3. Performs validation (row counts, basic checks).
     4. Writes to logging and watermark tables.
5. Validation & logging
   - Explicitly log row counts, status, and relevant identifiers (`task_id`, `task_executions_id`, `lineage_id`).
   - Use the logging stored procedures (`logging.usp_update_watermark_val`, etc.) through a helper rather than inline SQL sprinkled everywhere.
6. No secrets in notebooks
   - All secrets must come from Fabric connections, environments, or Key Vault integrations.
   - Never hard-code passwords, connection strings, or tenant IDs.

### Error handling & logging

- Wrap main notebook logic in a `try/except` pattern:
  - On *success*:
    - Mark the execution as `Succeeded` in `logging.task_execution`.
    - Optionally perform validations and log them.
  - On *failure*:
    - Capture the exception message and stack trace.
    - Update `logging.task_execution` with `status = 'Failed'` and `error_message`.
    - Let the exception propagate to the pipeline so retries/alerts can kick in.
- Always log:
  - `run_id` / `task_executions_id`
  - `task_id`
  - Source system, schema, table (if applicable)
  - Target lakehouse path / table

### Dependencies & shared libraries (wheels)

In the short term, notebooks can import helper modules from the repo. Long term, we standardize on shared libraries distributed as wheel packages:

1. Create a shared library project
   - Example: `edm_foundation_common`
   - Contains modules like:
     - `config` (reading `source_settings`/`target_settings`)
     - `watermark` (get/update watermark)
     - `logging` (interact with logging tables)
     - `validation` (row counts, schema checks)
2. Package as a wheel
   - Use modern Python packaging via a `pyproject.toml` (preferred) or `setup.cfg` following the Python Packaging User Guide. ([Python Packaging](https://packaging.python.org/en/latest/))
   - Build the package:

     ```bash
     python -m build  # or
     python -m pip wheel .
     ```

   - Output is a versioned `*.whl` file.
3. Install in Fabric
   - Use Fabric environments to manage libraries:
     - Upload the wheel as a custom library to the environment.
     - Attach the environment to notebooks and Spark jobs so the library is importable. ([Microsoft Learn - Manage Environment Library](https://learn.microsoft.com/en-us/fabric/data-engineering/environment-manage-library))
   - Version the wheel (`edm_foundation_common-0.1.0-py3-none-any.whl`) and treat it like any other artefact in CI/CD.
4. Usage pattern
   - In notebooks, replace local helper code with:

     ```python
     from edm_foundation_common.watermark import get_watermark, update_watermark
     from edm_foundation_common.logging import log_task_start, log_task_end
     ```

5. Standards for shared libraries
   - Same PEP 8 conventions as notebooks.
   - Fully unit-tested where feasible.
   - Semantic versioning for breaking/non-breaking changes.

### Testing & local development

- Where logic is complex (e.g. business rules, SCD-type handling), keep it in plain Python functions so it can be unit tested.
- Favor pure functions where possible (inputs -> outputs) so they can be tested outside Fabric.

## Fabric Data Pipeline Standards

Fabric Data Pipelines are used for orchestration and movement, not heavy business logic. Foundation already uses pipelines like `pl_scheduler`, `pl_orchestrator`, `pl_extract_oracle`, and `pl_extract_sap`.

We align to Microsoft’s guidance that pipelines are logical groupings of activities that can be scheduled and monitored as a unit.([Microsoft Learn - Fabric Pipeline Overview](https://learn.microsoft.com/en-us/fabric/data-factory/pipeline-overview))

### Naming conventions

We follow a consistent naming pattern inspired by Azure Data Factory best practices and use type prefixes to make components easily discoverable.([Microsoft Learn - ADF Naming Rules](https://learn.microsoft.com/en-us/azure/data-factory/naming-rules))

- Pipelines: `pl_<verb>_<source>_<target_or_stage>`
  - Examples:
    - `pl_scheduler`
    - `pl_orchestrator`
    - `pl_extract_oracle`
    - `pl_extract_sap`
    - `pl_ext_mdm_to_bronze`
- Notebooks: `nb_<verb>_<stage>`
  - `nb_load_to_bronze`, `nb_load_to_silver`, `nb_extract_sharepoint`
- Parameters:
  - `snake_case`, descriptive: `task_id`, `stage`, `source_settings`, `target_settings`.
- Activities:
  - `CamelCase` or descriptive phrase:
    - `GetTasksDueForExecution`
    - `ExecuteOrchestrator`
    - `LoadToBronze`, `LoadToSilver`

### Descriptions & annotations

- Every pipeline must have a description:
  - What it does, what layer(s) it touches, and the primary owner/team.
- Every activity must have:
  - A short description explaining its purpose.
  - Where relevant, a note on error handling (e.g. “Retries 3 times before failing”).
- Use annotations/tags to identify:
  - Environment (Dev/Test/Prod)
  - Stage (`Extract`, `LoadToBronze`, `LoadToSilver`)
  - Source system (`Maximo`, `MDM`, `LS`, `SAP`)

This helps both in Fabric Monitor and in the codebase.

### Pipeline structure

For Foundation’s core pipelines, we follow this pattern:

- `pl_scheduler`
  - Lightweight pipeline that:
    - Calls `meta.usp_get_tasks_due_for_execution` to determine due tasks.
    - Invokes `pl_orchestrator` with the list of tasks and relevant parameters.
- `pl_orchestrator`
  - Central orchestration pipeline:
    - Creates `logging.task_execution` records.
    - Dispatches to worker pipelines/notebooks based on `template_settings`.
    - Wires up `run_id`, `task_executions_id`, `lineage_id`.
    - Handles success/failure transitions and triggers next stages.
- Worker pipelines (e.g. `pl_extract_oracle`, `pl_extract_sap`)
  - Focused on a single responsibility:
    - Extract data from a specific source.
    - Run a specific notebook.
    - Move data from one layer to another.

General rules:

- No business rules in orchestration pipelines:
  - Business logic should live in notebooks or shared Python libraries.
- Keep pipelines shallow:
  - Avoid deep nesting of child pipelines unless there’s a clear need.
- Prefer reusable templates over one-off pipelines for new sources.

### Parameters, variables & configuration

- Pipeline parameters:
  - Use `snake_case` and align with notebook parameter names.
  - Example: `task_id`, `stage`, `task_list_json`.
- Variables:
  - Use for internal state, not for configuration that belongs in metadata.
- Configuration:
  - All source/target configuration must come from:
    - The `meta.task` row (`source_settings`, `target_settings`, `option_settings`, `template_settings`).
    - Control DB stored procedures.
  - Do not hard-code connection details or table names directly in pipelines.

### Error handling, retries & alerts

- Use Data Factory/Fabric retry settings on activities:
  - Align with per-task retry settings in metadata (`enable_retries`, `max_retry_attempts`) where appropriate.
- If a downstream notebook or child pipeline fails:
  - Bubble up the failure to the parent pipeline.
  - Do not swallow exceptions without logging.
- Integrate with the alert pipeline:
  - On failure (or critical success), send email notifications with:
    - Pipeline name
    - Task name
    - Status
    - Link to Fabric Monitor (`pipeline_run_url`)

### Scheduling

- Do not schedule worker pipelines directly.
- Schedule only:
  - `pl_scheduler`, which uses `meta.usp_get_tasks_due_for_execution` and `scheduling_settings` in `meta.task` to decide what to run when.
- See `02-Metadata-Framework/Scheduling.md` for details on `schedule_type`, `scheduled_times`, and `frequency_minutes`.

## SQL Standards for the Control Database

All SQL for the Control DB is managed via the `metadata_control_db.sqlproj` project. This includes schemas like `meta`, `logging`, `integration`, and others.

We follow:

- T-SQL conventions already used in the repo.
- Joe Celko-inspired “river” style / SQL style guides for readability. ([SQL Style Guide](https://www.sqlstyle.guide/))

### Object & file organization

- One object per file:
  - Tables, views, stored procedures, and functions all live in separate files under their schema folders, matching current project layout.
- Naming:
  - File name matches the object name:
    - `meta/Tables/task.sql`
    - `logging/StoredProcedures/usp_update_watermark_val.sql`
- Schemas:
  - `meta` for configuration / metadata (`meta.task`, etc.).
  - `logging` for execution logs and watermarks.
  - `integration` (or equivalent) for helper and integration procedures.

### Naming conventions

- Tables & views:
  - `snake_case` column names:
    - `task_id`, `task_name`, `source_connection_id`, `scheduling_settings`
  - Singular or existing convention per schema (`task`, `task_execution`, etc.).

- Stored procedures:

  - Prefix with schema and `usp_`:

    - `meta.usp_get_tasks_due_for_execution`
    - `logging.usp_update_watermark_val`
  - Use verbs that describe what the proc does (`get`, `update`, `set`, `validate`).

- Constraints & indexes:

  - PK: `PK_<schema>_<table>`
  - FK: `FK_<schema>_<table>_<ref_table>`
  - Indexes: `IX_<schema>_<table>_<column_or_purpose>`

### Query formatting (“river” style)

We use an adapted Celko “river” style:

- Keywords in UPPERCASE.
- Each major clause on its own line.
- Conditions aligned to form a visual “axis” down the page (no jagged “river” of whitespace. [SQL Style Fuide](https://www.sqlstyle.guide/))

Example:

```SQL
SELECT  te.task_id,
        te.status,
        te.start_datetime,
        te.end_datetime,
        te.error_message
  FROM  logging.task_executions AS te
  JOIN  meta.task               AS t
    ON  t.task_id = te.task_id
 WHERE  te.status = 'Failed'
   AND  t.stage   = 'extract'
 ORDER  BY  te.start_datetime DESC;
```

Guidelines:

- Always schema-qualify objects (`meta.task`, `logging.task_executions`).
- Avoid `SELECT *` in production code; explicitly name columns.
- Align keywords vertically (`SELECT`, `FROM`, `JOIN`, `WHERE`, `GROUP BY`, `ORDER BY`).

### Stored procedure patterns

For stored procedures (e.g. `meta.usp_get_tasks_due_for_execution`, `logging.usp_update_watermark_val`), follow:

- Header:
  - Short comment block explaining:
    - Purpose
    - Inputs and outputs
    - Any side effects (e.g. writes to `logging.task_executions`).

- Signature:
  - Parameters in `snake_case`, grouped logically:
    - Required first, optional last.
  - Default values for optional params where it makes sense.
- Body structure:
  1. `SET NOCOUNT ON;`
  2. Declare local variables at the top.
  3. Use `TRY...CATCH` blocks for error handling.
  4. On error:
     - Log the error where appropriate.
     - Re-throw with `THROW` (or `RAISERROR` for legacy) so callers can react.

Example pattern:

```SQL
CREATE PROCEDURE [logging].[usp_update_watermark_val]
      @task_id            VARCHAR(50)
    , @source_table       VARCHAR(200)
    , @incremental_column VARCHAR(200)
    , @watermark_value    VARCHAR(200)
    , @parent_run_id      VARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        MERGE INTO logging.execution_watermark AS target
        USING (
            SELECT  @task_id            AS task_id,
                    @source_table       AS source_table,
                    @incremental_column AS incremental_column,
                    @watermark_value    AS watermark_value,
                    @parent_run_id      AS parent_run_id,
                    GETDATE()           AS ingestion_timestamp
        ) AS source
           ON target.task_id = source.task_id
        WHEN NOT MATCHED THEN
            INSERT ( task_id,
                     source_table,
                     incremental_column,
                     watermark_value,
                     parent_run_id,
                     ingestion_timestamp )
            VALUES ( source.task_id,
                     source.source_table,
                     source.incremental_column,
                     source.watermark_value,
                     source.parent_run_id,
                     source.ingestion_timestamp )
        WHEN MATCHED THEN
            UPDATE SET target.source_table       = source.source_table,
                       target.incremental_column = source.incremental_column,
                       target.watermark_value    = source.watermark_value,
                       target.parent_run_id      = source.parent_run_id,
                       target.ingestion_timestamp = source.ingestion_timestamp;
    END TRY
    BEGIN CATCH
        -- Log error if needed, then re-throw
        THROW;
    END CATCH;
END;
```

### DDL & safety

- Always include explicit primary keys and relevant indexes.
- Use appropriate data types (`DATETIME2` vs `DATETIME`, `BIT` for booleans, etc.).
- When changing tables:

  - Use idempotent patterns (`IF OBJECT_ID(...) IS NOT NULL` or `CREATE OR ALTER`).
- Avoid destructive operations in scripts that may run repeatedly in CI/CD (no unconditional `DROP TABLE` without checks).

## Code Review & Pull Request Expectations

Across Python, pipelines, and SQL:

- Every change should go through a pull request (PR).
- PR reviewers should check:
  - Adherence to the standards in this document.
  - Clear naming, descriptions, and error handling.
  - No secrets or environment-specific values hard-coded.
  - Impact on existing metadata (`meta.task`) and logging behavior.
