# Architecture & Design

This section describes the *overall architecture and design* of the NRFC Microsoft Fabric Foundation (“Foundation”) platform.

Where the `02 Metadata Framework` section focuses on *how* metadata drives orchestration and ingestion, this section focuses on the *big-picture architecture*: how Foundation fits into the NRFC ecosystem, the major components (Fabric, control database, CI/CD, security), and how they work together to deliver a standardized, metadata-driven data platform.

## Architectural Overview

Foundation is a *centralized, metadata-driven data platform* built on Microsoft Fabric. It is designed to:

- Ingest data from multiple operational systems (Oracle Maximo, SAP, SQL sources, APIs, etc.) through reusable templates.
- Land data in a layered/medallion Lakehouse architecture (Bronze -> Silver -> Gold).
- Use a Control Database to drive all orchestration and execution via metadata.
- Leverage Microsoft Entra ID, Managed Identities, and Service Principals for secure, least-privilege access.
- Be deployed and managed via Azure DevOps CI/CD

At a high level:

- Business systems remain the system of record.
- Foundation provides a repeatable, governed platform to ingest and transform data from those systems.
- Downstream teams build reporting, analytics, and data products on top of the curated Silver and Gold layers.

## C4 Architecture Views

The design is documented using the **C4 Model**, from high-level context down to key containers and pipelines.

### C1 – System Context: Foundation in the NRFC Landscape

#### Diagram:

![C1 – Foundation System Context](../.images/C4-Model-Template-and-Arch-C1--Foundation-System-Diagram.png)

The **C1 view** shows the Foundation Platform in relation to the rest of the NRFC ecosystem:

- **User**
  - Develops and views reports/analytics.
  - Interacts with the Foundation Platform (e.g. Power BI, Fabric experiences).
- **DevOps System**
  - Provides source control, CI/CD automation, and release management for data assets.
  - Publishes code to the Foundation Platform and receives changes back via standard Git/CI pipelines.
- **Foundation Platform**
  - Unified analytics and data management SaaS platform for data integration, engineering, warehousing, and business intelligence (Microsoft Fabric).
- **Cloud Infrastructure Services**
  - Provides secure enterprise cloud capabilities such as storage, networking, and secrets management (Key Vault, Managed Identity, etc.).
- **External Systems**
  - **External On-Prem System** – on-prem sources such as Oracle databases.
  - **External SaaS/Cloud System** – external cloud applications and APIs.
  - **External System** – other non-Fabric systems that provide or consume data.
- **Data Governance Platform**
  - Provides catalog, lineage, and governance for data assets (e.g. Microsoft Purview).

*Note:* Foundation is **not** a standalone app for end users. It is an **internal platform** that enables fast onboarding of data through configutation and expedites the democratization of data.

### C2 – Container View: Foundation Platform

#### Diagram

![C2 – Foundation Platform Containers](./01-Architecture-and-Design/.images/C4-Model-Template-and-Arch-C1--Foundation-System-Diagram.png)

The **C2 view** focuses on the major “containers” that make up the Foundation Platform boundary:

- **Control Database**
  *Container: Microsoft Fabric SQL Database*
  - Stores metadata for connections and tasks.
  - Tracks pipeline executions and watermarks.
  - Hosts the stored procedures that drive orchestration and runtime behaviour.

- **Lakehouse**
  *Container: Microsoft Fabric Lakehouse*
  - Manages both source-aligned raw data (Bronze) and harmonized refined tables (Silver/Gold).
  - Enables scalable transformations from notebooks and pipelines.

- **Warehouse**
  *Container: Microsoft Fabric Warehouse*
  - Integrated, trusted data repository.
  - Holds business-aligned models with RLS/CLS and semantic alignment where required.

- **Semantic Models**
  *Container: Fabric Semantic Model*
  - Provide relationships, calculations, and business logic for reporting and analytics.
  - Are consumed by dashboards, reports, and external tools via standard query interfaces.

- **Orchestration**
  *Container: Fabric Data Factory, Fabric Notebooks*
  - Orchestrates execution of data pipelines and notebooks.
  - Retrieves configuration from the Control Database.
  - Sends logs and status updates back to the Control Database.

- **Rest APIs**
  *Container: API, JSON, HTTPS, OAuth*
  - Provide external endpoints and authentication for triggering or integrating orchestration where needed.

- **DevOps System**
  - Deploys changes to the Control Database, pipelines, notebooks, and semantic models.
  - Integrates with Fabric via APIs/CI pipelines for automated releases.

- **Cloud Services & Data Governance Platform**
  - Cloud infrastructure (Key Vault, Managed Identity, etc.) provides secure storage of secrets and credentials.
  - Governance platform (Purview) references Fabric assets for catalog, lineage, and policy.

The containers **separate concerns**, orchestration, metadata, compute, storage, authentication, deployment, and governance, while remaining tightly integrated via IDs and configuration (workspace IDs, lakehouse IDs, connection IDs, task IDs).

### C3 – Orchestration & Runtime Pipeline View

#### Diagram

![C3 – Orchestration Pipeline](./01-Architecture-and-Design/.images/C4-Model-Template-and-Arch-C3--Orchestration-Pipeline.png)

The **C3 view** zooms into the orchestration pattern inside Microsoft Fabric:

- **Scheduler**
  *Container: Fabric Data Factory / Fabric Notebooks*
  - Orchestrates and triggers work on an interval.
  - Reads metadata from the Control Store Interface (Control Database) and determines which tasks to run.

- **Control Store Interface**
  *Container: Microsoft Fabric SQL Database*
  - Encapsulates reads/writes to metadata.
  - Exposes stored procedures that the orchestration layer uses to fetch tasks, watermarks, and configuration.

- **Execution Engine Adapter**
  *Container: Fabric Data Factory / Fabric Notebooks*
  - Translates “planned work” (metadata) into concrete pipeline/notebook executions.
  - Sends logs back to the Control Database and updates task execution status.

- **Data Validation**
  *Container: Fabric Notebooks / SQL Database*
  - Performs row-count checks and post-load validations where required.
  - Sends logs and outcomes back to the Control Database.

- **External Sources and Cloud Services**
  - External On-Prem / SaaS systems execute tasks or provide data when requested.
  - Cloud Services provide data and credentials (e.g. Key Vault, workspaces, notebooks).

### Data Landscape View

#### Diagram

![Data Landscape – Environments & DevOps](./01-Architecture-and-Design/.images/C4-Model-Template-and-Arch--Data-Landscape.png)

This view shows how Foundation fits into the **broader data landscape and environments**:

- **Azure DevOps**
  - Repositories for Fabric artifacts and the metadata framework code.
  - CI/CD pipelines and Azure Artifacts.
  - Peer review and test automation for controlled releases.

- **Microsoft Fabric Environments**
  - **dev – Fabric Workspace**
    - Fabric Objects, Notebooks, Pipelines, Lakehouse, Warehouse, Semantic Models, Dashboards, Environment.
  - **tst – Fabric Workspace**
    - Mirrors dev, used for integration and validation.
  - **Production Fabric Workspace**
    - Hosts:
      - Metadata-driven Framework (orchestration pipelines, worker pipelines, transformation notebooks).
      - **MDF Control DB** (configuration + execution logs).
      - **Production Lakehouse** (Bronze, Silver, Gold).
      - Semantic models and downstream dashboards.

- **Microsoft Purview & Azure Services**
  - Purview provides Data Map, unified catalog, and data quality controls.
  - Azure services such as Key Vault, Security Center, and Entra Managed Identities support security and compliance.

- **External Systems**
  - SaaS APIs, file shares, and on-prem databases that exchange data with Fabric.

## Logical Component Breakdown

This section maps the C4 diagrams to concrete components that exist in the current implementation.

### Microsoft Fabric

- **Workspaces**
  - Foundation workspace for orchestration and platform assets.
  - Additional workspaces for data products / business domains.
- **Artifacts**
  - Lakehouses (Bronze, Silver, Gold).
  - Pipelines (scheduler, orchestrator, extract workers, validation).
  - Notebooks (ingestion, transformation, utilities).
  - Warehouses and Semantic Models.
  - Variable Libraries (workspace IDs, lakehouse IDs, Key Vault URIs, etc.).

### Metadata Control Database

See **[02 – Metadata Framework](./02-Metadata-Framework.md)** for full details.

At a high level:

- **`meta` schema** – what to run, when, and how.
- **`integration` schema** – cross-stage coordination (files ready for bronze/silver, watermarks).
- **`logging` schema** – every execution and watermark captured centrally.

### Security & Identity

- **Service Principal**
  - Used for CI/CD and automation (Fabric publishing, workspace provisioning).
- **Managed Identity**
  - Used by runtime pipelines and notebooks to:
    - Retrieve secrets from Key Vault.
    - Access Azure resources securely without embedding credentials.
- **Entra ID Groups**
  - Drive access to:
    - Fabric workspaces.
    - Administrative actions.
    - CI/CD permissions.

### CI/CD & Environment Strategy

- **Azure DevOps Pipelines**
  - Greenfield deployment for new environments.
  - DACPAC deployment for Control DB.
  - Fabric workspace deployment using Fabric APIs / `fabric-cicd`.
- **Key Vault**
  - One vault per environment (D/T/P).
  - Holds SPN credentials and other secrets.
- **parameter.yml**
  - Used to replace IDs (workspaces, lakehouses, connections) per environment during deployment.

## Runtime Data Flow (End-to-End)

The execution flow can be summarized as:

1. **Trigger**
   - Fabric scheduler triggers the Scheduler component (e.g. `pl_scheduler`) on an interval or via API.
2. **Determine Due Tasks**
   - Scheduler calls Control Database procedures (e.g. `meta.usp_get_tasks_due_for_execution`).
   - Returns set of tasks that should run now, filtered by stage and valid scheduling settings.
3. **Orchestration**
   - Orchestration component:
     - Creates `task_executions_id` and `lineage_id`.
     - Logs start via logging procedures.
     - Invokes the appropriate worker (Data Pipeline or Notebook) based on metadata.
4. **Extract**
   - Worker pipeline reads `source_settings` and connection info.
   - Uses watermarks for incremental loads.
   - Reads from external systems and lands data as Parquet in the **Bronze Lakehouse Files**.
   - Updates watermark and logging details (query, file paths, etc.).
5. **Load to Bronze**
   - Bronze loaders determine which files/runs are ready.
   - Load raw files into Bronze Delta tables using configured `load_strategy` (overwrite/append).
6. **Load to Silver**
   - Silver loaders determine which Bronze runs are ready.
   - Apply appropriate strategy: overwrite, append, merge, SCD1, SCD2-FULL, SCD2-INCREMENTAL (see **Data Ingestion Types**).
7. **Completion & Monitoring**
   - Each stage updates logging tables with final status and `next_stage_status`.
   - Foundation exposes monitoring views and Fabric monitoring URLs for operators and engineers.