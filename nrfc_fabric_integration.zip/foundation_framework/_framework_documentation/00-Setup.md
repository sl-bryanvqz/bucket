# Setup Overview

This section documents the foundation components required to deploy and operate the NRFC Microsoft Fabric Foundation Platform.

## Navigation

| Setup Component | Description |
|-----------------|-------------|
| [**Service Principal Setup**](./00-Setup/Service-Principal-Setup) | Enterprise application configuration |
| [**Azure Key Vault Setup**](./00-Setup/Azure-Key-Vault-Setup.md) | Centralized secret management |
| [**Managed Identity Setup**](./00-Setup/Managed-Identity-Setup.md) | Azure resource authentication |
| [**Entra ID Group Setup**](./00-Setup/Entra-ID-Group-Setup.md) | Security groups and Fabric tenant |
| [**Azure DevOps Setup**](./00-Setup/Azure-DevOps-Setup.md) | CI/CD pipeline configuration |
| [**Environment Replication**](./00-Setup/Environment-Replication.md) | Multi-environment deployment |

## Prerequisites

Before beginning setup, ensure you have:

- Azure subscription with appropriate permissions
- Microsoft Fabric tenant access
- Azure DevOps organization access
- NRFC corporate network connectivity

## Architecture Overview

{{placeholder}}

Start with [Service Principal Setup](./00-Setup/Service-Principal-Setup.md)