# Managed Identity Setup

## Overview

This identity is used for Fabric Foundation components that require access to Azure resources, such as Key Vault, Storage Accounts, SQL Databases, and OneLake. The Managed Identity provides secure, credential-free authentication for runtime operations.

## Prerequisites

- Azure subscription with appropriate permissions
- Access to Azure portal
- Resource Group permissions
- Azure Key Vault created (see [Azure Key Vault Setup](../00-setup/Azure-Key-Vault-Setup.md))

## Configuration Steps

### 1. Create Managed Identity

1.1 Navigate to Azure Portal → Managed Identities → `+ Create`

![azure-portal-create-mi](../00-setup/.images/azure-portal-create-mi.png)

1.2 **Name:** `MI-EDM-FOUNDATION-D`

> **Note:** Please refer to naming conventions for reference on how to name Managed Identities.

1.3 **Resource Group:** `RG-ENMAX-EDM-UW2-FABRICFOUNDATION-D` (or select the resource group for the data product)

1.4 **Region:** `West US 2`

### 2. Assign Key Vault Access

2.1 Go to `ENMAX-EDM-KV-FABRIC-D` → Access Control (IAM) → Add Role Assignment

2.2 **Role:** Key Vault Reader

2.3 **Principal:** `MI-EDM-FOUNDATION-D`

2.4 **Scope:** Leave as None for now

### 3. Assign Workspace Access (Microsoft Fabric)

3.1 In Fabric, grant the Managed Identity Contributor access to workspace-level resources (Lakehouse, Pipelines, SQL Database) where required.

3.2 This enables the identity to authenticate without stored secrets.

## Environment-Specific Names

| Environment | Managed Identity Name |
|-------------|----------------------|
| **DEV/TEST** | `MI-EDM-FOUNDATION-D` |
| **PRODUCTION** | `MI-EDM-FOUNDATION-P` |

## Testing Access

### Test Managed Identity Access to Key Vault

Assign a test Fabric notebook to run under the Managed Identity `MI-EDM-FOUNDATION-D` and call:

```python
secret_value = notebookutils.credentials.getSecret("https://enmax-edm-kv-fabric-d.vault.azure.net/", "fabric-api-sp-client-id")
print(secret_value)
```

## Integration with Foundation Framework

The Managed Identity is used by:

- **Data Pipelines:** For accessing Azure resources during runtime
- **Notebooks:** For credential-free authentication to Key Vault and storage
- **SQL Databases:** For secure connections to Azure SQL resources
- **OneLake:** For data access operations

## Troubleshooting

### Common Issues

**Issue:** Managed Identity cannot access Key Vault

- **Solution:** Verify the MI has Key Vault Reader role assigned in Access Control (IAM)

**Issue:** Authentication fails in Fabric notebooks

- **Solution:** Ensure the workspace is configured to use the correct Managed Identity

---

[← Back to Azure Key Vault Setup](../00-setup/Azure-Key-Vault-Setup.md) | [Next: Entra ID Group Setup →](../00-setup/Entra-ID-Group-Setup.md)
