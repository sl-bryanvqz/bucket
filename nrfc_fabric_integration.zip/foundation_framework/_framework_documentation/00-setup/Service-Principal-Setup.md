# Service Principal Setup

## Overview

This identity is used for all automated and non-interactive operations in Microsoft Fabric, including workspace deployments, CI/CD pipelines, DACPAC deployments, and Fabric CLI authentication.

## Prerequisites

- Azure subscription with appropriate permissions
- Access to Microsoft Entra ID admin center
- Ability to create App Registrations

## Configuration Steps

### 1. Create Service Principal in Azure Entra ID

1.1 Navigate to Azure Portal → Go to `Microsoft Entra ID` → App Registrations → `+ New` registration.

![azure-portal-entra-id](../00-setup/.images/azure-portal-entra-id.png)

1.2 **Name:** `sp_fabric_foundation_devops`

> **Note:** This name is for production. Use `sp_fabric_foundation_devops_dev` for DEV and TST environments.

1.3 **Supported account type:** Select single tenant.

![azure-portal-sp-single-tenant](../00-setup/.images/azure-portal-sp-single-tenant.png)

1.4 **Redirect URI:** Leave blank.

### 2. Record Key Identifiers

2.1 Ensure you take note of:

- Application (client) ID
- Directory (tenant) ID
- Object ID

![azure-portal-sp-key-identifiers](../00-setup/.images/azure-portal-sp-key-identifiers.png)

### 3. Create Client Secret

3.1 Navigate to **Certificates & Secrets** → `+ New Client Secret`

![azure-portal-sp-client-secrets](../00-setup/.images/azure-portal-sp-client-secrets.png)

3.2 **Copy the secret value immediately** - it will only be visible once.

3.3 Save the secret temporarily in a secure location.

> **Security Note:** This secret will be stored in Azure Key Vault in the next step.

### 4. Enterprise Application Verification

4.1 In `Microsoft Entra ID` → **Enterprise Applications**, confirm the SPN appears.

![azure-portal-enterprise-app](../00-setup/.images/azure-portal-sp-enterprise-app.png)

4.2 Ensure the SPN is **enabled** and set to "Accounts in this organization only."

![azure-portal-sp-org-only](../00-setup/.images/azure-portal-sp-org-only.png)

## Environment-Specific Names

| Environment | Service Principal Name |
|-------------|----------------------|
| **DEV/TEST** | `sp_fabric_foundation_devops_dev` |
| **PRODUCTION** | `sp_fabric_foundation_devops` |

## Next Steps

- [Configure Azure Key Vault](../00-setup/Azure-Key-Vault-Setup.md) to securely store the client secret
- [Setup Managed Identity](../00-setup/Managed-Identity-Setup.md) for runtime authentication

## Troubleshooting

### Common Issues

**Issue:** Cannot create new service principal

- **Solution:** Contact Azure admin to verify App Registration permissions

**Issue:** Client secret not visible

- **Solution:** Regenerate the secret and copy immediately

**Issue:** Post deployment pipeline error `FabricHTTPException: 401 Unauthorized for url` while executing notebook in the target workspace 

- **Solution:** Service principal execution requires semantic link version 0.12.0 or later. The default runtime image might include an earlier version. 
Ensure the execution environment installs the updated package as part of the job setup.
```python
%pip install -U semantic-link
```
- After installation, restart the kernel (or rerun the job) to pick up the updated package. Verify the installed version:
```python
import sempy
print(sempy.__version__)
```
---

[← Back to Setup Overview](../00-setup.md) | [Next: Azure Key Vault Setup →](../00-setup/Azure-Key-Vault-Setup.md)
