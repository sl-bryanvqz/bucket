# Service Principal Setup

## Overview

This identity is used for all automated and non-interactive operations in Microsoft Fabric, including workspace deployments, CI/CD pipelines, DACPAC deployments, and Fabric CLI authentication.

## Prerequisites

- Azure subscription with appropriate permissions
- Access to Microsoft Entra ID admin center
- Ability to create App Registrations

## Configuration Steps

### 1. NRFC has provided the Service Principal - (Security identity)

#### 1.1. Enterprise Application Verification

1.1.1 In `Microsoft Entra ID` → **Enterprise Applications**, confirm the SPN appears.

![azure-portal-enterprise-app](../00-setup/.images/azure-portal-sp-enterprise-app.png)


## Environment-Specific Names

| Environment | Service Principal Name |
|-------------|----------------------|
| **DEV/TEST** | `NRFC Apps Fabric SQL NonProd` |
| **PRODUCTION** | `NRFC Apps Fabric SQL Prod` |

## Next Steps

- [Configure Azure Key Vault](../00-setup/Azure-Key-Vault-Setup.md) to securely store the client secret
- [Setup Managed Identity](../00-setup/Managed-Identity-Setup.md) for runtime authentication

## Troubleshooting

### Common Issues


**Issue:** Client secret not visible

- **Solution:** Regenerate the secret and copy immediately

**Issue:** Post deployment pipeline error `FabricHTTPException: 401 Unauthorized for url` while executing notebook in the target workspace 

- **Solution:** Service principal execution requires semantic link version 0.12.0 or later. The default runtime image might include an earlier version. 
Ensure the execution environment installs the updated package as part of the job setup.
```python
%pip install -U semantic-link
```
- After installation, restart the kernel (or rerun the job) to pick up the updated package. Verify the installed version:
```python
import sempy
print(sempy.__version__)
```
---

[← Back to Setup Overview](../00-setup.md) | [Next: Azure Key Vault Setup →](../00-setup/Azure-Key-Vault-Setup.md)
