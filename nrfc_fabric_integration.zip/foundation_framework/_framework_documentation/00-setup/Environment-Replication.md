# Environment Replication

## Overview

This document provides guidance for replicating the Microsoft Fabric Foundation platform setup across multiple environments (Development, Test, and Production). It ensures consistent configuration patterns while maintaining proper isolation and security boundaries between environments.

## Prerequisites

- Access to Azure portal with appropriate permissions
- Microsoft Entra ID administrative access
- Azure DevOps project setup permissions
- Understanding of the base setup components

## Environment Configuration Matrix

| Environment | SPN Name | Managed Identity | Key Vault | Service Connection | Security Group |
|-------------|----------|------------------|-----------|-------------------|----------------|
| **DEV** | `sp_fabric_foundation_devops_dev` | `MI-EDM-FOUNDATION-D` | `NRFC-EDM-KV-FABRIC-D` | `sc-fabricfoundation-d` | `fabric_foundation_admin_dev` |
| **TEST** | `sp_fabric_foundation_devops_dev` | `MI-EDM-FOUNDATION-T` | `NRFC-EDM-KV-FABRIC-T` | `sc-fabricfoundation-t` | `fabric_foundation_admin_dev` |
| **PROD** | `sp_fabric_foundation_devops` | `MI-EDM-FOUNDATION-P` | `NRFC-EDM-KV-FABRIC-P` | `sc-fabricfoundation-p` | `fabric_foundation_admin_prd` |

## Replication Steps

### 1. Service Principal Replication

For each target environment:

1.1 **Development/Test Environment**

- Use existing SPN: `sp_fabric_foundation_devops_dev`
- Shared between DEV and TEST environments

1.2 **Production Environment**

- Create dedicated SPN: `sp_fabric_foundation_devops`
- Follow [Service Principal Setup](../00-setup.md#service-principal-enterprise-application) steps

### 2. Azure Key Vault Replication

For each environment, create a separate Key Vault:

2.1 **Key Vault Names:**

- DEV: `NRFC-EDM-KV-FABRIC-D`
- TEST: `NRFC-EDM-KV-FABRIC-T`
- PROD: `NRFC-EDM-KV-FABRIC-P`

2.2 **Resource Groups:**

- DEV: `RG-NRFC-EDM-UW2-FABRICFOUNDATION-D`
- TEST: `RG-NRFC-EDM-UW2-FABRICFOUNDATION-T`
- PROD: `RG-NRFC-EDM-UW2-FABRICFOUNDATION-P`

2.3 **Secrets Configuration:**
Store the same secret names with environment-specific values:

| Secret Name | Description |
|-------------|-------------|
| `fabric-api-sp-client-id` | Environment-specific SPN Application ID |
| `fabric-api-sp-tenant-id` | Tenant directory ID (same across environments) |
| `fabric-api-sp-clientsecret` | Environment-specific SPN client secret |

### 3. Managed Identity Replication

Create environment-specific Managed Identities:

3.1 **Naming Convention:**

- DEV: `MI-EDM-FOUNDATION-D`
- TEST: `MI-EDM-FOUNDATION-T`
- PROD: `MI-EDM-FOUNDATION-P`

3.2 **Access Assignments:**

- Assign Key Vault Reader role to respective environment Key Vault
- Grant Fabric workspace access as needed

### 4. Entra ID Security Groups

4.1 **Group Configuration:**

- DEV/TEST: `fabric_foundation_admin_dev`
- PROD: `fabric_foundation_admin_prd`

4.2 **Membership:**

- Add environment-specific Service Principals
- Include appropriate platform administrators
- Maintain separate groups for production isolation

### 5. Azure DevOps Service Connections

Create environment-specific service connections:

5.1 **Service Connection Names:**

- DEV: `sc-fabricfoundation-d`
- TEST: `sc-fabricfoundation-t`
- PROD: `sc-fabricfoundation-p`

5.2 **Configuration:**

- Reference environment-specific Key Vault for secrets
- Use appropriate Service Principal credentials
- Target correct resource groups

### 6. Fabric Tenant Configuration

6.1 **Development/Test Tenant:**

- Enable Service Principal authentication
- Add `fabric_foundation_admin_dev` to allow list
- Configure tenant-level settings for non-production workloads

6.2 **Production Tenant:**

- Separate tenant configuration or stricter controls
- Add `fabric_foundation_admin_prd` to allow list
- Enhanced security and monitoring settings

## Environment-Specific Variables

### Variable Groups Configuration

| Environment | Variable Group Name | Key Vault Reference |
|-------------|-------------------|-------------------|
| DEV | `Foundation-CICD-Config-D` | `NRFC-EDM-KV-FABRIC-D` |
| TEST | `Foundation-CICD-Config-T` | `NRFC-EDM-KV-FABRIC-T` |
| PROD | `Foundation-CICD-Config-P` | `NRFC-EDM-KV-FABRIC-P` |

### Pipeline Configuration

Environment-specific pipelines:

| Environment | Pipeline Name |
|-------------|---------------|
| **DEV** | `foundation-deployer-endtoend-greenfield-D.yml` |
| **TEST** | `foundation-deployer-endtoend-greenfield-T.yml` |
| **PROD** | `foundation-deployer-endtoend-greenfield-P.yml` |

## Security Considerations

### Environment Isolation

- **Network Separation:** Configure Key Vault networking rules per environment
- **Access Controls:** Maintain separate security groups for production
- **Secret Management:** Use environment-specific secrets with regular rotation

### Compliance Requirements

- **Audit Trails:** Enable logging for all Key Vault operations
- **Change Management:** Implement approval processes for production changes
- **Backup and Recovery:** Configure soft delete and purge protection

## Validation Steps

### 1. Service Principal Authentication Test

For each environment:

```bash
az login --service-principal -u <client-id> -p <client-secret> --tenant <tenant-id>
az keyvault secret show --vault-name <environment-keyvault> --name fabric-api-sp-client-id
```

### 2. Managed Identity Access Test

Test in Fabric notebook:

```python
secret_value = notebookutils.credentials.getSecret("<environment-keyvault-url>", "fabric-api-sp-client-id")
print("Authentication successful")
```

### 3. Pipeline Execution Test

- Deploy Foundation components to each environment
- Verify workspace creation and configuration
- Confirm secret retrieval from correct Key Vault

## Troubleshooting

### Common Issues

**Issue:** Cross-environment secret access

- **Solution:** Verify pipeline variable groups reference correct Key Vault

**Issue:** Service Principal permissions mismatch

- **Solution:** Ensure SPN is member of correct security group per environment

**Issue:** Managed Identity authentication failures

- **Solution:** Confirm MI has appropriate role assignments in target environment

## Maintenance Schedule

| Task | Frequency | Environment | Owner |
|------|-----------|-------------|-------|
| Secret Rotation | Every 6-12 months | All | IT Security/DevOps |
| Access Review | Quarterly | Production | Security Team |
| Configuration Sync Validation | Monthly | All | DevOps Team |
| Disaster Recovery Test | Annually | Production | Platform Team |

---

[← Back to Azure DevOps Setup](../00-setup/Azure-DevOps-Setup.md) | [Next: README →](../00-setup.md)
