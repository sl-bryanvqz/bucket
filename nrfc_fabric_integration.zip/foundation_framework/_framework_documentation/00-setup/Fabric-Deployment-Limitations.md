# Fabric Deployment Limitations

## Overview
As of December 2025, Microsoft Fabric has one critical limitation that prevents a true segregation of Dev/Test/Prod environments: **Fabric Data Pipeline Connections cannot yet be parameterized.**
[link](https://learn.microsoft.com/en-us/fabric/security/workspace-identity-authenticate), [link](https://community.fabric.microsoft.com/t5/Pipelines/The-invoke-pipeline-preview-connection-in-Fabric-is-not-reusable/m-p/4257780)

This means upon deployment (when using native Fabric Deployment Pipelines, not Azure DevOps pipelines), for every **Invoke Pipeline** activity in the framework, the Fabric Data Pipeline connection needs to be manually updated. For example, in the Dev environment we are using the following connection: fabric_foundation_pipelines_dev. Even after deploying to a Test or Prod workspace, the Fabric connection will continue to point to this connection and does not dynamically update to a Test or Prod connection.

![invoke-pl-connection](../00-setup/.images/invoke-pl-connection.png)

Note, this Fabric connection issue does not exist for other Fabric activities such as Lookup, Stored Procedure, Copy Data, etc - it is only present for Invoke Pipelines as they are still a brand new feature to Fabric.

## Rectification Steps
To fix this issue, upon deployments a developer must manually re-configure every single Invoke Pipeline activity, select the Fabric Data Pipeline connection, and select the correct connection for the given Workspace. The figure below demonstrates what this *may* look like:
 
 ![changing-pl-connection](../00-setup/.images/changing-pl-connection.png)

This must be done in 7 total places for the foundation framework:
- `pl_scheduler` (1 place): in the Invoke pl_orchestrator activity
![updating-pl-scheduler](../00-setup/.images/updating-pl-scheduler.png)

- `pl_orchestrator` (4 places): in the Invoke pl_worker activity, the pl_send_email nested within the first IF condition, the pl_send_email nested within the second IF condition, and finally the pl_send_email at the end of the pipeline
![updating-pl-orchestrator](../00-setup/.images/updating-pl-orchestrator.png)

- `pl_worker` (2 places): the Invoke DataPipeline activity, and the Invoke pl_send_email activity
![updating-pl-worker](../00-setup/.images/updating-pl-worker.png)

Once these have been manually configured to the correct workspace, you can then deploy the Fabric items to the next stage. 
