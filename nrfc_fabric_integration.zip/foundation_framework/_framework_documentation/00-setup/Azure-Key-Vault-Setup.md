# Azure Key Vault Setup

## Overview

The Azure Key Vault provides centralized, secure management of secrets, keys, and credentials used by the Microsoft Fabric Foundation platform. It ensures that sensitive information, such as service principal credentials and connection strings, is never stored directly in code, pipelines, or notebooks.

## Prerequisites

- Service Principal created (see [Service Principal Setup](../00-setup/Service-Principal-Setup.md))
- Azure subscription access
- Resource Group permissions

## Configuration Steps

The Azure Key Vault provides centralized, secure management of secrets, keys, and credentials used by the Microsoft Fabric Foundation platform.
It ensures that sensitive information, such as service principal credentials and connection strings, is never stored directly in code, pipelines, or notebooks.
The Foundation framework uses Key Vault to supply secrets dynamically to Data Pipelines, Notebooks, and CI/CD processes through managed identities and service principal authentication.

| Environment | Key Vault Name | Purpose |
|---|---|---|
| Development | kv-can-non-prod-fms-cc | Primary vault for dev/test workloads |
| Test |  | For UAT and QA validation |
| Production |  | Used by production Fabric tenant and CI/CD |

Each environment maintains an isolated Key Vault  instance under the NRFC Enterprise Data Management (EDM) subscription.

Steps to follow:

1. Add Service Principal Secrets

    1.1 Navigate to Objects -> Secrets -> `+ Generate/Import`

    ![azure-portal-kv-secrets-add](../00-setup/.images/azure-portal-kv-secrets-add.png)

    1.2 Create the following entries (one per environment):

    |Secret Name|Value|Description|
    |---|---|---|
    |`fabric-api-sp-client-id`|SPN Application(client) ID|Used for automation authentication|
    |`fabric-api-sp-tenant-id`|Tenant(directory) ID|Used by pipelines and notebooks for authentication context|
    |`NRFC-Apps-Fabric-SQL-NonProd`|SPN client secret value|Generated during SPN registration (visible only once)|

    1.3 Save all secrets and confirm the Secret Identifier URIs. These will be referenced by Fabric Variable libraries.

2. Enable Networking and Security Controls

    2.1 Navigate to the Networking tab.

    2.2 Select Private endpoint connections -> Enabled (optional but recommended for production)

    2.3 Configure Firewall:
    - Allow trusted Microsoft services.
    - Restrict access to NRFC corporate networks or VNets if applicable.

    2.4 Enable Soft Delete and Purge Protection under Recovery settings.
        - This protects secrets from accidental deletion and ensures recovery within retention period.

3. Integration with Fabric Variable Libraries

    3.1 In Fabric, the Key Vault is referenced through the Variable Library `vl_authentication`.

    3.2 Example JSON structure:

    ```json
    {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/variableLibrary/definition/variables/1.0.0/schema.json",
        "variables": [{
            "name": "akv_uri",
            "type": "String",
            "value": "https://kv-can-non-prod-fms-cc.vault.azure.net/"
        },
        {
            "name": "tenant_id_secret_name",
            "type": "String",
            "value": "fabric-api-sp-tenant-id"
        },
        {
            "name": "client_id_secret_name",
            "type": "String",
            "value": "fabric-api-sp-client-id"
        },
        {
            "name": "client_secret_name",
            "type": "String",
            "value": "NRFC-Apps-Fabric-SQL-NonProd"
        }]
    }
    ```

4. Test Access via Managed Identity and SPN. Return to these once you've created the Service Principal and Managed Identity.


    4.1 Managed Identity Test

    Assign a test Fabric notebook to run under the Managed Identity `NRFC Apps Fabric SQL NonProd` and call:

    ```python
    secret_value = notebookutils.credentials.getSecret("https://kv-can-non-prod-fms-cc.vault.azure.net/", "fabric-api-sp-client-id")
    print(secret_value)
    ```

---

[← Back to Service Principal Setup](../00-setup/Service-Principal-Setup.md) | [Next: Managed Identity Setup →](../00-setup/Managed-Identity-Setup.md)
