# Entra ID Group Setup

## Overview

The Entra ID Security Group provides centralized access management for Microsoft Fabric Foundation platform administrators and DevOps personnel. This group controls who can deploy, manage, and administer Fabric Foundation workspaces across environments and enables Service Principal authentication for automated operations.

## Prerequisites

- Access to Microsoft Entra ID admin center
- Ability to create Security Groups
- Service Principal created (see [Service Principal Setup](../00-setup/Service-Principal-Setup.md))
- Azure subscription access

## Configuration Steps

### 1. Create Security Group in Entra ID

1.1 Navigate to Azure Portal → Go to `Microsoft Entra ID` → Groups → `+ New Group`

1.2 **Group type:** Security

1.3 **Group name:** `fabric_foundation_admin_dev`

> **Note:** This name is for development/test environments. Use `fabric_foundation_admin_prd` for production.

1.4 **Group description:** "Fabric Foundation platform administrators and DevOps personnel with elevated permissions for workspace management and configuration tasks."

1.5 **Membership type:** Assigned

### 2. Add Group Members

2.1 Add the following members to the group:

- Platform Administrators
- DevOps Leads
- Service Principal: `sp_fabric_foundation_devops` (or `sp_fabric_foundation_devops_dev` for dev/test)
- Relevant engineers or support accounts

2.2 Click **Create** to save the group

### 3. Configure Fabric Tenant Settings

3.1 Navigate to Microsoft Fabric Admin Portal → Tenant Settings

3.2 **Enable Service Principal Authentication:**

- Find "Allow Service Principals to use APIs and create workspaces"
- Enable the setting
- Add `fabric_foundation_admin_dev` to the allow list

3.3 **Grant Fabric Admin Access:**

- Add `sp_fabric_foundation_devops` as a Fabric Admin
- Required for Fabric CLI and SDK operations during CI/CD

### 4. Verify Group Configuration

4.1 Confirm the group appears in:

- Entra ID → Groups
- Fabric Tenant Settings → Admin Portal → Tenant → Admin APIs

4.2 Verify all members are properly assigned and the Service Principal has appropriate permissions

## Environment-Specific Names

| Environment | Security Group Name | Purpose |
|-------------|-------------------|---------|
| **DEV/TEST** | `fabric_foundation_admin_dev` | Platform admin access for dev/test workspaces |
| **PRODUCTION** | `fabric_foundation_admin_prd` | Platform admin access for production workspaces |

## Group Permissions

The security group grants the following capabilities:

| Permission | Purpose |
|------------|---------|
| Fabric Workspace Management | Create, configure, and manage Fabric Foundation workspaces |
| Service Principal API Access | Enable automated CI/CD pipeline operations |
| Tenant Setting Configuration | Modify platform-level settings and policies |
| Admin Portal Access | Monitor and troubleshoot platform operations |

## Fabric Tenant Settings 

Enable below settings in Fabric Admin portal and Apply to Specific secutity groups

| Category | Setting |
|------------|---------|
| Developer settings | Service principals can create workspaces, connections, and deployment pipelines |
| Developer settings | Service principals can call Fabric public APIs |
| Admin API settings | Service principals can access read-only admin APIs |
| Admin API settings | Service principals can access admin APIs used for updates |
| Admin API settings | Enhance admin APIs responses with detailed metadata |

## Next Steps

- [Configure Azure DevOps Service Connections](../00-setup/Azure-DevOps-Setup.md) using the group principals
- [Setup Managed Identity](../00-setup/Managed-Identity-Setup.md) for runtime authentication

## Troubleshooting

### Common Issues

**Issue:** Service Principal cannot access Fabric APIs

- **Solution:** Verify the SPN is added to the security group and tenant settings are configured
- **Solution:** Verify the SPN has direct permission on Target Workspace as admin under manage access

**Issue:** Group not visible in Fabric Admin Portal

- **Solution:** Ensure group is created as Security type and sync has completed

**Issue:** Users cannot access Foundation workspaces

- **Solution:** Confirm user membership in the security group and workspace-level permissions

**Issue:** Users cannot access Foundation workspaces

- **Solution:** Confirm user membership in the security group and workspace-level permissions

---

[← Back to Azure Key Vault Setup](../00-setup/Azure-Key-Vault-Setup.md) | [Next: Managed Identity Setup →](../00-setup/Managed-Identity-Setup.md)
