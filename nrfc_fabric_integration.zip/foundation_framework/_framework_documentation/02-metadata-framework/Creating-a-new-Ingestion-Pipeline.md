# Creating a new Ingestion Pipeline

When a new data source needs to be onboarded to the framework, this requires a new worker data pipeline to be developed to ingest from that data source. This section offers step-by-step guidance for developers to complete this task.

This guided example creates an ingestion pipeline to onboard data from the Oracle Maximo data source.

***Note**: Each individual data source may have its own specific nuances that may not be covered in this documentation. This guide is meant to be a generic step-by-step instruction, but it will not be able to cover all possible edge cases.*

1. Begin by creating the **Fabric Connection** to the data source.

    ![create-connection](.images/creating-a-fabric-connection.png)

    ![fabric-connection](.images/fabric-connection.png)

2. Upon creation of the connection, capture the **connection id**

    ![connection-id](.images/connection-id.png)

3. Navigate back to the Workspace, and create a new **Pipeline** object. The naming convention of the worker pipeline is: **pl_extract_{data_source_name}**. In this example, it is pl_extract_oracle.
    ![create-a-pl](.images/creating-a-pl.png)

4. Add the following Parameters to the pipeline, to allow the Parent pipeline in the orchestration framework to communicate with the worker pipeline:

    - source_settings: String
    - source_connection_settings: String
    - target_settings: String
    - lineage_id: String
    - current_watermark_datetime: String
    - task_id: String
    - limit_rows_for_debugging: Bool
    - task_executions_id: String

    ![pl-parameters](.images/pl-parameters.png)

5. Create the two variables:

    - **sql_date_predicate [String]** this will be used to capture the incremental loading WHERE clause
    - **sql_query [String]** this builds the entire SQL SELECT query for querying the source database in the Copy Data Activity

    ![pl-variables](.images/pl-variables.png)

6. Import all necessary variables from the Variable Library. The following will be used for *most* worker pipelines, but a specific source may require a new variable:

    - bronze_workspace_id
    - bronze_lakehouse_id
    - metadata_control_db_connection_id
    - metadata_control_db_database
    - metadata_control_db_id
    - lakehouse_connection_id

    ![var-library](.images/var-library.png)

7. Add an **If Condition** activity to the pipeline. This objective of this activity is to create an if-else condition on whether an incremental load is required or not. Thus, the input of the If Condition activity is as follows. This means IF the is_incremental flag is set to True, we perform incremental loading activities (retrieve the watermark, create a WHERE clause, etc). If not, we skip those steps and move right to full load.

    ```javascript
    @if(equals(json(string(pipeline().parameters.source_settings)).is_incremental, 1),true,false)
    ```

    This is what the final If Condition may look like, with the watermarking/incremental load activities occuring in the True block, and full load in the False. Please note that this step is optional, and only required if a pipeline requires nuanced incremental and full load capability. If the execution will always be a full load or always be an incremental load, this step is not required.

    ![if-condition](.images/pl-worker-if-condition.png)

8. Within the False section of the If Condition (this is full load), no action is required. This is because the objective of this activity is to create the WHERE clause predicate for incremental loading, and a full load does not require a WHERE clause. Thus, create a simple Set Variable activity and set the sql_where_predicate variable to an empty string.

    ![if-condition-false](.images/pl-worker-if-condition-false.png)

9. Within the True section of the If Condition, create a **Lookup** activity to the pipeline and name it **usp_get_previous_watermark_val**. This activity is responsible for returning the execution value used for incremental executions. Perform the following:

    - Set the **Connection** to the **vl_guids_metadata_control_db_connection_id** variable
    - Select **SQL Database** as the **Connection type**
    - use **@pipeline().DataFactory** for the **Workspace ID**
    - Select the **vl_guids_metadata_control_db_id** variable for the **SQL Database ID** field
    - Select the **Stored Procedure** option in the **Use query** input
    - Scroll down and select the **integration.usp_get_previous_watermark_val** stored procedure
    - Add and configure the following parameters:
        - task_id [Int16]: **@pipeline().parameters.task_id**
        - incremental_col_data_type [String]: **@json(string(pipeline().parameters.source_settings)).incremental_col_data_type**

10. Still within the If Condition True block, add a **Lookup Activity**. This activity will query the source system to return the current MAX of the watermark/incremental loading column. To configure:

    - Set Connection to **@json(string(pipeline().parameters.source_connection_settings)).oracle_connection_id**
    - Set the Connection Type to the source system (in this example, Oracle)
    - Set Use Query to **Query**
    - In the query, we create a string to perform a simple SELECT MAX(watermark_col) FROM source_table. For example:

    ```javascript
    @concat(concat(concat(concat(concat(
        'SELECT MAX(' , json(string(pipeline().parameters.source_settings)).incremental_column
        ), ') as current_watermark_val FROM '),
        json(string(pipeline().parameters.source_settings)).schema_name)
        ,'.')
        ,json(string(pipeline().parameters.source_settings)).table_name
    )
    ```

    - Set First row only to True

    ![get-current-watermark](.images/get-current-watermark-val.png)

11. Still within the True block, add a **Switch Activity**. This will be used to dynamically create the WHERE clause of the query, but also taking into account that an incremental column can be either a date field or an integer value.

    To begin, set the Expression for the Switch to:

    ```javascript
    @json(string(pipeline().parameters.source_settings)).incremental_col_data_type
    ```

    and create 2 Cases: **datetime** and **int**.

    ![switch-activities](.images/switch-activities.png)

12. In the **datetime** Case, create a Set Variable activity and set the sql_where_predicate variable to the following json. The key note here is the TO_TIMESTAMP clauses that are used to generate the appropriate timestamp-related SQL query.

    ```javascript
    @if(
        equals(json(string(pipeline().parameters.source_settings)).is_incremental, 1),
        concat(
            json(string(pipeline().parameters.source_settings)).incremental_column,
            ' >= TO_TIMESTAMP(''',
            formatDateTime(activity('usp_get_previous_watermark_val').output.firstRow.previous_watermark_val, 'yyyy-MM-dd HH:mm:ss.fff'),
            ''', ''YYYY-MM-DD HH24:MI:SS.FF'') and ',
            json(string(pipeline().parameters.source_settings)).incremental_column,
            ' < TO_TIMESTAMP(''',
            formatDateTime(activity('Get current watermark from source').output.firstRow.current_watermark_val, 'yyyy-MM-dd HH:mm:ss.fff'),
            ''', ''YYYY-MM-DD HH24:MI:SS.FF'')'
        ),
        null
    )
    ```

13. In the **int** Case, similarly set the **sql_where_predicate** variable but now no longer with the TO_TIMESTAMP fields as we no longer need the datetime related queries:

    ```javascript
    @if(
        equals(json(string(pipeline().parameters.source_settings)).is_incremental, 1),
        concat(
            json(string(pipeline().parameters.source_settings)).incremental_column,
            ' > ',
            activity('usp_get_previous_watermark_val').output.firstRow.previous_watermark_val,
            ' and ',
            json(string(pipeline().parameters.source_settings)).incremental_column,
            ' <= ',
            activity('Get current watermark from source').output.firstRow.current_watermark_val
        ),
        null
    )
    ```

    The following image shows the entire chain of activities occuring in the **True** block in the If Activity:

    ![chain-in-true-block](.images/chain-in-true-block.png)

14. Navigate out of the If condition, and now set the **sql_query** variable by combining the sql_predicate_date variable with a `SELECT * FROM` clause. Notice in the example below that the code first checks to see if the **limit_rows_for_debugging parameter** is set to True, and if it is it only returns the top 1000 records. Otherwise it uses string concatenation to combine the `SELECT * FROM` with the WHERE clause defined in the activity above. The table name to query data from is defined in the **source_settings** parameter.

    ```javascript
    @concat(
        if(
            pipeline().parameters.limit_rows_for_debugging,
            'SELECT TOP 1000 *',
            'SELECT *'
        )
        ' FROM ',
        json(string(pipeline().parameters.source_settings)).schema_name ,'.', json(string(pipeline().parameters.source_settings)).table_name,
        ' WHERE 1 = 1 ',
        if(
            equals(json(string(pipeline().parameters.source_settings)).is_incremental, 1),
            concat(' AND ', variables('sql_date_predicate')),
            ''
        )
    )
    ```

15. **Note: the above steps 7-14 are only required if your data source requires a SQL string to query the source data. If your source does not require this, you may skip or alter these steps to suit that data source.**

16. Add a **Copy Data** activity to the pipeline. This will be configured dynamically via parameters. In the Source settings, configure the following:

    - The **Connection** field will come from the **meta.connections table**. For this example, the meta.connections table was configured with `{"oracle_connection_id":*****5311}`. To use this connection in the pipeline, use the following json code for the Connection field

    ```javascript
    @json(string(pipeline().parameters.source_connection_settings)).oracle_connection_id
    ```

    ![oracle-meta-connections-tbl](.images/connections-oracle-tbl.png)

    - **Connection Type** is set to the appropriate connection in the dropdown. For this example, it used **Oracle** but this will be specific to each data source.
    - Select **Query** in the Use query input
    - Use the **sql_query** variable set in Step 9 as the Query field in the Copy Data activity

    ![copy-data-source-oracle](.images/copy-data-source-oracle.png)

17. For the Copy Data activity **Destination** configure the following (this will be our Bronze Lakehouse):
    - Connection is set to **vl_guids_lakehouse_connection_idouse_connection_id** in the Variable Library
    - Connection type is **Lakehouse**
    - Workspace ID is set to the **vl_guids_bronze_workspace_id** Library variable
    - Lakehouse ID is set to the **vl_guids_bronze_lakehouse_id** Library variable
    - the Root Folder is set to **Files**
    - File Path comes from the target_settings parameter. As an example, the first portion before the slash in the image is:

    ```javascript
    @concat(
        'incoming/',
        json(string(pipeline().parameters.target_settings)).target_file_path,
        '/',
        formatDateTime(pipeline().TriggerTime, 'yyyy-MM-dd'),
        '/lineage_id=',
        pipeline().parameters.lineage_id

    )
    ```

    and the second portion is

    ```javascript
    @concat(json(string(pipeline().parameters.target_settings)).target_file_name,'.parquet')
    ```

    - File format is set to **Parquet**

    ![copy-data-destination](.images/copy-data-destination.png)

18. Create a Stored Procedure activity and connect it to the Metadata control database (Step 9). This will execute after the Copy Data activity completes successfully to update the watermark value stored in the **logging.watermark** table. Select the **logging.usp_update_watermark_val** stored procedure with the following parameters:

    - task_id [String]: @pipeline().parameters.task_id
    - source_table [String]: @json(string(pipeline().parameters.source_settings)).table_name
    - incremenetal_column [String]: @json(string(pipeline().parameters.source_settings)).incremental_column
    - watermark_value [String]: @activity('Get current watermark from source').output.firstRow.current_watermark_val
    - parent_run_id [String]: @pipeline().parameters.parent_run_id

    ![update_watermark_val](.images/usp-update-watermark-val.png)

19. Similarly, create another Stored Procedure activity and connect it to the Metadata control database (Step 9). This will also execute after the Copy Data activity completes successfully to update the logs via the **usp_set_log_data** stored procedure with the following parameters:

    - task_executions_id [String]: @pipeline().parameters.task_executions_id
    - log_data_string [String]: this can be set to anything the developer desires. The recommended parameter is ```@string(pipeline().parameters.source_settings)```

    ![usp-set-log-data](.images/usp-set-log-data.png)

    The final portion of the pipeline will look as follows:

    ![logging-activities](.images/pl-worker-logging-activities.png)

20. Test the pipeline and ensure data is loaded as expected.
