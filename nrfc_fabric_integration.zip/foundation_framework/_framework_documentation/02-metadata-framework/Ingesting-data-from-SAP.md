# Ingesting data from SAP


## Flow of pl_extract_sap
In comparison to Oracle and SQL ingestion, SAP's server does not store date-type columns as a datetime data type. Instead, dates and times are stored as INTEGER values ([SAP docs](https://learning.sap.com/courses/deepening-your-abap-programming-knowledge/calculating-with-dates-times-and-timestamps_a393cf01-946e-487b-a690-0aab8fc49a39)). This means that the pipeline currently supports only the **int** incremental_date_type_col parameter.

SAP Documentation is quite extensive, and parameters such as the Primary Keys, or incremental loading columns, can be found in their documentation ([ADRC Table docs](https://leanx.eu/en/sap/table/adrc.html)).

![sap-pipeline-img](.images/pl-extract-sap.png)

The execution sequence is as follows:

**Step 1: check to see if an incremental load is required or not**
Uses an If activity to check if the is_incremental parameter is set to 1 or 0. If 0, a full load is performed and the pipeline essentially skips to the "Set sap_query" step. If set to 1, an incremental load is required which creates an alternate execution path.

The incremental loading path is as follows:

![pl-sap-incremental-path](.images/pl-sap-incremental-path.png)

**Step 2: usp_get_previous_watermark_val**

Lookup activity executes the integration.usp_get_previous_watermark_val stored procedure to return the datetime or integer value of the last successful execution from the logging.execution_watermark table, to be used for watermarking.

**Step 3: Get current watermark from source**

Uses a Lookup activity to query the source system and return the MAX value of the watermark column. For example, ```SELECT MAX(CONCAT(CHDAT,CHTIM)) FROM SAPCRM.BUT000```.

Note, SAP tables commonly use a composite watermark column of CHDAT (Change Date) and CHTIM (Change Time).

**Step 4: Set where predicate**

Sets the sql_where_predicate variable for workers that require an incremental load (is_incremental flag set to 1). 

The Set Variable activity takes the outputs of the previous two Lookup activities to return a string with the appropriate incremental WHERE clause. One specific edge-case for SAP is that the concatenation of CHDAT and CHTIM columns are cast as BIGINT because a CONCAT operation returns a string instead of a numeric value. An example output for the BUT000 table is as follows: ```CAST(CONCAT(CHDAT,CHTIM) AS BIGINT) > 20251020000115 and CAST(CONCAT(CHDAT,CHTIM) AS BIGINT) <= 20251024000214```

**Step 5:  Set sql_query**

Concatenate the previously generated strings to build the fulsome SQL query, in the form of *"SELECT [output of step 3] WHERE [output of step 4]"*. For example: ```SELECT *  FROM SAPCRM.BUT000 WHERE 1=1  and CAST(CONCAT(CHDAT,CHTIM) AS BIGINT) > 20251024000214 and CAST(CONCAT(CHDAT,CHTIM) AS BIGINT) <= 20251024000214```

**Step 6: Copy Data from SAP to Bronze Lakehouse**

The SQL query that was built in Steps 1-45 are executed against the SAP server to return a table. That table is written to the Bronze Lakehouse Files as a Parquet file. Details such as the specific SAP source database/connection and target folder are configured via metadata.

**Step 7: Update Logs**

Upon successful execution of the Copy Data activity, the execution must be logged in two separate places:
- the **logging.execution_watermark** table is updated with the latest watermark in the **usp_update_watermark_val** stored procedure step. This will inform subsequent loads with a new watermark field. This only occurs if is_incremental is True, otherwise it is not required for a full load.
- the **logging.task_execution** table is updated with the **usp_set_log_data** stored procedure, which updates the execution log record in the table with the source_settings that were used in the extraction.

## The Metadata
This example illustrates the configuration of metadata for SAP HANA tables **BUT000** and **ADRC**. BUT000 has approx 1.7M records and supports incremental load as it contains the CHDAT and CHTIM columns. ADRC (6.1M records) by comparison is a static dimension table that does *not* have any watermarking columns - thus a full load is required. The example metadata below will demonstrate how to support both of these load types with SAP.

### meta.connections table
First, retrieve the Fabric Connection ID for the desired SAP server:

![sap-connection-id](.images/sap-connection-id.png)

Then, execute the follow SQL query to insert a record into the meta.connections table:

    INSERT INTO meta.connections(
        , connection_name,
        , uses_fabric_connection
        , connection_settings
    )
    VALUES (
        'SAP HANA Dev Server' 
        ,False
        ,'{"sap_connection_id":"**************12d"}'
    )

The following screenshot shows an example. Note that the connection we created has a connection_id of 4.

![sap-meta-connection](.images/sap-meta-connection.png)

### meta.task table

For each worker pipeline the following metadata parameters must be defined in SQL: task_name, object_name, stage, source_connection_id, source_settings, target_settings, option_settings, template_settings, enabled, file_hash, scheduling_settings, scheduling_settings, enable_retries, and max_retry_attempts. (Note, option_settings, file_hash, scheduling_settings, scheduling_settings, enable_retries, and max_retry_attempts were not configured in this example).

There are 3 stages of data ingestion: Extract, Load to bronze, and Load to silver. 

#### Stage 1: Extract

The following example illustrates the parameters one would use to ingest data from the SAP BUT000 and ADRC tables.

Some key instructions:
- **task_name** - is a description that has no functional purpose
- **object_name** - name of the object to ingest. This field must be kept consistent for the next two stages 
- **stage** - set to 'Extract' for this stage
- **source_connection_id** - in this example the ID is **4** as shown in the meta.connections table above
- **source_settings** - the following settings are required for SAP ingestion: schema_name, table_name, is_incremental, and incremental_column, incremental_col_data_type. 
    - In this example, notice that for the BUT000 table is_incremental is set to 1 and thus the incremental_column and incremental_col_data_type fields are required
    - For the ADRC table, a full load is configured - meaning is_incremental is set to 0 and incremental_column and incremental_col_data_type are not required
- **target_settings** - the following settings are required for the target: target_file_path, target_file_name. Note, it is key that the *target_file_path is unique.* 
- **template_settings** - for both of these ingestion pipelines, we will be using the pl_extract_sap Data Pipeline
- **enabled** - default to 1, which means the pipeline is enabled. 0 means not enabled


| **Attribute** | **BUT000** | **ADRC** |
| --- | --- | --- |
| task_name | Extract - SAP BUT000 | Extract - SAP ADRC |
| object_name | but000 | adrc |
| stage | Extract | Extract |
| source_connection_id | 4 | 4 |
| source_settings | {"schema_name":"SAPCRM","table_name":"BUT000", "is_incremental":1, "incremental_column":"CONCAT(CHDAT,CHTIM)", "incremental_col_data_type":"int"} | {"schema_name":"SAPCRM","table_name":"ADRC","is_incremental":0} |
| target_settings | {"target_file_path":"sap/crm/but000","target_file_name":"but000"} | {"target_file_path":"sap/crm/adrc","target_file_name":"adrc"} |
| template_settings | {"template_type": "DataPipeline", "template_name": "pl_extract_sap"} | {"template_type": "DataPipeline", "template_name": "pl_extract_sap"} |
| enabled | 1 | 1 |


#### Stage 2: Load to bronze
- **task_name** - is a description that has no functional purpose
- **object_name** - name of the object to ingest. This field must be kept consistent for all three stages.
- **stage** - set to **'Load to bronze'** for this stage
- **source_connection_id** - for a Fabric notebook execution no connection ID is needed as the artifact already exists in Fabric
- **source_settings** - the following settings are required for Load to bronze: target_file_path, target_file_name, and target_file_type. Note, the **target_file_path** and **target_file_name** should exactly match the parameters filled above in the Extract stage
- **target_settings** - the following settings are required for Load to bronze: schema_name, table_name, and load_strategy. These parameters define where to load the bronze data and will serve as the source for the next stage 
    - For this example, BUT000 is an incremental load. Thus, load_strategy is set to **append**. In comparison, the ADRC table is a full load with 6.1M records. Therefore the load_strategy is set to **overwrite**, as appending 6.1M records each load will eventually lead to degradation in performance.
- **template_settings** - for a Notebook execution, template settings are not required
- **enabled** - default to 1

| **Attribute** | **BUT000** | **ADRC** |
| --- | --- | --- |
| task_name | Load to bronze - SAP BUT000 | Load to bronze - SAP ADRC |
| object_name | but000 | adrc |
| stage | Load to bronze | Load to bronze |
| source_connection_id | NULL | NULL |
| source_settings | {"target_file_path": "sap/crm/but000/", "target_file_name": "but000", "target_file_type": "parquet"} | {"target_file_path": "sap/crm/adrc", "target_file_name": "adrc", "target_file_type": "parquet"} |
| target_settings | {"schema_name": "sap", "table_name": "but000", "load_strategy":"append"} | {"schema_name": "sap", "table_name": "adrc", "load_strategy":"overwrite"} |
| template_settings | NULL | NULL |
| enabled | 1 | 1 |



#### Stage 3: Load to silver
- **task_name** - is a description that has no functional purpose
- **object_name** - name of the object to ingest. This field must be kept consistent for all three stages.
- **stage** - set to **'Load to silver'** for this stage
- **source_connection_id** - for a Fabric notebook execution no connection ID is needed as the artifact already exists in Fabric
- **source_settings** - the following settings are required for Load to silver: schema_name and table_name, which should exactly match the target_settings from the Load to Bronze stage
- **target_settings** - the following settings are required for Load to silver: schema_name, table_name, load_strategy, and primary_keys. schema_name and table_name are used to define the destination of table in the Silver Lakehouse. load_strategy can be set to 'merge', 'overwrite' or 'append'. primary keys must be a comma separated string nested in a python list (ie. ["key1","key2","key3"])
    - For BUT000, a simple incremental load of new records can be ingested sufficiently with an **append** load strategy
    - For ADRC, this is a *full load*. If the developer wishes to truncate and re-load each day, then set the load_strategy to **overwrite**. For a MERGE operation to upsert records into the target table, set the load_strategy to **merge**.
- **template_settings** - for a Notebook execution, template settings are not required
- **enabled** - default to 1

| **Attribute** | **BUT000** | **ADRC** |
| --- | --- | --- |
| task_name | Load to silver - SAP BUT000 | Load to silver - SAP ADRC |
| object_name | but000 | adrc |
| stage | Load to silver | Load to silver |
| source_connection_id | NULL | NULL |
| source_settings | {"schema_name": "sap", "table_name": "but000"} | {"schema_name": "sap", "table_name": "adrc"} |
| target_settings | {"schema_name": "silver", "table_name": "sap_but000", "load_strategy": "append", "primary_keys": ["CLIENT","PARTNER"]} | {"schema_name": "silver", "table_name": "sap_adrc", "load_strategy": "merge", "primary_keys": ["CLIENT","ADDRNUMBER","NATION","DATE_FROM"]} |
| template_settings | NULL | NULL |
| enabled | 1 | 1 |