# Ingesting data from Oracle
Note: as of Oct 23, 2025, there exists a known Fabric issue when ingesting data from Oracle [link](https://support.fabric.microsoft.com/known-issues/?product=Data%2520Factory&active=true&fixed=false&sort=modified&issueId=757). Microsoft Fabric's Lakehouse cannot handle Decimal and Float values from Oracle, and thus all values of these data types must be CAST-ed to a data type that can be consumed by Fabric.

## Flow of pl_extract_oracle
![oracle-pl-flow](.images/pl-oracle.png)

The execution sequence is as follows:

**Step 1: check to see if an incremental load is required or not**
Uses an If activity to check if the is_incremental parameter is set to 1 or 0. If 0, a full load is performed and the pipeline essentially skips to the "Cast NUMBER data types" step. If set to 1, an incremental load is required which creates an alternate execution path.

The incremental loading path is as follows:
![oracle-pl-incremental](.images/pl-oracle-incremental.png)



**Step 2: usp_get_previous_watermark_val**

Lookup activity executes the integration.usp_get_previous_watermark_val stored procedure to return the datetime or integer value of the last successful execution from the logging.execution_watermark table, to be used for watermarking.


**Step 3: Get current watermark from source**

Uses a Lookup activity to query the source system and return the MAX value of the watermark column. For example, ```SELECT MAX(CHANGEDATE) FROM MAXIMO.WOSTATUS```.

**Step 4: Create the sql_where_predicate based on int or datetime value**

Sets the sql_where_predicate variable for workers that require an incremental load (is_incremental flag set to 1). 

Based on the **incremental_col_data_type** parameter, the behaviour of this Switch activity changes. 
If the parameter is set to **datetime** the following is an example output: ```CHANGEDATE >= TO_TIMESTAMP('2025-10-23 13:10:54.370', 'YYYY-MM-DD HH24:MI:SS') and CHANGEDATE < TO_TIMESTAMP('2025-10-23 13:30:54.370', 'YYYY-MM-DD HH24:MI:SS')```

If the parameter is set to **int* an example output would be ```WOSTATUSID >= 0 AND WOSTATUSID<=98474848```

**Step 5: Cast NUMBER data types**

Executes a Lookup against the Oracle ALL_TAB_COLUMNS table to identify all columns that have a FLOAT or NUMBER data type. For these columns, they will be nested in a "CAST( ... AS DECIMAL(38,18))" string. This activity returns a SQL SELECT string with the appropriate casting. (ex. ```"QUERY_STRING": "CHANGEBY, CHANGEDATE, FINCNTRLID, GLACCOUNT, MEMO, ORGID, PARENT, ROWSTAMP, SITEID, STATUS, WONUM, CAST(WOSTATUSID AS NUMBER(38,18)) AS WOSTATUSID"```)


**Step 6:  Set sql_query**

Concatenate the previously generated strings to build the fulsome SQL query, in the form of *"SELECT [output of step 5] WHERE [output of step 4]"*. For example: ```SELECT CHANGEBY, CHANGEDATE, FINCNTRLID, GLACCOUNT, MEMO, ORGID, PARENT, ROWSTAMP, SITEID, STATUS, WONUM, CAST(WOSTATUSID AS NUMBER(38,18)) AS WOSTATUSID FROM MAXIMO.WOSTATUS WHERE 1=1  and CHANGEDATE >= TO_TIMESTAMP('1900-01-01 00:00:00.000', 'YYYY-MM-DD HH24:MI:SS.FF') and CHANGEDATE < TO_TIMESTAMP('2025-10-29 13:54:36.000', 'YYYY-MM-DD HH24:MI:SS.FF')```

**Step 7: Copy Oracle data**

The SQL query that was built in Steps 1-6 are executed against the Oracle server to return a table. That table is written to the Bronze Lakehouse Files as a Parquet file. Details such as the specific Oracle source database/connection and target folder are configured via metadata.

**Step 8: Update Logs**

Upon successful execution of the Copy Data activity, the execution must be logged in two separate places:
- the **logging.execution_watermark** table is updated with the latest watermark in the **usp_update_watermark_val** stored procedure step. This will inform subsequent loads with a new watermark field. This only occurs if is_incremental is True, otherwise it is not required for a full load.
- the **logging.task_execution** table is updated with the **usp_set_log_data** stored procedure, which updates the execution log record in the table with the source_settings that were used in the extraction.


## The Metadata
This example illustrates the configuration of metadata for Oracle Maximo tables Wostatus and Workorder, providing insight into best practices and common challenges encountered when creating multiple pipelines.

### meta.connections table
First, retrieve the Fabric Connection ID for the desired Oracle server:

![connection-id](.images/connection-id.png)

Then, execute the follow SQL query to insert a record into the meta.connections table:

    INSERT INTO meta.connections(
        , connection_name,
        , uses_fabric_connection
        , connection_settings
    )
    VALUES (
        'Oracle Maximo Test Server' 
        ,False
        ,'{"oracle_connection_id":"*************5311"}'
    )

The following screenshot shows an example. Note that the connection we created has a connection_id of 3.
![oracle-meta-connections-tbl](.images/connections-oracle-tbl.png)


### meta.task table

For each worker pipeline the following metadata parameters must be defined in SQL: task_name, object_name, stage, source_connection_id, source_settings, target_settings, option_settings, template_settings, enabled, file_hash, scheduling_settings, scheduling_settings, enable_retries, and max_retry_attempts. (Note, option_settings, file_hash, scheduling_settings, scheduling_settings, enable_retries, and max_retry_attempts were not configured in this example).

There are 3 stages of data ingestion: Extract, Load to bronze, and Load to silver. 

#### Stage 1: Extract

The following example illustrates the parameters one would use to ingest data from the Oracle Maximo WOSTATUS and WORKORDER tables.

Some key instructions:
- **task_name** - is a description that has no functional purpose
- **object_name** - name of the object to ingest. This field must be kept consistent for the next two stages 
- **stage** - set to 'Extract' for this stage
- **source_connection_id** - in this example the ID is **3** as shown in the meta.connections table above
- **source_settings** - the following settings are required for Oracle ingestion: schema_name, table_name, is_incremental, and incremental_column, incremental_col_data_type
- **target_settings** - the following settings are required for the target: target_file_path, target_file_name. Note, it is key that the *target_file_path is unique.* This is because in the next stage, it will use the target_file_path as its source and if both the WOSTATUS and WORKORDER extracts are in the same location, the next stage will try to consolidate the files and fail.
- **template_settings** - for both of these ingestion pipelines, we will be using the pl_extract_oracle Data Pipeline
- **enabled** - default to 1, which means the pipeline is enabled. 0 means not enabled.

| Attribute | Oracle Maximo WOSTATUS | Oracle Maximo WORKORDER |
| --- | --- | --- |
| **task_name** | Extract - Oracle Maximo WOSTATUS | Extract - Oracle Maximo WORKORDER |
| **object_name** | wostatus | workorder |
| **stage** | Extract | Extract |
| **source_connection_id** | 3 | 3 |
| **source_settings** | {"schema_name":"MAXIMO","table_name":"WOSTATUS", "is_incremental":1, "incremental_column":"CHANGEDATE", "incremental_col_data_type":"datetime"} | {"schema_name":"MAXIMO","table_name":"WORKORDER", "is_incremental":1, "incremental_column":"CHANGEDATE", "incremental_col_data_type":"datetime"} |
| **target_settings** | {"target_file_path":"oracle/maximo/wostatus","target_file_name":"wostatus"} | {"target_file_path":"oracle/maximo/workorder","target_file_name":"workorder"} |
| **template_settings** | {"template_type": "DataPipeline", "template_name": "pl_extract_oracle"} | {"template_type": "DataPipeline", "template_name": "pl_extract_oracle"} |
| **enabled** | 1 | 1 |



#### Stage 2: Load to bronze
- **task_name** - is a description that has no functional purpose
- **object_name** - name of the object to ingest. This field must be kept consistent for all three stages.
- **stage** - set to **'Load to bronze'** for this stage
- **source_connection_id** - for a Fabric notebook execution no connection ID is needed as the artifact already exists in Fabric
- **source_settings** - the following settings are required for Load to bronze: target_file_path, target_file_name, and target_file_type. Note, the **target_file_path** and **target_file_name** should exactly match the parameters filled above in the Extract stage
- **target_settings** - the following settings are required for Load to bronze: schema_name, table_name, and load_strategy. These parameters define where to load the bronze data and will serve as the source for the next stage 
- **template_settings** - for a Notebook execution, template settings are not required
- **enabled** - default to 1

| **Attribute** | **Load to bronze - maximo wostatus** | **Load to bronze - maximo workorder** |
| --- | --- | --- |
| **task_name** | Load to bronze - maximo wostatus | Load to bronze - maximo workorder |
| **object_name** | wostatus | workorder |
| **stage** | Load to bronze | Load to bronze |
| **source_connection_id** | NULL | NULL |
| **source_settings** | {"target_file_path": "oracle/maximo/wostatus/", "target_file_name": "wostatus", "target_file_type": "parquet"} | {"target_file_path": "oracle/maximo/workorder", "target_file_name": "workorder", "target_file_type": "parquet"} |
| **target_settings** | {"schema_name": "oracle", "table_name": "maximo_wostatus", "load_strategy":"append"} | {"schema_name": "oracle", "table_name": "maximo_workorder", "load_strategy":"append"} |
| **template_settings** | NULL | NULL |
| **enabled** | 1 | 1 |


#### Stage 3: Load to silver
- **task_name** - is a description that has no functional purpose
- **object_name** - name of the object to ingest. This field must be kept consistent for all three stages.
- **stage** - set to **'Load to silver'** for this stage
- **source_connection_id** - for a Fabric notebook execution no connection ID is needed as the artifact already exists in Fabric
- **source_settings** - the following settings are required for Load to silver: schema_name and table_name, which should exactly match the target_settings from the Load to Bronze stage
- **target_settings** - the following settings are required for Load to silver: schema_name, table_name, load_strategy, and primary_keys. schema_name and table_name are used to define the destination of table in the Silver Lakehouse. load_strategy can be set to 'merge', 'overwrite' or 'append'. primary keys must be a comma separated string nested in a python list (ie. ["key1","key2","key3"])
- **option_settings** - optional setting to enforce_schema when writing data into the silver lakehouse
- **template_settings** - for a Notebook execution, template settings are not required
- **enabled** - default to 1


| **Attribute** | **Load to silver - maximo wostatus** | **Load to silver - maximo workorder** |
| --- | --- | --- |
| **task_name** | Load to silver - maximo wostatus | Load to silver - maximo workorder |
| **object_name** | wostatus | workorder |
| **stage** | Load to silver | Load to silver |
| **source_connection_id** | NULL | NULL |
| **source_settings** | {"schema_name": "oracle", "table_name": "maximo_wostatus"} | {"schema_name": "oracle", "table_name": "maximo_workorder"} |
| **target_settings** | {"schema_name": "oracle", "table_name": "maximo_wostatus", "load_strategy": "overwrite", "primary_keys": ["WOSTATUSID"]} | {"schema_name": "oracle", "table_name": "maximo_workorder", "load_strategy": "overwrite", "primary_keys": ["WORKORDERID"]} |
| **option_settings** | {"enforce_schema":{"WOSTATUSID":"bigint", "CHANGEDATE":"timestamp"}} | NULL |
| **template_settings** | NULL | NULL |
| **enabled** | 1 | 1 | 

Note, the schema used in the option_settings/enforce_schema parameter come from the ALL_TAB_COLUMNS table in the Oracle SQL Server. A helper query that can be used to generate the python dictionary is as follows:
```SQL
SELECT RTRIM(XMLAGG(XMLELEMENT(E,
CASE
	WHEN DATA_TYPE IN ('NUMBER','FLOAT') AND DATA_PRECISION IS NULL
		THEN '' || COLUMN_NAME || ': bigint'
	WHEN DATA_TYPE IN ('NUMBER','FLOAT') AND DATA_PRECISION IS NOT NULL
		THEN '' || COLUMN_NAME || ': decimal('|| DATA_LENGTH || ',' || DATA_PRECISION || ')' 
	 END,', ').EXTRACT('//text()') ORDER BY COLUMN_NAME).GetClobVal(),', ') AS query_string
FROM ALL_TAB_COLUMNS
 WHERE TABLE_NAME = 'WORKORDER'
 AND OWNER = 'MAXIMO'
```

However please note that the raw output from this query is NOT going to work in the code, as it is missing double quotes necessary for a Python list (this is because Oracle SQL does not have a double quote character). Thus, some manual string-manipulation is required to add the double quotes and clean up the string before configuring it in the metadata. The output will be in the form: `, {ACTINTLABCOST: decimal(22,10)}, ...` and must be cleaned up to `{"ACTINTLABCOST": "decimal(22,10)"}, ...`