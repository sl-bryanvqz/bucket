# Configuring Scheduling Metadata

The pipeline schedules are defined and driven by within the **meta.tasks** table, specifically using the **scheduling_settings** field.

This field is a user-defined json-formatted string that defines the following fields:
- **schedule_type** - Defines the type of schedule to configure. The available options include: time_of_day (which allows for intraday execution), monthly, and yearly.
- **skip_if_running** - Boolean flag (true/false), that determines whether or not to trigger a run if an occurance of that pipeline is already running. 

![scheduling-example](.images/scheduling-example.png)


***if schedule_type = 'time_of_day':***
- **scheduled_times** - This field is only used for the time_of_day schedule type. The proper format is a python list of times in **UTC** (not MST). 
    - ex: `{"schedule_type":"time_of_day","scheduled_times": ["10:00","12:45","15:15"], "skip_if_running":"true"}`
    would run at 10AM, 12:45PM, and 3:15PM UTC. There is no limit to how many scheduled times to configure.
- **frequency_minutes** - Defines an interval in minutes (integer) to trigger the pipeline on repeat. 
    - ex: `{"schedule_type":"time_of_day", "frequency_minutes": 75, "skip_if_running":"true"}` would run the pipeline every 75 minutes
- Note: the user may use scheduled_times **OR** frequency_minutes, not both.

***if schedule_type = 'monthly':***
- **day_of_month** - For a monthly schedule, this defines the day of the month to trigger executions.
- **time** - For a monthly schedule, this defines the time of day to trigger executions.
    - ex: `{"schedule_type":"monthly", "day_of_month": 20, "time":"12:30", "skip_if_running":"true"}` means the pipeline runs on the 20th of every month at 12:30 UTC.

***if schedule_type = 'yearly':***
- **month** - For an yearly schedule, this defines the month of the year to trigger executions.
- **day** - For an yearly schedule, this defines the day of the month to trigger executions.   
- **time** - For an yearly schedule, this defines the time of the day to trigger executions.
    - ex: `{"schedule_type":"yearly", "month": 7, "day":16,"time":"17:15", "skip_if_running":"true"}` means the pipeline runs every year on July (7) 16 at 17:15 UTC