# Incremental Loading
Incremental loading in the framework is dynamic and parameter-driven. This means each pipeline can handle both a full load and incremental load by updating a few metadata fields.

The following parameters must be defined in the **source_settings** field in the **meta.task** table:
- **is_incremental**: This is either **1 (incremental load)** or **0 (full load)**. 
- **incremental_col**: name of the column to be used for incremental loading
- **incremental_col_data_type**: data type of the incremental load. The framework currently handles two types: **datetime** and **int**.

For example: ```{"schema_name":"MAXIMO","table_name":"WOSTATUS", "is_incremental":1, "incremental_column":"CHANGEDATE", "incremental_col_data_type":"datetime"}```

## How does it work?
Incremental loading is driven by a few metadata fields:
- the three parameters above
- the **logging.execution_watermark** table: holds all watermark data for each task
- the **[integration].[usp_get_previous_watermark_val]** stored procedure: retrieves the last executed watermark value for the task
- the **[logging].[usp_update_watermark_val]** stored procedure updates the watermark value in the logging.execution_watermark table after successful execution

The image below shows the execution_watermark table:
![execution-watermark-tbl](.images/execution-watermark-tbl.png)

When an extraction pipeline begins executing, it first checks via an If Condition to see if the is_incremental flag is set to 1 or 0. If 0, this is a full load, incremental loading activities are skipped. When set to 1, incremental loading activities commence.

![pl-worker-if-condition](.images/pl-worker-if-condition.png)


The incremental loading activities are as follows:
![alt text](.images/pl-oracle-incremental.png)

- **usp_get_watermark_val**: executes the stored procedure to retrieve the previous watermark value from the logging.execution_watermark table. For example, for task_id=4 it would return '2025-10-28T08:16:15'
- **Get current watermark val from source** queries the source table to return the current watermark. In the example above (task_id=4), it would execute the query "SELECT MAX(CHANGEDATE) FROM MAXIMO.WOSTATUS" from the oracle source, and return a new value. 
- After the two values are returned, the Switch Activity is triggered and the behaviour is dependent on the incremental_col_data_type parameter. If the parameter is set to **datetime** the following is an example output: ```CHANGEDATE >= TO_TIMESTAMP('2025-10-23 13:10:54.370', 'YYYY-MM-DD HH24:MI:SS') and CHANGEDATE < TO_TIMESTAMP('2025-10-23 13:30:54.370', 'YYYY-MM-DD HH24:MI:SS')```.  If the parameter is set to **int** an example output would be ```WOSTATUSID >= 0 AND WOSTATUSID<=98474848```

Using the WHERE clause created above, the Copy Data activity can now query the source table with an incremental load and return only data that is new when compared to the previously loaded data.

Upon succesful execution, the watermark value in the logging.execution_watermark table is updated with the new watermark recorded by the **Get current watermark val from source** activity:

![logging-activities](.images/pl-worker-logging-activities.png)

## Handling Late Arriving Records
For some tables, data can be loaded retroactively with a historical watermark. For example, a data load that occurs on Dec 15 2AM will update the watermark to that value, but what if a record is loaded into the database *after* that but it has a watermark value that precedes Dec 15 2AM? This is not a common occurrence, but it can occur for some transactional tables. To do this, the `optional_buffer` option was created.

For example, the source_settings would become: `{"schema_name":"MAXIMO","table_name":"WOSTATUS", "is_incremental":1, "incremental_column":"CHANGEDATE", "incremental_col_data_type":"datetime", "optional_buffer":10}`

The value determines the **number of days** to retroactively search for data. For example, if the data was last loaded on Dec 15 2AM, 10 days of buffer will be granted, meaning a value of Dec **5** 2AM will be used for the incremental load again. This will pull in 10 extra days of history, which will be de-duplicated downstream, to handle any late arriving records.



