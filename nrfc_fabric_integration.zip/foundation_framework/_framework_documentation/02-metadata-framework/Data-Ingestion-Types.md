# Data Ingestion Types

## Introduction
The Foundation Framework supports several different combinations of ingestion/extraction types, providing immense flexibility for the developers to meet various use cases.

Recall that each data load is comprised of three stages, each with their own load types driven by configurations in the meta.task table:

1. **Extract** data from source
2. **Load to bronze** lakehouse
3. **Load to silver** lakehouse

## Extract
In the Extract stage, the pl_extract_{data_source} allows for two extraction types: 
- Incremental Load: extract only new or changed data from the source
- Full Load: extract the entire table from the source

The extraction type is determined by the **is_incremental** flag in the **source_settings** column in*meta.task.

![load-example](.images/extract-load-ex.png)

Further details on incremental loading from source can be found in the [Incremental Loading](Incremental-Loading.md) page of this wiki.


## Load to bronze
Based on the load type used for the source data, the developer may want to adjust the Bronze loading strategy accordingly. This is configured by the **load_strategy** field in the **target_settings** column in meta.task. There are two options for bronze loading:
- **overwrite**: this means the entire table in the bronze lakehouse is truncated, and re-loaded with the data extracted from the source. 
    - Note, if the Extract is set to Full load it is always recommended that the bronze load is in-turn set to overwrite, so data is not endlessly duplicated in the bronze layer leading to increased storage costs. 
- **append**: this means the data extracted from the source is added to the end of the bronze lakehouse target table, without altering/deleting the existing data. 
    - This method is recommended when using the incremental extract pattern. However, if SCD is required in the Silver lakehouse, it is not recommended to use the append mode in Bronze.

![bronze-load-example](.images/bronze-load-ex.png)


## Load to Silver
The final stage of silver load is configured again by the **load_strategy** field in the **target_settings** column in meta.task. 

For some data engineering background, the silver load introduces the concept of **Slowly Changing Dimensions (SCD)**. This is a fundamental of data warehousing that allows for the tracking of changing data over time. For further reading: https://en.wikipedia.org/wiki/Slowly_changing_dimension.

There are six options for silver loading:
![silver-load-example](.images/silver-load-ex.png)

- **overwrite** - entire table in silver is truncated and re-loaded with data from bronze
- **append** - data from bronze is added to the end of the silver lakehouse target table, without altering/deleting the existing data
- **merge** - performs an UPSERT operation, which combines an INSERT with an UPDATE. This means new records are inserted into the target table if it doesnt already exist. But for an existing row that is updated (based on primary key), it updates the data in-place. The image below shows how an upsert operates.
![silver-load-example](.images/merge-load-example.png)

- **SCD1** - SCD Type 1 is a concept that overwrites updated data in-place without preserving history. The example below shows how this works. SCD Type 1 enables soft-deletes from the source data without actually removing the record from the target, and performs updates in-place.
    - Note, this silver load type should ONLY be used in combination with a Full load from source and an overwrite load in bronze. Otherwise, it will accidentally soft-delete all records. 

![SCD1-example](.images/SCD1-example.png)

- **SCD2-FULL** - SCD Type 2 is a data warehousing concept that creates a new record for an update in the source, and preserving the original record. The validity is then governed by audit columns (Effective Start Date, Effective End Date and Current Flag). This allows for a fulsome preservation if historical data changes. The image below shows an SCD Type 2.
    - Note, this load type should only be used when the Extract stage/Load to Bronze stage are set to Full load and overwrite. This is because if an incremental load is used as the source, it will "delete" all records like it does for Record ID 2 in the screenshot below. 
![SCD2-example](.images/SCD2-FULL-example.png)


- **SCD2-INCREMENTAL** - This load type performs an SCD Type 2 query, but now allows for incremental loads from the source (use this load type when Extract is set to incremental and Load to Bronze is set to overwrite). This load type is only used when source data is NOT expected to be deleted but it IS expected to recieve updates. This is expecially helpful for large transactional tables where performing full extracts from the source daily is not feasible. 

![SCD2-Incremental-example](.images/SCD2-INCREMENTAL-example.png)


# Optional Settings - Enforce Schema in Silver
The **Load to silver** stage has one `option_setting` that can be optionally configured to enforce a schema in the Silver Lakehouse. This is especially helpful for Oracle data.
For example, consider the table below. When loading the data, what if the developer wishes to cast Col1 to an INT and Col2 to a DATE, but leave Col3 and Col4 as-is? To accomplish this, use the `enforce_schema` setting and configure it as follows: `"enforce_schema":"{"Col1":"int","Col2":"date"}"`

![option-settings-example](.images/option-settings-example.png)

This will produce a SQL SELECT string as follows: ```SELECT CAST(Col1 as INT) as Col1, CAST(Col2 as DATE) as Col2, Col3, Col4```. Notice that Col3 and Col4 are untouched.
This field can be left as NULL if no schema requirements exist.

