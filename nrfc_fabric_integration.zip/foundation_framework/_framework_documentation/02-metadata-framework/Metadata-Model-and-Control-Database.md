# Metadata Model & Control Database

This section provides an implementation-focused view of the Metadata Control Database, which is the operational and logical backbone of the Foundation Metadata Framework. It explains what the database does, how its objects work together, how developers interact with it locally (VS Code, SSMS, Docker SQL Server), and how it integrates with the metadata-driven orchestration pipelines.

## Purpose of the Metadata Control Database

The Metadata Control Database (referred to as `metadata_control_db`) is the authoritative system that drives all automation in the Foundation Framework. It acts as the *execution brain* which:

- Stores metadata defining all extract/transform tasks
- Stores connection metadata for source systems
- Manages incremental `watermarks` for recovery and idempotent execution
- Tracks scheduling configuration and validations
- Logs all task executions for lineage, troubleshooting, and SLA monitoring
- Feeds the runtime pipelines (`pl_scheduler`, `pl_orchestrator`, `pl_worker`) with structured metadata

No pipeline hard-codes logic. All behavior is controlled via metadata stored in this database.

## How the Control DB Works With the Framework

![control-db-framework-flowchart](./.images/control-db-framework-flowchart.png)

### Core operational responsibilities

#### **1. Identify tasks to run**

- `usp_get_tasks_due_for_execution` evaluates schedules, retries, last execution timestamps, and running tasks.

#### **2. Provide metadata needed to execute tasks**

- Source connection settings
- Source extraction settings
- Target settings (Bronze/Silver)
- Template configuration

#### **3. Maintain execution history + lineage**

- Every execution run logs:

  - Start/end time
  - Failure reasons
  - SQL queries used
  - File paths written
  - Monitoring URLs

#### **4. Track incremental load positions**

- `execution_watermark` table stores last processed values
- Used by extract templates to construct dynamic
  `WHERE` clauses

## Local Development Setup (VS Code, SSMS, Docker)

Developers should be able to iterate on stored procedures, tables, and logic without deploying to Fabric.

The recommended workflow:

### Local SQL Server using Docker Compose

A `docker-compose.yml` can spin up a local SQL Server instance:

```yaml
db:
  image: mcr.microsoft.com/mssql/server:2022-latest
  environment:
    SA_PASSWORD: "Your_password123"
    ACCEPT_EULA: "Y"
  ports:
    - "1433:1433"
  volumes:
    - ./sqldata:/var/opt/mssql/data
```

#### Benefits

- Test stored procedures locally
- Validate schema changes
- Avoid dependency on Fabric capacity or workspace deployments
- Run SQL projects directly from VS Code with `.sqlproj`

### Working With the SQL Project (metadata_control_db.sqlproj)

The control DB is a full SSDT-style SQL project that includes:

- Schema definitions (`meta`, `integration`, `logging`)
- All tables, views, functions, stored procedures
- Pre-/post-deployment scripts

### VS Code Workflow

1. Open the project folder containing `.sqlproj`
2. Use the **SQL Database Projects** extension found [here](https://marketplace.visualstudio.com/items?itemName=ms-mssql.sql-database-projects-vscode).
3. Build generative dacpac locally.
4. Deploy dacpac to local container SQL Server

For deployments, you can use the **SQL Server** connections manager within VS Code. You can also connecto to Fabric SQL Databases. Just be cautious when deploying and ensure you've selected the right server.

## Database Structure and Object Deep Dive

The control DB is organized into **3 schemas**, each serving a specific purpose.

### `meta` Schema

The *heart* of the metadata framework, the Meta Schema contains the core tables that define what gets processed, how it gets processed, and when it gets processed. This schema holds the authoritative configuration that drives all automation across the entire ingestion pipeline.

#### **meta.task**

- One row = one step in the ingestion pipeline.
- Stages: `Extract`, `Load to bronze`, `Load to silver`.
- Stores JSON for:

  - `source_settings`
  - `target_settings`
  - `template_settings`
  - `scheduling_settings`
  - retry settings
  - file hash (for detecting config drift)

#### How tasks get populated

All configuration in the `meta.task` table is managed through a YAML file. After the configuration file is uploaded to the `nb_load_metadata_config` notebook and the notebook is executed, it automatically processes and loads the configuration into the `meta.task` table within `metadata_control_db`. It also ensures that no duplicate entries are inserted into the configuration table.

Currently, the `config.yml` file is stored in Git repositories to enable version control and because Fabric workspaces do not allow storing `.yml` files. The process of transferring the file from Git to the notebook is manual today. However, as the number of configuration files grows, a designated lakehouse can be used to store these files, and the lakehouse can then be linked directly to the notebook for automated access.

Steps:

1. Prepare the `config.yml` file.
2. Upload the file to the notebook's built-in resources.
3. ![config-yml](./.images/config-yml.png)
3. Execute the notebook.
4. After successful completion validate change in `meta.task` table.

```YAML
tables:
  - object_name: "profile_vectors"
    enabled: "true"
    file_hash: ""

    stage:
      - "Extract"
      - "Load to bronze"
      - "Load to silver"

    enable_retries: "true"
    max_retry_attempts: "3"

    template_settings:
      - extract:
          template_type: "DataPipeline"
          template_name: "pl_extract_oracle"

    option_settings:

    source_connections:
      - extract:
          source_connection_name: "Oracle Maximo PWRODTST Server"

    scheduling_settings:
      - extract:
          schedule_type: "time_of_day"
          scheduled_times: ["9:00"]
          skip_if_running: "true"

    source_settings:
      - extract:
          schema_name: "LS_OWNER"
          table_name: "PROFILE_VECTORS"
          is_incremental: 1
          task_name: "Extract - Oracle ADS PROFILE_VECTORS"
          incremental_column: "LAST_MODIFY_DT_TM"
          incremental_col_data_type: "datetime"

      - load_to_bronze:
          target_file_path: "oracle/ads/profile_vectors/"
          target_file_name: "profile_vectors"
          target_file_type: "parquet"
          task_name: "Load to bronze - ads profile_vectors"

      - load_to_silver:
          schema_name: "oracle"
          table_name: "ads_profile_vectors"
          task_name: "Load to silver - ads profile_vectors"

    target_settings:
      - extract:
          target_file_path: "oracle/ads/profile_vectors/"
          target_file_name: "profile_vectors"

      - load_to_bronze:
          schema_name: "oracle"
          table_name: "ads_profile_vectors"
          load_strategy: "append"

      - load_to_silver:
          schema_name: "ads"
          table_name: "profile_vectors"
          load_strategy: "overwrite"
          primary_keys:
            - "PROFILE_VECTOR_ID"
```

Structure:

- `tables` - Root list.
- `object_name` - Unique identifier for the object/table.
- `enabled` - Boolean flag to include or exclude this pipeline from execution.
- `file_hash` - Optional. Leave empty if not used; your loader may populate it.
- `stage` - Ordered list of stage names to run end-to-end. These stages should be the one that are recognised by the framework.  Stages recognised by the framework:
  - `Extract`
  - `Load to bronze`
  - `Load to silver`
- `enable_retries` - Boolean toggle to allow retry logic.
- `max_retry_attempts` - Integer count of retry attempts when a stage fails.
- `template_settings` - List of per-stage template declarations.
  - Each list item has a single stage key (e.g., extract)
    - `template_type` - Type of template the stage uses e.g. DataPipline/Notebook.
    - `template_name` - Concrete template identifier your orchestrator resolves. (e.g., `pl_extract_oracle`).
    - Entries for `load_to_bronze` and `load_to_silver` can be added in the future if those stages use templates as well. Currently, this is determined by the `pl_orchestrator` job, and therefore templates are not defined for the bronze and silver stages.
- `option_settings` - this is to store an optional setting that are not standard and are specific to only a certain object.
- `source_connections`-  List of per-stage connection references.
  - This is required only for stages that reference the global Fabric connection. In the RMS flow, only the extract stages need to reference the Oracle connections.
    - `source_connection_name` - Logical name of the source system connection. This is looked up in from `meta.connections` tables stored in metadata control db.
- `scheduling_settings` - List of per-stage scheduling info.
  - The stage should have following information regarding to scheduling:
    - `schedule_type` - How scheduling is defined. In your example, `time_of_day`.
    - `scheduled_times` - One or more times the job should run. Use a list for multiple times (e.g., `["09:00", "15:00"]`).
    - `skip_if_running` - Boolean to avoid starting a new run if a previous run is still active.
- `source_settings` - List of per-stage inputs and operational parameters.
  - These inputs vary from stage to stage. For example,m  extract stage has different source settings vs load to bronze and load to silver stages.
  - `extract`:
    - `schema_name` - Source schema at the connection.
    - `table_name` - Source table name.
    - `is_incremental` - Whether to run incremental extraction. Prefer boolean `true`/`false` (you can use 1/0 if your loader expects integers).
    - `incremental_column` - Column used to detect changes (e.g., last-modified timestamp).
    - `incremental_col_data_type`: Data type of the incremental column (e.g., `datetime`, `date`, `integer`).
  - `load_to_bronze`:
    - `target_file_path` - Landing path for raw/bronze files.
    - `target_file_name` - Base filename without extension.
    - `target_file_type` - File format (parquet, csv, etc.).
    - `task_name` - Label for the bronze load.
  - `load_to_silver`:
    - `schema_name` - Bronze schema where the silver table resides.
    - `table_name` - Bronze table name.
    - `task_name` - Label for the Bronze load step.
- `target_settings` - List of per-stage outputs and write strategies.
  - These inputs vary from stage to stage. E.g. extract stage has different source settings vs load to bronze and load to silver stages.
  - `extract`:
    - `target_file_path` - Path where extract stage writes its output
    - `target_file_name` - File name in the path where the extract stage writes its output files. Often mirrors bronze source path for consistency.
  - `load_to_bronze`:
    - `schema_name` -  Schema name for the target bronze table.
    - `table_name` - Where the bronze data catalog or table is registered.
    - `load_strategy` - Append/ Overwrite. Currently only these two load strategies are applicable for bronze layer.
  - `load_to_silver`:
    - `schema_name` - Target schema name.
    - `table_name` - Silver target table.
    - `load_strategy` - Overwrite/ Merge/Append/
    - `primary_keys` - List of columns that uniquely identify rows, required for deduplication/merge logic.

Using Multiple Tables

To add another pipeline, append another item to the tables list. For example:

```YAML
tables:
  - object_name: <table_1>
    ...
  - object_name: <table_2>
    ...
```

#### **meta.connections**

This table contains the connections that have been created at the Fabric tenant level.

The following fields are part of this table:

|Field Name|Purpose|Example|
|---|---|---|
|`connection_id`|Unique Identifier of the connection|`INT`, i.e. 1|
|`connection_name`|Unique name of the connection|`oracle_financials_conn`, `Tests Fabric SQL DB`|
|`uses_fabric_connection`|Placeholder for V2 differentiating Fabric connections to other types. Future enhancements.|`True`, `False`|
|`connection_settings`|Contains the connection settings in JSON format for extensibility|```{"oracle_connection_id":"487ed2ae-596d-4740-b822-560f47a4e7c1"}```|
|`file_hash`|Placeholder for V2 for future feature for change detection.|`86aa6fa93a8a71bf79b615e926c50649`|

#### **meta.task_metadata (VIEW)**

A convenience projection joining tasks + connection metadata.
Used by orchestration stored procedures.

#### **meta.task_dependencies (VIEW)**

A convenience view created to join an extract task to its children bronze and silver tasks id's. This shows lineage of each extract to bronze to silver task execution chain.

### `integration` Schema

The `integration` schema serves as the orchestration bridge between stages of the Foundation ingestion framework, enabling controlled, metadata-driven movement of data from raw extraction through Bronze and into Silver.

It provides stored procedures that determine *what should be processed next*, using lineage-aware logic, execution history, and watermark values captured during prior runs. These procedures expose standardized interfaces for pipelines and notebooks to retrieve the correct set of Extract outputs to load into Bronze, the set of Bronze outputs ready for Silver, and the appropriate incremental boundaries via persisted watermarks.

The integration schema therefore centralizes all cross-stage coordination, ensuring that execution is consistent, resumable, idempotent, and aware of task dependencies, allowing the framework to reliably progress data through the ingestion lifecycle without hard-coded logic inside pipelines.

#### **usp_get_previous_watermark_val**

The stored procedure `integration.usp_get_previous_watermark_val` is used by the Foundation ingestion framework to retrieve the last successfully processed incremental watermark for a given task. When an incremental load runs, the pipeline must know where it left off so it can extract only new or changed data.

This procedure looks up the most recent watermark for the specified `task_id` from the `logging.execution_watermark` table and returns it in the correct data type format based on the task’s incremental column (e.g., `datetime` or `int`). If no watermark exists yet, such as during a first-time load, it supplies a default starting point (`0001-01-01` for `datetime` or `-1` for integer values).

#### **usp_get_files_to_load_to_bronze**

The stored procedure `integration.usp_get_files_to_load_to_bronze` returns the list of Extract-stage task runs whose output files are ready to be ingested into the Bronze Lakehouse. It does this by joining `meta.task` (filtered to Load to bronze tasks) with `logging.task_executions` where the `Extract` stage has completed successfully and has a `next_stage_status = 'Ready'`.

For each eligible task, it provides the previous Extract run’s `task_executions_id` and `lineage_id`, which the Bronze loader uses to locate the correct raw files, as well as the task’s source/target configuration. The pipeline then uses this output to parallelize Bronze loads in `nb_parallelize_load_to_bronze`.

#### **usp_get_run_ids_to_load_to_silver**

The stored procedure `integration.usp_get_run_ids_to_load_to_silver` identifies all Bronze-stage task executions whose outputs are ready to be promoted into the Silver layer. It does this by joining `meta.task` (filtered to Load to silver tasks) with `logging.task_executions` where the `Load to bronze` stage has completed successfully and set `next_stage_status = 'Ready'`.

For each eligible task, the procedure returns the Bronze `task_executions_id`, `lineage_id`, along with the task’s source and target settings. This enables the Silver parallelization notebook (`nb_parallelize_load_to_silver`) to know exactly which Bronze runs to process, preserving lineage, ensuring incremental consistency, and allowing the framework to execute Silver transformations deterministically and in parallel.

### `logging` Schema

Responsible for all operational telemetry.

#### **logging.task_executions**

The `logging.task_executions` table is the central audit and monitoring table for the Foundation ingestion framework. Each row represents a single execution attempt of a metadata-driven task, whether `Extract`, `Load to Bronze`, or `Load to Silver`. It captures execution lineage, run identifiers, start/end timestamps, status transitions, retry information, template used, workspace and monitoring URLs, and any error details.

This table enables full observability, recovery, retry logic, troubleshooting, and lineage tracing across the entire pipeline lifecycle. It is the authoritative source for understanding what ran, when it ran, how it ran, and whether it succeeded or failed.

|Field Name|Purpose|Example Value|
|---|---|---|
|`task_executions_id`|Unique identifier for this specific execution attempt| `6c0bc455-8937-4857-9fac-e95ded3d0946`|
|`lineage_id`|Identifies the lineage grouping for related runs across stages|`82d3d436-66a0-4ca4-a019-2376636082a6`|
|`run_id`|Pipeline run identifier for the parent Fabric activity| `96fa1bf3-6cad-4585-818a-d44e64a5762b`|
|`parent_run_id`|Links child executions back to the main orchestration run| `a3ef42a1-5a5e-444e-abc9-a8d3f254d0d5`|
|`task_id`|FK to `meta.task`; identifies which metadata-defined task executed|`44`|
|`task_name`|Human-friendly name of the task|`Extract - Oracle Maximo WORKLOG`|
|`stage`|Which layer the task belongs to (Extract/Bronze/Silver)|`Extract`|
|`status`|Current execution status (`Completed`, `Failed`, `Running`, etc.)|`Completed`|
|`num_retries`|Counts how many retry attempts occurred for this run|`0`|
|`start_date`|Date (UTC) the execution began|`2025-11-07`|
|`start_datetime`|Timestamp the execution began|`2025-11-07 14:22:18.123`|
|`end_datetime`|Timestamp when execution completed|`2025-11-07 14:22:48.985`|
|`template_name`|Template or pipeline used for this execution|`pl_extract_sap`|
|`workspace_id`|Workspace GUID the pipeline/notebook executed under|`0052e1a0-a5f1-437d-96f9-f01dd30bb606`|
|`log_data`|JSON payload storing detailed execution metadata (SQL, paths, etc.) |`{"schema_name": "MAXIMO","table_name": "EX_WOFAILUREREASONS","is_incremental": 1,"incremental_column": "EX_LASTMODIFY_DATE","incremental_col_data_type": "datetime"}`|
|`monitoring_url`|URL to the Fabric monitoring page for this execution|`https://app.powerbi.com/workloads/data-pipeline/monitoring/workspaces/0052e1a0-a5f1-437d-96f9-f01dd30bb606/pipelines/pl_worker/96fa1bf3-6cad-4585-818a-d44e64a5762b`|
|`next_stage_status`|Describes downstream readiness (`Ready`, `Processed`, etc.)| `Ready`|
|`object_name`|The business entity/table being processed|`wostatus`|
|`error_details`|Error message when an execution fails|`Timeout querying Oracle source`|

#### **logging.execution_watermark**

The `logging.execution_watermark` table maintains the most recent successfully processed incremental value for each metadata-driven task. During Extract and Load processes, incremental pipelines query this table to determine where the previous run left off, and update it after each successful run.

This enables incremental ingestion, idempotent processing, and checkpoint-based recovery, ensuring that only new or changed records are extracted from the source. It is a core component of the Foundation’s incremental load strategy.Tracks incremental loading checkpoint.

|Field Name|Purpose|Example Value|
|---|---|---|
|`task_id`|Identifies which task this watermark belongs to; links to `meta.task`|`13`|
|`source_table`|Name of the source table for the incremental extraction|`EX_SITECUSTOMER`|
|`incremental_column` |Column used to track changes and determine incremental boundaries|`EX_CHANGE_DATE`|
|`watermark_value`|The last successfully processed incremental value (datetime or int)|`2025-10-28 18:55:26.617`|
|`parent_run_id`|The run that generated this watermark value; allows lineage tracing|`cc912278-c2b1-4453-9bdf-47d7a7795870`|
|`ingestion_timestamp`|UTC timestamp when the watermark record was inserted/updated|`2025-10-28 19:02:12.450000`|

#### **logging.task_config_errors**

The `logging.task_config_errors` table captures all configuration-related issues detected when validating task metadata—primarily during scheduling validation via meta.`usp_validate_task_scheduling_settings`. Whenever a task has invalid, missing, or contradictory scheduling settings (e.g., invalid `time_of_day` formats, missing `frequency_minutes`, invalid day/month combinations), a record is logged here.

This table provides a persistent audit trail of configuration problems so that engineers can diagnose failures, monitor misconfigurations over time, and ensure that incorrectly configured tasks never enter the execution pipeline.

|Field Name|Purpose|Example Value|
|---|---|---|
|`task_config_error_id`|Unique identifier for the specific configuration error entry|`a51b675b-b7cf-424e-bdd4-00ecf6ee5f58`|
|`task_id`|Identifies which metadata task contains the invalid configuration|`42`|
|`detected_at`|UTC timestamp when the error was detected during validation|`2025-11-07 14:32:11.123`|
|`error_code`|Machine-readable code describing the type of configuration issue| `TIME_OF_DAY_TIME_INVALID`|
|`error_message`|Human-readable error description detailing what is misconfigured| `Invalid time in scheduled_times: "25:99"`|
|`scheduling_settings_snapshot`|JSON snapshot of the full scheduling block at the time of error|`{"schedule_type": "time_of_day", "scheduled_times": ["25:99"]}`|
|`validator_version`|Version of the scheduling validator that produced the error|`v1`|

*NOTE*: The validator version allows the framework to record which version of the validation logic evaluated a task’s configuration, ensuring traceability as validation rules evolve. This enables engineers to distinguish errors produced by older logic from those generated by newer, potentially stricter or expanded validation rules. It also provides a path to support multiple validator behaviors in the future, allowing backward compatibility for legacy configurations.

#### **logging.row_count_audit**
The `logging.row_count_audit` table captures the row counts at each stage of execution. This includes the row counts from the source table prior to extraction, the row counts in the bronze lakehouse in Fabric, and the row counts in the silver lakehouse in Fabric.
This then provides an auditing log that can be used to validate that that the expected number of row counts were ingested for each execution, and provides an avenue for investigation in the event that row counts are not captured as expected.

|Field Name|Purpose|Example Value|
|---|---|---|
|`extract_task_id`|task_id from meta.task table for the **Extract** stage |`1`|
|`bronze_task_id`|task_id from meta.task table for the **Load to bronze** stage|`2`|
|`silver_task_id`|task_id from meta.task table for the **Load to silver** stage|`3`|
|`source_system`|name of the source system data is ingested from|`oracle`|
|`source_table`|schema and name of source table|`test.employees`|
|`source_row_count`|total row count measured from source|`6`|
|`bronze_lh_row_count`|number of records in bronze lakehouse in Fabric (note, this can be an incremental load meaning the value will be less than the source value)|`1`|
|`silver_lh_row_count`|number of records in silver lakehouse in Fabric. This value should equal the source_row_count |`6`|
|`is_incremental`|flag to discern if the load used incremental load or full|`1`|
|`parent_run_id`|data factory run id for the entire execution |`112d8621-c2e5-408c-b642-21ed37afc0ed`|
|`bronze_run_status`|status of bronze load. If set to 'NOT STARTED', do not expect the bronze_lh_row_count to be filled |`COMPLETE` or `NOT STARTED`|
|`bronze_run_task_executions_id`|task_executions_id from logging.task_executions table for the bronze run|`331ca57f-26b7-4e5c-888c-3d27e24f324d`|
|`silver_run_status`|status of silver load. If set to 'NOT STARTED', do not expect the silver_lh_row_count to be filled|`COMPLETE` or `NOT STARTED`|
|`silver_run_task_executions_id`|task_executions_id from logging.task_executions table for the silver run|`2ee86870-0eea-4e5d-bf28-eb166dbac3d4`|
|`ingestion_timestamp`|timestamp of ingestion, in UTC time|`2025-11-21 12:53`|

### Logging is two-phase

Logging in the Foundation framework follows a two-phase model to ensure every task execution is fully traceable from start to finish.

- **Start log (`usp_log_task_execution`):** When a task begins, a new execution record is created capturing the task ID, lineage, run identifiers, workspace and object metadata, and a start timestamp. This establishes the execution context before any work is performed.

- **Completion log (`usp_log_task_execution_completion`):** When the task finishes (successfully or with failure), the same record is updated with the final status, end timestamp, and next-stage status, completing the lifecycle of the execution entry.

This two-step approach guarantees accurate auditability even when tasks fail mid-process, retry, or crash unexpectedly.

## Key Stored Procedures (Deep Dive)

Below is a structured overview. A later subsection will provide line-by-line explanations.

### **meta.usp_validate_task_scheduling_settings**

The stored procedure `meta.usp_validate_task_scheduling_settings` is basically the “linting engine” for your metadata-driven scheduler.

At a high level, this procedure:

- Reads `meta.task.scheduling_settings` (JSON) for all enabled tasks, optionally filtered by `@stage`.
- Applies a set of validation rules over that JSON (schedule type, required fields, value ranges, time formats, etc.).
- Returns a rowset of configuration problems per task, and optionally persists those problems to a logging table for long-term audit.
- `meta.usp_get_tasks_due_for_execution` calls this procedure up front and excludes tasks with configuration errors from scheduling, so misconfigured tasks can’t accidentally run.

#### Parameters

```SQL
CREATE PROCEDURE [meta].[usp_validate_task_scheduling_settings]
  @stage             VARCHAR(50) NULL,
  @persist           BIT         = 1,
  @validator_version VARCHAR(20) = 'v1'
```

- `@stage` – Optional filter ('Extract', 'Load to bronze'); only tasks in that stage are validated.
- `@persist` – If 1, the procedure writes discovered errors into a persistent logging table (`logging.task_config_errors`); if 0, it only returns the issues via the result set.
- `@validator_version` – A string that tags which version of the validator produced the errors, enabling you to evolve rules over time and keep legacy vs. new behavior distinguishable.

#### Logical Flow

The `meta.usp_validate_task_scheduling_settings` procedure evaluates the JSON-based `scheduling_settings` for every enabled task (optionally filtered by stage) and normalizes that JSON into typed fields for validation. It interprets values such as `schedule_type`, `frequency_minutes`, `scheduled_times`, and calendar-based fields (day, month, day_of_month) and expands arrays like `scheduled_times` for `time_of_day` schedules. This normalization step ensures downstream validation rules operate on clean, typed metadata rather than raw JSON, making the validator robust and extensible as the scheduling model evolves.

The procedure then applies a comprehensive set of rule checks—implemented as a UNION of targeted validation queries—to identify configuration mistakes. These include invalid schedule types, missing or non-positive interval frequencies, malformed or empty `scheduled_times` lists, and out-of-range values for monthly or yearly schedules. All identified problems are collected into a temporary table along with a snapshot of the task’s original scheduling JSON, giving engineers complete visibility into what went wrong and why. The result set is returned to the caller, and—if `@persist = 1` the issues are also written to a persistent logging table, providing a historical audit trail of configuration quality.

This procedure is used by the scheduler (`usp_get_tasks_due_for_execution`) to automatically exclude misconfigured tasks before execution begins. By calling the validator up front, the scheduler ensures that only tasks with valid and coherent scheduling metadata enter the execution pipeline. Engineers can also run this stored procedure manually in SSMS/VS Code to troubleshoot individual tasks, test new scheduling patterns, or validate evolving JSON schemas. The `validator_version` parameter gives the team the flexibility to evolve validation logic over time while maintaining backward compatibility for legacy configurations.

### **meta.usp_get_tasks_due_for_execution**

The stored procedure `meta.usp_get_tasks_due_for_execution` is the scheduler brain of the Foundation framework: it decides which tasks are due to run right now based on their metadata-driven `scheduling_settings`. It evaluates the current UTC time, validates scheduling configuration, and then returns only those tasks that are enabled, correctly configured, and due for execution, ready to be passed into the orchestration pipeline. It’s designed so the scheduler (`pl_scheduler`/`pl_orchestrator`) can simply call this procedure and receive a clean, pre-filtered list of tasks to execute next.

At a high level, this procedure:

- Captures the current UTC time (or uses a provided timestamp) and reads all enabled tasks from meta.task, optionally filtered by `@stage`.
- Calls `meta.usp_validate_task_scheduling_settings` and excludes any tasks with invalid scheduling JSON from further consideration.
- Uses execution history in `logging.task_executions` to determine when each task last ran successfully and whether it is currently running.
- Applies scheduling rules (e.g., interval-based, time-of-day, monthly, yearly) against the current time and last-successful-run to decide which tasks are due.
- Returns a rowset of tasks ready to execute, each with generated `task_executions_id` and `lineage_id`, which the orchestrator uses to kick off pipelines and log runs consistently.

#### Parameters

```SQL
CREATE PROCEDURE [meta].[usp_get_tasks_due_for_execution]
    @stage       VARCHAR(50) = NULL
AS
BEGIN
    -- internal: @now_utc DATETIME2(3) = SYSUTCDATETIME();
    ...
END
```

*NOTE*: In the current implementation, the procedure derives “now” using `SYSUTCDATETIME()` internally; earlier versions also accepted a `@current_time` parameter for override/testing.

- `@stage` – Optional filter (e.g., 'Extract', 'Load to bronze', 'Load to silver'); when provided, only tasks in that stage are evaluated for execution. If `NULL`, all enabled tasks across stages are considered. In other words, you can specify what stages to run manually.

#### Logical Flow

The `meta.usp_get_tasks_due_for_execution` procedure starts by capturing the current UTC time into a local variable (`@now_utc = SYSUTCDATETIME()`) and building a working set of tasks from `meta.task`. It then calls `meta.usp_validate_task_scheduling_settings`, inserting any detected configuration problems into a table variable. Tasks that appear in this error set are filtered out, ensuring that only enabled tasks with valid scheduling JSON progress into the scheduling logic. This gives the scheduler a clean universe of “valid tasks” before any due/not-due decisions are made.

Next, the procedure looks at execution history in `logging.task_executions` to compute last successful run per task and to identify tasks that are currently running. A `last_runs` CTE aggregates `MAX(start_datetime)` for executions with `status = 'Completed'`, while a `currently_running` CTE marks tasks where there is an in-flight execution (e.g., status `IS NULL` or equivalent). These CTEs are joined back to the valid tasks so the scheduler can apply different rules depending on whether a task has never run, ran before, or is already running. This avoids double-running tasks and provides the timing context required for interval and calendar-based logic.

Finally, the procedure applies the scheduling rules encoded in each task’s `scheduling_settings`. For interval-based tasks (`schedule_type = 'interval'`), it compares `@now_utc` to `last_successful_run` + `frequency_minutes` to see if enough time has elapsed. For time-of-day, monthly, or yearly schedules, it evaluates whether the current date/time matches the configured window (such as “run at 06:00 every day” or “run on day 1 of the month”). Tasks that meet their schedule criteria, are not currently running, and are enabled are projected into the final result set, each with a new `task_executions_id` and `lineage_id` for downstream logging and orchestration. The scheduler pipeline simply calls this procedure, uses the returned rows as the worklist, and hands those IDs into `logging.usp_log_task_execution` and the execution pipelines, making `meta.usp_get_tasks_due_for_execution` the central decision point for what runs, and when.

### **integration.usp_get_previous_watermark_val**

The stored procedure `integration.usp_get_previous_watermark_val` is the entry point for incremental logic in the Foundation framework. It’s called by the Extract templates (e.g., `pl_extract_oracle`, `pl_extract_sap`) at runtime to determine the last successfully processed watermark for a given task, so the pipeline knows where to resume from. Instead of hard-coding any dates or IDs, the pipelines simply pass in the `task_id` and the data type of the incremental column, and this procedure returns the correct starting value for the next incremental window.

At a high level, this procedure:

- Looks up the most recent successful execution for the given `task_id` in the watermark store (`logging.execution_watermark`) or equivalent history.
- Returns the previous watermark value in a shape that matches the incremental column’s data type (for example, `datetime` or `int`), using sensible defaults when no history exists (first-time/full-load scenarios).
- Is invoked by the Extract pipeline via a Lookup activity (`integration.usp_get_previous_watermark_val`) and its output is used to build the `WHERE` clause for incremental extraction (`WHERE incremental_col > @previous_watermark_val`).

#### Parameters

```SQL
CREATE PROCEDURE [integration].[usp_get_previous_watermark_val]
   @task_id VARCHAR(50)
   ,@incremental_col_data_type VARCHAR(50)
AS
BEGIN
  ...
END
```

- `@task_id` – Identifies which metadata-driven task is requesting a watermark; this ties the watermark to the configuration in meta.task.
- `@incremental_col_data_type` – Indicates how the watermark should be interpreted and returned (e.g., `datetime` vs `int`), so the pipeline can safely cast and embed it into the dynamic SQL `WHERE` clause.

#### Logical Flow

The `integration.usp_get_previous_watermark_val` procedure is called early in the Extract pipeline, right after the metadata and source settings are resolved. Given a `task_id`, it queries the watermark history (or execution history) to find the last successful watermark associated with that task. If the task has run before, it returns the most recent value; if it has never run, it returns a default “starting” watermark (for example, a very low integer or an early date) so the first execution behaves like a full load without needing special-case logic in the pipeline.

The pipeline’s control flow then uses this returned value to construct the incremental filter. In the orchestration JSON you can see the following pattern: the pipeline first calls `usp_get_previous_watermark_val`, then separately queries the source for the current max value, and finally builds a `sql_where_predicate` that only selects rows where the incremental column is greater than the previous watermark. This design keeps all state about “how far we’ve gone” inside the metadata/control database instead of in the pipelines themselves. Engineers can safely re-run tasks, recover from failures, or adjust incremental strategies knowing that the source of truth for the last processed point is encapsulated in this stored procedure and its underlying watermark table.

### **integration.usp_get_files_to_load_to_bronze**

The stored procedure `integration.usp_get_files_to_load_to_bronze` is the bridge between Extract and Bronze in the Foundation framework. It tells the Bronze loader which Extract runs are ready to be ingested into the Bronze Lakehouse and provides all the metadata needed to do so. Instead of having the notebook or pipeline scan OneLake for files, the framework uses this stored procedure to return a clean, lineage-aware list of Extract executions that have completed successfully and are marked as ready for the next stage.

At a high level, this procedure:

- Joins `meta.task` (configured as `stage = 'Load to bronze'`) with logging.`task_executions` where the previous stage is `Extract`.
- Filters to executions where the Extract stage has `status = 'Completed' and next_stage_status = 'Ready'`, meaning the raw files are prepared and waiting to be processed.
- Returns, for each such pair, the previous Extract execution identifiers plus the Bronze configuration (source/target/option settings) that the Bronze notebook will use to load data into Delta tables.

#### Parameters

```SQL
CREATE PROCEDURE integration.[usp_get_files_to_load_to_bronze]
    @bronze_workspace_id VARCHAR(200),
    @bronze_lakehouse_id VARCHAR(200)
AS
BEGIN
  ...
END
```

- `@bronze_workspace_id` – The GUID of the Fabric workspace that hosts the Bronze Lakehouse; this is injected into the result so the notebook knows where to write.
- `@bronze_lakehouse_id` – The GUID of the Bronze Lakehouse; also returned per row so the ingestion code doesn’t need to hard-code lakehouse identifiers.

#### Logical Flow

The `integration.usp_get_files_to_load_to_bronze` procedure starts by selecting all tasks in `meta.task` where `stage = 'Load to bronze'`, which represent the Bronze-load definitions rather than the raw Extract tasks themselves. It then joins to logging.`task_executions` on `object_name`, specifically looking for executions where `stage = 'Extract'`. This modeling assumes a consistent object_name (source table/entity) across the Extract and Load-to-Bronze tasks, allowing the procedure to pair “the Bronze task definition” with “the last successful Extract execution for that object.”

From that joined set, the procedure filters to only those Extract executions with `status = 'Completed'` and `next_stage_status = 'Ready'`. This means the files produced by those runs have passed prior checks and are explicitly flagged as ready to be promoted to Bronze, and that they haven’t yet been marked as processed by a downstream stage. For each such row, the procedure returns:

- `previous_task_executions_id` and `previous_lineage_id` (from the Extract run),
- the Bronze workspace and lakehouse IDs (from the parameters), and
- the Bronze task’s `task_id`, `task_name`, and JSON-based source_settings, `target_settings`, and `option_settings`.

The Bronze notebook (e.g., `nb_parallelize_load_to_bronze`) calls this stored procedure to get its worklist: each row tells it which Extract run to read from (via the execution IDs and lineage), and how to land the data in Bronze (via the task settings and lakehouse identifiers). Once processing completes, the notebook uses the logging procedures to mark the current Bronze run as Completed and to update the previous Extract execution’s `next_stage_status` (for example, to Processed), closing the loop and preventing the same files from being ingested twice.

### **integration.usp_get_run_ids_to_load_to_silver**

The stored procedure `integration.usp_get_run_ids_to_load_to_silver` is the bridge between Bronze and Silver in the Foundation framework. It tells the Silver loader which Bronze runs are ready to be transformed and provides the execution identifiers and metadata needed to do so in a controlled, lineage-aware way. Functionally, it mirrors `integration.usp_get_files_to_load_to_bronze`, but for the next hop in the pipeline: instead of pairing Extract -> Bronze, it pairs Load to bronze -> Load to silver so that Silver notebooks don’t need to scan tables or files to figure out what to process next.

At a high level, this procedure:

- Identifies meta.task entries configured with `stage = 'Load to silver'` and links them to the corresponding Bronze executions in `logging.task_executions` (typically via `object_name` and `stage = 'Load to bronze'`).
- Filters to Bronze runs that have completed successfully (e.g., `status = 'Completed'`) and have set `next_stage_status = 'Ready'`, indicating their outputs are prepared for Silver.
- Returns a rowset of “work items” for Silver: each row contains the previous Bronze run’s execution IDs and the Silver task’s metadata (e.g., source/target/option settings and, if required, workspace/lakehouse IDs), which the Silver parallelization notebook uses to drive its processing.

#### Parameters

The procedure is designed to be called by the Silver orchestration notebook/pipeline (`nb_parallelize_load_to_silver`) and typically accepts:

- A **Silver workspace identifier** – so the caller doesn’t hard-code where the Silver tables live; the procedure simply echoes this into each returned row.
- A **Silver lakehouse or warehouse identifier** – so the notebook knows which Fabric artifact to write to.
- No task-specific parameters are needed, because the linkage is done by joining meta.task (for `stage = 'Load to silver'`) with `logging.task_executions` for the Bronze stage; the procedure returns only those combinations that are ready to move forward.

*NOTE:* Exact parameter names and types follow the same pattern as `integration.usp_get_files_to_load_to_bronze`, but target the Silver layer instead of Bronze.

#### Logical Flow

`integration.usp_get_run_ids_to_load_to_silver` starts by selecting all tasks in meta.task where `stage = 'Load to silver'`. These tasks define how Silver should be populated (e.g., which Bronze tables/paths to read from, what load strategy to use), but they don’t themselves know which specific runs are ready. The procedure then joins this task metadata to `logging.task_executions` entries for the Bronze stage (e.g., `stage = 'Load to bronze'`) using a shared identifier such as `object_name`. This pairing associates each Silver task with the Bronze executions that produced its upstream data.

From this joined set, it filters to Bronze executions that are ready to be consumed: those with `status = 'Completed'` and `next_stage_status = 'Ready'`, ensuring that in-flight or failed Bronze loads never feed Silver. For each qualifying Bronze run, the procedure returns the previous Bronze `task_executions_id` and `lineage_id`, the Silver workspace/lakehouse identifiers (passed as parameters), and the Silver task’s configuration JSON (source/target/option settings).

The Silver parallelization notebook calls this procedure to obtain its worklist, iterates over the returned rows to perform the actual transformations, and then uses the logging procedures to mark the new Silver executions as completed and the corresponding Bronze runs as processed, closing the loop and preventing the same Bronze output from being ingested into Silver multiple times.

### **logging.usp_log_task_execution**

The stored procedure `logging.usp_log_task_execution` is the “start log” for every metadata-driven task run in the Foundation framework. When the orchestrator (pipeline or notebook) decides a task should execute, it calls this procedure with pre-generated IDs and execution context to create a new row in `logging.task_executions`. This sets up a fully populated execution record including task metadata, stage, template, workspace, and monitoring URL before any work happens, so every run is traceable even if it fails mid-flight.

#### Parameters

```SQL
CREATE PROCEDURE [logging].[usp_log_task_execution]
    @task_executions_id UNIQUEIDENTIFIER,
    @lineage_id UNIQUEIDENTIFIER,
    @run_id UNIQUEIDENTIFIER,
    @parent_run_id UNIQUEIDENTIFIER,
    @task_id INT,
    @workspace_id UNIQUEIDENTIFIER,
    @executing_object_id UNIQUEIDENTIFIER,
    @executing_object_name VARCHAR(200),
    @executing_object_run_id UNIQUEIDENTIFIER,
    @executing_object_type VARCHAR(20)
AS
BEGIN
  ...
END
```

- `@task_executions_id` – A unique ID for this specific execution of the task; generated by the orchestrator and used as the primary handle in logging.task_executions.
- `@lineage_id` – A correlation ID that groups related executions across stages (e.g., Extract -> Bronze -> Silver) for the same logical run.
- `@run_id` – The overarching run ID for the current batch/orchestration (often the scheduler/orchestrator pipeline run).
- `@parent_run_id` – A higher-level run identifier used to group multiple task executions under a single parent (e.g., “nightly job run”).
- `@task_id` – Foreign key into meta.task; used to look up task_name, stage, object_name, and template settings.
- `@workspace_id` – Fabric workspace GUID where the executing object (pipeline/notebook) is running.
- `@executing_object_id` – The GUID of the actual Fabric artifact executing the task (pipeline or notebook).
- `@executing_object_name` – The name of the executing object; used both for monitoring URL construction and as a fallback template name.
- `@executing_object_run_id` – The Fabric run ID for the executing pipeline or notebook instance; embedded into the monitoring URL.
- `@executing_object_type` – Indicates whether the executing object is a 'pipeline' or 'notebook', driving different monitoring URL patterns.

The procedure typically returns the newly created task_executions_id (and possibly lineage_id) to the caller so they can pass it into downstream activities and logging helpers.

#### Logical Flow

When `logging.usp_log_task_execution` is called, it first looks up the task metadata from `meta.task` using `@task_id`. From that row it pulls `task_name`, `stage`, `object_name`, and `template_settings`. The `template_name` is resolved by checking `template_settings` for `$.template_name` and falling back to `@executing_object_name` if that JSON field is not present. At the same time, it builds a `@monitoring_url based` on the `@executing_object_type`: for pipelines, it constructs a Data Pipeline monitoring URL; for notebooks, it builds a Spark Monitor URL using the `@executing_object_id` and `@executing_object_run_id`. This gives each execution a clickable link back into Fabric for quick troubleshooting.

After resolving these values, the procedure inserts a row into `logging.task_executions` with the supplied IDs and the derived metadata: `task_executions_id`, `lineage_id`, `run_id`, `parent_run_id`, `task_id`, `task_name`, `stage`, `object_name`, the current date (`start_date`), the current timestamp (`start_dateTime`), the resolved `template_name`, the `workspace_id`, and the constructed `monitoring_url`. No status is set here—that’s handled later by `logging.usp_log_task_execution_completion`, but from this point onward the run is fully traceable. Pipelines and notebooks pass `@task_executions_id` into downstream logging helpers and, at completion time, into the completion proc to set status, `next_stage_status`, and `end_datetime`, completing the two-phase logging pattern.

### **logging.usp_log_task_execution_completion**

The stored procedure `logging.usp_log_task_execution_completion` is the “completion log” for each task execution in the Foundation framework. After a pipeline or notebook finishes processing a task—whether successfully or with an error—it calls this procedure to finalize the corresponding row in `logging.task_executions`. Together with `logging.usp_log_task_execution`, it implements the two-phase logging pattern: start when the run begins, complete when it ends, ensuring every execution has a clear beginning and end in the audit trail.

At a high level, this procedure:

- Updates the execution record created at task start, marking it with a final status (Completed, Failed, etc.).
- Sets the next_stage_status, allowing downstream stages (Bronze/Silver loaders) to determine whether this run’s output is ready to be consumed.
- Stamps the run with an end_datetime, closing the execution window and preventing duplicate completion updates.

#### Parameters

```SQL
CREATE PROCEDURE logging.usp_log_task_execution_completion
    @task_executions_id UNIQUEIDENTIFIER,
    @status             VARCHAR(50),
    @next_stage_status  VARCHAR(20)
AS
BEGIN
  ...
END
```

- `@task_executions_id` – The unique ID of the execution record to finalize; this is the same ID generated at run start.
- `@status` – The terminal execution status (`Completed`, `Failed`, `No files to process`, etc.).
- `@next_stage_status` – Indicates downstream consumability (`Ready`, `Processed`, `Failed`, `N/A`); used by integration stored procedures and orchestrator logic.

#### Logical Flow

When called, the procedure updates the corresponding row in logging.`task_executions`, but only if `end_datetime` is still `NULL`, ensuring that execution records cannot be completed more than once. It writes the final status, updates `next_stage_status` for downstream orchestration, and stamps the execution with`end_datetime = GETDATE()` to mark the exact completion moment. This makes the execution log both immutable and audit-friendly.

In practice, pipelines and notebooks call this stored procedure inside their success/failure paths after performing `Extract`, `Load to Bronze`, or `Load to Silver` work. Integration-layer procedures such as `integration.usp_get_files_to_load_to_bronze` and `integration.usp_get_run_ids_to_load_to_silver` rely on these statuses to determine which executions are ready to move forward and which require retries or manual investigation, making this completion logic a foundational part of the metadata-driven execution engine.

### **logging.usp_update_processed_flag**

The stored procedure `logging.usp_update_processed_flag` is a lightweight but essential part of the Foundation’s multi-stage orchestration model. Whereas `logging.usp_log_task_execution_completion` finalizes the current stage’s execution, this procedure updates the previous stage’s execution record to indicate how its output was consumed by the next layer (Bronze or Silver).

It is typically called by notebooks or orchestration logic after a downstream stage successfully processes the outputs of an upstream run, ensuring that no execution is picked up twice and that lineage remains accurate across extract, bronze, and silver stages.

#### Parameters

```SQL
CREATE PROCEDURE logging.usp_update_processed_flag
    @task_executions_id UNIQUEIDENTIFIER,
    @next_stage_status  VARCHAR(20)
AS
BEGIN
  ...
END
```

- `@task_executions_id` – The execution record from the previous stage whose processed flag needs updating (typically an Extract run being acknowledged by Bronze, or a Bronze run acknowledged by Silver).
`@next_stage_status` – The new downstream status (`Processed`, `Failed`, `No files to process`, `N/A`), which determines whether this execution is eligible for further stage transitions.

#### Logical Flow

The procedure performs a simple but critical `UPDATE` on `logging.task_executions`, setting the `next_stage_status` field for the identified `task_executions_id`. Unlike `logging.usp_log_task_execution_completion`, it does not modify status or timestamps; it exists solely to inform the orchestration engine that the output of a prior run has been consumed. This is what prevents the same Extract-generated files or Bronze-generated data from being pulled into later stages more than once.

In practice, the process looks like this:

1. A Bronze or Silver loader notebook processes the output of a previous run.
2. It logs its own run via `usp_log_task_execution` and completes it with `usp_log_task_execution_completion`.
3. It then calls `usp_update_processed_flag` to mark the upstream execution (Extract -> Bronze or Bronze -> Silver) as 'Processed'.

### **logging.usp_set_custom_log__extract_sql**

The stored procedure `logging.usp_set_custom_log__extract_sql` is the enriched metadata logger for SQL-based Extract runs. While `logging.usp_log_task_execution` and its completion companion capture when a task ran and whether it succeeded, this procedure captures what exactly was extracted and where it landed—including source connection details, database/schema/table, target OneLake path, and the executed SQL query. It writes all of this into the log_data column of logging.task_executions as a JSON payload, giving you a rich, queryable audit trail for each Extract run.

At a high level, this procedure:

- Accepts detailed source and target metadata (Fabric connection, database/schema/table, lakehouse IDs, file path/name, and SQL).
- Builds a single JSON object (`log_data`) that encapsulates all of this context in a structured, machine-readable way.\
- Updates the corresponding `logging.task_executions` row for the given `@task_executions_id`, only if `log_data` is currently `NULL`, preventing accidental overwrite of existing logs.

```SQL
CREATE PROCEDURE logging.usp_set_custom_log__extract_sql
    @task_executions_id         UNIQUEIDENTIFIER,
    @source_fabric_connection_id VARCHAR(200),
    @source_database_name        VARCHAR(200),
    @source_schema_name          VARCHAR(200),
    @source_table_name           VARCHAR(200),
    @target_lakehouse_id         VARCHAR(200),
    @target_workspace_id         VARCHAR(200),
    @target_file_path            VARCHAR(400),
    @target_file_name            VARCHAR(200),
    @sql_query                   VARCHAR(400)
AS
BEGIN
  ...
END
```

- `@task_executions_id` – The execution record to enrich; ties this metadata back to a specific run in logging.task_executions.
- `@source_fabric_connection_id` – The Fabric connection GUID used to reach the source SQL database.
- `@source_database_name` – Name of the source database (e.g., PWMAXQA, PWRODQA2).
- `@source_schema_name` – Schema of the source table (e.g., MDM_OWNER).
- `@source_table_name` – Table being extracted (e.g., CUSTOMERS).
- `@target_lakehouse_id` – The GUID of the target Lakehouse where data is being written.
- `@target_workspace_id` – The workspace GUID hosting that Lakehouse.
- `@target_file_path` – Folder/path within OneLake (e.g., raw/maximo/customers/2025-11-01).
- `@target_file_name` – The file name or prefix used for the extract (e.g., `customers_20251101_120000.parquet`).
- `@sql_query` – The exact SQL query executed against the source (with watermark predicate, filters, etc.).

#### Logical Flow

Inside the procedure, all the provided parameters are combined into a single JSON payload using `JSON_OBJECT`, with keys like `source_fabric_connection_id`, `source_database_name`, `source_schema_name`, `source_table_name`, `target_lakehouse_id`, `target_workspace_id`, `target_file_path`, `target_file_name`, and `sql_query`. This JSON is stored in a local variable `@log_data`.

The procedure then issues an `UPDATE` to `logging.task_executions`, setting `log_data = @log_data` only for the row matching `@task_executions_id` and where `log_data IS NULL`. This guard ensures that custom log details are set once per run and are not accidentally overwritten by subsequent calls. In practice, the Extract template (e.g., `pl_extract_sql`) will:

- Start the run with `logging.usp_log_task_execution`.
- Execute the copy / extract activity.
- Call `logging.usp_set_custom_log__extract_sql` with the actual query and paths used.
- Complete the run via `logging.usp_log_task_execution_completion`.

### **logging.usp_update_watermark_val**

The stored procedure `logging.usp_update_watermark_val` is the write path for the Foundation’s incremental watermarking system. After a successful Extract execution determines the new highest incremental value (e.g., the max timestamp or max numeric ID from the source), the Extract pipeline calls this procedure to persist that value into logging.`execution_watermark`. This ensures that on the next run, the framework knows precisely where to resume, enabling safe incremental loads, idempotent re-runs, and reliable recovery after failures.

At a high level, this procedure:

- Accepts the task identifier and the current watermark value (e.g., max of the incremental column from the latest run).
- Inserts or updates a record in the watermark store (e.g., `logging.execution_watermark`) so that the next run can start from this new point.
- Optionally records context such as `parent_run_id` or ingestion timestamp, providing lineage and traceability for when and by which run the watermark was advanced.

#### Parameters

```SQL
CREATE PROCEDURE [logging].[usp_update_watermark_val]
    @task_id             VARCHAR(50),
    @source_table        VARCHAR(200),
    @incremental_column  VARCHAR(200),
    @watermark_value     VARCHAR(200),
    @parent_run_id       VARCHAR(200)
BEGIN
  ...
END
```

- `@task_id` – Links the watermark back to a specific entry in meta.task, ensuring the value is task-specific.
- `@source_table` – The name of the table from which data was just incrementally extracted.
- `@incremental_column` – The column used as the incremental boundary (e.g., `LASTUPDATED`, `MOD_DATE`, `SEQUENCE_ID`).
- `@watermark_value` – The new watermark value, represented as a string so it can accommodate both datetime and numeric types.
- `@parent_run_id` – Identifies which orchestration run advanced the watermark, improving lineage and troubleshooting clarity.

#### Logical Flow

The procedure builds a one-row `SOURCE` dataset containing the new watermark metadata and the current timestamp (`GETDATE()` as `ingestion_timestamp`). It then performs a `MERGE` against `logging.execution_watermark` on `task_id`:

- If no existing watermark exists for the task -> it inserts a new row with the full metadata and ingestion timestamp.
- If a watermark already exists -> it updates the existing row, replacing the source table name, incremental column, stored value, and parent run ID with the new values.
- Because the `MERGE` matches only on `task_id`, each task maintains a single authoritative watermark record, simplifying incremental logic and guaranteeing that integration.`usp_get_previous_watermark_val` always returns the latest value.

This stored procedure is called after the Extract run has successfully completed and logged via `logging.usp_log_task_execution_completion`. Once updated, the orchestration engine can immediately use this new value during the next run, enabling clean incremental windows and making the ingestion pipeline reliable, restartable, and fully traceable across executions.

### **meta.usp_log_insert_row_count_audit**
The stored procedure `meta.usp_log_insert_row_count_audit` is used to populate the logging.row_count_audit table with the initial extraction. This stored procedure is called while executing pl_worker, before any data is ingested.

At a high level, this procedure:

- Recieves the parameters from the data factory pipeline
- INSERT's a record into the logging.row_count_audit table, populating the source_row_count but leaving the bronze and silver fields NULL to be filled in later down the execution chain

#### Parameters

```SQL
CREATE PROCEDURE [logging].[usp_log_insert_row_count_audit]
    @task_id INT,
    @source_system VARCHAR(100),
    @source_table_name VARCHAR(100),
    @source_row_count BIGINT,
    @is_incremental INT,
    @parent_run_id UNIQUEIDENTIFIER
AS
BEGIN
...
END
```

- `@task_id` – task_id for the Extract stage of the pipeline execution.
- `@source_system` - name of source system.
- `@source_table_name` – name of the table from which data was extracted.
- `@source_row_count` - row count measured from the source table.
- `@is_incremental` - flag that determines if the extraction was incremental (1) or full load (0).
- `@parent_run_id` -  Identifies which orchestration run advanced the watermark, improving lineage and troubleshooting clarity.

#### Logical Flow
The `meta.usp_log_insert_row_count_audit` procedure starts by recieving the required parameters from the parent data factory pipeline. 

It then does a simple INSERT INTO query, filling the columns in with the fields recieved from the pipeline. However, the bronze and silver run fields are left as NULL, to be updated later by the next stored procedure.

### **meta.usp_log_update_row_count_audit**
The stored procedure `meta.usp_log_update_row_count_audit` is used to update an existing record in the logging.row_count_audit table after a bronze or silver execution is complete.

At a high level, this procedure:

- Based on the task_id (could be bronze or silver load), use the meta.task_dependencies table to determine what the parent extract_task_id was.
- Perform an UPDATE query to update the necessary record in the logging.row_count_audit table. The key used for this update is the extract_task_id and parent_run_id fields.
- Based on the 'stage' parameter, it determines whether or not to update the bronze or silver record counts/run status/run id.


#### Parameters

```SQL
CREATE PROCEDURE [logging].[usp_log_update_row_count_audit]
    @parent_run_id UNIQUEIDENTIFIER,
    @stage VARCHAR(50),
    @row_count BIGINT,
    @task_id INT,
    @task_executions_id VARCHAR(50)
AS
BEGIN
...
END
```

- `@parent_run_id` -  Identifies which orchestration run advanced the watermark, improving lineage and troubleshooting clarity.
- `@stage` - this field will either be 'BRONZE' or 'SILVER'. Based on this field, it will update the appropriate columns (for instance, bronze_lh_record_count versus silver_lh_record_count)
- `@row_count` - row count from lakehouse table measured from Fabric.
- `@task_id` – task_id for the run that triggered the stored proc (either the bronze or silver load)
- `@task_executions_id` - task_executions_id from the bronze or silver load notebook, to be used to JOIN to the logging.task_executions table.


#### Logical Flow
The `meta.usp_log_update_row_count_audit` procedure starts by recieving the required parameters from the load_to_bronze or load_to_silver notebook that executes it.

First, it uses the `@task_id` parameter to then reverse-search the meta.task_dependencies table to determine the extract_task_id. This is because the meta.task table does not define relationships between the individual tasks.

Then, it triggers the UPDATE query to update the record in the logging.row_count_audit table based on the parent_run_id and extract_task_id. 

First, it updates the appropriate columns. For Bronze: bronze_lh_row_count, bronze_run_status, bronze_run_task_executions_id, and bronze_task_id. For silver: silver_lh_row_count, silver_run_status, silver_run_task_executions_id, and silver_task_id. These fields all come from the parameters, and the stored procedure knows whether to update bronze or silver based on the @stage parameter.



## How Metadata Drives the End-to-End Execution

![end-to-end-metadata](./.images/end-to-end%20metadata.png)
