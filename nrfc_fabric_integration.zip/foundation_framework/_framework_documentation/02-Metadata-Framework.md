# Metadata Framework (Foundation) Overview

This section introduces the metadata-driven architecture that powers all ingestion, orchestration, validation, and transformation capabilities within Microsoft Fabric. It provides a conceptual understanding of how the framework works, why it exists, and how data engineers can use it to rapidly onboard and manage new data sources.

## What is the Metadata Framework?

The Metadata Framework (also referred to as Foundation) is a reusable, configurable ingestion and transformation engine built on Microsoft Fabric. Instead of manually building pipelines for each table or source system, engineers define configuration in metadata (control tables and YAML files). The framework interprets this metadata and automatically orchestrates ingestion across Extract → Load to Bronze → Load to Silver stages.

This allows:

- Declarative onboarding of new tables and sources
- Standardized ETL patterns across ENMAX
- Full + incremental loading
- Automated monitoring, lineage tracking, and logging
- Centralized scheduling and retry behavior
- Extensibility through templates (SQL, Oracle, SAP, REST API, etc.)

## Why Use a Metadata-Driven Approach?

Traditional ETL development often involves writing custom code for each data source and table, leading to:

- High maintenance overhead
- Inconsistent patterns and practices
- Difficulty scaling as new sources are added

By adopting a metadata-driven approach, the Metadata Framework enables:

- Rapid onboarding of new data sources with minimal coding
- Reusability of common ingestion and transformation logic
- Easier maintenance through centralized configuration
- Improved consistency and standardization across data pipelines

## High-Level Architecture

The framework's flow is divided into four core components:

- Metadata (control database + YAML config)
- Scheduler pipeline (determines what should run)
- Orchestrator pipeline (executes tasks)
- Worker pipelines / notebooks (executes template logic)

![hihg-level-architecture](./01-Architecture-and-Design/.images/C4-Model-Template-and-Arch-C2--Foundation-Platform.png)

## Metadata-Driven configuration

All ingestion behaviour is defined using metadata:

- **Connections:** Information to authenticate and connect to systems.
  - These connections are created within the Microsoft Fabric Tenant and permissions are granted through Entra ID.
- **Tasks:** One row per ingestion/transformation step.
- **Task Settings:** Source settings, target settgins, scheduling, templates.
- **Watermarks:** Incremental tracking of activities.
- **Execution Logs:** Lineage, row coutns, failures, run URLs.

Data Engineers define tasks using YAML files (or SQL Scripts), and a deployment utility syncs them into the control database.

## Scheduling and Orchestration

### `pl_scheduler`

Runs every _X_ minutes and determines which tasks should run based on:

- Schedule type (interval, time-of-day, monthly, yearly, etc.)
- Retry Rules
- Whether task is already running
- Last Successful or Failed run

### `pl_orchestrator`

Receives a list of tasks due for execution and begins processing in parallel by:

- Invoking `pl_worker` for each extract tasks.
- Coordinating Bronze loads.
- Coordinating Silver loads.

## Template-Based Execution

Each task specifies a template such as:

_Data Pipelines_:

- `pl_extract_sql`
- `pl_extract_oracle`
- `pl_extract_sap`

_Notebooks_:

- `nb_extract_api`
- `nb_load_to_bronze`
- `nd_load_to_silver`

Templates enforce:

- Consistent Logic
- Parameterized Execution
- Centralized Logging
- Checkpoint Recovery

The orchestrator invokes the appropriate template for each task, passing in parameters defined in metadata. This allows engineers to focus on configuration rather than coding.

![Sequence-Diagram](.images/sequence-diagram.png)

## Layered Ingestion

### Bronze

The Bronze layer serves as the initial landing zone for raw data ingested from various source systems. Key characteristics include:

- Raw replicated files.
- Stored in Lakehouse/Files
- Supports Parquet, JSON, and CSV
- Includes ingestion metadata

### Silver

The Silver layer is where data is cleansed, transformed, and structured for analytical consumption. Key characteristics include:

- Cleansed, conformed, and normalized Delta tables.
- Deduplication, incremental merge, schema alignment.
- Hash keys + change detection
- Validation before promotion

## Logging, Monitoring and Lineage

All execution details are logged to the control database, including:

- Task execution start and end timestamps.
- Pipeline run URLs for easy access for debugging.
- Schema and row counts.
- Error messages.
- SQL queries (for SQL templates)
- Source and target metadata.

This enables:

- Auditability
- End-to-end lineage tracking.
- Simplified troubleshooting and root cause analysis.
- Enables the creation of observability dashboards.
- Automated email/Teams/Distribution Group notifications.
