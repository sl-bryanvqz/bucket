# Orchestration and Monitoring

This section describes how the Foundation framework orchestrates pipeline executions and how engineers and operators monitor, troubleshoot, and receive alerts for those executions.

Foundation uses a combination of:

- **Metadata-driven orchestration** (Control DB + `pl_scheduler` + `pl_orchestrator`)
- **Detailed logging tables** in the Control DB
- **Fabric Monitor** for run-level visibility
- **An alert pipeline** that sends email notifications on failures and (optionally) successful completions

## Orchestration Overview

At a high level, orchestration in Foundation works as follows:

1. Fabric schedule or manual trigger runs the **scheduler pipeline** (`pl_scheduler`) on a regular interval (for example, every 15 minutes).
2. `pl_scheduler` queries the **Control Database** (via `meta.usp_get_tasks_due_for_execution`) to determine which tasks are due to run based on their `scheduling_settings`.
3. The scheduler passes the list of due tasks to `pl_orchestrator`.
4. `pl_orchestrator`:

   - Creates/logs a task execution record for each task.
   - Determines the appropriate template (Data Pipeline or Notebook) from `template_settings`.
   - Invokes the corresponding worker pipeline/notebook (e.g. `pl_extract_oracle`, `pl_extract_sap`, `nb_load_to_bronze`, `nb_load_to_silver`).
5. Each worker:

   - Executes the Extract / Load to Bronze / Load to Silver logic.
   - Updates logging and watermark tables.
6. On completion or failure, monitoring and alerting components:

   - Expose execution details via Fabric Monitor.
   - Persist detailed logs in the Control DB.
   - Optionally trigger email alerts.

This entire flow is metadata-driven. Adding or changing a task is done by updating metadata in the Control DB (typically via the YAML -> notebook loader), not by editing the orchestrator itself.

## Key Orchestration Components

### Scheduler pipeline (`pl_scheduler`)

- Runs on a *fixed cadence* defined in Fabric’s pipeline scheduling UI.
- Calls `meta.usp_get_tasks_due_for_execution` to retrieve tasks whose `scheduling_settings` indicate they should run now, taking into account:
  - `schedule_type` (time-of-day, monthly, yearly)
  - `scheduled_times` or `frequency_minutes`
  - `skip_if_running`
  - Last successful / failed execution time
  - Retry windows and limits (if retries are enabled)

`pl_scheduler` is intentionally lightweight. It does not execute work itself, it simply computes *what* should run and hands that list to the orchestrator.

### Orchestrator pipeline (`pl_orchestrator`)

`pl_orchestrator` is the “traffic controller” or "dispatcher" of runtime execution:

- Receives a list of *task IDs* (and optional filters like stage) from `pl_scheduler`.
- For each task:
  - Creates a `logging.task_execution` row.
  - Generates a lineage ID for end-to-end tracking.
  - Determines the correct template:
-Data Pipelines: `pl_extract_sql`, `pl_extract_oracle`, `pl_extract_sap`, etc.
    - Notebooks: `nb_load_to_bronze`, `nb_load_to_silver`, etc.
  - Passes all required parameters:
    - `source_settings`, `target_settings`, `template_settings`
    - `task_id`, `task_executions_id`, `lineage_id`
    - Current watermark (for incremental jobs)
- Executes child pipelines/notebooks **in parallel** where possible, while tracking each child run.

When the worker completes, `pl_orchestrator` updates the `logging.task_execution` record with final status and (where applicable) triggers the next stage (e.g. from Extract to Load to Bronze).

### Worker pipelines and notebooks

Worker templates implement the actual ETL logic, but do not decide *when* they run. Examples include:

- **Extract templates**:
  - `pl_extract_oracle`
  - `pl_extract_sap`
  - `pl_extract_sql`
- **Load templates**:
  - `nb_load_to_bronze`
  - `nb_load_to_silver`

All workers follow common patterns:

- Read `source_settings` and `target_settings` from parameters.
- Use *watermark* procedures for incremental loads:
  - `integration.usp_get_previous_watermark_val`
  - `logging.usp_update_watermark_val`
- Log execution metadata back to Control DB:
  - Source system/table.
  - Target lakehouse path/table.
  - Row counts.
  - SQL queries (where applicable).
  - Fabric pipeline run URL.

## Logging Model

The logging model provides more granular information than Fabric’s native monitor, and is the primary source for auditing and troubleshooting within Foundation.

### Core logging tables

The key tables in the **`logging`** schema include:

|Table|Purpose|Examples of key fields|
|---|---|---|
|`logging.task_execution`|One row per execution of a task (Extract, Load to Bronze, Load to Silver)|`task_executions_id`, `task_id`, `stage`, `status`, `start_time`, `end_time`, `rows_read`, `rows_written`, `pipeline_run_url`, `error_message`, `next_stage_status`|
|`logging.execution_watermark`|Tracks incremental positions for each task|`task_id`, `source_table`, `incremental_column`, `watermark_value`, `parent_run_id`, `ingestion_timestamp`|
|`logging.row_count_audit`|Tracks the number of records in source, and number of records loaded to Bronze and Silver in Fabric |`extract_task_id`, `source_table`, `source_row_count`, `bronze_row_count`, `silver_row_count`, `parent_run_id`, `ingestion_timestamp`|


Worker templates populate these tables through stored procedures like:

- `logging.usp_update_watermark_val`
- `logging.usp_set_log_data` (to attach additional metadata/log payloads to a `task_executions_id`)
- `logging.usp_log_update_row_count_audit` (updates the row count values in the row_count_audit logging table)

These logs allow you to answer questions such as:

- When did a particular table last successfully load?
- How many rows were processed for a given run?
- What query was used to extract data from Oracle or SAP?
- Which pipeline run in Fabric corresponds to this execution?
- How many rows are in the source and how were are loaded in this execution? Is there a mis-match in the row counts?

### Relationship to Fabric Monitor

- Fabric Monitor provides run-level details:
  - End-to-end activity tree.
  - Durations and data volumes.
  - Raw error messages per activity.
- The Control DB logging tables provide:
  - Cross-run history over time.
  - Cross-source/cross-stage views (Extract → Bronze → Silver).
  - Additional metadata (SQL queries, file paths, source/target identifiers).
  - Keys (`task_id`, `task_executions_id`, `lineage_id`) that link runs across multiple pipelines and stages.

The `pipeline_run_url` stored in `logging.task_execution` is the bridge between both worlds: you can start in a SQL query against the Control DB, identify a failing run, and click directly into the corresponding Fabric Monitor entry for deep debugging.

## Monitoring Executions

Monitoring in Foundation is a combination of Fabric-native tools and Control DB views.

### Using Fabric Monitor

You can monitor the following pipelines directly in Fabric:

- `pl_scheduler`
- `pl_orchestrator`
- All worker pipelines (e.g. `pl_extract_oracle`, `pl_extract_sap`)
- The **email alert pipeline** (see below)

Typical usage:

1. Open the Foundation workspace in Fabric.
2. Select **Data Factory -> Monitor**.
![fabric-monitor](.images/fabric-monitor.png)
3. Filter by pipeline name (e.g. `pl_orchestrator`) and time range.
4. Drill into a run to:

   - View activity tree.
   - Check activity-level error messages.
   - See inputs/outputs for key activities (Lookups, Copy Data, Notebooks).

Because the run URL is logged into `logging.task_execution`, you can also:

- Start from an internal dashboard or SQL query of the Control DB.
- Locate a failed task by `object_name`, `stage`, or time.
- Click the **run URL** to open that exact run in Fabric Monitor.

### Monitoring with Control DB Queries / Dashboards

Common query patterns against the Control DB include:

- Recent failures:

  ```SQL
  SELECT TOP 50
      te.task_executions_id,
      te.task_id,
      t.object_name,
      t.stage,
      te.status,
      te.start_datetime,
      te.end_datetime,
      te.error_details,
      te.monitoring_url
  FROM logging.task_executions te
  JOIN meta.task t ON t.task_id = te.task_id
  WHERE te.status = 'Failed'
  ORDER BY te.start_datetime DESC;
  ```

- Execution history for a specific object:

  ```SQL
  SELECT
      te.task_executions_id,
      te.status,
      te.start_datetime,
      te.end_datetime,
      te.log_data,
      te.num_retries
  FROM logging.task_executions te
  JOIN meta.task t ON t.task_id = te.task_id
  WHERE t.object_name = 'wostatus'
  ORDER BY te.start_datetime DESC;
  ```

- Row count history for a specific object:
    (Note, if the bronze or silver row count status are NULL, it may be because the runs have not executed yet, hence the need for the run status)
    
  ```SQL
  SELECT
      RCA.extract_task_id
      , RCA.bronze_lh_row_count
      , RCA.silver_lh_row_count
      , RCA.parent_run_id
      , RCA.bronze_run_status 
      , RCA.silver_run_status
  FROM logging.row_count_audit RCA
  WHERE LOWER(RCA.source_table) = 'maximo.wostatus'
  ORDER BY RCA.ingestion_timestamp DESC;
  ```

These queries can be embedded into Power BI or Fabric Warehouse/Lakehouse for monitoring dashboards.

## Email Alerts Pipeline

Beyond Fabric Monitor, Foundation provides an alert pipeline that sends email notifications when key events occur.

### What the alert pipeline does

- Sends an email to one or more **configured recipients** when:

  - A pipeline or task **fails**.
  - Optionally, when a pipeline **completes successfully** (e.g. for critical nightly jobs).

- Emails typically include:

  - Environment (Dev/Test/Prod).
  - Task name and stage (`Extract`, `Load to bronze`, `Load to silver`).
  - Status (Failed / Succeeded).
  - Error message (for failures).
  - Link to Fabric Monitor (`pipeline_run_url`).
  - Timestamp of the run.

### How it is triggered

The alert pipeline is designed to be triggered programmatically, not manually:

- **From `pl_orchestrator`**:
  - On task completion, `pl_orchestrator` checks the status (Success/Failed).
  - If the task meets the alert criteria (e.g. `status = 'Failed'` or “any Extract failure”), it calls the alert pipeline with parameters like:
    - `task_executions_id`
    - `severity`
    - `recipient_list`
- **From worker pipelines**:
  - In some cases, the worker pipeline can directly trigger the alert pipeline (for example, on a validation failure).

### How to configure recipients & behavior

Depending on the implementation, recipient lists and behavior can be configured via:

- **Pipeline parameters**:
  - e.g. a `email_to` parameter that can be set per environment or per pipeline.
- **Variable Library**:
  - e.g. `vl_alerts` containing an environment-specific distribution list.
- **Metadata**:
  - A future enhancement could store alert configuration in a metadata table (e.g. per `object_name`/stage), similar to `scheduling_settings`.

Operational guidance

- Use **distribution lists** (e.g. `dataops-alerts@NRFC.com`) instead of individual addresses so membership can be managed by NRFC.
- Consider different lists for:
  - Dev/Test vs Prod.
  - High-priority vs low-priority pipelines.

## Managing the Scheduler & Cadence for `pl_orchestrator`

This section explains how to run the metadata-driven framework on a predictable schedule and control how often tasks are executed. For detailed field-level definitions of scheduling metadata, see [Scheduling](/02-Metadata-Framework/Scheduling.md).

### Scheduling model recap

Each task has a `scheduling_settings` JSON column in `meta.task`, which typically looks like:

```json
{"schedule_type":"time_of_day","scheduled_times":["10:00","12:45"],"skip_if_running":"true"}
```

Key concepts (see Scheduling.md for full details):

- `schedule_type`:
  - `"time_of_day"` – run one or more times per day, or at a fixed frequency in minutes.
  - `"monthly"` – run on a specific day/time each month.
  - `"yearly"` – run once a year on a specific month/day/time.
- `scheduled_times` (for `time_of_day`) – list of **UTC** times (e.g. `"10:00"`).
- `frequency_minutes` (for `time_of_day`) – run every N minutes.
- `skip_if_running` – if `true`, the scheduler **does not** start a new run when a previous instance is still active.

`meta.usp_get_tasks_due_for_execution` interprets this JSON and returns only the rows that should run at the current time.

### Scheduling `pl_scheduler` in Fabric

`pl_scheduler` itself must be scheduled using Fabric’s pipeline scheduling UI:

1. Open `pl_scheduler` in Fabric.
2. Click **Schedule**.
![scheduler](.images/schedule.png)
3. Configure:
   - **Frequency** (e.g. every 15 minutes).
   - Start date/time.
   - Time zone (remember that `scheduling_settings` uses **UTC**).

**Guidance:**

- For most workloads, running `pl_scheduler` every **15 minutes** is a good starting point.
- For very latency-sensitive use cases, you can reduce to **5 minutes**, but consider downstream system load.
- For purely batch/nightly jobs, you can run `pl_scheduler` less frequently (e.g. every hour) if all schedules are based on `time_of_day`.

Because `pl_scheduler` is safe and lightweight, you can run it **more frequently** than any individual task is scheduled; the metadata controls when each task is actually allowed to run.

### How `pl_orchestrator` cadence works

`pl_orchestrator` is **not** scheduled directly in Fabric. Instead:

- It is invoked **on demand** by `pl_scheduler` whenever there are tasks due.
- Each scheduler run may result in:

  - Zero orchestrator runs (no tasks due).
  - One orchestrator run with many tasks.
  - Multiple orchestrator invocations if you choose to segment by stage or group.

Therefore, the **effective cadence** of `pl_orchestrator` is a function of:

1. How often `pl_scheduler` runs.
2. How individual tasks are configured in `scheduling_settings`.

### Examples

**Example 1 – Hourly Extract, nightly Load to Silver**

- Extract tasks:
  - `scheduling_settings` = `{"schedule_type":"time_of_day","frequency_minutes":60 "skip_if_running":"true"}`
- Load to Bronze:
  - May run directly after Extract as part of the same orchestration flow, or on its own schedule.
- Load to Silver:
  - `scheduling_settings` = `{"schedule_type":"time_of_day","scheduled_times":["09:00"],"skip_if_running":"true"}`

With `pl_scheduler` running every 15 minutes:

- Extract tasks are considered every 15 minutes, but run **at most once per hour**.
- Silver loads only run shortly after 09:00 UTC.

**Example 2 – Specific intraday times**

- A critical table should run at **02:00, 06:00, and 10:00 UTC**:

  ```json
  {
    "schedule_type": "time_of_day",
    "scheduled_times": ["02:00","06:00","10:00"],
    "skip_if_running": "true"
  }
  ```

As long as `pl_scheduler` runs at least every 15 minutes, it will catch each window and trigger the task once.

### Operational tasks for managing the scheduler

Typical operations for platform owners / data engineers:

- **Enable/disable a task**:
  - Set `enabled = 0` in `meta.task` to prevent any execution, regardless of schedule.
- **Pause a schedule without deleting configuration**:
  - Option 1: Set `schedule_type` to `null` (or an empty JSON).
  - Option 2: Temporarily set `enabled = 0` for that specific stage.
- **Change cadence**:
  - Update `scheduling_settings` JSON:
    - Adjust `frequency_minutes` (e.g. 60 → 30).
    - Add/remove `scheduled_times`.
- **Ad-hoc or backfill runs**:
  - Manually trigger `pl_orchestrator` or worker pipelines directly from Fabric with specific parameters (e.g. `task_id` and a custom watermark), outside of scheduling.
  - Be careful to coordinate with `skip_if_running` and existing schedules to avoid overlap.