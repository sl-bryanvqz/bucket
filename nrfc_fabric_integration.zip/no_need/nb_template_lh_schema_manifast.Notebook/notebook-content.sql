-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "synapse_pyspark"
-- META   },
-- META   "dependencies": {}
-- META }

-- CELL ********************

-- This notebook that stores  DDL statements as a Python dictionary of strings.
-- Nameing Standard: 
-- nb_source_target_lh_schema_manifest_vxx.xx
-- template : raw, base, curated
-- For raw_sourcename: example: nb_rmdr_plus_sap_raw_lh_schema_manifest_v01.00


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

/* Metadata for reference entities
            -- Core
            natural_key_hash STRING,
            source_system STRING,
            -- Timing
            inserted_date_time TIMESTAMP,
            updated_date_time TIMESTAMP,
            -- Change tracking
            is_deleted BOOLEAN,
            -- Operational (light)
            load_date DATE,
            ingestion_id STRING
*/
-- Constraints are informational, not transactional enforcement like in SQL Server.

-- We don't partion reference tables
-- we partion Transactional tables

/* Metadata for transactional entities 

            -- Core
            natural_key_hash STRING,
            source_system STRING,
            -- Timing
            inserted_date_time TIMESTAMP,
            updated_date_time TIMESTAMP,
            -- Change tracking
                -- Operational (light)
            load_date DATE,
             ingestion_id STRING
             
PARTITIONED BY (transaction_date) -- this is real transaction date no process date)
*/

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


%%pyspark

SQL_TABLES = {
    "reference_table": """
        CREATE TABLE IF NOT EXISTS dbo.reference_table (
            customer_id INT NOT NULL COMMENT 'Unique customer identifier',
            first_name STRING COMMENT 'Customer first name',
            last_name STRING COMMENT 'Customer last name',
            email STRING COMMENT 'Customer email address',

            --Metadata
            natural_key_hash STRING,
            source_system STRING,
            inserted_date_time TIMESTAMP,
            updated_date_time TIMESTAMP,
            is_deleted BOOLEAN,
            load_date DATE,
            record_source_file STRING,
            ingestion_id STRING


            CONSTRAINT pk_customer PRIMARY KEY (customer_id)
        )
        USING DELTA
        LOCATION 'Tables/base on design'


        TBLPROPERTIES (
            'delta.autoOptimize.optimizeWrite' = 'true',
            'delta.autoOptimize.autoCompact' = 'true',
            'delta.logRetentionDuration' = 'interval 30 days',
            'delta.deletedFileRetentionDuration' = 'interval 7 days'
        )
    """,

    "transactional_table": """
        CREATE TABLE IF NOT EXISTS dbo.transactional_table (
            order_id INT NOT NULL COMMENT 'Unique order ID',
            customer_id INT NOT NULL COMMENT 'Customer reference ID',
            order_date DATE COMMENT 'Date of the order',
            amount DOUBLE COMMENT 'Order total amount',
            natural_key_hash STRING,
            source_system STRING,
            inserted_date_time TIMESTAMP,
            updated_date_time TIMESTAMP,
            load_date DATE,
             ingestion_id STRING
             
            


            CONSTRAINT pk_order PRIMARY KEY (order_id),
            CONSTRAINT valid_amount CHECK (amount >= 0)
        )
        USING DELTA
        LOCATION 'Tables/base on design'
        PARTITIONED BY (transaction_date)
        COMMENT 'Orders fact table'

        TBLPROPERTIES (
            'delta.autoOptimize.optimizeWrite' = 'true',
            'delta.autoOptimize.autoCompact' = 'true',
            'delta.logRetentionDuration' = 'interval 30 days',
            'delta.deletedFileRetentionDuration' = 'interval 7 days'
            
        )
    """
}



-- METADATA ********************

-- META {
-- META   "language": "python",
-- META   "language_group": "synapse_pyspark"
-- META }
