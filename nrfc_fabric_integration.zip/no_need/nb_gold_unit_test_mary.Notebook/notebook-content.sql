-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "synapse_pyspark"
-- META   },
-- META   "dependencies": {
-- META     "lakehouse": {
-- META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
-- META       "default_lakehouse_name": "lh_canada_global_mds",
-- META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
-- META       "known_lakehouses": [
-- META         {
-- META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
-- META         }
-- META       ]
-- META     },
-- META     "warehouse": {}
-- META   }
-- META }

-- MARKDOWN ********************

-- 1. All CAST('cmidb' AS STRING)   should change to '' , description region pass blank  

-- MARKDOWN ********************

-- ### Matter

-- CELL ********************

-- MAGIC %%sql
-- MAGIC DESCRIBE lh_canada_global_mds.gold_master.gold_master_matter;

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

-- Welcome to your new notebook
-- Type here in the cell editor to add code!
WITH fk_counts AS (

SELECT STACK(
14,

'member_firm_code', CAST(member_firm_code AS STRING),
'billing_office_key', CAST(billing_office_key AS STRING),
'nature_of_proceeding_key', CAST(nature_of_proceeding_key AS STRING),
'matter_status_key', CAST(matter_status_key AS STRING),
'matter_company_code', CAST(matter_company_code AS STRING),
'client_key', CAST(client_key AS STRING),
'practice_group_key', CAST(practice_group_key AS STRING),
'matter_category_key', CAST(matter_category_key AS STRING),
'currency_code', CAST(currency_code AS STRING),
'matter_billing_frequency_key', CAST(matter_billing_frequency_key AS STRING),
'matter_sector_key', CAST(matter_sector_key AS STRING),
'team_key', CAST(team_key AS STRING),
'matter_entry_type_key', CAST(matter_entry_type_key AS STRING),
'work_type_key', CAST(work_type_key AS STRING)

) AS (fk_column, fk_value)

FROM lh_canada_global_mds.gold_master.dev_gold_master_matter

)

SELECT
    fk_column,
    COUNT(*) AS total_rows,
    COUNT(DISTINCT fk_value) AS distinct_count,
    SUM(CASE WHEN fk_value IS NULL THEN 1 ELSE 0 END) AS null_count,
    SUM(CASE WHEN TRIM(fk_value) = '-1' THEN 1 ELSE 0 END) AS minus1_count,
    SUM(
        CASE
            WHEN fk_value IS NULL
              OR TRIM(fk_value) = '-1'
            THEN 1
            ELSE 0
        END
    ) AS null_or_minus1_count,

    COUNT(DISTINCT CASE
        WHEN fk_value IS NOT NULL
         AND TRIM(fk_value) <> '-1'
        THEN fk_value
    END) AS valid_distinct_count

FROM fk_counts
GROUP BY fk_column
ORDER BY null_or_minus1_count DESC;


--matter_entry_type_key

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- MARKDOWN ********************

-- ### Person

-- CELL ********************

WITH fk_counts AS (

SELECT STACK(
8,

'member_firm_code', CAST(member_firm_code AS STRING),
'team_key', CAST(team_key AS STRING),
'practice_group_key', CAST(practice_group_key AS STRING),
'cost_centre_code', CAST(cost_centre_code AS STRING),
'company_key', CAST(company_key AS STRING),
'office_key', CAST(office_key AS STRING),
'employee_sub_group_key', CAST(employee_sub_group_key AS STRING),
'band_level_key', CAST(band_level_key AS STRING)

) AS (fk_column, fk_value)

FROM lh_canada_global_mds.gold_master.dev_gold_master_person

)

SELECT
    fk_column,
    COUNT(*) AS total_rows,
    COUNT(DISTINCT fk_value) AS distinct_count,
    SUM(CASE WHEN fk_value IS NULL THEN 1 ELSE 0 END) AS null_count,
    SUM(CASE WHEN TRIM(fk_value) = '-1' THEN 1 ELSE 0 END) AS minus1_count,

    SUM(
        CASE
            WHEN fk_value IS NULL
              OR TRIM(fk_value) = '-1'
            THEN 1
            ELSE 0
        END
    ) AS null_or_minus1_count,

    COUNT(
        DISTINCT CASE
            WHEN fk_value IS NOT NULL
             AND TRIM(fk_value) <> '-1'
            THEN fk_value
        END
    ) AS valid_distinct_count

FROM fk_counts
GROUP BY fk_column
ORDER BY null_or_minus1_count DESC;

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- MARKDOWN ********************

-- ### Client 

-- CELL ********************

DESCRIBE lh_canada_global_mds.gold_master.gold_master_client;

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

WITH fk_counts AS (

SELECT STACK(
7,
'client_key', CAST(client_key AS STRING),
'member_firm_code', CAST(member_firm_code AS STRING),
--'client_category_key', CAST(client_category_key AS STRING),
'client_programme_key', CAST(client_programme_key AS STRING),
--'client_status_key', CAST(client_status_key AS STRING),
--'company_code_key', CAST(company_code_key AS STRING),
'client_sector_key', CAST('client_sector_key' AS STRING),
'client_practice_group', CAST(client_practice_group AS STRING),
--client_industry_key', CAST(client_industry_key AS STRING),
--'client_type_key', CAST(client_type_key AS STRING)

) AS (fk_column, fk_value)

FROM lh_canada_global_mds.gold_master.dev_gold_master_client

)

SELECT
    fk_column,
    COUNT(*) AS total_rows,
    COUNT(DISTINCT fk_value) AS distinct_count,

    SUM(CASE WHEN fk_value IS NULL THEN 1 ELSE 0 END) AS null_count,

    SUM(
        CASE
            WHEN TRIM(fk_value) = '-1'
            THEN 1
            ELSE 0
        END
    ) AS minus1_count,

    SUM(
        CASE
            WHEN fk_value IS NULL
                 OR TRIM(fk_value) = '-1'
            THEN 1
            ELSE 0
        END
    ) AS null_or_minus1_count,

    COUNT(
        DISTINCT CASE
            WHEN fk_value IS NOT NULL
             AND TRIM(fk_value) <> '-1'
            THEN fk_value
        END
    ) AS valid_distinct_count

FROM fk_counts
GROUP BY fk_column
ORDER BY null_or_minus1_count DESC;

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- MARKDOWN ********************

-- ### Address

-- CELL ********************

WITH fk_counts AS (

SELECT STACK(
5,
'member_firm_code', CAST(member_firm_code AS STRING),
'client_key', CAST(client_key AS STRING),
'address_type_code', CAST(address_type_code AS STRING),
'country_code_iso2', CAST(country_code_iso2 AS STRING)


) AS (fk_column, fk_value)

FROM lh_canada_global_mds.gold_master.dev_gold_master_address

)

SELECT
    fk_column,
    COUNT(*) AS total_rows,
    COUNT(DISTINCT fk_value) AS distinct_count,

    SUM(CASE WHEN fk_value IS NULL THEN 1 ELSE 0 END) AS null_count,

    SUM(
        CASE
            WHEN TRIM(fk_value) = '-1'
            THEN 1
            ELSE 0
        END
    ) AS minus1_count,

    SUM(
        CASE
            WHEN fk_value IS NULL
                 OR TRIM(fk_value) = '-1'
            THEN 1
            ELSE 0
        END
    ) AS null_or_minus1_count,

    COUNT(
        DISTINCT CASE
            WHEN fk_value IS NOT NULL
             AND TRIM(fk_value) <> '-1'
            THEN fk_value
        END
    ) AS valid_distinct_count

FROM fk_counts
GROUP BY fk_column
ORDER BY null_or_minus1_count DESC;

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

-- MAGIC %%pyspark
-- MAGIC # Fabric Notebook - Check for NULL values in Primary Key columns for all RMDD tables
-- MAGIC 
-- MAGIC from pyspark.sql.types import StructType, StructField, StringType, LongType
-- MAGIC 
-- MAGIC target_schema = "silver_rmdd"
-- MAGIC 
-- MAGIC table_config = [
-- MAGIC     {"source_table":"Address","target_pk":["address_id"]},
-- MAGIC     {"source_table":"Client","target_pk":["client_number","member_firm_code"]},
-- MAGIC     {"source_table":"Cost_Centre","target_pk":["cost_centre_code","member_firm_code","valid_from_date"]},
-- MAGIC     {"source_table":"Country","target_pk":["country_id"]},
-- MAGIC     {"source_table":"Email","target_pk":["entity_id"]},
-- MAGIC     {"source_table":"Employee_Sub_Group","target_pk":["sub_group_id"]},
-- MAGIC     {"source_table":"Matter","target_pk":["matter_number","member_firm_code"]},
-- MAGIC     {"source_table":"Matter_Office","target_pk":["office_id","matter_id"]},
-- MAGIC     {"source_table":"Matter_Status","target_pk":["matter_status_id"]},
-- MAGIC     {"source_table":"Office","target_pk":["office_id"]},
-- MAGIC     {"source_table":"Person","target_pk":["person_number","member_firm_code"]},
-- MAGIC     {"source_table":"Person_Cost_Centre","target_pk":["person_cost_centre_id"]},
-- MAGIC     {"source_table":"Person_Locale","target_pk":["person_id"]},
-- MAGIC     {"source_table":"Person_Relationship","target_pk":["person_relationship_id"]},
-- MAGIC     {"source_table":"Person_System_Map","target_pk":["person_id"]},
-- MAGIC     {"source_table":"Phone","target_pk":["entity_id","entity_type_code","phone_type_code"]},
-- MAGIC     {"source_table":"Relationship_Type","target_pk":["relationship_type_id"]},
-- MAGIC     {"source_table":"Sub_Team","target_pk":["sub_team_id"]},
-- MAGIC     {"source_table":"Team","target_pk":["team_id"]}
-- MAGIC ]
-- MAGIC 
-- MAGIC results = []
-- MAGIC 
-- MAGIC for table in table_config:
-- MAGIC 
-- MAGIC     table_name = f"{target_schema}.{target_schema}_{table['source_table'].lower()}"
-- MAGIC 
-- MAGIC     try:
-- MAGIC         df = spark.table(table_name)
-- MAGIC 
-- MAGIC         null_condition = " OR ".join(
-- MAGIC             [f"`{col}` IS NULL" for col in table["target_pk"]]
-- MAGIC         )
-- MAGIC 
-- MAGIC         null_count = df.filter(null_condition).count()
-- MAGIC 
-- MAGIC         results.append(
-- MAGIC             (
-- MAGIC                 table_name,
-- MAGIC                 ",".join(table["target_pk"]),
-- MAGIC                 int(null_count),
-- MAGIC                 "PASS" if null_count == 0 else "FAIL"
-- MAGIC             )
-- MAGIC         )
-- MAGIC 
-- MAGIC     except Exception as ex:
-- MAGIC 
-- MAGIC         results.append(
-- MAGIC             (
-- MAGIC                 table_name,
-- MAGIC                 ",".join(table["target_pk"]),
-- MAGIC                 -1,
-- MAGIC                 f"ERROR: {str(ex)}"
-- MAGIC             )
-- MAGIC         )
-- MAGIC 
-- MAGIC schema = StructType([
-- MAGIC     StructField("table_name", StringType(), True),
-- MAGIC     StructField("pk_columns", StringType(), True),
-- MAGIC     StructField("null_pk_count", LongType(), True),
-- MAGIC     StructField("status", StringType(), True)
-- MAGIC ])
-- MAGIC 
-- MAGIC results_df = spark.createDataFrame(results, schema)
-- MAGIC 
-- MAGIC display(results_df.orderBy("null_pk_count", ascending=False))

-- METADATA ********************

-- META {
-- META   "language": "python",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

-- MAGIC %%pyspark
-- MAGIC from pyspark.sql.types import StructType, StructField, StringType, LongType
-- MAGIC 
-- MAGIC target_schema = "silver_gmdr"
-- MAGIC 
-- MAGIC table_config = [
-- MAGIC     {"target_table":"silver_gmdr_sap_ihpa","target_pk":["pspid","parvw"]},
-- MAGIC     {"target_table":"silver_gmdr_sap_kna1","target_pk":["kunnr"]},
-- MAGIC     {"target_table":"silver_gmdr_sap_knvk","target_pk":["parnr","client_number"]},
-- MAGIC     {"target_table":"silver_gmdr_sap_pa0000","target_pk":["person_number"]},
-- MAGIC     {"target_table":"silver_gmdr_sap_pa0001","target_pk":["pernr"]},
-- MAGIC     {"target_table":"silver_gmdr_sap_pa9007","target_pk":["pernr"]},
-- MAGIC     {"target_table":"silver_gmdr_sap_pa0709","target_pk":["person_number"]},
-- MAGIC     {"target_table":"silver_gmdr_sap_proj","target_pk":["pspid"]},
-- MAGIC     {"target_table":"silver_gmdr_sap_zprs_mat_ph_set","target_pk":["zzpspid"]},
-- MAGIC     {"target_table":"silver_gmdr_sap_zprs_mattercatt","target_pk":["mattercat"]},
-- MAGIC     {"target_table":"silver_gmdr_sap_zprs_tkalocclnt","target_pk":["client_number","person_number","begin_date"]},
-- MAGIC     {"target_table":"silver_gmdr_sap_zprs_tkalocmattr","target_pk":["matter_number","member_firm_code","person_number","begin_date","partner_function_code","office_code","team_code"]}
-- MAGIC ]
-- MAGIC 
-- MAGIC results = []
-- MAGIC 
-- MAGIC for table in table_config:
-- MAGIC 
-- MAGIC     table_name = f"{target_schema}.{table['target_table']}"
-- MAGIC 
-- MAGIC     try:
-- MAGIC 
-- MAGIC         df = spark.table(table_name)
-- MAGIC 
-- MAGIC         null_condition = " OR ".join(
-- MAGIC             [f"`{col}` IS NULL" for col in table["target_pk"]]
-- MAGIC         )
-- MAGIC 
-- MAGIC         null_count = df.filter(null_condition).count()
-- MAGIC 
-- MAGIC         results.append(
-- MAGIC             (
-- MAGIC                 table_name,
-- MAGIC                 ",".join(table["target_pk"]),
-- MAGIC                 int(null_count),
-- MAGIC                 "PASS" if null_count == 0 else "FAIL"
-- MAGIC             )
-- MAGIC         )
-- MAGIC 
-- MAGIC     except Exception as ex:
-- MAGIC 
-- MAGIC         results.append(
-- MAGIC             (
-- MAGIC                 table_name,
-- MAGIC                 ",".join(table["target_pk"]),
-- MAGIC                 -1,
-- MAGIC                 f"ERROR: {str(ex)}"
-- MAGIC             )
-- MAGIC         )
-- MAGIC 
-- MAGIC schema = StructType([
-- MAGIC     StructField("table_name", StringType(), True),
-- MAGIC     StructField("pk_columns", StringType(), True),
-- MAGIC     StructField("null_pk_count", LongType(), True),
-- MAGIC     StructField("status", StringType(), True)
-- MAGIC ])
-- MAGIC 
-- MAGIC results_df = spark.createDataFrame(results, schema)
-- MAGIC 
-- MAGIC display(results_df.orderBy("table_name"))

-- METADATA ********************

-- META {
-- META   "language": "python",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

-- MAGIC %%pyspark
-- MAGIC from pyspark.sql.types import StructType, StructField, StringType, LongType
-- MAGIC 
-- MAGIC target_schema = "gold_master"
-- MAGIC 
-- MAGIC table_config = [
-- MAGIC     {
-- MAGIC         "target_table": "dev_gold_master_address",
-- MAGIC         "target_pk": ["address_id", "client_number", "member_firm_code"]
-- MAGIC     },
-- MAGIC     {
-- MAGIC         "target_table": "dev_gold_master_client",
-- MAGIC         "target_pk": ["client_number", "member_firm_code"]
-- MAGIC     },
-- MAGIC     {
-- MAGIC         "target_table": "dev_gold_master_client_partner_allocation",
-- MAGIC         "target_pk": ["client_number", "member_firm_code", "person_number", "partner_function_key", "begin_date"]
-- MAGIC     },
-- MAGIC     {
-- MAGIC         "target_table": "dev_gold_master_cost_centre",
-- MAGIC         "target_pk": ["cost_centre_code", "member_firm_code", "valid_from_date"]
-- MAGIC     },
-- MAGIC     {
-- MAGIC         "target_table": "dev_gold_master_matter",
-- MAGIC         "target_pk": ["matter_number", "member_firm_code"]
-- MAGIC     },
-- MAGIC     {
-- MAGIC         "target_table": "dev_gold_master_matter_partner_allocation",
-- MAGIC         "target_pk": ["matter_number", "member_firm_code", "person_number", "partner_function_key", "office_key", "team_key", "begin_date"]
-- MAGIC     },
-- MAGIC     {
-- MAGIC         "target_table": "dev_gold_master_person",
-- MAGIC         "target_pk": ["person_number", "member_firm_code"]
-- MAGIC     }
-- MAGIC ]
-- MAGIC 
-- MAGIC results = []
-- MAGIC 
-- MAGIC for table in table_config:
-- MAGIC 
-- MAGIC     table_name = f"{target_schema}.{table['target_table']}"
-- MAGIC 
-- MAGIC     try:
-- MAGIC 
-- MAGIC         df = spark.table(table_name)
-- MAGIC 
-- MAGIC         null_condition = " OR ".join(
-- MAGIC             [f"`{col}` IS NULL" for col in table["target_pk"]]
-- MAGIC         )
-- MAGIC 
-- MAGIC         null_count = df.filter(null_condition).count()
-- MAGIC 
-- MAGIC         results.append(
-- MAGIC             (
-- MAGIC                 table_name,
-- MAGIC                 ",".join(table["target_pk"]),
-- MAGIC                 int(null_count),
-- MAGIC                 "PASS" if null_count == 0 else "FAIL"
-- MAGIC             )
-- MAGIC         )
-- MAGIC 
-- MAGIC     except Exception as ex:
-- MAGIC 
-- MAGIC         results.append(
-- MAGIC             (
-- MAGIC                 table_name,
-- MAGIC                 ",".join(table["target_pk"]),
-- MAGIC                 -1,
-- MAGIC                 f"ERROR: {str(ex)}"
-- MAGIC             )
-- MAGIC         )
-- MAGIC 
-- MAGIC schema = StructType([
-- MAGIC     StructField("table_name", StringType(), True),
-- MAGIC     StructField("pk_columns", StringType(), True),
-- MAGIC     StructField("null_pk_count", LongType(), True),
-- MAGIC     StructField("status", StringType(), True)
-- MAGIC ])
-- MAGIC 
-- MAGIC results_df = spark.createDataFrame(results, schema)
-- MAGIC 
-- MAGIC display(results_df.orderBy("table_name"))

-- METADATA ********************

-- META {
-- META   "language": "python",
-- META   "language_group": "synapse_pyspark"
-- META }
