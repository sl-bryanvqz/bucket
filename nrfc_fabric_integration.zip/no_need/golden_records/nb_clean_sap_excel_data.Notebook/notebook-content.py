# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import pandas as pd

xls = pd.ExcelFile("/lakehouse/default/Files/csv_data/Matters by Clients by Employees.xlsx")

for sheet in xls.sheet_names:
    df = pd.read_excel(xls, sheet_name=sheet)
    print(sheet, len(df))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Step 2: Load all Excel tabs dynamically

import pandas as pd

# Replace with your actual file path
xls = pd.ExcelFile("/lakehouse/default/Files/csv_data/Matters by Clients by Employees.xlsx")

# Dictionary to hold all dataframes
dfs = {}

for sheet in xls.sheet_names:

    # Convert sheet name to a Fabric-friendly table name
    table_name = (
        sheet.strip()
             .lower()
             .replace(" ", "_")
             .replace("-", "_")
    )

    # Read sheet
    df = pd.read_excel(xls, sheet_name=sheet)

    # Store in dictionary
    dfs[table_name] = df

    print(f"Loaded sheet '{sheet}' -> table '{table_name}' ({len(df)} rows)")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import re

for table_name, df in dfs.items():

    # Clean column names
    df.columns = [
        re.sub(r'[^a-zA-Z0-9_]', '_', str(col)).strip('_')
        for col in df.columns
    ]

    # Handle duplicate column names
    seen = {}
    new_cols = []

    for col in df.columns:
        if col in seen:
            seen[col] += 1
            new_cols.append(f"{col}_{seen[col]}")
        else:
            seen[col] = 0
            new_cols.append(col)

    df.columns = new_cols
    
    # Step 3: Create Delta tables in Lakehouse
    spark.createDataFrame(df) \
        .write \
        .mode("overwrite") \
        .saveAsTable(table_name)

    print(f"Created table: {table_name}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("SHOW TABLES").show(truncate=False)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.table("matters_by_clients").columns

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for t in [
    "matters_by_clients",
    "clients",
    "matter_allocations",
    "client_allocations",
    "costcenter"
]:
    print(t)
    spark.sql(f"select count(*) from {t}").show()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(spark.table("matters_by_clients").limit(5))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC CREATE OR REPLACE VIEW vw_matter_dashboard AS
# MAGIC SELECT
# MAGIC     m.*,
# MAGIC     c.client_name
# MAGIC FROM matters_by_clients m
# MAGIC LEFT JOIN clients c
# MAGIC     ON m.Client = c.client_number;

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
