# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    source_table              = "person_relationship"
    map_view                  = f"map_{source_table}"
    target_workspace          = "ws_canada_global_mds_dev"
    target_lakehouse          = "lh_canada_global_mds"
    target_table              = f"gold_master_{source_table}"
    target_pk                 = ["person_number_1"]
    limit_rows_for_debugging  = True
    watermark_filter          = "1=1"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"map_view: {map_view}")
    print(f"target_workspace: {target_workspace}")
    print(f"map_view: {map_view}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
    SELECT
        row_number() OVER (ORDER BY p.person_id) AS person_relationship_key,
        p.person_number                     AS person_number_1,
        p.member_firm_code                  AS member_firm_code_1,
        'mds_person'                        AS person_number_2,
        'mds_person'                        AS member_firm_code_2,
        rt.relationship_description         AS relationship_description,
        pr.primary_flag                     AS primary_flag,
        pr.is_active                        AS is_active,
        pr.last_updated_date_utc_at_source  AS last_updated_date_utc_at_source
FROM {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_person p
    LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_person_relationship pr
        ON p.person_id = pr.person_id_1
    LEFT JOIN {target_workspace}.{target_lakehouse}.silver_rmdd.silver_rmdd_relationship_type rt
        ON pr.relationship_type_id = rt.relationship_type_id
WHERE {watermark_filter}
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
