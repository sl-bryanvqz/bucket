# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

def compare_dev_tables_case_insensitive(schema_name, dev_prefix="dev_"):
    tables = {t.name for t in spark.catalog.listTables(schema_name)}
    base_tables = [t for t in tables if not t.startswith(dev_prefix)]

    differences_found = False

    for base_table in sorted(base_tables):
        dev_table = f"{dev_prefix}{base_table}"

        if dev_table not in tables:
            print(f"\nWarning: Dev table not found -> {schema_name}.{dev_table}")
            continue

        base_df = spark.table(f"{schema_name}.{base_table}")
        dev_df = spark.table(f"{schema_name}.{dev_table}")

        base_columns = {
            field.name.lower(): field.dataType.simpleString()
            for field in base_df.schema.fields
        }

        dev_columns = {
            field.name.lower(): field.dataType.simpleString()
            for field in dev_df.schema.fields
        }

        base_col_set = set(base_columns.keys())
        dev_col_set = set(dev_columns.keys())

        only_in_base = base_col_set - dev_col_set
        only_in_dev = dev_col_set - base_col_set

        type_differences = []
        for col in base_col_set.intersection(dev_col_set):
            if base_columns[col] != dev_columns[col]:
                type_differences.append((col, base_columns[col], dev_columns[col]))

        if only_in_base or only_in_dev or type_differences:
            differences_found = True
            print("\n" + "=" * 100)
            print(f"TABLE: {schema_name}.{base_table} <-> {schema_name}.{dev_table}")
            print("=" * 100)

            if only_in_base:
                print("\nColumns only in BASE table:")
                for col in sorted(only_in_base):
                    print(f"  - {col}")

            if only_in_dev:
                print("\nColumns only in DEV table:")
                for col in sorted(only_in_dev):
                    print(f"  - {col}")

            if type_differences:
                print("\nColumns with different data types:")
                for col, base_type, dev_type in type_differences:
                    print(f"  - {col}: BASE={base_type} | DEV={dev_type}")

    if not differences_found:
        print("No column differences found.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

compare_dev_tables_case_insensitive('gold_master', dev_prefix="dev_")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
