# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql.types import (
    ArrayType, BinaryType, BooleanType, ByteType, DataType, DateType, DecimalType,
    DoubleType, FloatType, IntegerType, LongType, MapType, NullType, ShortType,
    StringType, StructType, TimestampType
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def spark_type_to_sql(data_type: DataType) -> str:
    if isinstance(data_type, StringType):
        return "STRING"
    if isinstance(data_type, IntegerType):
        return "INT"
    if isinstance(data_type, LongType):
        return "BIGINT"
    if isinstance(data_type, ShortType):
        return "SMALLINT"
    if isinstance(data_type, ByteType):
        return "TINYINT"
    if isinstance(data_type, BooleanType):
        return "BOOLEAN"
    if isinstance(data_type, FloatType):
        return "FLOAT"
    if isinstance(data_type, DoubleType):
        return "DOUBLE"
    if isinstance(data_type, DecimalType):
        return f"DECIMAL({data_type.precision}, {data_type.scale})"
    if isinstance(data_type, DateType):
        return "DATE"
    if isinstance(data_type, TimestampType):
        return "TIMESTAMP"
    if isinstance(data_type, BinaryType):
        return "BINARY"
    if isinstance(data_type, ArrayType):
        return f"ARRAY<{spark_type_to_sql(data_type.elementType)}>"
    if isinstance(data_type, MapType):
        key_type = spark_type_to_sql(data_type.keyType)
        value_type = spark_type_to_sql(data_type.valueType)
        return f"MAP<{key_type}, {value_type}>"
    if isinstance(data_type, StructType):
        nested_fields = []
        for nested_field in data_type.fields:
            nested_sql_type = spark_type_to_sql(nested_field.dataType)
            nested_fields.append(f"{nested_field.name}: {nested_sql_type}")
        return f"STRUCT<{', '.join(nested_fields)}>"
    if isinstance(data_type, NullType):
        return "STRING"
    return data_type.simpleString().upper()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def build_create_table_sql(schema: StructType, schema_name: str, table_name: str) -> str:
    column_lines = []
    for field in schema.fields:
        sql_type = spark_type_to_sql(field.dataType)
        nullable_sql = "" if field.nullable else " NOT NULL"
        column_lines.append(f"    [{field.name}] {sql_type}{nullable_sql}")

    qualified_name = f"[{schema_name}].[{table_name}]" if schema_name else f"[{table_name}]"
    columns_sql = ",\n".join(column_lines)
    return f"CREATE TABLE {qualified_name} (\n{columns_sql}\n);"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

source_schema_name = 'lh_canada_global_mds.gold_master'

target_schema_name = source_schema_name


tables_df = spark.sql(f"SHOW TABLES IN {source_schema_name}")
table_names = [row.tableName for row in tables_df.collect() if not row.isTemporary]

if not table_names:
    raise ValueError(f"No tables found in schema: {source_schema_name}")

all_create_scripts = []

for table_name in sorted(table_names):
    full_source_name = f"{source_schema_name}.{table_name}"
    df = spark.read.table(full_source_name)

    create_table_sql = build_create_table_sql(
        schema=df.schema,
        schema_name=target_schema_name,
        table_name=table_name
    )
    all_create_scripts.append(create_table_sql)

    print(f"-- {full_source_name}")
    print(create_table_sql)
    print()

print(f"Generated {len(all_create_scripts)} CREATE TABLE statements.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
