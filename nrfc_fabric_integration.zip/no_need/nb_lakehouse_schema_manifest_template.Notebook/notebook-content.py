# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "d66a8795-61e5-4bd3-97ab-b9eb6508bf5a",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "a7ad27b1-6ad7-440f-bf78-030662ef90fd",
# META       "known_lakehouses": [
# META         {
# META           "id": "d66a8795-61e5-4bd3-97ab-b9eb6508bf5a"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Tables definition

# CELL ********************

schema_name = "base_mds4"
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

location_path = "Files/base/mds4"

tbl_properties = """
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite'     = 'true',
    'delta.autoOptimize.autoCompact'       = 'true',
    'delta.logRetentionDuration'           = 'interval 30 days',
    'delta.deletedFileRetentionDuration'   = 'interval 7 days'
)
"""

tables_definition = [
    {
        "table_name" : "base_mds4_address",
        "sql_statement" : """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name}(
            address_key                            BIGINT,
            address_id                             INT,
            address_type_code                      STRING,
            address_1                              STRING,
            
            _table                                 STRING,
            _lineage_id                            STRING,
            _effective_start_datetime              TIMESTAMP,
            _effective_end_datetime                TIMESTAMP,
            _current_flag                          BOOLEAN,
            hashed_pk                              STRING,
            hashed_row                             STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    },
    {
        "table_name" : "base_mds_client",
        "sql_statement" : """
        CREATE TABLE IF NOT EXISTS {schema_name}.{table_name} (
            client_key                             BIGINT,
            client_number                          STRING,
            member_firm_code                       STRING,
            client_id                              INT,
            pms_client_id                          INT,
            client_name                            STRING,
            alternate_client_name                  STRING,
            contact_name                           STRING,
            open_date_utc                          TIMESTAMP,
            close_date_utc                         TIMESTAMP,
            
            is_active                              BOOLEAN,
            created_date_utc_at_source             TIMESTAMP,
            last_updated_date_utc_at_source        TIMESTAMP,

        --metadata for reference entities
            _ingest_time                           TIMESTAMP,
            _ingest_date                           DATE,
            _source_file                           STRING,
            _source_system                         STRING,
            _table                                 STRING,
            _lineage_id                            STRING,
            _effective_start_datetime              TIMESTAMP,
            _effective_end_datetime                TIMESTAMP,
            _current_flag                          BOOLEAN,
            hashed_pk                              STRING,
            hashed_row                             STRING
        )
        USING DELTA
        LOCATION '{location_path}/{table_name}'
        {tbl_properties}
        """
    }
    
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for t in tables_definition:
    table_name = t["table_name"]

    sql = t["sql_statement"].format(
        schema_name=schema_name,
        table_name=table_name,
        location_path=location_path,
        tbl_properties=tbl_properties   
    )

    spark.sql(sql)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
