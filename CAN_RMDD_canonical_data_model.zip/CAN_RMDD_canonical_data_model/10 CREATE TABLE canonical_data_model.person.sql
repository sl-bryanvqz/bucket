--DROP TABLE IF EXISTS canonical_data_model.person

CREATE TABLE canonical_data_model.person(
person_key BIGINT IDENTITY NOT NULL
,person_number NVARCHAR(20) NOT NULL
,member_firm_code NVARCHAR(10) NOT NULL
,timekeeper_id NVARCHAR(20)
,person_id NVARCHAR(50) NOT NULL
,person_status_code NVARCHAR(50) NOT NULL
,gender NVARCHAR(1)
,prefix NVARCHAR(50)
,first_name NVARCHAR(50) NOT NULL
,first_name_known_as NVARCHAR(50) NOT NULL
,middle_name NVARCHAR(50)
,last_name NVARCHAR(50)
,suffix NVARCHAR(50)
,initials NVARCHAR(50)
,photo_path NVARCHAR(500)
,commencement_date_utc DATETIME
,departure_date_utc DATETIME
,leave_status NVARCHAR(200)
,team_key BIGINT
,job_title NVARCHAR(250)
,job_title_pms NVARCHAR(256)
,practice_group_key BIGINT
,year_of_call NVARCHAR(8)
,desk_location NVARCHAR(100)
,domain_name NVARCHAR(100)
,unified_sap_person_external_id NVARCHAR(20)
,windows_login NVARCHAR(100)
,dms_system_id NVARCHAR(100)
,human_resources_system_id NVARCHAR(100)
,work_phone_number NVARCHAR(24) NOT NULL
,work_phone_extension NVARCHAR(6)
,mobile_phone_number NVARCHAR(24) NOT NULL
,email_address NVARCHAR(100) NOT NULL
,employee_name_reporting NVARCHAR(256) NOT NULL
,cost_centre_code NVARCHAR(256)
,company_key BIGINT
,office_key BIGINT
,employee_sub_group_key BIGINT
,band_level_key BIGINT
,person_record_rank INT
,is_active BIT NOT NULL
,last_updated_date_utc_at_source DATETIME NOT NULL
,source_system NVARCHAR(100) NOT NULL
,inserted_process_instance_id NVARCHAR(100) NOT NULL
,updated_process_instance_id NVARCHAR(100) NOT NULL
,inserted_process_queue_id NVARCHAR(100) NOT NULL
,updated_process_queue_id NVARCHAR(100) NOT NULL
,inserted_date_time DATETIME NOT NULL
,updated_date_time DATETIME NOT NULL
,natural_key_hash NVARCHAR(100) NOT NULL
)