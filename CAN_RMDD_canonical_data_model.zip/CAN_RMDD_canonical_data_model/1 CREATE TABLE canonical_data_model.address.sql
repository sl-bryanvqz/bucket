CREATE TABLE canonical_data_model.address(
 address_key BIGINT IDENTITY
,address_id NVARCHAR(50)
,client_number NVARCHAR(50)
,member_firm_code NVARCHAR(50)
,client_key BIGINT
,address_type_code NVARCHAR(10)
,address_1 NVARCHAR(60)
,address_2 NVARCHAR(60)
,address_3 NVARCHAR(60)
,address_4 NVARCHAR(60)
,address_5 NVARCHAR(60)
,city NVARCHAR(50)
,country_code_iso2 NVARCHAR(50)
,state NVARCHAR(50)
,zip_code NVARCHAR(12)
,street_address_check NVARCHAR(500)
,is_active BIT
,last_updated_date_utc_at_source DATETIME
,source_system NVARCHAR(100)
,inserted_process_instance_id NVARCHAR(100)
,updated_process_instance_id NVARCHAR(100)
,inserted_process_queue_id NVARCHAR(100)
,updated_process_queue_id NVARCHAR(100)
,inserted_date_time DATETIME
,updated_date_time DATETIME
,natural_key_hash NVARCHAR(100)
)
