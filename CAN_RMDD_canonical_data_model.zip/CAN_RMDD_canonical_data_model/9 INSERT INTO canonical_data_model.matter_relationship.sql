
TRUNCATE TABLE canonical_data_model.matter_relationship
SELECT COUNT(*) FROM canonical_data_model.matter_relationship
--118,578

-- Matters to Migrate

DROP TABLE IF EXISTS #MatterstoMigrate

SELECT MatterID, MatterNumber, ClientID
INTO #MatterstoMigrate
FROM Matter
WHERE MemberFirmCode IN ('GPMS')
AND MatterStatusID IN (39,49,59,69,79)
UNION
SELECT MatterID, MatterNumber, ClientID
FROM Matter
WHERE MemberFirmCode IN ('GPMS')
AND MatterCloseDateGMT >= '2019-01-01'
--(280502 rows affected)
--(1148876 rows affected)

--==========================================================================================

INSERT INTO canonical_data_model.matter_relationship(
matter_number
,member_firm_code
,parent_matter_number
,parent_member_firm_code
,matter_relationship_type
,matter_key
,parent_matter_key
,source_system
,inserted_process_instance_id
,updated_process_instance_id
,inserted_process_queue_id
,updated_process_queue_id
,inserted_date_time
,updated_date_time
,natural_key_hash
)
SELECT
matter_number = mds_matter.MatterNumber
,member_firm_code = mds_matter.MemberFirmCode
,parent_matter_number = mds_parent_matter.MatterNumber
,parent_member_firm_code = mds_parent_matter.MemberFirmCode
,matter_relationship_type = 'Parent'
,matter_key	= c_matter.matter_key
,parent_matter_key = c_parent_matter.matter_key
,source_system = 'Internal'	
,inserted_process_instance_id = 'Internal'	
,updated_process_instance_id = 'Internal'	
,inserted_process_queue_id = 'Internal'	
,updated_process_queue_id = 'Internal'	
,inserted_date_time = GETUTCDATE()	
,updated_date_time = GETUTCDATE()
,natural_key_hash = 'Internal'	
FROM [dbo].Matter mds_matter
INNER JOIN #MatterstoMigrate MatterstoMigrate ON mds_matter.MatterID = MatterstoMigrate.MatterID
INNER JOIN [dbo].Matter mds_parent_matter ON mds_matter.ParentMatterID = mds_parent_matter.MatterID
LEFT JOIN [canonical_data_model].[matter] c_matter on mds_matter.MatterNumber = c_matter.matter_number AND mds_matter.MemberFirmCode = c_matter.member_firm_code
LEFT JOIN [canonical_data_model].[matter] c_parent_matter on mds_parent_matter.MatterNumber = c_parent_matter.matter_number AND mds_parent_matter.MemberFirmCode = c_matter.member_firm_code

