--DROP TABLE canonical_data_model.matter

CREATE TABLE canonical_data_model.matter(
matter_key BIGINT IDENTITY NOT NULL
,matter_number NVARCHAR(200) NOT NULL
,member_firm_code NVARCHAR(100) NOT NULL
,matter_id NVARCHAR(500) NOT NULL
,pms_matter_id NVARCHAR(500)
,matter_name NVARCHAR(2550) NOT NULL
,long_matter_name NVARCHAR(4000)
,alternate_matter_name NVARCHAR(2550)
,alternate_matter_number NVARCHAR(200)
,matter_create_date_utc DATETIME  NOT NULL
,matter_name_cmi NVARCHAR(2550) NOT NULL
,member_firm_code_cmi NVARCHAR(100)
,matter_description_cmi NVARCHAR(4000)
,billing_office_key BIGINT
,nature_of_proceeding_key BIGINT
,matter_status_key BIGINT
,matter_status_cmi_key BIGINT
,matter_company_code NVARCHAR(40)
,client_key BIGINT
,practice_group_key BIGINT
,matter_category_key BIGINT 
,is_confidential BIT
,matter_pass_through_flag BIT
,currency_code NVARCHAR(50)
,matter_jurisdiction_code_cmi NVARCHAR(100)
,matter_fee_estimate_cmi FLOAT
,matter_cost_estimate_cmi FLOAT
,matter_billing_frequency_key BIGINT
,matter_billing_method_key BIGINT
,matter_open_date_utc DATETIME
,matter_close_date_utc DATETIME
,matter_billable_flag INT
,matter_time_unit NVARCHAR(200)
,matter_sector_key BIGINT
,team_key BIGINT
,matter_purchase_order_number NVARCHAR(2550)
,ip_matter_number NVARCHAR(200)
,matter_entry_type_key BIGINT
,comments NVARCHAR(MAX)
,matter_pricing_group NVARCHAR(100)
,client_bill_contact_code NVARCHAR(100)
,client_bill_contact_name NVARCHAR(500)
,payer_code NVARCHAR(120)
,payer_name NVARCHAR(2550)
,z3_payer_code NVARCHAR(120)
,z3_payer_name NVARCHAR(2550)
,client_case_number NVARCHAR(2550)
,client_case_description NVARCHAR(2550)
,group_billing NVARCHAR(240)
,reporting_group NVARCHAR(240)
,is_sanctions_checked BIT
,is_security_wall_created BIT NOT NULL
,matter_phase_set_code NVARCHAR(2550)
,work_type_key BIGINT
,is_active BIT NOT NULL
,last_updated_date_utc_at_source DATETIME NOT NULL
,source_system NVARCHAR(1000) NOT NULL
,inserted_process_instance_id NVARCHAR(1000) NOT NULL
,updated_process_instance_id NVARCHAR(1000) NOT NULL
,inserted_process_queue_id NVARCHAR(1000) NOT NULL
,updated_process_queue_id NVARCHAR(1000) NOT NULL
,inserted_date_time DATETIME NOT NULL
,updated_date_time DATETIME NOT NULL
,natural_key_hash NVARCHAR(1000) NOT NULL
)