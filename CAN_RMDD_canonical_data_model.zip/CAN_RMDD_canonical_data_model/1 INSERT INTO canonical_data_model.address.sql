--truncate table canonical_data_model.address
--select top 10 * from canonical_data_model.address
--select count(*) from canonical_data_model.address
-- 46,818
--(39,574 rows affected)



-- Matters to Migrate

DROP TABLE IF EXISTS #MatterstoMigrate

SELECT MatterID, ClientID
INTO #MatterstoMigrate
FROM Matter
WHERE MemberFirmCode IN ('GPMS')
AND MatterStatusID IN (39,49,59,69,79)
UNION
SELECT MatterID, ClientID
FROM Matter
WHERE MemberFirmCode IN ('GPMS')
AND MatterCloseDateGMT >= '2019-01-01'
--(280502 rows affected)

-- Clients to Migrate
DROP TABLE IF EXISTS #ClientstoMigrate

SELECT ClientID
INTO #ClientstoMigrate
FROM Client 
WHERE MemberFirmCode IN ('GPMS')
AND ClientStatusID IN (19)
UNION 
SELECT c.ClientID
FROM Client c
JOIN #MatterstoMigrate m ON c.ClientID = m.ClientID

--=======================================

INSERT INTO canonical_data_model.address(
address_id
,client_number
,member_firm_code
,client_key
,address_type_code
,address_1
,address_2
,address_3
,address_4
,address_5
,city
,country_code_iso2
,state
,zip_code
,street_address_check
,is_active
,last_updated_date_utc_at_source
,source_system
,inserted_process_instance_id
,updated_process_instance_id
,inserted_process_queue_id
,updated_process_queue_id
,inserted_date_time
,updated_date_time
,natural_key_hash)
SELECT
address_id = CONVERT(NVARCHAR(50),mds_address.AddressID)
,client_number = mds_client.ClientNumber
,member_firm_code = mds_client.MemberFirmCode
,client_key	= canonical_client.client_key
,address_type_code = mds_address.AddressTypeCode
,address_1 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Address1, CHAR(9), ''), CHAR(10), ''),CHAR(12), ''), CHAR(13), ''), CHAR(22), ''), CHAR(32), '')
,address_2 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Address2, CHAR(9), ''), CHAR(10), ''),CHAR(12), ''), CHAR(13), ''), CHAR(22), ''), CHAR(32), '')
,address_3 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Address3, CHAR(9), ''), CHAR(10), ''),CHAR(12), ''), CHAR(13), ''), CHAR(22), ''), CHAR(32), '')
,address_4 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Address4, CHAR(9), ''), CHAR(10), ''),CHAR(12), ''), CHAR(13), ''), CHAR(22), ''), CHAR(32), '')
,address_5 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Address5, CHAR(9), ''), CHAR(10), ''),CHAR(12), ''), CHAR(13), ''), CHAR(22), ''), CHAR(32), '')
,city = mds_address.City
,country_code_iso2 = t_Country.country_code_iso2
,state = mds_address.State
,zip_code = mds_address.PostalCode
,street_address_check = CONCAT(mds_address.Address1, mds_address.Address2, mds_address.Address3, mds_address.Address4, mds_address.Address5)
,is_active = mds_address.Active
,last_updated_date_utc_at_source = mds_address.LastUpdatedDateGMT
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = GETUTCDATE()
,updated_date_time = GETUTCDATE()
,natural_key_hash = 'Internal'
FROM [dbo].[Address] mds_address
INNER JOIN #ClientstoMigrate ClientstoMigrate ON mds_address.EntityID = ClientstoMigrate.ClientID
INNER JOIN [dbo].[Client] mds_client ON mds_address.EntityID = mds_client.ClientID
LEFT JOIN canonical_data_model.client canonical_client ON mds_client.ClientNumber = canonical_client.client_number AND mds_client.MemberFirmCode = canonical_client.member_firm_code
LEFT JOIN [dbo].[Country] mds_country ON mds_address.CountryID = mds_country.CountryID
LEFT JOIN [taxonomy_data_model].[curated_country] t_Country ON mds_country.CountryCode = t_Country.country_code_iso2 COLLATE DATABASE_DEFAULT
WHERE mds_client.MemberFirmCode = 'GPMS'
AND mds_address.Active = 1
AND mds_address.EntityTypeCode = 'CL'
AND mds_address.AddressTypeCode = 'B'
--AND mds_address.AddressID IN ('216669')



--==========================================