--TRUNCATE TABLE canonical_data_model.matter_partner_allocation
--select count(*) from canonical_data_model.matter_partner_allocation
-- 3,236,180
--(1,184,267 rows affected)
--(1,183,710 rows affected)



-- Matters to Migrate

DROP TABLE IF EXISTS #MatterstoMigrate

SELECT MatterID, MatterNumber, ClientID
INTO #MatterstoMigrate
FROM Matter
WHERE MemberFirmCode IN ('GPMS')
AND MatterStatusID IN (39,49,59,69,79)
UNION
SELECT MatterID, MatterNumber, ClientID
FROM Matter
WHERE MemberFirmCode IN ('GPMS')
AND MatterCloseDateGMT >= '2019-01-01'
--(280502 rows affected)

--==================================================================================

DROP TABLE IF EXISTS #gmdr_person_sorted
SELECT DISTINCT RANK() OVER (PARTITION BY P9.PERSONID_EXT ORDER BY P0.STAT2 desc, P0.BEGDA desc, P0.AEDTM desc, P0.TIMESTAMP desc) AS xRank           
 ,P9.PERSONID_EXT, P9.PERNR, P0.BEGDA, P0.ENDDA, P0.AEDTM, P0.STAT2, P0.TIMESTAMP
 INTO #gmdr_person_sorted
FROM [SAP_PA0709] p9
join [SAP_PA0000] p0 on p9.PERNR = P0.PERNR
WHERE P0.ENDDA = '9999-12-31'

DROP TABLE IF EXISTS #gmdr_person_mastered
SELECT *
INTO #gmdr_person_mastered
FROM #gmdr_person_sorted
WHERE xRank = 1

SELECT PERSONID_EXT, COUNT(*) FROM #gmdr_person_mastered
GROUP BY PERSONID_EXT
HAVING COUNT(*) > 1

--==================================================================================

DROP TABLE IF EXISTS #gmdr_sap_zprs_tkalocmattr_Sorted

SELECT DISTINCT RANK() OVER (PARTITION BY PSPID,PERNR,PARVW,WERKS,ZZTEAM,BEGDA ORDER BY ZZCTSTAMP DESC,TIMESTAMP DESC) AS xRank           
 ,PSPID,PARVW,BEGDA,ENDDA,WERKS,ZZTEAM,PERNR,GUID,PERNR_ASSOC,ZZALLOCPERCET,ZZCTSTAMP,ERNAM,ZZCHTSTAMP,AENAM,DELETION_INDICATOR,TIMESTAMP
INTO #gmdr_sap_zprs_tkalocmattr_Sorted
FROM [SAP_ZPRS_TKALOCMATTR]
WHERE DELETION_INDICATOR <> 'X'

DROP TABLE IF EXISTS #gmdr_sap_zprs_tkalocmattr_mastered
SELECT *
INTO #gmdr_sap_zprs_tkalocmattr_mastered
FROM #gmdr_sap_zprs_tkalocmattr_Sorted
WHERE xRank = 1
				

SELECT PSPID,PERNR,PARVW,WERKS,ZZTEAM,BEGDA, COUNT(*) 
FROM #gmdr_sap_zprs_tkalocmattr_mastered
GROUP BY PSPID,PERNR,PARVW,WERKS,ZZTEAM,BEGDA
HAVING COUNT(*) > 1
--==================================================================================

--==================================================================================

INSERT INTO canonical_data_model.matter_partner_allocation(
 matter_number
,member_firm_code
,person_number
,partner_function_key
,office_key
,team_key
,begin_date
,end_date
,associate_person_number
,allocation_percentage
,matter_key
,person_key
,associate_person_key
,is_active
,last_updated_date_utc_at_source
,source_system
,inserted_process_instance_id
,updated_process_instance_id
,inserted_process_queue_id
,updated_process_queue_id
,inserted_date_time
,updated_date_time
,natural_key_hash
)
SELECT
 matter_number = gmdr_sap_zprs_tkalocmattr.PSPID
,member_firm_code = 'GPMS'
,person_number = gmdr_sap_zprs_tkalocmattr.PERNR
,partner_function_key = partner_function.partner_function_key
,office_key = t_office.office_key
,team_key = t_team.team_key
,begin_date = gmdr_sap_zprs_tkalocmattr.BEGDA
,end_date = gmdr_sap_zprs_tkalocmattr.ENDDA
,associate_person_number = gmdr_sap_zprs_tkalocmattr.PERNR_ASSOC
,allocation_percentage = gmdr_sap_zprs_tkalocmattr.ZZALLOCPERCET
,matter_key	= c_matter.matter_key
,person_key = c_person.person_key
,associate_person_key = c_person_PERNR_ASSOC.person_key
,is_active = CASE WHEN gmdr_sap_zprs_tkalocmattr.DELETION_INDICATOR <> 'X' 
						AND current_timestamp BETWEEN gmdr_sap_zprs_tkalocmattr.BEGDA AND gmdr_sap_zprs_tkalocmattr.ENDDA THEN 1 
					ELSE 0 
				END
,last_updated_date_utc_at_source = gmdr_sap_zprs_tkalocmattr.TIMESTAMP
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = GETUTCDATE()
,updated_date_time = GETUTCDATE()
,natural_key_hash = 'Internal'
FROM #gmdr_sap_zprs_tkalocmattr_mastered gmdr_sap_zprs_tkalocmattr
INNER JOIN #MatterstoMigrate MatterstoMigrate ON gmdr_sap_zprs_tkalocmattr.PSPID = MatterstoMigrate.MatterNumber
INNER JOIN [taxonomy_data_model].[curated_partner_function] partner_function ON gmdr_sap_zprs_tkalocmattr.PARVW = partner_function.sap_code COLLATE DATABASE_DEFAULT
INNER JOIN #gmdr_person_mastered gmdr_person_mastered ON gmdr_sap_zprs_tkalocmattr.PERNR = gmdr_person_mastered.PERNR AND gmdr_person_mastered.xRank = 1
INNER JOIN PersonSystemMap mds_personsystemmap 
		ON gmdr_person_mastered.PERSONID_EXT = COALESCE(mds_personsystemmap.GPMSExternalPersonID, mds_personsystemmap.GPMSPersonnelNumber)
LEFT JOIN Person mds_person ON mds_personsystemmap.PersonID = mds_person.PersonID
LEFT JOIN [canonical_data_model].[matter] c_matter ON gmdr_sap_zprs_tkalocmattr.PSPID = c_matter.matter_number AND c_matter.member_firm_code = 'GPMS'
LEFT JOIN [taxonomy_data_model].[curated_office] t_office ON gmdr_sap_zprs_tkalocmattr.WERKS = t_office.office_code
LEFT JOIN [taxonomy_data_model].[curated_team] t_team ON gmdr_sap_zprs_tkalocmattr.ZZTEAM = t_team.team_code
LEFT JOIN [canonical_data_model].[person] c_person ON CAST(mds_person.PersonID AS VARCHAR(50)) = c_person.person_id
LEFT JOIN #gmdr_person_mastered gmdr_person_mastered_PERNR_ASSOC ON gmdr_sap_zprs_tkalocmattr.PERNR_ASSOC = gmdr_person_mastered_PERNR_ASSOC.PERNR AND gmdr_person_mastered_PERNR_ASSOC.xRank = 1
LEFT JOIN PersonSystemMap mds_personsystemmap_PERNR_ASSOC 
		ON gmdr_person_mastered_PERNR_ASSOC.PERSONID_EXT = COALESCE(mds_personsystemmap_PERNR_ASSOC.GPMSExternalPersonID, mds_personsystemmap_PERNR_ASSOC.GPMSPersonnelNumber)
LEFT JOIN Person mds_person_PERNR_ASSOC ON mds_personsystemmap_PERNR_ASSOC.PersonID = mds_person_PERNR_ASSOC.PersonID
LEFT JOIN [canonical_data_model].[person] c_person_PERNR_ASSOC ON CAST(mds_person_PERNR_ASSOC.PersonID AS VARCHAR(50)) = c_person_PERNR_ASSOC.person_id
