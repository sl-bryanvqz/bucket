

DROP TABLE IF EXISTS canonical_data_model.matter_relationship

CREATE TABLE canonical_data_model.matter_relationship(
matter_relationship_key BIGINT IDENTITY NOT NULL
,matter_number NVARCHAR(20) NOT NULL
,member_firm_code NVARCHAR(20) NOT NULL
,parent_matter_number NVARCHAR(20) NOT NULL
,parent_member_firm_code NVARCHAR(20) NOT NULL
,matter_relationship_type NVARCHAR(20) NOT NULL
,matter_key BIGINT
,parent_matter_key BIGINT
,source_system NVARCHAR(100) NOT NULL
,inserted_process_instance_id NVARCHAR(100) NOT NULL
,updated_process_instance_id NVARCHAR(100) NOT NULL
,inserted_process_queue_id NVARCHAR(100) NOT NULL
,updated_process_queue_id NVARCHAR(100) NOT NULL
,inserted_date_time DATETIME NOT NULL
,updated_date_time DATETIME NOT NULL
,natural_key_hash NVARCHAR(100) NOT NULL
)