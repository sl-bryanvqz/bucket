DROP TABLE IF EXISTS canonical_data_model.matter_partner_allocation

CREATE TABLE canonical_data_model.matter_partner_allocation(
 matter_partner_allocation_key BIGINT IDENTITY NOT NULL
,matter_number NVARCHAR(20) NOT NULL
,member_firm_code VARCHAR(10) NOT NULL
,person_number NVARCHAR(20) NOT NULL
,partner_function_key BIGINT NOT NULL
,office_key BIGINT
,team_key BIGINT
,begin_date DATETIME NOT NULL
,end_date DATETIME NOT NULL
,associate_person_number NVARCHAR(20)
,allocation_percentage DECIMAL NOT NULL
,matter_key BIGINT
,person_key BIGINT
,associate_person_key BIGINT
,is_active BIT
,last_updated_date_utc_at_source DATETIME
,source_system NVARCHAR(100) NOT NULL
,inserted_process_instance_id NVARCHAR(100) NOT NULL
,updated_process_instance_id NVARCHAR(100) NOT NULL
,inserted_process_queue_id NVARCHAR(100) NOT NULL
,updated_process_queue_id NVARCHAR(100) NOT NULL
,inserted_date_time DATETIME NOT NULL
,updated_date_time DATETIME NOT NULL
,natural_key_hash NVARCHAR(100) NOT NULL
)