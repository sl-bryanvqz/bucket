--truncate table canonical_data_model.person


INSERT INTO canonical_data_model.person(
person_number
,member_firm_code
,timekeeper_id
,person_id
,person_status_code
,gender
,prefix
,first_name
,first_name_known_as
,middle_name
,last_name
,suffix
,initials
,photo_path
,commencement_date_utc
,departure_date_utc
,leave_status
,team_key
,job_title
,job_title_pms
,practice_group_key
,year_of_call
,desk_location
,domain_name
,unified_sap_person_external_id
,windows_login
,dms_system_id
,human_resources_system_id
,work_phone_number
,work_phone_extension
,mobile_phone_number
,email_address
,employee_name_reporting
,cost_centre_code
,company_key
,office_key
,employee_sub_group_key
,band_level_key
,person_record_rank
,is_active
,last_updated_date_utc_at_source
,source_system
,inserted_process_instance_id
,updated_process_instance_id
,inserted_process_queue_id
,updated_process_queue_id
,inserted_date_time
,updated_date_time
,natural_key_hash
)

SELECT
person_number = LTRIM(RTRIM(mds_person.SystemEmployeeCode))
,member_firm_code = mds_person.MemberFirmCode
,timekeeper_id = COALESCE(mds_personsystemmap.GPMSPersonnelNumber,mds_personsystemmap.GPMSExternalPersonID)
,person_id = CONVERT(VARCHAR(50),mds_person.PersonID)
,person_status_code = mds_person.PersonStatusCode
,gender = mds_person.Gender
,prefix = mds_person.Prefix
,first_name = mds_person.FirstName
,first_name_known_as = LTRIM(RTRIM(ISNULL(mds_person.FirstNameKnownAs,'')))
,middle_name = LTRIM(RTRIM(ISNULL(mds_person.MiddleName,'')))
,last_name = LTRIM(RTRIM(ISNULL(mds_person.LastName,'')))
,suffix = mds_person.Suffix
,initials = mds_person.Initials
,photo_path = mds_person.PhotoPath
,commencement_date_utc = mds_person.CommencementDateGMT
,departure_date_utc = COALESCE(mds_person.DepartureDateGMT, '9999-12-31')
,leave_status = mds_person.LeaveStatus
,team_key = t_Team.team_key
,job_title = mds_person.JobTitle
,job_title_pms = mds_person.JobTitlePMS
,practice_group_key = t_Practice_Group.practice_group_key
,year_of_call = mds_person.YearOfCall
,desk_location = mds_PersonLocale.DeskLocation
,domain_name = LTRIM(RTRIM(ISNULL(mds_personsystemmap.DomainName,'')))
,unified_sap_person_external_id = CAST(COALESCE(mds_personsystemmap.GPMSExternalPersonID,mds_personsystemmap.GPMSPersonnelNumber) AS VARCHAR(50))
,windows_login = LTRIM(RTRIM(ISNULL(mds_personsystemmap.WindowsLogin,'')))
,dms_system_id = LTRIM(RTRIM(ISNULL(mds_personsystemmap.DMSSystemID,'')))
,human_resources_system_id = LTRIM(RTRIM(ISNULL(mds_personsystemmap.HumanResourcesSystemID,'')))
,work_phone_number = LTRIM(RTRIM(ISNULL(mds_WorkPhone.PhoneNumber,'')))
,work_phone_extension = LTRIM(RTRIM(ISNULL(mds_WorkPhone.PhoneExtension,'')))
,mobile_phone_number = LTRIM(RTRIM(ISNULL(mds_MobilPhone.PhoneNumber,'')))
,email_address = LTRIM(RTRIM(ISNULL(mds_Email.EmailAddress,'')))
,employee_name_reporting = CONCAT(mds_person.LastName,', ',coalesce(mds_person.FirstNameKnownAs,mds_person.FirstName),' (', 
        CAST(COALESCE(mds_personsystemmap.GPMSExternalPersonID COLLATE DATABASE_DEFAULT,mds_personsystemmap.GPMSPersonnelNumber COLLATE DATABASE_DEFAULT) AS VARCHAR(50)),')')
,cost_centre_code = mds_costcentre.CostCenter
,company_key = t_Company.company_key
,office_key = t_Office.office_key
,employee_sub_group_key = t_Employee_Sub_Group.employee_sub_group_key
,band_level_key	= t_band_level.band_level_key
,person_record_rank = 
    CASE
        WHEN CAST(COALESCE(mds_personsystemmap.GPMSExternalPersonID, mds_personsystemmap.GPMSPersonnelNumber) AS VARCHAR(50)) IS NULL
            THEN 1
        ELSE ROW_NUMBER() OVER (
            PARTITION BY CAST(COALESCE(mds_personsystemmap.GPMSExternalPersonID, mds_personsystemmap.GPMSPersonnelNumber) AS VARCHAR(50))
            ORDER BY
                CASE WHEN mds_person.DeleteFlag NOT IN ('Y', '1') THEN 1 ELSE 2 END, -- 1. Active records
                CASE WHEN mds_person.DeleteFlag NOT IN ('Y', '1') AND COALESCE(mds_person.DepartureDateGMT, '9999-12-31') = '9999-12-31'  THEN 1 ELSE 2 END,  -- 2. Within  Active records, Prefer no departure_date_utc
                COALESCE(mds_person.DepartureDateGMT, '9999-12-31') DESC, -- 3. Most recent departure date
                mds_person.LastUpdatedDateGMT DESC, -- 4. Most recent updated
                mds_person.PersonID DESC -- 5. Last resort, take maximum person_id
        )
    END
,is_active = CASE WHEN mds_person.DeleteFlag IN ('Y', '1') THEN 0 ELSE 1 END
,last_updated_date_utc_at_source = mds_person.LastUpdatedDateGMT
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = GETUTCDATE()
,updated_date_time = GETUTCDATE()
,natural_key_hash = 'Internal'
from Person mds_person
left join PersonSystemMap mds_personsystemmap ON mds_person.PersonID = mds_personsystemmap.PersonID
left join PersonLocale mds_personlocale ON mds_person.PersonID = mds_personlocale.PersonID
left join Office mds_Office ON mds_personlocale.OfficeID = mds_Office.OfficeID
LEFT JOIN [taxonomy_data_model].[curated_office] t_Office ON mds_Office.SAPCode = t_Office.office_code
left join SubTeam mds_SubTeam on mds_person.SubTeamID = mds_SubTeam.SubTeamID
left join Phone mds_WorkPhone on mds_person.PersonID = mds_WorkPhone.EntityID and mds_WorkPhone.PhoneTypeCode = 'W'
left join Phone mds_MobilPhone on mds_person.PersonID = mds_MobilPhone.EntityID and mds_MobilPhone.PhoneTypeCode = 'M'
left join Email mds_Email on mds_person.PersonID = mds_Email.EntityID and mds_Email.EmailTypeCode = 'W'
left join PersonCostCentre mds_Personcostcentre on mds_person.PersonID = mds_Personcostcentre.PersonID
left join CostCenter mds_costcentre on mds_Personcostcentre.CostCentreID = mds_costcentre.CostCenterId
left join [SAP_PA0001] gmdr_sap_pa0001 
	on CAST(COALESCE(mds_personsystemmap.GPMSExternalPersonID,mds_personsystemmap.GPMSPersonnelNumber) AS VARCHAR(50)) = gmdr_sap_pa0001.PERNR COLLATE DATABASE_DEFAULT 
	and gmdr_sap_pa0001.ENDDA = '9999-12-31'
LEFT JOIN [taxonomy_data_model].[curated_company] t_Company ON gmdr_sap_pa0001.BUKRS = t_Company.company_code COLLATE DATABASE_DEFAULT
LEFT JOIN [taxonomy_data_model].[curated_team] t_Team ON mds_SubTeam.SubTeamCode = t_Team.team_code COLLATE DATABASE_DEFAULT AND t_Team.member_firm_code = 'GPMS'
LEFT JOIN [taxonomy_data_model].[curated_practice_group] t_Practice_Group ON mds_person.PracticeGroup = t_Practice_Group.practice_group_code COLLATE DATABASE_DEFAULT
LEFT JOIN [taxonomy_data_model].[curated_employee_sub_group] t_Employee_Sub_Group ON gmdr_sap_pa0001.PERSK = t_Employee_Sub_Group.employee_sub_group_code COLLATE DATABASE_DEFAULT
left join [SAP_PA9007] gmdr_sap_pa9007 ON gmdr_sap_pa0001.PERNR = gmdr_sap_pa9007.PERNR and gmdr_sap_pa9007.ENDDA = '9999-12-31'
LEFT JOIN [taxonomy_data_model].[curated_band_level] t_band_level ON gmdr_sap_pa9007.ZZBLVL = t_band_level.band_level_code COLLATE DATABASE_DEFAULT
WHERE mds_person.MemberFirmCode in ('NRCAN')
AND mds_person.SystemEmployeeCode NOT IN ('UNDEF')
