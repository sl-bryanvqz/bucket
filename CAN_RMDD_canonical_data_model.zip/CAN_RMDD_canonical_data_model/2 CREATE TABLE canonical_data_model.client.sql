CREATE TABLE canonical_data_model.client(
 client_key BIGINT IDENTITY NOT NULL
,client_number NVARCHAR(20) NOT NULL
,member_firm_code NVARCHAR(10) NOT NULL
,client_id INT NOT NULL
,pms_client_id NVARCHAR(50)
,client_name NVARCHAR(255) NOT NULL
,alternate_client_name NVARCHAR(255)
,contact_name NVARCHAR(100)
,open_date_utc DATETIME
,close_date_utc DATETIME
,client_e_billing_vendor NVARCHAR(20)
,client_information_barier NVARCHAR(1)
,client_name_cmi NVARCHAR(256) NOT NULL
,member_firm_code_cmi NVARCHAR(10)
,client_status_cmi NVARCHAR(256)
,client_non_consent NVARCHAR(1)
,client_pricing_group NVARCHAR(10)
,customer_account_group NVARCHAR(4)
,client_programme_key BIGINT
,tax_jurisdiction NVARCHAR(15)
,tax_number_1 NVARCHAR(16)
,tax_number_2 NVARCHAR(11)
,vat_registration_number NVARCHAR(20)
,vat_valid_date DATETIME
,client_duns NVARCHAR(50)
,client_guduns NVARCHAR(50)
,comments NVARCHAR(255)
,pms_entity_type NVARCHAR(50)
,client_type NVARCHAR(1)
,is_confidential NVARCHAR(1)
,client_sector_key BIGINT
,is_sanctions_checked BIT
,is_active BIT NOT NULL
,created_date_utc_at_source DATETIME
,last_updated_date_utc_at_source DATETIME NOT NULL
,source_system NVARCHAR(100) NOT NULL
,inserted_process_instance_id NVARCHAR(100) NOT NULL
,updated_process_instance_id NVARCHAR(100) NOT NULL
,inserted_process_queue_id NVARCHAR(100) NOT NULL
,updated_process_queue_id NVARCHAR(100) NOT NULL
,inserted_date_time DATETIME NOT NULL
,updated_date_time DATETIME NOT NULL
,natural_key_hash NVARCHAR(100) NOT NULL
)