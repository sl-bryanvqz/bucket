CREATE TABLE canonical_data_model.cost_centre
(
cost_centre_key BIGINT IDENTITY NOT NULL
,cost_centre_code NVARCHAR(10) NOT NULL
,member_firm_code NVARCHAR(10) NOT NULL
,valid_from_date DATETIME NOT NULL
,valid_to_date DATETIME
,company_key BIGINT
,currency_code NVARCHAR(5)
,profit_centre NVARCHAR(10)
,cost_centre_description NVARCHAR(20)
,cost_centre_long_description NVARCHAR(40)
,is_active BIT NOT NULL
,last_updated_date_utc_at_source DATETIME
,source_system NVARCHAR(100) NOT NULL
,inserted_process_instance_id NVARCHAR(100) NOT NULL
,updated_process_instance_id NVARCHAR(100) NOT NULL
,inserted_process_queue_id NVARCHAR(100) NOT NULL
,updated_process_queue_id NVARCHAR(100) NOT NULL
,inserted_date_time DATETIME NOT NULL
,updated_date_time DATETIME NOT NULL
,natural_key_hash NVARCHAR(100) NOT NULL
)