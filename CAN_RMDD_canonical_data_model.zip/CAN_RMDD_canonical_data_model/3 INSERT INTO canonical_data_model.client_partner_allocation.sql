--TRUNCATE TABLE canonical_data_model.client_partner_allocation
--select count(*) from canonical_data_model.client_partner_allocation
--(60,224 rows affected)
--(50,931 rows affected)


-- Matters to Migrate

DROP TABLE IF EXISTS #MatterstoMigrate

SELECT MatterID, ClientID
INTO #MatterstoMigrate
FROM Matter
WHERE MemberFirmCode IN ('GPMS')
AND MatterStatusID IN (39,49,59,69,79)
UNION
SELECT MatterID, ClientID
FROM Matter
WHERE MemberFirmCode IN ('GPMS')
AND MatterCloseDateGMT >= '2019-01-01'
--(280502 rows affected)

-- Clients to Migrate
DROP TABLE IF EXISTS #ClientstoMigrate

SELECT ClientID, ClientNumber
INTO #ClientstoMigrate
FROM Client 
WHERE MemberFirmCode IN ('GPMS')
AND ClientStatusID IN (19)
UNION 
SELECT c.ClientID, ClientNumber
FROM Client c
JOIN #MatterstoMigrate m ON c.ClientID = m.ClientID


--==================================================================================

DROP TABLE IF EXISTS #gmdr_person_sorted
SELECT DISTINCT RANK() OVER (PARTITION BY P9.PERSONID_EXT ORDER BY P0.STAT2 desc, P0.BEGDA desc, P0.AEDTM desc, P0.TIMESTAMP desc) AS xRank           
 ,P9.PERSONID_EXT, P9.PERNR, P0.BEGDA, P0.ENDDA, P0.AEDTM, P0.STAT2, P0.TIMESTAMP
 INTO #gmdr_person_sorted
FROM [SAP_PA0709] p9
join [SAP_PA0000] p0 on p9.PERNR = P0.PERNR
WHERE P0.ENDDA = '9999-12-31'

DROP TABLE IF EXISTS #gmdr_person_mastered
SELECT *
INTO #gmdr_person_mastered
FROM #gmdr_person_sorted
WHERE xRank = 1

SELECT PERSONID_EXT, COUNT(*) FROM #gmdr_person_mastered
GROUP BY PERSONID_EXT
HAVING COUNT(*) > 1


--=======================================


DROP TABLE IF EXISTS #gmdr_sap_zprs_tkalocclnt_Sorted

SELECT DISTINCT RANK() OVER (PARTITION BY KUNNR,PARVW,BEGDA,PERNR ORDER BY ZZCTSTAMP desc) AS xRank           
 ,KUNNR,PARVW,BEGDA,ENDDA,PERNR,GUID,ZZALLOCPERCENT,ZZCTSTAMP,ERNAM,ZZCHTSTAMP,AENAM,DELETION_INDICATOR,TIMESTAMP
 INTO #gmdr_sap_zprs_tkalocclnt_Sorted
FROM [SAP_ZPRS_TKALOCCLNT] 
WHERE DELETION_INDICATOR <> 'X'


DROP TABLE IF EXISTS #gmdr_sap_zprs_tkalocclnt_mastered
SELECT *
INTO #gmdr_sap_zprs_tkalocclnt_mastered
FROM #gmdr_sap_zprs_tkalocclnt_Sorted
WHERE xRank = 1
				

SELECT KUNNR,PARVW,BEGDA,PERNR, COUNT(*) 
FROM #gmdr_sap_zprs_tkalocclnt_mastered
GROUP BY KUNNR,PARVW,BEGDA,PERNR
HAVING COUNT(*) > 1

--==================================================================================

INSERT INTO canonical_data_model.client_partner_allocation(
 client_number
,member_firm_code
,person_number
,partner_function_key
,begin_date
,end_date
,allocation_percentage
,client_key
,person_key
,is_active
,last_updated_date_utc_at_source
,source_system
,inserted_process_instance_id
,updated_process_instance_id
,inserted_process_queue_id
,updated_process_queue_id
,inserted_date_time
,updated_date_time
,natural_key_hash
)
SELECT
 client_number = gmdr_sap_zprs_tkalocclnt.KUNNR
,member_firm_code = 'GPMS'
,person_number = gmdr_sap_zprs_tkalocclnt.PERNR
,partner_function_key = t_partner_function.partner_function_key
,begin_date = gmdr_sap_zprs_tkalocclnt.BEGDA
,end_date = gmdr_sap_zprs_tkalocclnt.ENDDA
,allocation_percentage = gmdr_sap_zprs_tkalocclnt.ZZALLOCPERCENT
,client_key	= c_client.client_key
,person_key	 = c_person.person_key
,is_active = CASE WHEN gmdr_sap_zprs_tkalocclnt.DELETION_INDICATOR <> 'X' AND current_timestamp >= gmdr_sap_zprs_tkalocclnt.BEGDA and current_timestamp<= gmdr_sap_zprs_tkalocclnt.ENDDA THEN 1 ELSE 0 END
,last_updated_date_utc_at_source = gmdr_sap_zprs_tkalocclnt.TIMESTAMP
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = GETUTCDATE()
,updated_date_time = GETUTCDATE()
,natural_key_hash = 'Internal'
FROM #gmdr_sap_zprs_tkalocclnt_mastered gmdr_sap_zprs_tkalocclnt
INNER JOIN #ClientstoMigrate ClientstoMigrate ON gmdr_sap_zprs_tkalocclnt.KUNNR = ClientstoMigrate.ClientNumber
INNER JOIN [taxonomy_data_model].[curated_partner_function] t_partner_function ON gmdr_sap_zprs_tkalocclnt.PARVW = t_partner_function.sap_code COLLATE DATABASE_DEFAULT
INNER JOIN #gmdr_person_mastered gmdr_person_mastered ON gmdr_sap_zprs_tkalocclnt.PERNR = gmdr_person_mastered.PERNR AND gmdr_person_mastered.xRank = 1
INNER JOIN [dbo].[PersonSystemMap] mds_PersonSystemMap 
	ON gmdr_person_mastered.PERSONID_EXT = CAST(COALESCE(mds_PersonSystemMap.GPMSExternalPersonID,mds_PersonSystemMap.GPMSPersonnelNumber) AS VARCHAR(50)) COLLATE DATABASE_DEFAULT
AND LEN(CAST(COALESCE(mds_personsystemmap.GPMSExternalPersonID, mds_personsystemmap.GPMSPersonnelNumber) as VARCHAR(50))) = 6
LEFT JOIN [dbo].[Person] mds_Person ON mds_PersonSystemMap.PersonID = mds_Person.PersonID
LEFT JOIN [canonical_data_model].[client] c_client ON gmdr_sap_zprs_tkalocclnt.KUNNR = c_client.client_number AND c_client.member_firm_code = 'GPMS'
LEFT JOIN [canonical_data_model].[person] c_person ON CAST(mds_Person.PersonID AS VARCHAR(50)) = c_person.person_id
--WHERE gmdr_sap_zprs_tkalocclnt.KUNNR = '10000003'