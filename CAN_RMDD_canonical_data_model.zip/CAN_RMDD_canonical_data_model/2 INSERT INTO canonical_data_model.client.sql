--truncate table canonical_data_model.client
--select count(*) from canonical_data_model.client
--  46,818
--( 39,574 rows affected)

DROP TABLE IF EXISTS #MatterstoMigrate

SELECT MatterID, ClientID
INTO #MatterstoMigrate
FROM Matter
WHERE MemberFirmCode IN ('GPMS')
AND MatterStatusID IN (39,49,59,69,79)
UNION
SELECT MatterID, ClientID
FROM Matter
WHERE MemberFirmCode IN ('GPMS')
AND MatterCloseDateGMT >= '2019-01-01'
--(280502 rows affected)

-- Clients to Migrate
DROP TABLE IF EXISTS #ClientstoMigrate

SELECT ClientID
INTO #ClientstoMigrate
FROM Client 
WHERE MemberFirmCode IN ('GPMS')
AND ClientStatusID IN (19)
UNION 
SELECT c.ClientID
FROM Client c
JOIN #MatterstoMigrate m ON c.ClientID = m.ClientID

--=======================================

INSERT INTO canonical_data_model.client(
client_number
,member_firm_code
,client_id
,pms_client_id
,client_name
,alternate_client_name
,contact_name
,open_date_utc
,close_date_utc
,client_e_billing_vendor
,client_information_barier
,client_name_cmi
,member_firm_code_cmi
,client_status_cmi
,client_non_consent
,client_pricing_group
,customer_account_group
,client_programme_key
,tax_jurisdiction
,tax_number_1
,tax_number_2
,vat_registration_number
,vat_valid_date
,client_duns
,client_guduns
,comments
,pms_entity_type
,client_type
,is_confidential
,client_sector_key
,is_sanctions_checked
,is_active
,created_date_utc_at_source
,last_updated_date_utc_at_source
,source_system
,inserted_process_instance_id
,updated_process_instance_id
,inserted_process_queue_id
,updated_process_queue_id
,inserted_date_time
,updated_date_time
,natural_key_hash)
SELECT
client_number = mds_Client.ClientNumber
,member_firm_code = LTRIM(RTRIM(ISNULL(mds_Client.MemberFirmCode,''))) 
,client_id = CAST(mds_Client.ClientID AS NVARCHAR(50))
,pms_client_id = mds_Client.PMSClientID
,client_name = mds_Client.ClientName
,alternate_client_name = mds_Client.AlternateClientName
,contact_name = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(mds_Client.ContactName, CHAR(9), ''), CHAR(10), ''),CHAR(12), ''), CHAR(13), ''), CHAR(22), ''), CHAR(32), ''), CHAR(160), ''), CHAR(255), '')
,open_date_utc = mds_Client.OpenDateGMT
,close_date_utc = mds_Client.CloseDateGMT
,client_e_billing_vendor = gmdr_SAP_KNA1.ZZEBILLVENDOR
,client_information_barier = gmdr_SAP_KNA1.ZZPRICONF
,client_name_cmi = 'cmi'
,member_firm_code_cmi = 'cmi'
,client_status_cmi = 'cmi'
,client_non_consent = CAST(gmdr_SAP_KNA1.ZNONCONSENT AS VARCHAR(10))
,client_pricing_group = CAST(gmdr_SAP_KNA1.ZZCLNTGRP AS VARCHAR(100))
,customer_account_group = gmdr_SAP_KNA1.KTOKD
,client_programme_key = t_client_programme.client_programme_key
,tax_jurisdiction = gmdr_SAP_KNA1.TXJCD
,tax_number_1 = gmdr_SAP_KNA1.STCD1
,tax_number_2 = gmdr_SAP_KNA1.STCD2
,vat_registration_number = gmdr_SAP_KNA1.STCEG
,vat_valid_date = gmdr_SAP_KNA1.ZZVATVALDT
,client_duns = mds_Client.ClientDUNS
,client_guduns = mds_Client.ClientGUDUNS
,comments = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(mds_Client.Comments, CHAR(1), ''), CHAR(9), ''),CHAR(10), ''), CHAR(12), ''), CHAR(13), ''), CHAR(22), ''), CHAR(32), '')
,pms_entity_type = mds_Client.PMSEntityType
,client_type = CASE WHEN ISNULL(mds_Client.ClientType,'') = '' AND mds_Client.MemberFirmCode = 'GPMS' THEN 'O'
					WHEN mds_Client.ClientType = 'O' THEN 'O'
					WHEN mds_Client.ClientType IN ('X','P','I') THEN 'P'
					ELSE NULL
				END
,is_confidential = mds_Client.IsConfidential
,client_sector_key = t_client_sector.client_sector_key
,is_sanctions_checked = mds_Client.SanctionsChecked_YN
,is_active = mds_Client.Active
,created_date_utc_at_source = mds_Client.CreatedDateGMT
,last_updated_date_utc_at_source = mds_Client.LastUpdatedDateGMT
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = GETUTCDATE()
,updated_date_time = GETUTCDATE()
,natural_key_hash = 'Internal'
FROM [dbo].[Client] mds_Client
INNER JOIN #ClientstoMigrate ClientstoMigrate ON mds_Client.ClientID = ClientstoMigrate.ClientID
LEFT JOIN [SAP_KNA1] gmdr_SAP_KNA1 ON mds_Client.ClientNumber = gmdr_SAP_KNA1.KUNNR COLLATE DATABASE_DEFAULT
LEFT JOIN [taxonomy_data_model].[curated_client_programme] t_client_programme ON gmdr_SAP_KNA1.ZZCLNTPRG = t_client_programme.client_programme_code COLLATE DATABASE_DEFAULT
LEFT JOIN [taxonomy_data_model].[curated_client_sector] t_client_sector ON COALESCE(mds_Client.SICCode,gmdr_SAP_KNA1.ZZSICCD) = t_client_sector.sic_code COLLATE DATABASE_DEFAULT
--WHERE ClientNumber IN ('10000015')
