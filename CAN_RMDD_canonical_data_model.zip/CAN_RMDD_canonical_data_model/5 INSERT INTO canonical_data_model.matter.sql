


-- Matters to Migrate

DROP TABLE IF EXISTS #MatterstoMigrate

SELECT MatterID, ClientID
INTO #MatterstoMigrate
FROM Matter
WHERE MemberFirmCode IN ('GPMS')
AND MatterStatusID IN (39,49,59,69,79)
UNION
SELECT MatterID, ClientID
FROM Matter
WHERE MemberFirmCode IN ('GPMS')
AND MatterCloseDateGMT >= '2019-01-01'
--(280502 rows affected)

--============================================

DROP TABLE IF EXISTS #s_MAT_PH_SET
SELECT DISTINCT RANK() OVER (PARTITION BY ZZPSPID ORDER BY BEGDA desc, TIMESTAMP desc, ZZPHASESET desc) AS xRank           
 ,ZZPSPID, ZZPHASESET, BEGDA, ENDDA, ZZCTSTAMP, ERNAM, ZZCHTSTAMP, AENAM, TIMESTAMP
 INTO #s_MAT_PH_SET
      FROM [SAP_ZPRS_MAT_PH_SET]

SELECT ZZPSPID, COUNT(*)
FROM #s_MAT_PH_SET
WHERE xRank = 1
GROUP BY ZZPSPID
HAVING COUNT(*) > 1
--==============================
DROP TABLE IF EXISTS #s_SAP_KNVK

SELECT DISTINCT RANK() OVER (PARTITION BY KUNNR ORDER BY PARNR desc) AS xRank           
 ,PARNR, KUNNR, NAME1, ADRND, ADRNP, TELF1, PARAU, LOEVM, ADRNP_2, TIMESTAMP, NAMEV, ABTPA, TITEL_AP, PRSNR
INTO #s_SAP_KNVK
FROM [SAP_KNVK]

SELECT KUNNR, COUNT(*)
FROM #s_SAP_KNVK
WHERE xRank = 1
GROUP BY KUNNR
HAVING COUNT(*) > 1

--==============================
DROP TABLE IF EXISTS #s_SAP_IHPA_PY

SELECT DISTINCT RANK() OVER (PARTITION BY PSPID ORDER BY COUNTER desc) AS xRank           
 ,PSPID, PARVW, COUNTER, PARNR, KZLOESCH, TIMESTAMP
INTO #s_SAP_IHPA_PY
FROM [SAP_IHPA]
WHERE PARVW = 'PY' and KZLOESCH <> 'X'

SELECT PSPID, COUNT(*)
FROM #s_SAP_IHPA_PY
WHERE xRank = 1
GROUP BY PSPID
HAVING COUNT(*) > 1

--==============================
DROP TABLE IF EXISTS #s_SAP_IHPA_Z3
SELECT DISTINCT RANK() OVER (PARTITION BY PSPID ORDER BY COUNTER desc) AS xRank           
 ,PSPID, PARVW, COUNTER, PARNR, KZLOESCH, TIMESTAMP
INTO #s_SAP_IHPA_Z3
FROM [SAP_IHPA]
WHERE PARVW = 'Z3' and KZLOESCH <> 'X'

SELECT PSPID, COUNT(*)
FROM #s_SAP_IHPA_Z3
WHERE xRank = 1
GROUP BY PSPID
HAVING COUNT(*) > 1

--SELECT COUNT(*) FROM canonical_data_model.matter
-- 330,503
--(280,502 rows affected)
--TRUNCATE TABLE canonical_data_model.matter
--==============================
INSERT INTO canonical_data_model.matter(
 matter_number
,member_firm_code
,matter_id
,pms_matter_id
,matter_name
,long_matter_name
,alternate_matter_name
,alternate_matter_number
,matter_create_date_utc
,matter_name_cmi
,member_firm_code_cmi
,matter_description_cmi
,billing_office_key
,nature_of_proceeding_key
,matter_status_key
,matter_status_cmi_key
,matter_company_code
,client_key
,practice_group_key
,matter_category_key
,is_confidential
,matter_pass_through_flag
,currency_code
,matter_jurisdiction_code_cmi
,matter_fee_estimate_cmi
,matter_cost_estimate_cmi
,matter_billing_frequency_key
,matter_billing_method_key
,matter_open_date_utc
,matter_close_date_utc
,matter_billable_flag
,matter_time_unit
,matter_sector_key
,team_key
,matter_purchase_order_number
,ip_matter_number
,matter_entry_type_key
,comments
,matter_pricing_group
,client_bill_contact_code
,client_bill_contact_name
,payer_code
,payer_name
,z3_payer_code
,z3_payer_name
,client_case_number
,client_case_description
,group_billing
,reporting_group
,is_sanctions_checked
,is_security_wall_created
,matter_phase_set_code
,work_type_key
,is_active
,last_updated_date_utc_at_source
,source_system
,inserted_process_instance_id
,updated_process_instance_id
,inserted_process_queue_id
,updated_process_queue_id
,inserted_date_time
,updated_date_time
,natural_key_hash
)
SELECT
 matter_number = mds_Matter.MatterNumber
,member_firm_code = mds_Matter.MemberFirmCode
,matter_id = mds_Matter.MatterID
,pms_matter_id = mds_Matter.PMSMatterID
,matter_name = mds_Matter.MatterName
,long_matter_name = mds_Matter.LongMatterName
,alternate_matter_name = mds_Matter.AlternateMatterName
,alternate_matter_number = mds_Matter.AlternateMatterNumber
,matter_create_date_utc = GETUTCDATE()
,matter_name_cmi = 'cmidb'
,member_firm_code_cmi = 'cmidb'
,matter_description_cmi = 'cmidb'
,billing_office_key = t_office.office_key
,nature_of_proceeding_key = t_nopc.nature_of_proceeding_key
,matter_status_key = t_mtstat.matter_status_key
,matter_status_cmi_key = 9999
,matter_company_code = t_Company.company_code
,client_key	= canonical_client.client_key
,practice_group_key	= t_practice_group.practice_group_key
,matter_category_key = t_matter_category.matter_category_key
,is_confidential = CASE WHEN ISNULL(mds_Matter.Confidential,'') IN ('','N','X') THEN 0
                        WHEN ISNULL(mds_Matter.Confidential,'') IN ('Y') THEN 1
                    ELSE 0
                    END
,matter_pass_through_flag = 0 --gmdr_SAP_PROJ.ZZPASSTHRU
,currency_code = mds_Matter.CurrencyCode
,matter_jurisdiction_code_cmi = 'cmidb'
,matter_fee_estimate_cmi = 99.99
,matter_cost_estimate_cmi = 99.99
,matter_billing_frequency_key = t_mbf.matter_billing_frequency_key
,matter_billing_method_key = t_mbm.matter_billing_method_key
,matter_open_date_utc =	mds_matter.MatterOpenDateGMT
,matter_close_date_utc = mds_matter.MatterCloseDateGMT
,matter_billable_flag = mds_matter.MatterBillableFlag
,matter_time_unit =	mds_matter.MatterTimeUnit
,matter_sector_key = t_mst.matter_sector_key
,team_key = t_team.team_key
,matter_purchase_order_number = CAST(gmdr_SAP_PROJ.ZZIPPONUM AS VARCHAR(255))
,ip_matter_number = CAST(gmdr_SAP_PROJ.ZZIP_REF_NUM AS VARCHAR(100))
,matter_entry_type_key = t_met.matter_entry_type_key
,comments = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(mds_matter.Comments, CHAR(1), ''), CHAR(9), ''),CHAR(10), ''), CHAR(12), ''), CHAR(13), ''), CHAR(22), ''), CHAR(27), ''), CHAR(32), '')
,matter_pricing_group =  CAST(gmdr_SAP_PROJ.ZZMPRGRP AS VARCHAR(10))
,client_bill_contact_code = s_SAP_KNVK.PARNR
,client_bill_contact_name = TRIM(CAST(CASE WHEN s_SAP_KNVK.NAMEV ='' THEN s_SAP_KNVK.NAME1 ELSE CONCAT(s_SAP_KNVK.NAMEV,' ',s_SAP_KNVK.NAME1) END AS VARCHAR(50)))
,payer_code = s_SAP_IHPA_PY.PARNR
,payer_name	= Payer_Client.ClientName
,z3_payer_code = s_SAP_IHPA_Z3.PARNR
,z3_payer_name = Z3_Client.ClientName
,client_case_number = gmdr_SAP_PROJ.ZZCLCASENBR
,client_case_description = gmdr_SAP_PROJ.ZZCLCASENAME
,group_billing = mds_matter.GPMSGroupBilling
,reporting_group = mds_matter.GPMSReportingGroup
,is_sanctions_checked = mds_matter.SanctionsChecked_YN
,is_security_wall_created = 0
,matter_phase_set_code = s_MAT_PH_SET.ZZPHASESET
,work_type_key = t_wt.work_type_key
,is_active = mds_matter.Active
,last_updated_date_utc_at_source = mds_matter.LastUpdatedDateGMT
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = GETUTCDATE()
,updated_date_time = GETUTCDATE()
,natural_key_hash = 'Internal'
FROM [dbo].[Matter] mds_Matter
INNER JOIN #MatterstoMigrate MatterstoMigrate ON mds_Matter.MatterID = MatterstoMigrate.MatterID
LEFT JOIN [Client] mds_client ON mds_Matter.ClientID = mds_client.ClientID
LEFT JOIN canonical_data_model.client canonical_client ON mds_client.ClientNumber = canonical_client.client_number AND mds_client.MemberFirmCode = canonical_client.member_firm_code
LEFT JOIN [Office] mds_Office ON mds_Matter.OfficeID = mds_Office.OfficeID
LEFT JOIN [MatterOffice] mds_MatterOffice ON mds_Matter.MatterID = mds_MatterOffice.MatterID
     and mds_MatterOffice.MattOfficeID in (select max(MattOfficeID) from [MatterOffice] where MatterID = mds_MatterOffice.MatterID)
LEFT JOIN [taxonomy_data_model].[curated_office] t_office ON mds_Office.OfficeCode = t_office.office_code COLLATE DATABASE_DEFAULT
LEFT JOIN [taxonomy_data_model].[curated_nature_of_proceeding] t_nopc ON mds_Matter.NatureOfProceeding = t_nopc.nature_of_proceeding_code COLLATE DATABASE_DEFAULT
LEFT JOIN [MatterStatus] mds_MatterStatus ON mds_Matter.MatterStatusID = mds_MatterStatus.MatterStatusID
LEFT JOIN [taxonomy_data_model].[curated_matter_status] t_mtstat ON mds_MatterStatus.PMSStatusCode = t_mtstat.matter_status_code COLLATE DATABASE_DEFAULT
LEFT JOIN [SAP_PROJ] gmdr_SAP_PROJ ON mds_Matter.MatterNumber = gmdr_SAP_PROJ.PSPID COLLATE DATABASE_DEFAULT and mds_matter.MemberFirmCode = 'GPMS'
LEFT JOIN [SAP_ZPRS_MATTERCATT] gmdr_SAP_ZPRS_MATTERCATT ON gmdr_SAP_PROJ.ZZMATTERCAT = gmdr_SAP_ZPRS_MATTERCATT.MATTERCAT
LEFT JOIN [taxonomy_data_model].[curated_matter_billing_frequency] t_mbf ON gmdr_SAP_PROJ.ZZBILLFREQ = RIGHT('00' + CAST(t_mbf.matter_billing_frequency_code AS VARCHAR(2)), 2)
LEFT JOIN [taxonomy_data_model].[curated_matter_billing_method] t_mbm ON gmdr_SAP_PROJ.ZZBILLMTHD = RIGHT('00' + CAST(t_mbm.matter_billing_method_code AS VARCHAR(2)), 2)
LEFT JOIN [taxonomy_data_model].[curated_matter_sector] t_mst ON mds_matter.SubIndustry = t_mst.sic_code COLLATE DATABASE_DEFAULT
LEFT JOIN SubTeam gmdr_subteam ON mds_matter.TeamID = gmdr_subteam.SubTeamID 
LEFT JOIN [taxonomy_data_model].[curated_team] t_team ON gmdr_subteam.SubTeamCode = t_team.team_code COLLATE DATABASE_DEFAULT
LEFT JOIN [taxonomy_data_model].[curated_matter_entry_type] t_met ON REPLACE(gmdr_SAP_PROJ.ZZENTTYPE, '0','') = t_met.matter_entry_type_code COLLATE DATABASE_DEFAULT
LEFT JOIN [taxonomy_data_model].[curated_work_type] t_wt ON mds_matter.TechnicalArea = t_wt.technical_area_code COLLATE DATABASE_DEFAULT
LEFT JOIN [taxonomy_data_model].[curated_company] t_Company ON mds_MatterOffice.CompanyCode = t_Company.company_code COLLATE DATABASE_DEFAULT
LEFT JOIN [taxonomy_data_model].[curated_practice_group] t_practice_group ON gmdr_SAP_PROJ.ZZPRACTICEGROUP = t_practice_group.practice_group_code COLLATE DATABASE_DEFAULT
LEFT JOIN #s_MAT_PH_SET s_MAT_PH_SET ON mds_Matter.MatterNumber = s_MAT_PH_SET.ZZPSPID COLLATE DATABASE_DEFAULT AND s_MAT_PH_SET.xRank = 1
LEFT JOIN #s_SAP_KNVK s_SAP_KNVK ON mds_client.ClientNumber = s_SAP_KNVK.KUNNR COLLATE DATABASE_DEFAULT AND s_SAP_KNVK.xRank = 1
LEFT JOIN #s_SAP_IHPA_PY s_SAP_IHPA_PY ON gmdr_SAP_PROJ.PSPID = s_SAP_IHPA_PY.PSPID COLLATE DATABASE_DEFAULT AND s_SAP_IHPA_PY.xRank = 1
LEFT JOIN [Client] Payer_Client ON s_SAP_IHPA_PY.PARNR = Payer_Client.ClientNumber COLLATE DATABASE_DEFAULT
LEFT JOIN #s_SAP_IHPA_Z3 s_SAP_IHPA_Z3 ON gmdr_SAP_PROJ.PSPID = s_SAP_IHPA_Z3.PSPID COLLATE DATABASE_DEFAULT AND s_SAP_IHPA_Z3.xRank = 1
LEFT JOIN [Client] Z3_Client ON s_SAP_IHPA_Z3.PARNR = Z3_Client.ClientNumber COLLATE DATABASE_DEFAULT
LEFT JOIN [taxonomy_data_model].[curated_matter_category] t_matter_category ON gmdr_SAP_ZPRS_MATTERCATT.MATTERCAT = t_matter_category.matter_category_code COLLATE DATABASE_DEFAULT
WHERE mds_Matter.MemberFirmCode in ('GPMS')
