# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Parameters

# PARAMETERS CELL ********************

# # This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
# source_settings = None
# target_settings = None
# source_connection_settings = None
# lineage_id = "2a05c657-0b3f-41a7-8796-a47ba6d9eb0f"
# task_executions_id = "a4ca02ba-2fa1-4407-989e-4623f98ae083"
# task_id = 94
# parent_run_id = "7f3a23e8-014d-4b5e-82b6-c3f5e32080bc"
# option_settings = None
# run_id = "d3c12921-244d-4b8d-84ab-fb77399c806f"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Configuration and imports

# CELL ********************

import sys
import json

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Import shared functions and setup logging

# CELL ********************

%run nb_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

setup_logging()
logger = logging.getLogger('ParallelizeLoadToBronze')
logger.setLevel(logging.INFO)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Main Execution Logic

# CELL ********************

# Get variable libraries
vl_authentication = notebookutils.variableLibrary.getLibrary('vl_authentication')
vl_guids = notebookutils.variableLibrary.getLibrary('vl_guids')

# Build bronze lakehouse path
bronze_workspace_id = vl_guids.bronze_workspace_id
bronze_lakehouse_id = vl_guids.bronze_lakehouse_id
lakehouse_path = f'abfss://{bronze_workspace_id}@onelake.dfs.fabric.microsoft.com/{bronze_lakehouse_id}'

# Identify notebook to run
notebook_path = 'nb_load_to_bronze'

# Extract configuration values
akv_uri = vl_authentication.akv_uri
tenant_id_secret_name = vl_authentication.tenant_id_secret_name
client_id_secret_name = vl_authentication.client_id_secret_name
client_secret_name = vl_authentication.client_secret_name

server = vl_guids.metadata_control_db_server
database = vl_guids.metadata_control_db_database

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Get task metadata for DAG execution
source_settings_json = json.loads(source_settings)
task_ids_to_execute = source_settings_json.get('task_ids')

# Instantiate Objects
metadata_db = SQLDatabase.from_metadata_control_db(akv_uri, tenant_id_secret_name, client_id_secret_name, client_secret_name, server, database)
execution_manager = ExecutionManager(metadata_db, logger)

# Get task metadata
task_metadata = execution_manager.generate_tasks_for_parallel_load(task_ids_to_execute, parent_run_id, 'bronze', run_id)
print(task_metadata)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

try:
    logger.info('Getting file directories that need to loaded to bronze...')
    logger.info(f'Running {len(task_metadata)} load_to_bronze jobs:')

    if not task_metadata:
        notebookutils.notebook.exit('No files to process')
    
    for task in task_metadata:
        metadata_db.execute_stored_procedure(
            'logging.usp_log_task_execution', 
            False, 
            run_id = run_id,
            task_id = task['task_id'],
            workspace_id = notebookutils.runtime.context['currentWorkspaceId'],
            executing_object_id = notebookutils.runtime.context.get('currentNotebookId'),
            executing_object_name = notebookutils.runtime.context.get('currentNotebookName'),
            executing_object_run_id = notebookutils.runtime.context.get('activityId'),
            executing_object_type = 'notebook',
            parent_run_id = parent_run_id,
            lineage_id = task['lineage_id'],
            task_executions_id = task['task_executions_id']
        )

    logger.info('Building DAG...')
    activities = []
    for i, task in enumerate(task_metadata):
        activities.append(
            {
                "name": task['task_name'],
                "path": notebook_path,
                "timeoutPerCellInSeconds": 7200,
                "args": task
            }
        )


    DAG = {
        "activities": activities,
        "timeoutInSeconds": 7200,
        "concurrency": 50
    }

    logger.info(f"Executing DAG for {len(DAG['activities'])} notebooks in parallel...")

    try:
        exit_values = notebookutils.notebook.runMultiple(DAG, {"displayDAGViaGraphviz": False})
        logger.info('All notebooks completed successfully')

    except Exception as run_exception:
        exit_values = run_exception.result

        failed_notebooks = []
        successful_notebooks = []

        # Map index back to activity names
        for activity_name, exit_value in exit_values.items():
            
            # Check if it failed
            if exit_value.get('exception') is not None:
                failed_notebooks.append({
                    'name': activity_name,
                    'exit_value': exit_value.get('exitVal'),
                    'error': str(exit_value.get('exception'))
                })
                logger.error(f"Notebook '{activity_name}' failed: {exit_value.get('exception')}")
            else:
                successful_notebooks.append(activity_name)
                logger.info(f"Notebook '{activity_name}' completed successfully")
        
        # Log summary
        logger.error(f"Failed: {len(failed_notebooks)} notebook(s)")
        logger.info(f"Successful: {len(successful_notebooks)} notebook(s)")

        raise

    ## Clean up empty directories
    logger.info('Cleaning up empty directories...')
    directory_maintenance = DirectoryMaintenance()

    root = f'{lakehouse_path}/Files/incoming/'
    directory_maintenance.delete_empty_directories(root, True)

    root = f'{lakehouse_path}/Files/processing/'
    directory_maintenance.delete_empty_directories(root, True)
    
except Exception as e:
    print(e)
    raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
