CREATE TABLE [meta].[data_products] (
    [data_product_id]   INT           IDENTITY (1, 1) NOT NULL,
    [data_product_name] VARCHAR (200) NULL,
    [description]       VARCHAR (MAX) NULL
);


GO

