CREATE TABLE [meta].[stages] (
    [stage_id]    INT           IDENTITY (1, 1) NOT NULL,
    [stage_name]  VARCHAR (200) NULL,
    [description] VARCHAR (MAX) NULL
);


GO

