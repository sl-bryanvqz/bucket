CREATE TABLE [logging].[execution_queue] (
    [parent_run_id]   UNIQUEIDENTIFIER NULL,
    [task_id]         INT              NULL,
    [queued_datetime] DATETIME2 (7)    NULL,
    [status]          VARCHAR (50)     NULL
);


GO

