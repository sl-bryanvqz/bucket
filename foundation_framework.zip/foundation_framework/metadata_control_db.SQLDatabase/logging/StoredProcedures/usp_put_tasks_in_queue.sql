
CREATE PROCEDURE logging.usp_put_tasks_in_queue
    @tasks_to_execute_json NVARCHAR(MAX),
    @parent_run_id UNIQUEIDENTIFIER
AS
BEGIN
    DECLARE @all_task_ids NVARCHAR(MAX);

    SELECT @all_task_ids =
        STRING_AGG(JSON_VALUE(j.value, '$.task_ids_in_stage'), ',')
            WITHIN GROUP (ORDER BY TRY_CONVERT(INT, JSON_VALUE(j.value, '$.stage')))
    FROM OPENJSON(@tasks_to_execute_json) j;

    INSERT INTO logging.execution_queue (
        parent_run_id
        , task_id
        , queued_datetime
        , status
    )
    SELECT
        @parent_run_id
        , task_id
        , GETDATE()
        , 'Queued'
    FROM (SELECT CAST(TRIM(value) as INT) as task_id FROM STRING_SPLIT(@all_task_ids, ','))x

END;

GO

