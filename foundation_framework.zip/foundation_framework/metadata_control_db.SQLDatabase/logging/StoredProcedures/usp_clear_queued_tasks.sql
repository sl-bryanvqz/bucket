
CREATE PROCEDURE [logging].[usp_clear_queued_tasks]
    @parent_run_id UNIQUEIDENTIFIER,
    @task_ids_in_stage NVARCHAR(MAX) = NULL
AS
BEGIN
    IF @task_ids_in_stage IS NULL OR @task_ids_in_stage = ''
    BEGIN
        DELETE FROM logging.execution_queue
        WHERE parent_run_id = @parent_run_id;
    END
    ELSE
    BEGIN
        DELETE FROM logging.execution_queue
        WHERE parent_run_id = @parent_run_id
          AND task_id IN (
              SELECT value
              FROM STRING_SPLIT(@task_ids_in_stage, ',')
              WHERE value <> ''
          );
    END
END;

GO

