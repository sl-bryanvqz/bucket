
CREATE PROCEDURE [logging].[usp_set_log_data]
    @task_executions_id UNIQUEIDENTIFIER,
    @log_data_string VARCHAR(MAX),
    @num_rows BIGINT
AS
BEGIN
    /**Update the logging.task_executions table to fill in the log_data and num_rows_ingested fields**/
    UPDATE
        logging.task_executions
    SET
        log_data = @log_data_string
        , num_rows_ingested = @num_rows
    WHERE
        task_executions_id = @task_executions_id
        AND log_data IS NULL
END;

GO

