
CREATE PROCEDURE [logging].[usp_get_api_watermark_val]
   @source_table VARCHAR(50),
   @column_inc_col VARCHAR(50)
AS
BEGIN
   SELECT watermark_value
   FROM logging.execution_watermark 
   WHERE source_table = @source_table and incremental_column=@column_inc_col
END

GO

