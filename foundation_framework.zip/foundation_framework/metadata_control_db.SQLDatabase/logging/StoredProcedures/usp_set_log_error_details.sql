
CREATE PROCEDURE [logging].[usp_set_log_error_details]
    @task_executions_id UNIQUEIDENTIFIER,
    @error_details_string VARCHAR(MAX)
AS
BEGIN
    /**Update the logging.task_executions table to fill in the error_details field**/
    UPDATE
        logging.task_executions
    SET
        error_details = @error_details_string
    WHERE
        task_executions_id = @task_executions_id
        AND error_details IS NULL
END;

GO

