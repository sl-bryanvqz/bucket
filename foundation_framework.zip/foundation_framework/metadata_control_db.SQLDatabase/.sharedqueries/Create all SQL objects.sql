--------------------------------
-------- Create schemas --------
--------------------------------

CREATE SCHEMA meta;
GO;
CREATE SCHEMA logging;
GO;
CREATE SCHEMA integration;


--------------------------------
------ Create task Table -------
--------------------------------
IF OBJECT_ID('meta.task') IS NOT NULL
    DROP TABLE meta.task;

CREATE TABLE meta.task (
	[task_id] [int] IDENTITY(1, 1) NOT NULL,
	[task_name] [varchar](200) NULL,
    [object_name] [varchar](200) NULL,
	[stage] [varchar](50) NULL,
    [source_connection_id] INT,
	[source_settings] [varchar](8000) NULL,
	[target_settings] [varchar](8000) NULL,
	[option_settings] [varchar](8000) NULL,
    [template_settings] [varchar](8000) NULL,
    [scheduling_settings] [varchar](8000) NULL,
	[enabled] [int] NULL,
    [file_hash] [varchar](8000) NULL
) ON [PRIMARY];


-----------------------------
-- Create meta.connections --
-----------------------------
IF OBJECT_ID('meta.connections') IS NOT NULL
    DROP TABLE meta.connections;

CREATE TABLE meta.connections (
    connection_id INT IDENTITY(1, 1),
    connection_name VARCHAR(200),
    uses_fabric_connection BIT,
    connection_settings VARCHAR(8000),
    [file_hash] [varchar](8000) NULL
);

-----------------------------
-- Create meta.task_metadata --
-----------------------------
IF OBJECT_ID('meta.task_metadata') IS NOT NULL
    DROP VIEW meta.task_metadata;

CREATE VIEW meta.task_metadata AS
SELECT
    t.task_id, t.task_name, t.stage, t.source_connection_id,
    e.uses_fabric_connection AS source_uses_fabric_connection,
    e.connection_settings AS source_connection_settings,
    t.source_settings, t.target_settings, t.option_settings,
    t.template_settings, t.scheduling_settings, t.enabled
FROM
    meta.task AS t
INNER JOIN
    meta.connections AS e
    ON
        t.source_connection_id = e.connection_id;


--------------------------------
-- Create usp_get_enabled_tasks --
--------------------------------
IF OBJECT_ID('meta.usp_get_enabled_tasks') IS NOT NULL
    DROP PROCEDURE meta.usp_get_enabled_tasks;

GO

CREATE PROCEDURE [meta].[usp_get_enabled_tasks]
    @stage VARCHAR(100) = NULL
AS
BEGIN
    IF @stage = '' 
        SET @stage = NULL

    SELECT
        NEWID() AS task_executions_id, NEWID() AS lineage_id, *
    FROM
        meta.task_metadata
    WHERE
        enabled = 1
        AND (
            @stage IS NULL
            OR UPPER(stage) = UPPER(@stage)
        )
END;


DROP PROCEDURE meta.usp_get_tasks_due_for_execution;
GO
CREATE PROCEDURE meta.usp_get_tasks_due_for_execution
    @current_time DATETIME = NULL,
    @stage VARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    IF @current_time IS NULL
        SET @current_time = GETUTCDATE();
    
    WITH
    last_runs AS (
        SELECT 
            task_id,
            MAX(start_datetime) as last_successful_run
        FROM
            logging.task_executions
        WHERE
            status = 'Completed'
        GROUP BY
            task_id
    ),
    currently_running AS (
        SELECT DISTINCT
            task_id
        FROM
            logging.task_executions
        WHERE
            status IS NULL -- Not sure if this always identifies running tasks. What about failures?
    ),
    tasks_with_scheduling AS (
        SELECT
            NEWID() AS task_executions_id,
            NEWID() AS lineage_id,
            t.task_id,
            t.task_name,
            t.stage,
            t.source_connection_id,
            t.source_connection_settings,
            t.source_settings,
            t.target_settings,
            t.option_settings,
            t.template_settings,            
            -- Extract scheduling parameters
            JSON_VALUE(t.scheduling_settings, '$.schedule_type') as schedule_type,
            JSON_QUERY(t.scheduling_settings, '$.scheduled_times') as scheduled_times,
            CAST(JSON_VALUE(t.scheduling_settings, '$.frequency_minutes') AS INT) as frequency_minutes,
            CAST(JSON_VALUE(t.scheduling_settings, '$.skip_if_running') AS BIT) as skip_if_running,
            -- Get last run info
            lr.last_successful_run,
            DATEDIFF(MINUTE, ISNULL(lr.last_successful_run, '1900-01-01'), @current_time) as minutes_since_last_run,
            
            -- Check if currently running
            CASE WHEN cr.task_id IS NOT NULL THEN 1 ELSE 0 END as is_currently_running
            
        FROM
             meta.task_metadata AS t
        LEFT JOIN
            last_runs AS lr
            ON
                t.task_id = lr.task_id
        LEFT JOIN
            currently_running AS cr
            ON
                t.task_id = cr.task_id
        WHERE
            t.enabled = 1
            AND (@stage IS NULL OR t.stage = @stage)
    ),
    tasks_with_scheduling_detail AS (
        SELECT 
            task_executions_id,
            lineage_id,
            task_id,
            task_name,
            stage,
            source_connection_id,
            source_connection_settings,
            source_settings,
            target_settings,
            option_settings,
            template_settings,
            is_currently_running,
            skip_if_running,
            last_successful_run,
            schedule_type,
            frequency_minutes
            minutes_since_last_run,
            scheduled_times,
            @current_time AS curr_time,
            
            -- Determine if task is due
            CASE 
                -- If no schedule always run...won't want this after development is complete
                --WHEN schedule_type IS NULL THEN 1
    
                -- Skip if currently running and configured to do so
                WHEN is_currently_running = 1 AND skip_if_running = 1 THEN 0
                
                -- Never run before - always due
                WHEN last_successful_run IS NULL THEN 1
                
                -- Interval-based scheduling: check if enough time has passed
                WHEN schedule_type = 'interval' 
                    AND minutes_since_last_run >= frequency_minutes THEN 1
                
                -- Time-of-day scheduling: check if past scheduled time and not run today
                WHEN schedule_type = 'time_of_day'
                    AND scheduled_times IS NOT NULL
                    AND EXISTS (
                         SELECT 1
                         FROM OPENJSON(scheduled_times) WITH (time_slot TIME '$') AS times
                         WHERE CAST(@current_time AS TIME) >= times.time_slot
                           -- Check if we haven't run since this time slot today
                           AND (last_successful_run IS NULL 
                                OR CAST(last_successful_run AS DATE) < CAST(@current_time AS DATE)  -- Last run was yesterday or earlier
                                OR CAST(last_successful_run AS TIME) < times.time_slot)  -- Last run was before this time slot today
                     ) THEN 1
                
                ELSE 0
            END as is_due
            
        FROM
            tasks_with_scheduling
    )
    SELECT *
    FROM
        tasks_with_scheduling_detail
    WHERE
        is_due = 1
END

-----------------------------------
-- Create logging.task_executions --
-----------------------------------
IF OBJECT_ID('logging.task_executions') IS NOT NULL
    DROP TABLE logging.task_executions;

GO

CREATE TABLE logging.task_executions (
    task_executions_id UNIQUEIDENTIFIER NOT NULL,
    lineage_id UNIQUEIDENTIFIER NOT NULL,
    run_id UNIQUEIDENTIFIER NOT NULL,
    parent_run_id UNIQUEIDENTIFIER NULL,
    task_id INT NOT NULL,
    task_name VARCHAR(200) NULL,
    stage VARCHAR(50) NULL,
    status VARCHAR(20) NULL,
	start_date DATE NOT NULL,
	start_datetime DATETIME2(6) NOT NULL,
	end_datetime DATETIME2(6) NULL,
	template_name VARCHAR(200) NULL,
    workspace_id UNIQUEIDENTIFIER NULL,
    log_data VARCHAR(8000) NULL,
    monitoring_url VARCHAR(200) NULL,
    next_stage_status VARCHAR(20) NULL,
    object_name VARCHAR(200) NULL
)

-----------------------------------------
-- Create logging.usp_log_task_execution --
-----------------------------------------
IF OBJECT_ID('logging.usp_log_task_execution') IS NOT NULL
    DROP PROCEDURE logging.usp_log_task_execution;

GO

CREATE PROCEDURE [logging].[usp_log_task_execution]
    @task_executions_id UNIQUEIDENTIFIER,
    @lineage_id UNIQUEIDENTIFIER,
    @run_id UNIQUEIDENTIFIER,
    @parent_run_id UNIQUEIDENTIFIER,
    @task_id INT,
    @workspace_id UNIQUEIDENTIFIER,
    @executing_object_id UNIQUEIDENTIFIER,
    @executing_object_name VARCHAR(200),
    @executing_object_run_id UNIQUEIDENTIFIER,
    @executing_object_type VARCHAR(20)
AS
BEGIN
    SET NOCOUNT OFF

    DECLARE
        @task_name VARCHAR(200),
        @stage VARCHAR(50),
        @template_name VARCHAR(100),
        @monitoring_url VARCHAR(200),
        @object_name VARCHAR(200)
        
    SELECT
        @task_name = task_name,
        @stage = stage,
        @template_name = COALESCE(JSON_VALUE(template_settings, '$.template_name'), @executing_object_name),
        @monitoring_url =
            CASE
                WHEN LOWER(@executing_object_type) = 'pipeline' THEN LOWER('https://app.powerbi.com/workloads/data-pipeline/monitoring/workspaces/' + CONVERT(varchar(36), @workspace_id) + '/pipelines/' + @executing_object_name + '/' + CONVERT(VARCHAR(36), @executing_object_run_id))
                WHEN LOWER(@executing_object_type) = 'notebook' THEN LOWER('https://app.powerbi.com/workloads/de-ds/sparkmonitor/' + CONVERT(VARCHAR(36), @executing_object_id) + '/' + CONVERT(VARCHAR(36), @executing_object_run_id) + '/?experience=fabric-developer/')
                ELSE NULL
            END,
        @object_name = object_name
    FROM
        meta.task
    WHERE
        task_id = @task_id

    INSERT INTO logging.task_executions (
        task_executions_id,
        lineage_id,
        run_id,
        parent_run_id,
        task_id,
        task_name,
        stage,
        start_date,
        start_dateTime,
        template_name,
        workspace_id,
        monitoring_url,
        object_name
    )
    VALUES (
        @task_executions_id,
        @lineage_id,
        @run_id,
        @parent_run_id,
        @task_id,
        @task_name,
        @stage,
        CONVERT(DATE, GETDATE()),
        GETDATE(),
        @template_name,
        @workspace_id,
        @monitoring_url,
        @object_name
    )
END
GO

---------------------------------------------------
-- Create logging.usp_log_task_execution_completion --
---------------------------------------------------
IF OBJECT_ID('logging.usp_log_task_execution_completion') IS NOT NULL
    DROP PROCEDURE logging.usp_log_task_execution_completion;

GO

CREATE PROCEDURE logging.usp_log_task_execution_completion
    @task_executions_id UNIQUEIDENTIFIER,
    @status VARCHAR(50),
    @next_stage_status VARCHAR(20)
AS
BEGIN
    UPDATE
        logging.task_executions
    SET
        status = @status,
        next_stage_status = @next_stage_status,
        end_datetime = GETDATE()
    WHERE
        task_executions_id = @task_executions_id
        AND end_datetime IS NULL
END

----------------------------------------------
-- Create logging.usp_update_processed_flag --
----------------------------------------------
IF OBJECT_ID('logging.usp_update_processed_flag') IS NOT NULL
    DROP PROCEDURE logging.usp_update_processed_flag;
GO

CREATE PROCEDURE logging.usp_update_processed_flag
    @task_executions_id UNIQUEIDENTIFIER,
    @next_stage_status VARCHAR(20)
AS
BEGIN
    UPDATE
        logging.task_executions
    SET
        next_stage_status = @next_stage_status
    WHERE
        task_executions_id = @task_executions_id
END

----------------------------------------------------
-- Create logging.usp_set_custom_log__extract_sql --
----------------------------------------------------
IF OBJECT_ID('logging.usp_set_custom_log__extract_sql') IS NOT NULL
    DROP PROCEDURE logging.usp_set_custom_log__extract_sql;

GO

CREATE PROCEDURE logging.usp_set_custom_log__extract_sql
    @task_executions_id UNIQUEIDENTIFIER,
    @source_fabric_connection_id VARCHAR(200),
    @source_database_name VARCHAR(200),
    @source_schema_name VARCHAR(200),
    @source_table_name VARCHAR(200),
    @target_lakehouse_id VARCHAR(200),
    @target_workspace_id VARCHAR(200),
    @target_file_path VARCHAR(400),
    @target_file_name VARCHAR(200),
    @sql_query VARCHAR(400)
AS
BEGIN
    DECLARE @log_data VARCHAR(8000)
    SELECT @log_data = JSON_OBJECT(
                    'source_fabric_connection_id': @source_fabric_connection_id,
                    'source_database_name': @source_database_name,
                    'source_schema_name': @source_schema_name,
                    'source_table_name': @source_table_name,
                    'target_lakehouse_id': @target_lakehouse_id,
                    'target_workspace_id': @target_workspace_id,
                    'target_file_path': @target_file_path,
                    'target_file_name': @target_file_name,
                    'sql_query': @sql_query
                )

    UPDATE
        logging.task_executions
    SET
        log_data = @log_data 
    WHERE
        task_executions_id = @task_executions_id
        AND log_data IS NULL
END;


--------------------------------------------------------
-- Create integration.usp_get_previous_watermark_date --
--------------------------------------------------------
IF OBJECT_ID('integration.usp_get_previous_watermark_date') IS NOT NULL
    DROP PROCEDURE integration.usp_get_previous_watermark_date;

CREATE PROCEDURE integration.[usp_get_previous_watermark_date]
   @task_id VARCHAR(50),
   @current_watermark_datetime DATETIME
AS
BEGIN
   SELECT COALESCE(MAX(start_dateTime), '1900-01-01') AS previous_watermark_date
   FROM
      logging.task_executions
   WHERE
      task_id = @task_id
      AND status = 'Completed'
      --AND start_dateTime < @current_watermark_datetime  -- If the process is run twice for the same watermark date, we want to replace the extracts incremental tables that were run on the same day
END
GO


--------------------------------------------------------
-- Create integration.usp_get_files_to_load_to_bronze --
--------------------------------------------------------
IF OBJECT_ID('integration.usp_get_files_to_load_to_bronze') IS NOT NULL
    DROP PROCEDURE integration.usp_get_files_to_load_to_bronze;

GO

CREATE PROCEDURE integration.[usp_get_files_to_load_to_bronze]
    @bronze_workspace_id VARCHAR(200),
    @bronze_lakehouse_id VARCHAR(200)
AS
SELECT
    --execution.task_log_id AS raw_task_log_id,
    --execution.lineage_id AS raw_lineage_id,
    execution.task_executions_id AS previous_task_executions_id,
    execution.lineage_id AS previous_lineage_id,
    @bronze_workspace_id AS bronze_workspace_id,
    @bronze_lakehouse_id AS bronze_lakehouse_id,
    meta.task_id,
    meta.task_name,
    meta.source_settings,
    meta.target_settings,
    meta.option_settings
FROM
    meta.task AS meta
INNER JOIN
    logging.task_executions AS execution
    ON
        execution.object_name = meta.object_name
        AND execution.stage = 'Extract'
WHERE
    meta.stage = 'Load to bronze'
    AND execution.next_stage_status = 'Ready'
    AND execution.status = 'Completed'


--------------------------------------------------------
-- Create integration.usp_get_files_to_load_to_silver --
--------------------------------------------------------
IF OBJECT_ID('integration.usp_get_run_ids_to_load_to_silver') IS NOT NULL
    DROP PROCEDURE integration.usp_get_run_ids_to_load_to_silver;

GO

CREATE PROCEDURE integration.[usp_get_run_ids_to_load_to_silver]
AS
SELECT
    execution.task_executions_id AS previous_task_executions_id,
    execution.lineage_id AS previous_lineage_id,
    meta.task_id,
    meta.task_name,
    meta.source_settings,
    meta.target_settings
FROM
    meta.task AS meta
INNER JOIN
    logging.task_executions AS execution
    ON
        execution.object_name = meta.object_name
WHERE
    meta.stage = 'Load to silver'
    AND execution.stage = 'Load to bronze'
    AND execution.next_stage_status = 'Ready'
    AND execution.status = 'Completed'

---------------------------------------------------------------
-- Create integration.usp_generate_html_table_of_failed_runs --
---------------------------------------------------------------

IF OBJECT_ID('integration.usp_generate_html_table_of_failed_runs') IS NOT NULL
    DROP PROCEDURE integration.usp_generate_html_table_of_failed_runs;

GO

CREATE PROCEDURE integration.[usp_generate_html_table_of_failed_runs]
    @parent_run_id VARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @html NVARCHAR(MAX);

    -- Build HTML table
    SET @html = N'
    <html>
    <head>
        <style>
            table {
                border-collapse: collapse;
                width: 100%;
                font-family: Arial, sans-serif;
                margin: 20px 0;
            }
            th {
                background-color: #d32f2f;
                color: white;
                padding: 12px;
                text-align: left;
                font-weight: bold;
            }
            td {
                border: 1px solid #ddd;
                padding: 10px;
                vertical-align: top;
            }
            tr:nth-child(even) {
                background-color: #f9f9f9;
            }
            tr:hover {
                background-color: #f5f5f5;
            }
            .error-cell {
                font-family: monospace;
                font-size: 12px;
                max-width: 500px;
                word-wrap: break-word;
            }
        </style>
    </head>
    <body>
        <h2>Failed Notebook Runs Report</h2>
        <p>Parent Run ID: ' + @parent_run_id + '</p>
        <p>The following notebooks failed during execution:</p>
        <table>
            <thead>
                <tr>
                    <th>Run ID</th>
                    <th>Task Id</th>
                    <th>Task Name</th>
                    <th>Start Date</th>
                </tr>
            </thead>
            <tbody>';

    -- Add data rows using FOR XML PATH
    SELECT @html = @html + 
        N'<tr>' +
        N'<td>' + ISNULL(CAST(run_id AS NVARCHAR(50)), 'N/A') + N'</td>' +
        N'<td>' + ISNULL(CAST(task_id AS NVARCHAR(50)), 'N/A') + N'</td>' +
        N'<td>' + ISNULL(CAST(task_name AS NVARCHAR(50)), 'N/A') + N'</td>' +
        N'<td>' + ISNULL(CAST(start_date AS NVARCHAR(50)), 'N/A') + N'</td>' +
        N'</tr>'

    FROM
        logging.task_executions
    WHERE
        parent_run_id = @parent_run_id
        AND status = 'Failed'

    -- Close HTML
    SET @html = @html + N'
            </tbody>
        </table> ' + 
        N'</p>
    </body>
    </html>';

    -- Remove new lines
    SET @html = REPLACE(REPLACE(@html, CHAR(13), ''), CHAR(10), '');
    -- Return as single row
    SELECT @html AS html_report;
END;


exec integration.[usp_generate_html_table_of_failed_runs] '3078fc80-d437-47df-991d-5ecca2b0f125'