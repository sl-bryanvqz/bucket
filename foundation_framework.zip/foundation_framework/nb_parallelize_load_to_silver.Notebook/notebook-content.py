# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# MARKDOWN ********************

# ##### Parameters

# PARAMETERS CELL ********************

# # This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
# source_settings = "{\"task_ids\":\"3,6,12,72\"}"
# target_settings = None
# source_connection_settings = None
# lineage_id = "42e50c40-e0fc-4053-a504-bd1f3f56e5df"
# task_executions_id = "1202b67c-9e26-413f-82b8-3d8ba9848691"
# task_id = 104
# parent_run_id = "96ca1fc0-be87-4f9a-8795-06f91ab1d7a1"
# option_settings = None
# run_id = "f52c7e7e-3fef-4d59-8e01-cfd0fa140834"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Configuration and imports

# CELL ********************

import sys
import json

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Import shared functions and setup logging

# CELL ********************

%run nb_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

setup_logging()
logger = logging.getLogger('ParallelizeLoadToSilver')
logger.setLevel(logging.INFO)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### Main Execution Logic

# CELL ********************

# Get variable libraries
vl_authentication = notebookutils.variableLibrary.getLibrary('vl_authentication')
vl_guids = notebookutils.variableLibrary.getLibrary('vl_guids')

# Build silver lakehouse path
silver_workspace_id = vl_guids.silver_workspace_id
silver_lakehouse_id = vl_guids.silver_lakehouse_id
lakehouse_path = f'abfss://{silver_workspace_id}@onelake.dfs.fabric.microsoft.com/{silver_lakehouse_id}'

# Identify notebook to run
notebook_path = 'nb_load_to_silver'

# Extract configuration values
akv_uri = vl_authentication.akv_uri
tenant_id_secret_name = vl_authentication.tenant_id_secret_name
client_id_secret_name = vl_authentication.client_id_secret_name
client_secret_name = vl_authentication.client_secret_name
server = vl_guids.metadata_control_db_server
database = vl_guids.metadata_control_db_database

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Get task metadata for DAG execution
source_settings_json = json.loads(source_settings)
task_ids_to_execute = source_settings_json.get('task_ids')

# Instantiate Objects
metadata_db = SQLDatabase.from_metadata_control_db(akv_uri, tenant_id_secret_name, client_id_secret_name, client_secret_name, server, database)
execution_manager = ExecutionManager(metadata_db, logger)

# Get task metadata
task_metadata = execution_manager.generate_tasks_for_parallel_load(task_ids_to_execute, parent_run_id, 'silver', run_id)
print(task_metadata)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

try:
    logger.info('Getting lineage_ids/rows that need to loaded to silver...')
    logger.info(f'Running {len(task_metadata)} load_to_silver jobs:')

    if not task_metadata:
        notebookutils.notebook.exit('No data to process')

    for task in task_metadata:
        metadata_db.execute_stored_procedure(
            'logging.usp_log_task_execution', 
            False, 
            run_id = run_id,
            task_id = task['task_id'],
            workspace_id = notebookutils.runtime.context['currentWorkspaceId'],
            executing_object_id = notebookutils.runtime.context.get('currentNotebookId'),
            executing_object_name = notebookutils.runtime.context.get('currentNotebookName'),
            executing_object_run_id = notebookutils.runtime.context.get('activityId'),
            executing_object_type = 'notebook',
            parent_run_id = parent_run_id,
            lineage_id = task['lineage_id'],
            task_executions_id = task['task_executions_id']
        )

    logger.info('Building DAG...')
    activities = []
    for i, task in enumerate(task_metadata):
        activities.append(
            {
                "name": task['task_name'],
                "path": notebook_path,
                "timeoutPerCellInSeconds": 7200,
                "args": task
            }
        )
    DAG = {
        "activities": activities,
        "timeoutInSeconds": 7200,
        "concurrency": 50
    }
    logger.info(f"Executing DAG for {len(DAG['activities'])} notebooks in parallel...")

    try:
        exit_values = notebookutils.notebook.runMultiple(DAG, {"displayDAGViaGraphviz": False})
        logger.info('All notebooks completed successfully')

    except Exception as run_exception:
        exit_values = run_exception.result

        failed_notebooks = []
        successful_notebooks = []

        # Map index back to activity names
        for idx_str, exit_value in exit_values.items():
            idx = int(idx_str)
            activity_name = activities[idx]['name']
            
            # Check if it failed
            if exit_value.get('exception') is not None:
                failed_notebooks.append({
                    'name': activity_name,
                    'index': idx,
                    'exit_value': exit_value.get('exitVal'),
                    'error': str(exit_value.get('exception'))
                })
                logger.error(f"Notebook '{activity_name}' failed: {exit_value.get('exception')}")
            else:
                successful_notebooks.append(activity_name)
                logger.info(f"Notebook '{activity_name}' completed successfully")
        
        # Log summary
        logger.error(f"Failed: {len(failed_notebooks)} notebook(s)")
        logger.info(f"Successful: {len(successful_notebooks)} notebook(s)")

        raise

except Exception as e:
    print(e)
    raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
