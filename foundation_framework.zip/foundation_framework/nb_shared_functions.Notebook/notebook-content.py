# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

import sys
import logging

import urllib.parse
from sqlalchemy import create_engine, text
from typing import Dict, Any, Optional, List

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Define a function for logging
def setup_logging():
    '''
    Set up logging configuration for Fabric notebooks.
    '''
    # Create formatter
    FORMAT = "%(asctime)s UTC - %(levelname)s - %(message)s (%(name)s)"
    formatter = logging.Formatter(fmt=FORMAT)

    # Get root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.WARNING)

    # Check if handlers exist, if not add console handler
    if not root_logger.handlers:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)
        root_logger.addHandler(console_handler)
    else:
        # Apply formatter to existing handlers
        for handler in root_logger.handlers:
            handler.setFormatter(formatter)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

class DirectoryMaintenance:

    def __init__(self):
        pass


    def _ls(self, path):
        try:
            return notebookutils.fs.ls(path)
        except Exception:
            return []


    def _is_dir(self, entry):
        return getattr(entry, "isDir", False)


    def _depth(self, path: str) -> int:
        return path.strip("/").count("/")

    
    def delete_empty_directories(self, root: str, protect_root: bool = True) -> None:
        """
        Delete empty directories under `root`, deepest first.
        - `protect_root=True` prevents deleting the root itself.
        """
        # 1) collect all subdirectories
        stack = [root]
        directories = set()
        while stack:
            current = stack.pop()
            entries = self._ls(current)
            for entry in entries:
                if self._is_dir(entry):
                    directories.add(entry.path)
                    stack.append(entry.path)

        # 2) include the root for evaluation (we may skip deleting it)
        directories = list(directories | {root})
        # deepest first
        directories.sort(key=self._depth, reverse=True)

        # 3) delete empties
        for directory in directories:
            if protect_root and directory.rstrip("/") == root.rstrip("/"):
                continue
            if len(self._ls(directory)) == 0:
                try:
                    notebookutils.fs.rm(directory, True)  # recurrentsive delete of empty dir marker
                    file_path = f"Files/{directory.split('/Files/')[1]}"
                    logger.info(f"Deleted empty dir: {file_path}")
                except Exception as e:
                    # harmless if raced with another task or if the dir just got new files
                    pass

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import logging
from typing import Dict


def get_metadata_control_db_connection_info(akv_uri, tenant_id_secret_name, client_id_secret_name, client_secret_name, server, database, schema_name: str = "dbo") -> Dict[str, str]:
    """
    Retrieve metadata control database connection information from Azure Key Vault.
    
    Args:
        schema_name: Default schema name (defaults to 'dbo')
        
    Returns:
        Dictionary with connection parameters
        
    Raises:
        ValueError: If required secrets are missing or empty
    """
    try:
        # As of October 2025, SPN's cannot access Variable Libraries through Notebooks. Thus, this section is commented out. In the event that 
        # Microsoft fixes this issue, the code can be re-instated

        # Get variable libraries
        # vl_authentication = notebookutils.variableLibrary.getLibrary('vl_authentication')
        # vl_guids = notebookutils.variableLibrary.getLibrary('vl_guids')

        # Extract configuration values
        # akv_uri = vl_authentication.akv_uri
        # tenant_id_secret_name = vl_authentication.tenant_id_secret_name
        # client_id_secret_name = vl_authentication.client_id_secret_name
        # client_secret_name = vl_authentication.client_secret_name

        # Retrieve secrets from Key Vault
        tenant_id = notebookutils.credentials.getSecret(akv_uri, tenant_id_secret_name)
        client_id = notebookutils.credentials.getSecret(akv_uri, client_id_secret_name)
        client_secret = notebookutils.credentials.getSecret(akv_uri, client_secret_name)

        # Validate secrets were retrieved
        if not all([tenant_id, client_id, client_secret]):
            raise ValueError("One or more secrets could not be retrieved from Key Vault")

        # server = vl_guids.metadata_control_db_server
        # database = vl_guids.metadata_control_db_database

        return {
            #'tenant_id': tenant_id,
            'client_id': client_id,
            'client_secret': client_secret,
            'server': server,
            'database': database,
            'schema_name': schema_name
        }
        
    except Exception as e:
        logging.error(f"Failed to retrieve database connection information: {str(e)}")
        raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

class SQLDatabase:
    """
    A class for managing SQL Server database connections and operations using SQLAlchemy.
    """
    
    def __init__(self, server: str, database: str, client_id: str, client_secret: str, schema_name: str = "dbo"):
        """
        Initialize the database connection.
        
        Args:
            server: SQL Server instance
            database: Database name
            client_id: Service principal client ID
            client_secret: Service principal client secret
            schema_name: Default schema name (defaults to 'dbo')
        """
        self.server = server
        self.database = database
        self.client_id = client_id
        self.client_secret = client_secret
        self.schema_name = schema_name
        self.engine = None
        self._create_engine()
    
    def _create_engine(self):
        """Create the SQLAlchemy engine with the connection string."""
        connection_string = (
            f"DRIVER={{ODBC Driver 18 for SQL Server}};"
            f"SERVER={self.server};"
            f"DATABASE={self.database};"
            f"UID={self.client_id};"
            f"PWD={self.client_secret};"
            f"Authentication=ActiveDirectoryServicePrincipal;"
            f"DefaultSchema={self.schema_name};"
            f"Encrypt=yes;"
        )
        
        # URL encode the connection string      
        params = urllib.parse.quote_plus(connection_string)
        self.engine = create_engine(f'mssql+pyodbc:///?odbc_connect={params}')
    
    def execute_query(self, query: str, params: Optional[Dict[str, Any]] = None) -> List[Dict]:
        """
        Execute a SELECT query and return results as a list of dictionaries.
        
        Args:
            query: SQL query string
            params: Optional parameters for the query
            
        Returns:
            List of dictionaries representing the result rows
        """
        try:
            with self.engine.connect() as conn:
                if params:
                    result = conn.execute(text(query), params)
                else:
                    result = conn.execute(text(query))
                
                # Convert result to list of dictionaries
                columns = result.keys()
                return [dict(zip(columns, row)) for row in result.fetchall()]
                
        except Exception as e:
            logging.error(f"Error executing query: {e}")
            raise
    
    def execute_non_query(self, query: str, params: Optional[Dict[str, Any]] = None) -> int:
        """
        Execute a non-SELECT query (INSERT, UPDATE, DELETE, etc.) and return affected row count.
        
        Args:
            query: SQL query string
            params: Optional parameters for the query
            
        Returns:
            Number of affected rows
        """
        try:
            with self.engine.connect() as conn:
                if params:
                    result = conn.execute(text(query), params)
                else:
                    result = conn.execute(text(query))
                
                conn.commit()
                return result.rowcount
                
        except Exception as e:
            logging.error(f"Error executing non-query: {e}")
            raise
    
    def execute_stored_procedure(self, proc_name: str, show_query: bool = False, return_results: bool = False, **params) -> Any:
        """
        Execute a stored procedure with optional parameters.
        
        Args:
            proc_name: Name of the stored procedure
            return_results: Whether to return results (True) or just row count (False)
            **params: Keyword arguments for procedure parameters
            
        Returns:
            List of dictionaries if return_results=True, otherwise row count
        """
        exec_statement = self._build_exec_statement(proc_name, **params)
        if show_query:
            print(exec_statement)
        if return_results:
            return self.execute_query(exec_statement)
        else:
            return self.execute_non_query(exec_statement)
    
    def _build_exec_statement(self, proc_name: str, **params) -> str:
        """
        Build an EXEC statement for a stored procedure with parameters.
        
        Args:
            proc_name: Name of the stored procedure
            **params: Keyword arguments for procedure parameters
            
        Returns:
            Formatted EXEC statement
        """
        param_strs = []
        for key, value in params.items():
            if value is not None:
                if isinstance(value, str):
                    param_strs.append(f"@{key}='{value}'")
                else:
                    param_strs.append(f"@{key}={value}")
        
        if param_strs:
            return f"EXEC {proc_name} " + ", ".join(param_strs)
        else:
            return f"EXEC {proc_name}"
    
    def test_connection(self) -> bool:
        """
        Test the database connection.
        
        Returns:
            True if connection is successful, False otherwise
        """
        try:
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
                return True
        except Exception as e:
            logging.error(f"Connection test failed: {e}")
            return False
    
    def close(self):
        """Close the database engine."""
        if self.engine:
            self.engine.dispose()


    @classmethod
    def from_metadata_control_db(cls, akv_uri, tenant_id_secret_name, client_id_secret_name, client_secret, server, database, schema_name: str = "meta"):
        """
        Create SQLDatabase instance for metadata control database using Key Vault credentials.
        
        Args:
            schema_name: Schema name for the metadata database (defaults to 'meta')
            
        Returns:
            SQLDatabase instance connected to metadata control database
        """
        connection_info = get_metadata_control_db_connection_info(akv_uri, tenant_id_secret_name, client_id_secret_name, client_secret, server, database, schema_name)
        return cls(**connection_info)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

class ExecutionManager:
    """
    A class for handling reusable Logging activities in the framework

    Args:
        metadata_db_obj: SQLDatabase object, used to interact with the metadata SQL control db
        logger: Logger object, used to output spark logs
    """

    def __init__(self, metadata_db_obj, logger):
        self.metadata_db_obj = metadata_db_obj
        self.logger = logger


    def get_tasks_from_last_stage(self, task_id: int, parent_run_id: str, current_stage:str) -> str:
        """
        Builds a SQL query to fetch completed task_executions from the previous stage that are marked Ready for the next stage

        Args:
            task_id: The task_id from meta.task
            parent_run_id: The parent_run_id used from pl_orchestrator
            current_stage: options are either 'bronze' or 'silver'

        Returns:
            A list of all data returned by the SQL query. Can be empty, if no tasks are chained
        """

        if current_stage not in ['bronze','silver']:
            raise ValueError("layer must be either 'bronze' or 'silver'")

        execution_stage = 1 if current_stage == "bronze" else 2
        meta_stage = 2 if current_stage == "bronze" else 3 
                
        query = f"""
    SELECT
        execution.task_executions_id AS previous_task_executions_id,
        execution.lineage_id AS previous_lineage_id
    FROM
        meta.task AS meta
    INNER JOIN
        logging.task_executions AS execution
        ON execution.object_name = meta.object_name
        AND execution.stage = {execution_stage}
    WHERE
        meta.stage = {meta_stage}
        AND execution.next_stage_status = 'Ready'
        AND execution.status = 'Completed'
        AND meta.task_id = {task_id}
        AND meta.enabled = 1
        AND execution.parent_run_id = '{parent_run_id}'

    """
        try:
            query_output = self.metadata_db_obj.execute_query(query)
        except Exception as e:
            raise Exception(f'Something went wrong getting the previous task data. Likely due to issues at the logging.task_executions table or a server timeout issue. \n{e}')

        return query_output


    def update_execution_lineage_id(self, lineage_id: str, task_executions_id: str, parent_run_id: str, run_id: str) -> None:
        """
        Update the lineage_id for a task execution record in logging.task_executions.
        This is required because pl_worker will instantiate a record in logging.task_executions with a randomly generated GUID for lineage_id (this is simply how pl_worker works).
        However, IF there is a previously executed Extract task, we want the lineage_id to remain consistent throughout all stages (1,2, and 3), so we update the lineage_id from the 
        randomly generated one to the lineage_id from the previous task

        Args:
            lineage_id: The lineage_id of the previous task to set on the current task_execution
            task_executions_id: The task_executions currently running. This would have been generated by pl_worker upstream and passed into the notebook
            parent_run_id: The parent_run_id of the overarching pl_orchestrator
            run_id: The run_id of pl_worker

        Returns:
            None
        """
        try:
            self.metadata_db_obj.execute_non_query(f"""UPDATE logging.task_executions SET lineage_id = '{lineage_id}' 
            WHERE UPPER(task_executions_id) = '{task_executions_id.upper()}' AND parent_run_id = '{parent_run_id}' AND run_id = '{run_id}'""")
            self.logger.info(f"Successfully set lineage_id to {lineage_id} for task_executions_id={task_executions_id}")

        except Exception as e:
            raise Exception(f'Something went wrong getting the previous task data. Likely due to issues at the logging.task_executions table or a server timeout issue. \n{e}')


    def update_previous_execution_status_after_processing(self, lineage_ids_in_execution: list[str], current_stage:str) -> None:
        """
        Update previous task executions to mark their next_stage_status as Processed, after a file/table with a given lineage_id has been ingested by the calling stage

        Args:
            lineage_ids_in_execution: List of lineage IDs involved in the calling execution
            current_stage: options are either 'bronze' or 'silver'

        Returns:
            None
        """

        if current_stage not in ['bronze','silver']:
            raise ValueError("layer must be either 'bronze' or 'silver'")

        previous_stage = 1 if current_stage == "bronze" else 2

        if lineage_ids_in_execution == [] or not lineage_ids_in_execution:
            raise ValueError("lineage_ids_in_execution cannot be empty. Aborting execution")

        for lineage_id in lineage_ids_in_execution:
            update_query = f"""UPDATE logging.task_executions SET next_stage_status = 'Processed'
            WHERE UPPER(lineage_id) = '{lineage_id.upper()}' AND stage = {previous_stage} AND status = 'Completed' AND next_stage_status = 'Ready'
            """

            try:
                self.metadata_db_obj.execute_non_query(update_query)
                self.logger.info(f'Succesfully set next_stage_status to Processed for lineage_id {lineage_id}')
            except Exception as e:
                raise Exception(f'Error: {e}')


    def update_log_data_with_lineage_ids(self, lineage_ids_in_execution: list[str], task_executions_id:str, parent_run_id:str, run_id:str) -> None:
        """
        Updates the log_data field in logging.task_executions with the list of all lineage_ids that were ingested for this run

        Args:
            lineage_ids_in_execution: List of lineage IDs involved in the calling execution
            task_executions_id: The task_executions currently running. This would have been generated by pl_worker upstream and passed into the notebook
            parent_run_id: The parent_run_id of the overarching pl_orchestrator
            run_id: The run_id of pl_worker

        Returns:
            None
        """

        if lineage_ids_in_execution == [] or not lineage_ids_in_execution:
            raise ValueError("lineage_ids_in_execution cannot be empty. Aborting execution")

        log_data_str = f"""lineage_ids ingested in this run: {str(lineage_ids_in_execution).replace("'","''")}"""
        update_query = f"""UPDATE logging.task_executions SET log_data='{log_data_str}'
                           WHERE UPPER(task_executions_id) = '{task_executions_id.upper()}' AND parent_run_id = '{parent_run_id}' AND run_id = '{run_id}'"""
        
        try:
            self.metadata_db_obj.execute_non_query(update_query)
            self.logger.info(f'Succesfully set log_data field with all lineage_ids for the current run')
        except Exception as e:
            raise Exception(f'Error: {e}')

    def generate_tasks_for_parallel_load(self, tasks_ids_to_execute: str, parent_run_id: str, current_stage: str, run_id: str):
        """
        Build the SQL query used to fetch Bronze tasks that are eligible for execution.

        Args:
            bronze_tasks_to_execute: Comma-separated task_ids, e.g. "1,4,7"
            parent_run_id: pl_orchestrator run_id
            current_stage: options are either 'bronze' or 'silver'
            run_id: Current ADF run_id

        Returns:
            List of tasks and metadata to execute in parallel DAG
        """

        if current_stage not in ['bronze','silver']:
            raise ValueError("layer must be either 'bronze' or 'silver'")

        current_stage_id = 2 if current_stage == "bronze" else 3

        query_to_execute = f"""
        WITH tasks_in_stage AS (
            SELECT
                t.task_id,
                t.task_name,
                t.object_name,
                t.stage,
                t.source_connection_id,
                c.uses_fabric_connection AS source_uses_fabric_connection,
                c.connection_settings AS source_connection_settings,
                t.source_settings,
                t.target_settings,
                t.option_settings,
                t.template_settings
            FROM meta.task t
            LEFT JOIN meta.connections c
                ON t.source_connection_id = c.connection_id
            WHERE t.enabled = 1
            AND t.task_id IN ({tasks_ids_to_execute})
        ),
        latest_execution AS (
            SELECT task_id, object_name, stage, status, start_datetime, parent_run_id
            FROM (
                SELECT task_id, status, stage, object_name, start_datetime,parent_run_id,
                ROW_NUMBER() OVER (PARTITION BY task_id ORDER BY start_datetime DESC) AS row_num
                FROM logging.task_executions
                WHERE parent_run_id = '{parent_run_id}'
            ) AS subquery
            WHERE row_num = 1
        ),
        not_blocked AS (
            SELECT ct.*
            FROM tasks_in_stage ct
            WHERE EXISTS (
                SELECT 1
                FROM latest_execution te_prev
                INNER JOIN meta.task t_prev
                    ON t_prev.task_id = te_prev.task_id
                WHERE te_prev.parent_run_id = '{parent_run_id}'
                AND te_prev.status = 'Completed'
                AND t_prev.object_name = ct.object_name
                AND t_prev.stage = {current_stage_id-1}
            )
        ),
        re_run_check AS (
            SELECT *
            FROM logging.task_executions e
            WHERE e.parent_run_id = '{parent_run_id}'
            AND e.status IN ('Completed', 'No files to process')
            AND e.stage = {current_stage_id}
        )
        SELECT
            NEWID() AS task_executions_id,
            NEWID() AS lineage_id,
            nb.task_id,
            nb.task_name,
            nb.object_name,
            nb.stage,
            nb.source_connection_settings,
            nb.source_settings,
            nb.target_settings,
            nb.option_settings,
            nb.template_settings,
            '{parent_run_id}' AS parent_run_id,
            '{run_id}' AS run_id
        FROM not_blocked nb
        WHERE nb.task_id NOT IN (
            SELECT task_id
            FROM re_run_check
        );
        """
        
        try:
            task_metadata = self.metadata_db_obj.execute_query(query_to_execute)
            self.logger.info(f'Succesfully retrieved metadata needed for DAG execution')
        except Exception as e:
            raise Exception(f'Error: {e}')
            
        return task_metadata


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
