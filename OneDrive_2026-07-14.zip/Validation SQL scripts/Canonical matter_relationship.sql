--SCA3VTSQLSRV01
--[NRCAN_RMDD]
--Canonical matter_relationship

SELECT
matter_relationship_key	= 'Identity'
,matter_number = mds_matter.MatterNumber
,member_firm_code = mds_matter.MemberFirmCode
,parent_matter_number = mds_parent_matter.MatterNumber
,parent_member_firm_code = mds_parent_matter.MemberFirmCode
,matter_relationship_type = 'Parent'
,matter_key	= 'matter.matter_key'
,parent_matter_key = 'mds_parent_matter.matter_key'
,source_system = 'Internal'	
,inserted_process_instance_id = 'Internal'	
,updated_process_instance_id = 'Internal'	
,inserted_process_queue_id = 'Internal'	
,updated_process_queue_id = 'Internal'	
,inserted_date_time = 'Internal'	
,updated_date_time = 'Internal'	
,natural_key_hash = 'Internal'	
FROM [dbo].Matter mds_matter
LEFT JOIN [dbo].Matter mds_parent_matter ON mds_matter.ParentMatterID = mds_parent_matter.MatterID
WHERE mds_matter.MatterNumber = '1000034493'

