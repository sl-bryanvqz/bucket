--SCA3VTSQLSRV01
--[NRCAN_RMDD]
--Canonical Address

SELECT
 address_key = 'IDENTITY'
,address_id = mds_address.AddressID
,client_number = mds_client.ClientNumber
,member_firm_code = mds_client.MemberFirmCode
,client_key	= mds_client.ClientID
,address_type_code = mds_address.AddressTypeCode
,address_1 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Address1, CHAR(9), ''), CHAR(10), ''),CHAR(12), ''), CHAR(13), ''), CHAR(22), ''), CHAR(32), '')
,address_2 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Address2, CHAR(9), ''), CHAR(10), ''),CHAR(12), ''), CHAR(13), ''), CHAR(22), ''), CHAR(32), '')
,address_3 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Address3, CHAR(9), ''), CHAR(10), ''),CHAR(12), ''), CHAR(13), ''), CHAR(22), ''), CHAR(32), '')
,address_4 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Address4, CHAR(9), ''), CHAR(10), ''),CHAR(12), ''), CHAR(13), ''), CHAR(22), ''), CHAR(32), '')
,address_5 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Address5, CHAR(9), ''), CHAR(10), ''),CHAR(12), ''), CHAR(13), ''), CHAR(22), ''), CHAR(32), '')
,city = mds_address.City
--,country_code_iso2 = t_Country.country_code_iso2
,state = mds_address.State
,zip_code = mds_address.PostalCode
,street_address_check = CONCAT(mds_address.Address1 , mds_address.Address2, mds_address.Address3, mds_address.Address4, mds_address.Address5)
,is_active = mds_address.Active
,last_updated_date_utc_at_source = mds_address.LastUpdatedDateGMT
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = 'Internal'
,updated_date_time = 'Internal'
,natural_key_hash = 'Internal'
FROM [dbo].[Address] mds_address
LEFT JOIN [dbo].[Client] mds_client ON mds_address.EntityID = mds_client.ClientID
LEFT JOIN [dbo].[Country] mds_country ON mds_address.CountryID = mds_country.CountryID
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_country] t_Country ON mds_country.CountryCode = t_Country.country_code_iso2 COLLATE DATABASE_DEFAULT

--COLLATE DATABASE_DEFAULT
WHERE mds_address.AddressID IN ('216669')



--==========================================