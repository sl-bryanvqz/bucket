--SCA3VTSQLSRV01
--[NRCAN_RMDD]
--Canonical Matter

--where PSPID in ('1000034493')
--client_number = '10000203'

WITH s_MAT_PH_SET
AS
(SELECT DISTINCT RANK() OVER (PARTITION BY ZZPSPID ORDER BY BEGDA desc) AS xRank           
 ,ZZPSPID, ZZPHASESET, BEGDA, ENDDA, ZZCTSTAMP, ERNAM, ZZCHTSTAMP, AENAM, TIMESTAMP
      FROM [QA1_RMDR_CAN].[can].[SAP_ZPRS_MAT_PH_SET]
)
, s_SAP_KNVK
AS
(SELECT DISTINCT RANK() OVER (PARTITION BY KUNNR ORDER BY PARNR desc) AS xRank           
 ,PARNR, KUNNR, NAME1, ADRND, ADRNP, TELF1, PARAU, LOEVM, ADRNP_2, TIMESTAMP, NAMEV, ABTPA, TITEL_AP, PRSNR
      FROM [QA1_RMDR_CAN].[can].[SAP_KNVK]
)
, s_SAP_IHPA_PY
AS
(SELECT DISTINCT RANK() OVER (PARTITION BY PSPID ORDER BY COUNTER desc) AS xRank           
 ,PSPID, PARVW, COUNTER, PARNR, KZLOESCH, TIMESTAMP
      FROM [QA1_RMDR_CAN].[can].[SAP_IHPA]
      WHERE PARVW = 'PY' and KZLOESCH <> 'X'
)
, s_SAP_IHPA_Z3
AS
(SELECT DISTINCT RANK() OVER (PARTITION BY PSPID ORDER BY COUNTER desc) AS xRank           
 ,PSPID, PARVW, COUNTER, PARNR, KZLOESCH, TIMESTAMP
      FROM [QA1_RMDR_CAN].[can].[SAP_IHPA]
      WHERE PARVW = 'Z3' and KZLOESCH <> 'X'
)
SELECT
 matter_key = 'IDENTITY COLUMN'
,matter_number = mds_Matter.MatterNumber
,member_firm_code = mds_Matter.MemberFirmCode
,matter_id = mds_Matter.MatterID
,pms_matter_id = mds_Matter.PMSMatterID
,matter_name = mds_Matter.MatterName
,long_matter_name = mds_Matter.LongMatterName
,alternate_matter_name = mds_Matter.AlternateMatterName
,alternate_matter_number = mds_Matter.AlternateMatterNumber
,matter_create_date_utc = 'cmidb'
,matter_name_cmi = 'cmidb'
,member_firm_code_cmi = 'cmidb'
,matter_description_cmi = 'cmidb'
,billing_office_Code = mds_Office.OfficeCode
--,billing_office_key = t_office.office_key
,nature_of_proceeding_Code = mds_Matter.NatureOfProceeding
--,nature_of_proceeding_key = t_nopc.nature_of_proceeding_key
,matter_status_Code = mds_MatterStatus.PMSStatusCode
--,matter_status_key = t_mtstat.matter_status_key
,matter_status_cmi_key = 'cmidb'
--,matter_company_code = t_Company.company_code
,client_number = mds_Client.ClientNumber -- Client_Key?????????????????????????????????????????????????????????????????????
,practice_group_Code = gmdr_SAP_PROJ.ZZPRACTICEGROUP
--,practice_group_key	= t_practice_group.practice_group_key
,matter_category_key = gmdr_SAP_ZPRS_MATTERCATT.MATTERCAT
,is_confidential = mds_Matter.Confidential
,matter_pass_through_flag = gmdr_SAP_PROJ.ZZPASSTHRU
,currency_code = mds_Matter.CurrencyCode
,matter_jurisdiction_code_cmi = 'cmidb'
,matter_fee_estimate_cmi = 'cmidb'
,matter_cost_estimate_cmi = 'cmidb'
,matter_billing_frequency_Code = gmdr_SAP_PROJ.ZZBILLFREQ
--,matter_billing_frequency_key = t_mbf.matter_billing_frequency_key
,matter_billing_method_Code = gmdr_SAP_PROJ.ZZBILLMTHD
--,matter_billing_method_key = t_mbm.matter_billing_method_key
,matter_open_date_utc =	mds_matter.MatterOpenDateGMT
,matter_close_date_utc = mds_matter.MatterCloseDateGMT
,matter_billable_flag = mds_matter.MatterBillableFlag
,matter_time_unit =	mds_matter.MatterTimeUnit
,matter_sector_Code = mds_matter.SubIndustry
--,matter_sector_key = t_mst.matter_sector_key
,team_Code = gmdr_subteam.SubTeamCode
--,team_key = t_team.team_key
,matter_purchase_order_number = gmdr_SAP_PROJ.ZZIPPONUM	
,ip_matter_number = gmdr_SAP_PROJ.ZZIP_REF_NUM
,matter_entry_type_Code = gmdr_SAP_PROJ.ZZENTTYPE
--,matter_entry_type_key = t_met.matter_entry_type_key
,comments = mds_matter.Comments
,matter_pricing_group = gmdr_SAP_PROJ.ZZMPRGRP
,client_bill_contact_code = s_SAP_KNVK.PARNR
,client_bill_contact_name = TRIM(CAST(CASE WHEN s_SAP_KNVK.NAMEV ='' THEN s_SAP_KNVK.NAME1 ELSE CONCAT(s_SAP_KNVK.NAMEV,' ',s_SAP_KNVK.NAME1) END AS VARCHAR(50)))
,payer_code = s_SAP_IHPA_PY.PARNR
,payer_name	= Payer_Client.ClientName
,z3_payer_code = s_SAP_IHPA_Z3.PARNR
,z3_payer_name = Z3_Client.ClientName
,client_case_number = gmdr_SAP_PROJ.ZZCLCASENBR
,client_case_description = gmdr_SAP_PROJ.ZZCLCASENAME
,group_billing = mds_matter.GPMSGroupBilling
,reporting_group = mds_matter.GPMSReportingGroup
,is_sanctions_checked = mds_matter.SanctionsChecked_YN
,is_security_wall_created = 'wallbuilder'
,matter_phase_set_code = s_MAT_PH_SET.ZZPHASESET
,work_type_Code = mds_matter.TechnicalArea
--,work_type_key = t_wt.work_type_key
,is_active = mds_matter.Active
,last_updated_date_utc_at_source = mds_matter.LastUpdatedDateGMT
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = 'Internal'
,updated_date_time = 'Internal'
,natural_key_hash = 'Internal'

FROM [dbo].[Matter] mds_Matter
LEFT JOIN [Client] mds_Client ON mds_Matter.ClientID = mds_Client.ClientID
LEFT JOIN [Office] mds_Office ON mds_Matter.OfficeID = mds_Office.OfficeID
LEFT JOIN [MatterOffice] mds_MatterOffice ON mds_Matter.MatterID = mds_MatterOffice.MatterID
     and mds_MatterOffice.MattOfficeID in (select max(MattOfficeID) from [MatterOffice] where MatterID = mds_MatterOffice.MatterID)
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_office] t_office ON mds_Office.OfficeCode = t_office.office_code COLLATE DATABASE_DEFAULT
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_nature_of_proceeding] t_nopc ON mds_Matter.NatureOfProceeding = t_nopc.nature_of_proceeding_code COLLATE DATABASE_DEFAULT
LEFT JOIN [MatterStatus_GMDR] mds_MatterStatus ON mds_Matter.MatterStatusID = mds_MatterStatus.MatterStatusID
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_matter_status] t_mtstat ON mds_MatterStatus.PMSStatusCode = t_mtstat.matter_status_code COLLATE DATABASE_DEFAULT
LEFT JOIN [QA1_RMDR_CAN].[can].[SAP_PROJ] gmdr_SAP_PROJ ON mds_Matter.MatterNumber = gmdr_SAP_PROJ.PSPID COLLATE DATABASE_DEFAULT and mds_matter.MemberFirmCode = 'GPMS'
LEFT JOIN [QA1_RMDR_CAN].[dbo].[SAP_ZPRS_MATTERCATT] gmdr_SAP_ZPRS_MATTERCATT ON gmdr_SAP_PROJ.ZZMATTERCAT = gmdr_SAP_ZPRS_MATTERCATT.MATTERCAT
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_matter_billing_frequency] t_mbf ON gmdr_SAP_PROJ.ZZBILLFREQ = RIGHT('00' + CAST(t_mbf.matter_billing_frequency_code AS VARCHAR(2)), 2)
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_matter_billing_method] t_mbm ON gmdr_SAP_PROJ.ZZBILLMTHD = RIGHT('00' + CAST(t_mbm.matter_billing_method_code AS VARCHAR(2)), 2)
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_matter_sector] t_mst ON mds_matter.SubIndustry = t_mst.sic_code COLLATE DATABASE_DEFAULT
LEFT JOIN SubTeam gmdr_subteam ON mds_matter.TeamID = gmdr_subteam.SubTeamID 
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_team] t_team ON gmdr_subteam.SubTeamCode = t_team.team_code COLLATE DATABASE_DEFAULT
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_matter_entry_type] t_met ON REPLACE(gmdr_SAP_PROJ.ZZENTTYPE, '0','') = t_met.matter_entry_type_code COLLATE DATABASE_DEFAULT
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_work_type] t_wt ON mds_matter.TechnicalArea = t_wt.technical_area_code COLLATE DATABASE_DEFAULT
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_company] t_Company ON mds_MatterOffice.CompanyCode = t_Company.company_code COLLATE DATABASE_DEFAULT
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_practice_group] t_practice_group ON gmdr_SAP_PROJ.ZZPRACTICEGROUP = t_practice_group.practice_group_code COLLATE DATABASE_DEFAULT
LEFT JOIN s_MAT_PH_SET ON mds_Matter.MatterNumber = s_MAT_PH_SET.ZZPSPID COLLATE DATABASE_DEFAULT AND s_MAT_PH_SET.xRank = 1
LEFT JOIN s_SAP_KNVK ON mds_Client.ClientNumber = s_SAP_KNVK.KUNNR COLLATE DATABASE_DEFAULT AND s_SAP_KNVK.xRank = 1
LEFT JOIN s_SAP_IHPA_PY ON gmdr_SAP_PROJ.PSPID = s_SAP_IHPA_PY.PSPID COLLATE DATABASE_DEFAULT AND s_SAP_IHPA_PY.xRank = 1
LEFT JOIN [Client] Payer_Client ON s_SAP_IHPA_PY.PARNR = Payer_Client.ClientNumber COLLATE DATABASE_DEFAULT
LEFT JOIN s_SAP_IHPA_Z3 ON gmdr_SAP_PROJ.PSPID = s_SAP_IHPA_Z3.PSPID COLLATE DATABASE_DEFAULT AND s_SAP_IHPA_Z3.xRank = 1
LEFT JOIN [Client] Z3_Client ON s_SAP_IHPA_Z3.PARNR = Z3_Client.ClientNumber COLLATE DATABASE_DEFAULT
WHERE mds_Matter.MatterNumber IN ('1000034493')

