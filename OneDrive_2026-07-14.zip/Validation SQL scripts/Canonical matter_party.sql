--SCA3VTSQLSRV01
--[NRCAN_RMDD]
--Canonical matter_party

SELECT
matter_party_key = 'Identity'
,matter_number = 'cmidb'
,party_number = 'cmidb'
,member_firm_code = 'cmidb'
,matter_key = 'matter.matter_key'
,party_name = 'cmidb'
,is_active = 'cmidb'
,last_updated_date_utc_at_source = 'cmidb'
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = 'Internal'
,updated_date_time = 'Internal'
,natural_key_hash = 'Internal'
