--SCA3VTSQLSRV01
--[NRCAN_RMDD]
--Canonical Address

SELECT
 cost_centre_key = 'IDENTITY'
,cost_centre_code = LTRIM(RTRIM(mds_costcenter.CostCenter))
,member_firm_code = 'GPMS'
,valid_from_date = mds_costcenter.ValidFromDate
,valid_to_date = mds_costcenter.ValidToDate
,company_Code = mds_costcenter.CompanyCode
--,company_key = curated_company.company_key
,currency_code = mds_costcenter.CurrencyKey
,profit_centre = mds_costcenter.ProfitCenter
,cost_centre_description = mds_costcenter.[Description]
,cost_centre_long_description = mds_costcenter.LongDescription
,is_active = CASE WHEN current_timestamp BETWEEN ValidFromDate AND ValidToDate THEN 1 ELSE 0 END
,last_updated_date_utc_at_source = mds_costcenter.TIMESTAMP
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = 'Internal'
,updated_date_time = 'Internal'
,natural_key_hash = 'Internal'


FROM [dbo].[CostCenter] mds_costcenter
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_company] curated_company ON mds_costcenter.CompanyCode = curated_company.company_code COLLATE DATABASE_DEFAULT
WHERE CostCenter LIKE 'TOR1964001'

