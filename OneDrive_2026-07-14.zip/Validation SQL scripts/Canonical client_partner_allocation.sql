--SCA3VTSQLSRV01
--[NRCAN_RMDD]
--Canonical client_partner_allocation

SELECT
 client_partner_allocation_key = 'Identity'
,client_number = gmdr_sap_zprs_tkalocclnt.KUNNR
,client_number = mds_client.ClientNumber
,member_firm_code = 'GPMS'
,member_firm_code = mds_client.MemberFirmCode
,person_number = gmdr_sap_zprs_tkalocclnt.PERNR
,person_number = mds_Person.SystemEmployeeCode
--,partner_function_key = t_partner_function.partner_function_key
--,partner_function_key = t_partner_function.partner_function_key
,begin_date = gmdr_sap_zprs_tkalocclnt.BEGDA
,begin_date = mds_client.OpenDateGMT
,end_date = gmdr_sap_zprs_tkalocclnt.ENDDA
,end_date = mds_client.CloseDateGMT
,allocation_percentage = gmdr_sap_zprs_tkalocclnt.ZZALLOCPERCENT
,allocation_percentage = '100'
,client_key	= 'client_key'
,person_key	 = 'person_key'
,is_active = CASE WHEN gmdr_sap_zprs_tkalocclnt.DELETION_INDICATOR <> 'X' AND current_timestamp >= gmdr_sap_zprs_tkalocclnt.BEGDA and current_timestamp<= gmdr_sap_zprs_tkalocclnt.ENDDA THEN 1 ELSE 0 END
,is_active = mds_client.Active
,last_updated_date_utc_at_source = gmdr_sap_zprs_tkalocclnt.TIMESTAMP
,last_updated_date_utc_at_source = mds_client.LastUpdatedDateGMT
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = 'Internal'
,updated_date_time = 'Internal'
,natural_key_hash = 'Internal'

FROM [dbo].[Client] mds_client 
LEFT JOIN [QA1_RMDR_CAN].[dbo].[SAP_ZPRS_TKALOCCLNT] gmdr_sap_zprs_tkalocclnt ON mds_client.ClientNumber = gmdr_sap_zprs_tkalocclnt.KUNNR COLLATE DATABASE_DEFAULT
LEFT JOIN [dbo].[PersonSystemMap] mds_PersonSystemMap 
	ON gmdr_sap_zprs_tkalocclnt.PERNR = CAST(COALESCE(mds_PersonSystemMap.GPMSEXTERNALPERSONID,mds_PersonSystemMap.GPMSPERSONNELNUMBER) AS VARCHAR(50)) COLLATE DATABASE_DEFAULT
LEFT JOIN [dbo].[Person] mds_Person ON mds_PersonSystemMap.PersonID = mds_Person.PersonID
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_partner_function] t_partner_function ON gmdr_sap_zprs_tkalocclnt.PARVW = t_partner_function.sap_code COLLATE DATABASE_DEFAULT

WHERE mds_client.MemberFirmCode = 'GPMS'
AND mds_client.ClientNumber = '10000003'

