--SCA3VTSQLSRV01
--[NRCAN_RMDD]
--Canonical matter_key_initiative

SELECT

matter_key_initiative_key = 'Internal'
,matter_number = 'cmidb'
,member_firm_code = 'GPMS'
,global_strategic_initiative_key = 'cmidb'
,matter_key = 'cmidb'
,is_active = 'cmidb'
,last_updated_date_utc_at_source = 'cmidb'
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = 'Internal'
,updated_date_time = 'Internal'
,natural_key_hash = 'Internal'

