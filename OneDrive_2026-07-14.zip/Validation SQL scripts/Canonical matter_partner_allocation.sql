--SCA3VTSQLSRV01
--[NRCAN_RMDD]
--Canonical matter_partner_allocation

SELECT
 matter_partner_allocation_key = 'IDENTITY'
,matter_number = gmdr_sap_zprs_tkalocmattr.PSPID
,member_firm_code = 'GPMS'
,person_number = gmdr_sap_zprs_tkalocmattr.PERNR
--,partner_function_key = partner_function.partner_function_key
--,office_key = office.office_key
--,team_key = team.team_key
,begin_date = gmdr_sap_zprs_tkalocmattr.BEGDA
,end_date = gmdr_sap_zprs_tkalocmattr.ENDDA
,associate_person_number = gmdr_sap_zprs_tkalocmattr.PERNR_ASSOC
,allocation_percentage = gmdr_sap_zprs_tkalocmattr.ZZALLOCPERCET
,matter_key	= 'matter_key'
,person_key = 'TBD'
,associate_person_key = 'person.person_key'
,is_active = CASE WHEN gmdr_sap_zprs_tkalocmattr.DELETION_INDICATOR <> 'X' AND current_timestamp BETWEEN BEGDA AND ENDDA THEN 1 ELSE 0 END
,last_updated_date_utc_at_source = gmdr_sap_zprs_tkalocmattr.TIMESTAMP
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = 'Internal'
,updated_date_time = 'Internal'
,natural_key_hash = 'Internal'
FROM [QA1_RMDR_CAN].[dbo].[SAP_ZPRS_TKALOCMATTR] gmdr_sap_zprs_tkalocmattr
LEFT JOIN [dbo].[Matter] mds_matter ON gmdr_sap_zprs_tkalocmattr.PSPID = mds_matter.MatterNumber COLLATE DATABASE_DEFAULT
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_partner_function] partner_function ON gmdr_sap_zprs_tkalocmattr.PARVW = partner_function.sap_code COLLATE DATABASE_DEFAULT
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_office] office ON gmdr_sap_zprs_tkalocmattr.WERKS = office.office_code COLLATE DATABASE_DEFAULT
--LEFT JOIN [Fabric_GMDR].[taxonomy_data_model].[curated_team] team ON gmdr_sap_zprs_tkalocmattr.ZZTEAM = team.team_code COLLATE DATABASE_DEFAULT AND team.member_firm_code = 'GPMS'
--LEFT JOIN MatterAttorney ON mds_matter.MatterNumber = MatterAttorney.MatterNumber
--LEFT JOIN [dbo].[Person_GMDR] mds_person ON MatterAttorney.PersonID = mds_person.PersonID
WHERE PSPID IN ('1000034493')

