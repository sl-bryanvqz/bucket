--SCA3VTSQLSRV01
--[NRCAN_RMDD]
--Canonical Client

SELECT
client_key = 'Identity Column'
,client_number = mds_Client.ClientNumber
,member_firm_code = LTRIM(RTRIM(ISNULL(mds_Client.MemberFirmCode,''))) 
,client_id = mds_Client.ClientID
,pms_client_id = mds_Client.PMSClientID
,client_name = mds_Client.ClientName
,alternate_client_name = mds_Client.AlternateClientName
,contact_name = mds_Client.ContactName
,open_date_utc = mds_Client.OpenDateGMT
,close_date_utc = mds_Client.CloseDateGMT
,client_e_billing_vendor = gmdr_SAP_KNA1.ZZEBILLVENDOR
,client_information_barier = gmdr_SAP_KNA1.ZZPRICONF
,client_name_cmi = 'cmi'
,member_firm_code_cmi = 'cmi'
,client_status_cmi = 'cmi'
,client_non_consent = gmdr_SAP_KNA1.ZNONCONSENT
,client_pricing_group = gmdr_SAP_KNA1.ZZCLNTGRP
,customer_account_group = gmdr_SAP_KNA1.KTOKD
,client_programme_key = gmdr_SAP_KNA1.ZZCLNTPRG
,tax_jurisdiction = gmdr_SAP_KNA1.TXJCD
,tax_number_1 = gmdr_SAP_KNA1.STCD1
,tax_number_2 = gmdr_SAP_KNA1.STCD2
,vat_registration_number = gmdr_SAP_KNA1.STCEG
,vat_valid_date = gmdr_SAP_KNA1.ZZVATVALDT
,client_duns = mds_Client.ClientDUNS
,client_guduns = mds_Client.ClientGUDUNS
,comments = mds_Client.Comments
,pms_entity_type = mds_Client.PMSEntityType
,client_type = mds_Client.ClientType
,is_confidential = mds_Client.IsConfidential
,client_sector_key = mds_Client.SICCode
,is_sanctions_checked = mds_Client.SanctionsChecked_YN
,is_active = mds_Client.Active
,created_date_utc_at_source = mds_Client.CreatedDateGMT
,last_updated_date_utc_at_source = mds_Client.LastUpdatedDateGMT
,source_system = 'Internal'
,inserted_process_instance_id = 'Internal'
,updated_process_instance_id = 'Internal'
,inserted_process_queue_id = 'Internal'
,updated_process_queue_id = 'Internal'
,inserted_date_time = 'Internal'
,updated_date_time = 'Internal'
,natural_key_hash = 'Internal'
FROM [dbo].[Client] mds_Client
LEFT JOIN [QA1_RMDR_CAN].[can].[SAP_KNA1] gmdr_SAP_KNA1 ON mds_Client.ClientNumber = gmdr_SAP_KNA1.KUNNR COLLATE DATABASE_DEFAULT
WHERE ClientNumber IN ('10000015')
