# Azure DevOps Setup

## Overview

Azure DevOps provides the CI/CD infrastructure for deploying and managing the Microsoft Fabric Foundation platform. It integrates with Azure Key Vault for secure credential management and uses service principals for automated deployments across environments.

## Prerequisites

- Azure DevOps project access
- Service Principal created and configured (see [Service Principal Setup](../00-setup/Service-Principal-Setup.md))
- Azure Key Vault with stored credentials (see [Azure Key Vault Setup](../00-setup/Azure-Key-Vault-Setup.md))
- Appropriate permissions to create service connections and variable groups

## Configuration Steps

### 1. Service Connection Setup

1.1 Navigate to Azure DevOps Project → **Project Settings** → **Pipelines** → **Service Connections** → `+ New Service Connection`

1.2 Choose **Azure Resource Manager** → **Managed Identity (manual)**

![azure-devops-service-connection](../00-setup/.images/azure-devops-service-connection.png)

1.3 Provide the following details:

- **Managed Identity:** `MI-EDM-FOUNDATION-D`
- **Subscription:** NRFC Fabric subscription
- **Resource Group:** `RG-NRFC-EDM-UW2-FABRICFOUNDATION-D`

1.4 **Name the connection:** `sc-fabricfoundation-d`

1.5 Verify connection by clicking **Verify**

### 2. Variable Groups Configuration

2.1 Navigate to **Pipelines** → **Library** → `+ Variable Group`

#### 2.1.1 Non-Secret Variables Group

Create variable group: `Foundation-CICD-Config`

| Variable Name | Value | Purpose |
|---------------|-------|---------|
| `DevWorkspace` | `[DEV-WORKSPACE-ID]` | Target workspace for DEV deployments |
| `TestWorkspace` | `[TEST-WORKSPACE-ID]` | Target workspace for TEST deployments |
| `PRODWorkspace` | `[PROD-WORKSPACE-ID]` | Target workspace for PROD deployments |
| `environment_name` | `Dev/Test/Prod` | Current environment identifier |
| `artifact_path` | `$(Build.ArtifactStagingDirectory)` | Build artifacts location |

#### 2.1.2 Secrets Variable Group

Create variable group: `Foundation-CICD-Secrets`

2.2 **Link to Azure Key Vault:**

- Select **Link secrets from an Azure key vault as variables**
- Choose Key Vault: `NRFC-EDM-KV-FABRIC-D`
- Authorize using service connection: `sc-fabricfoundation-d`
- Add the following secrets:

| Variable Name | Key Vault Secret | Purpose |
|---------------|------------------|---------|
| `fabric-api-sp-client-id` | `fabric-api-sp-client-id` | Service Principal Client ID |
| `fabric-api-sp-tenant-id` | `fabric-api-sp-tenant-id` | Azure Tenant ID |
| `fabric-api-sp-clientsecret` | `fabric-api-sp-clientsecret` | Service Principal Secret |

2.3 **Security Settings:**

- Check **Allow access to all pipelines**
- Configure appropriate pipeline permissions

### 3. CI/CD Pipeline Configuration

The following pipelines are configured for deploying Fabric Foundation components:

#### 3.1 Development Environment Pipelines

| Pipeline Name | Purpose | Trigger |
|---------------|---------|---------|
| `foundation-deployer-endtoend-greenfield-D.yml` | Full greenfield deployment to DEV | Manual/Scheduled |
| `foundation-deployer-publishartifacts-sqldacpac-D.yml` | Incremental updates to DEV | Pull request |
| `foundation-deployer-sqldacpac-D.yml` | SQL database object deployment to DEV | Database changes |

#### 3.2 Production Environment Pipelines

| Pipeline Name | Purpose | Trigger |
|---------------|---------|---------|
| `foundation-deployer-endtoend-greenfield-P.yml` | Full greenfield deployment to PROD | Manual approval |
| `foundation-deployer-publishartifacts-sqldacpac-P.yml` | Incremental updates to PROD | Release branch |
| `foundation-deployer-sqldacpac-P.yml` | SQL database object deployment to PROD | Database changes |

#### 3.3 Pipeline Authentication

3.3.1 **Service Principal Authentication:**

- Uses SPN (`sp_fabric_foundation_devops`) credentials
- Executes `auth_spn_secret_AzDo.py` for Fabric workspace publishing
- Retrieves credentials from Azure Key Vault during runtime

3.3.2 **Security Implementation:**

- No plain-text secrets in YAML files
- All sensitive data retrieved from Key Vault
- Service connections use least-privilege access

### 4. Environment-Specific Configuration

| Environment | Service Connection | Variable Group Suffix | Key Vault |
|-------------|-------------------|---------------------|-----------|
| **DEV/TEST** | `sc-fabricfoundation-d` | `-D` | `NRFC-EDM-KV-FABRIC-D` |
| **PRODUCTION** | `sc-fabricfoundation-p` | `-P` | `NRFC-EDM-KV-FABRIC-P` |

4.1 **Dynamic Parameters:**

- The YAML Pipeline leverages dynamic parameters to update GUIDs and IDs of deployed artifacts in the target workspace, using values defined in `parameter.yml`.
- The purpose of the `parameter.yml` file is to manage environment-specific values within your deployment process. By committing this file to your repository, you allow for programmatic modification of values, ensuring that each deployment is tailored to its specific environment.
- During pipeline execution, the pipeline checks the environment field passed into the `FabricWorkspace` object. If a corresponding environment is found in `parameter.yml`, the pipeline applies the relevant values. If the environment is not defined, any dependent replacements for that environment will be skipped.
- Within the `find_replace` parameter, you can use the `replace_value` field to reference `fabric-cicd` defined variables, such as workspace or deployed item metadata. These variables enable the dynamic insertion of values like updated GUIDs and IDs during pipeline execution.

```python
find_replace:
  # Workspace GUID
  - find_value: "3a5b3702-edbf-4cc5-927d-c599ac477bb3"
    replace_value:
      Default: "$workspace.id"
      Test: "$workspace.id"
      Prod: "$workspace.id"

  # Bronze Lakehouse GUID (dynamic replacement)
  - find_value: "4e0aeb58-a55e-4c44-9495-d17c11ede608"
    replace_value:
      Default: "4e0aeb58-a55e-4c44-9495-d17c11ede608"
      Test: "$items.Lakehouse.bronze_lh.$id"
      Prod: "$items.Lakehouse.bronze_lh.$id"
```

### 5. Pipeline Security and Approvals

5.1 **Environment Protection:**

- Configure environment approvals for production deployments
- Require manual approval from authorized personnel
- Implement branch protection policies

5.2 **Access Control:**

- Limit pipeline edit permissions to DevOps leads
- Use security groups for role-based access
- Audit pipeline execution logs regularly

## Testing and Validation

### 1. Service Connection Test

1.1 In the service connection settings, click **Verify and save**
1.2 Confirm successful authentication with Azure resources

### 2. Variable Group Test

2.1 Create a test pipeline that references both variable groups
2.2 Verify secrets are retrieved successfully from Key Vault
2.3 Confirm non-secret variables are accessible

### 3. End-to-End Pipeline Test

3.1 Execute `foundation-deployer-endtoend-greenfield-D.yml` in DEV
3.2 Monitor deployment logs for authentication success
3.3 Verify Fabric workspace artifacts are deployed correctly

## Troubleshooting

### Common Issues

**Issue:** Service connection authentication fails

- **Solution:** Verify managed identity permissions in Key Vault
- **Solution:** Check service principal permissions in Azure subscription

**Issue:** Variable group secrets not accessible

- **Solution:** Confirm Key Vault access policies for service connection
- **Solution:** Verify variable group is linked to correct Key Vault

**Issue:** Pipeline fails during Fabric authentication

- **Solution:** Check Fabric tenant settings allow service principal access
- **Solution:** Verify service principal is member of `fabric_foundation_admin_dev` group

**Issue:** Warnings during pipeline run to adjust the code to new variable format

- **Solution:** Check `fabric-cicd` python library for new format updates
---

[← Back to Entra ID Group Setup](../00-setup/Entra-ID-Group-Setup.md) | [Next: Environment Replication →](../00-setup/Environment-Replication.md)
