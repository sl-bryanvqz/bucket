# Azure Key Vault Setup

## Overview

The Azure Key Vault provides centralized, secure management of secrets, keys, and credentials used by the Microsoft Fabric Foundation platform. It ensures that sensitive information, such as service principal credentials and connection strings, is never stored directly in code, pipelines, or notebooks.

## Prerequisites

- Service Principal created (see [Service Principal Setup](../00-setup/Service-Principal-Setup.md))
- Azure subscription access
- Resource Group permissions

## Configuration Steps

The Azure Key Vault provides centralized, secure management of secrets, keys, and credentials used by the Microsoft Fabric Foundation platform.
It ensures that sensitive information, such as service principal credentials and connection strings, is never stored directly in code, pipelines, or notebooks.
The Foundation framework uses Key Vault to supply secrets dynamically to Data Pipelines, Notebooks, and CI/CD processes through managed identities and service principal authentication.

| Environment | Key Vault Name | Purpose |
|---|---|---|
| Development | NRFC-EDM-KV-FABRIC-D | Primary vault for dev/test workloads |
| Test | NRFC-EDM-KV-FABRIC-T | For UAT and QA validation |
| Production | NRFC-EDM-KV-FABRIC-P | Used by production Fabric tenant and CI/CD |

Each environment maintains an isolated Key Vault  instance under the NRFC Enterprise Data Management (EDM) subscription.

Steps to follow for configurations:

1. Create the Key Vault.

    1.1 Navigate to Azure Portal -> Create a Resource -> Security + Identity -> Key Vault -> `+ Create`

    ![azure-portal-key-vault](../00-setup/.images/azure-portal-key-vault.png)

    1.2 Name: `NRFC-EDM-KV-FABRIC-D` (or select the appropriate name for the environment)

    1.3 Resource Group: `RG-NRFC-EDM-UW2-FABRICFOUNDATION-D` (or select the resource group for the data product)

    1.4 Region: `West US 2`

    ![azure-portal-key-vault-create](../00-setup/.images/azure-portal-key-vault-create.png)

2. Configure Access Policies

    2.1 Go to Key Vault -> Access Control (IAM) -> Add Role Assignment.

    ![azure-portal-kv-mi-role](../00-setup/.images/azure-portal-kv-mi-role.png)

    2.2 Add the following principals and assign appropriate roles:

    |Principal|Role|Purpose|
    |---|---|---|
    |`sp_fabric_foundation_devops`|Key vault secrets user|Allows SPN-based CI/CD pipelines to retrieve secrets|
    |`MI-EDM-FOUNDATION-D`|Key vault reader|Allows Fabric Data Pipelines and Notebooks to read secrets at runtime using Managed Identity.|
    |Platform Admins/DevOps Leads|Key vault administrator|For vault management, secret rotation, and monitoring|

    _Use Role-Based Access Control (RBAC), not legacy access policies, to ensure centralized management through Entra ID_
    - Currently, access is implemented using Access policies `Get, List` Secret Permissions

3. Add Service Principal Secrets

    3.1 Navigate to Objects -> Secrets -> `+ Generate/Import`

    ![azure-portal-kv-secrets-add](../00-setup/.images/azure-portal-kv-secrets-add.png)

    3.2 Create the following entries (one per environment):

    |Secret Name|Value|Description|
    |---|---|---|
    |`fabric-api-sp-client-id`|SPN Application(client) ID|Used for automation authentication|
    |`fabric-api-sp-tenant-id`|Tenant(directory) ID|Used by pipelines and notebooks for authentication context|
    |`fabric-api-sp-clientsecret`|SPN client secret value|Generated during SPN registration (visible only once)|

    3.3 Save all secrets and confirm the Secret Identifier URIs. These will be referenced by Fabric Variable libraries.

4. Enable Networking and Security Controls

    4.1 Navigate to the Networking tab.

    4.2 Select Private endpoint connections -> Enabled (optional but recommended for production)

    4.3 Configure Firewall:
    - Allow trusted Microsoft services.
    - Restrict access to NRFC corporate networks or VNets if applicable.

    4.4 Enable Soft Delete and Purge Protection under Recovery settings.
        - This protects secrets from accidental deletion and ensures recovery within retention period.

5. Integration with Fabric Variable Libraries

    5.1 In Fabric, the Key Vault is referenced through the Variable Library `vl_authentication`.

    5.2 Example JSON structure:

    ```json
    {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/variableLibrary/definition/variables/1.0.0/schema.json",
        "variables": [{
            "name": "akv_uri",
            "type": "String",
            "value": "https://NRFC-edm-kv-fabric-d.vault.azure.net/"
        },
        {
            "name": "tenant_id_secret_name",
            "type": "String",
            "value": "fabric-api-sp-tenant-id"
        },
        {
            "name": "client_id_secret_name",
            "type": "String",
            "value": "fabric-api-sp-client-id"
        },
        {
            "name": "client_secret_name",
            "type": "String",
            "value": "fabric-api-sp-clientsecret"
        }]
    }
    ```

6. Test Access via Managed Identity and SPN. Return to these once you've created the Service Principal and Managed Identity.

    6.1 SPN Test

    Run a PowerShell command using Azure CLI:

    ```bash
    az login --service-principal -u <client-id> -p <client-secret> --tenant <tenant-id>
    az keyvault secret show --vault-name NRFC-EDM-KV-FABRIC-D --name fabric-api-sp-client-id
    ```

    6.2 Managed Identity Test

    Assign a test Fabric notebook to run under the Managed Identity `MI-EDM-FOUNDATION-D` and call:

    ```python
    secret_value = notebookutils.credentials.getSecret("https://NRFC-edm-kv-fabric-d.vault.azure.net/", "fabric-api-sp-client-id")
    print(secret_value)
    ```

7. Ongoing Maintenance

    |Task|Frequency|Owner|
    |---|---|---|
    |Rotate Service Principal Client Secrets|Every 6 to 12 months|IT Security/DevOps|
    |Review Access COntrol (IAM) Assignments|Quarterly|Security/Platform Admin|
    |Audit Key Vault Access Logs|Monthly|Security/Compliance|
    |Validate Environment Sync (DEV -> TST -> PRD)|During release|DevOps|

---

[← Back to Service Principal Setup](../00-setup/Service-Principal-Setup.md) | [Next: Managed Identity Setup →](../00-setup/Managed-Identity-Setup.md)
