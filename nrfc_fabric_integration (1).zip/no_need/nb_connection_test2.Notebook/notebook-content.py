# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

def _test_jdbc_connection(jdbc_url,driver):

    try:
        (spark.read.format("jdbc")
        .option("url", jdbc_url)
        .option("dbtable", "(SELECT 'Successfull' AS Result) t")
        .option("driver", driver)
        .load()
        ).show()
    except Exception as e:
        print(f"Failed to retrieve database connection information: {str(e)}")
        raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

akv_uri = 'https://kv-can-non-prod-fms-cc.vault.azure.net/'

#tenant_id = notebookutils.credentials.getSecret(akv_uri, "fabric-api-sp-tenant-id")
#client_id = notebookutils.credentials.getSecret(akv_uri, "fabric-api-sp-client-id")

tenant_id = 'f8a46a38-2d3d-4672-ae57-34e8f266feb4'

client_id = 'ed123509-1f6d-4796-8edc-ad8f5ebc264a' # '3ae50bf0-cabd-49d0-8028-31bec3959959'


client_secret = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-SQL-NonProd")



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# jdbc:sqlserver://hbvkj6b5fvzenlsxgtupezx6wq-vpmebwjonseebbnygm27gkd4xq.database.fabric.microsoft.com:1433;database={metadata_control_db-03c614fe-5ce2-4490-976d-6be276017af0};encrypt=true;trustServerCertificate=false;authentication=ActiveDirectoryInteractive

# MARKDOWN ********************

# ##### metadata_control_db - ws_canada_global_mds_dev
# jdbc:sqlserver://hbvkj6b5fvzenlsxgtupezx6wq-vpmebwjonseebbnygm27gkd4xq.database.fabric.microsoft.com:1433;database={metadata_control_db-03c614fe-5ce2-4490-976d-6be276017af0};encrypt=true;trustServerCertificate=false;authentication=ActiveDirectoryInteractive
# 
# 
# 
# 
# 
# ##### metadata_control_db - ws_canada_parallel_slow_integration_dev2
# 
# jdbc:sqlserver://hbvkj6b5fvzenlsxgtupezx6wq-izcmegq3oxzuvfw56xovti4bve.database.fabric.microsoft.com:1433;database={metadata_control_db-ba07dc7b-cb72-41b8-8a2e-171c2df9ca92};encrypt=true;trustServerCertificate=false;authentication=ActiveDirectoryInteractive


# CELL ********************

jdbc_hostname = 'hbvkj6b5fvzenlsxgtupezx6wq-vpmebwjonseebbnygm27gkd4xq.database.fabric.microsoft.com'
jdbc_database = 'metadata_control_db-03c614fe-5ce2-4490-976d-6be276017af0'
jdbc_url = (
  f"jdbc:sqlserver://{jdbc_hostname}:1433;"
  f"database={jdbc_database};"
  f"authentication=ActiveDirectoryServicePrincipal;"
  f"aadSecurePrincipalId={client_id};"
  f"aadSecurePrincipalSecret={client_secret};"
  f"aadAuthority=https://login.microsoftonline.com/{tenant_id}"
)
driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

_test_jdbc_connection(jdbc_url,driver)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # New Connection

# CELL ********************

akv_uri = 'https://kv-can-non-prod-fms-cc.vault.azure.net/'

#tenant_id = notebookutils.credentials.getSecret(akv_uri, "fabric-api-sp-tenant-id")
#client_id = notebookutils.credentials.getSecret(akv_uri, "fabric-api-sp-client-id")

tenant_id = 'f8a46a38-2d3d-4672-ae57-34e8f266feb4'

client_id = 'ed123509-1f6d-4796-8edc-ad8f5ebc264a' # '3ae50bf0-cabd-49d0-8028-31bec3959959'


client_secret = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-SQL-NonProd")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

jdbc_hostname = 'hbvkj6b5fvzenlsxgtupezx6wq-vpmebwjonseebbnygm27gkd4xq.database.fabric.microsoft.com'
jdbc_database = 'metadata_control_db-03c614fe-5ce2-4490-976d-6be276017af0'
jdbc_url = (
  f"jdbc:sqlserver://{jdbc_hostname}:1433;"
  f"database={jdbc_database};"
  f"authentication=ActiveDirectoryServicePrincipal;"
  f"aadSecurePrincipalId={client_id};"
  f"aadSecurePrincipalSecret={client_secret};"
  f"aadAuthority=https://login.microsoftonline.com/{tenant_id}"
)
driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # JDBC - Token (without SP)

# CELL ********************

import json, yaml, notebookutils, time

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

token = notebookutils.credentials.getToken("https://database.windows.net/.default")
token_generated = time.time()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_token():
    global token_generated
    global token
    if time.time() - token_generated > 3000:
        token_generated = time.time()
        token = notebookutils.credentials.getToken("https://database.windows.net/.default")
    return token

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def _test_jdbc_connection(jdbc_url,driver):

    access_token = get_token()
    
    try:
        (spark.read.format("jdbc")
        .option("url", jdbc_url)
        .option("dbtable", "(SELECT 'Successfull' AS Result) t")
        .option("driver", driver)
        .option("accessToken", access_token)
        .load()
        ).show()
    except Exception as e:
        logging.error(f"Failed to retrieve database connection information: {str(e)}")
        raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

jdbc_hostname = 'hbvkj6b5fvzenlsxgtupezx6wq-vpmebwjonseebbnygm27gkd4xq.database.fabric.microsoft.com'
jdbc_database = 'metadata_control_db-03c614fe-5ce2-4490-976d-6be276017af0'
jdbc_url = (
  f"jdbc:sqlserver://{jdbc_hostname}:1433;"
  f"database={jdbc_database};"
)
driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

_test_jdbc_connection(jdbc_url,driver)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # ODBC - Key Vault- Service Principal - Token

# CELL ********************

akv_uri = 'https://kv-can-non-prod-fms-cc.vault.azure.net/'
tenant_id = 'f8a46a38-2d3d-4672-ae57-34e8f266feb4'
client_id = 'ed123509-1f6d-4796-8edc-ad8f5ebc264a'
client_secret = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-SQL-NonProd")

server = 'hbvkj6b5fvzenlsxgtupezx6wq-vpmebwjonseebbnygm27gkd4xq.database.fabric.microsoft.com'
database = 'metadata_control_db-03c614fe-5ce2-4490-976d-6be276017af0'

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import urllib
import struct
from sqlalchemy import create_engine,text
from azure.identity import ClientSecretCredential

# Acquire token using Azure AD (Service Principal)
credential = ClientSecretCredential(
    tenant_id=tenant_id,
    client_id=client_id,
    client_secret=client_secret
)

token = credential.get_token("https://database.windows.net/.default").token

# Encode token for pyodbc
token_bytes = token.encode("utf-16-le")
token_struct = struct.pack(f'<I{len(token_bytes)}s', len(token_bytes), token_bytes)

# Base connection string (no UID/PWD/Auth)
connection_string = (
    f"DRIVER={{ODBC Driver 18 for SQL Server}};"
    f"SERVER={server};"
    f"DATABASE={database};"
    f"Encrypt=yes;"
    f"TrustServerCertificate=no;"
)

params = urllib.parse.quote_plus(connection_string)

# Create engine with access token
engine = create_engine(
    f"mssql+pyodbc:///?odbc_connect={params}",
    connect_args={"attrs_before": {1256: token_struct}}  # 1256 = SQL_COPT_SS_ACCESS_TOKEN
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

query = text("SELECT * FROM meta.task")

with engine.connect() as conn:
    result = conn.execute(query, {"id": 1})
    
    for row in result:
        print(row)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # ODBC - Token

# CELL ********************

server = 'hbvkj6b5fvzenlsxgtupezx6wq-vpmebwjonseebbnygm27gkd4xq.database.fabric.microsoft.com'
database = 'metadata_control_db-03c614fe-5ce2-4490-976d-6be276017af0'

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import urllib
import struct
from sqlalchemy import create_engine,text
import json, yaml, notebookutils, time


# Acquire token using Azure AD (Service Principal)


token = notebookutils.credentials.getToken("https://database.windows.net/.default")

# Encode token for pyodbc
token_bytes = token.encode("utf-16-le")
token_struct = struct.pack(f'<I{len(token_bytes)}s', len(token_bytes), token_bytes)

# Base connection string (no UID/PWD/Auth)
connection_string = (
    f"DRIVER={{ODBC Driver 18 for SQL Server}};"
    f"SERVER={server};"
    f"DATABASE={database};"
    f"Encrypt=yes;"
    f"TrustServerCertificate=no;"
)

params = urllib.parse.quote_plus(connection_string)

# Create engine with access token
engine = create_engine(
    f"mssql+pyodbc:///?odbc_connect={params}",
    connect_args={"attrs_before": {1256: token_struct}}  # 1256 = SQL_COPT_SS_ACCESS_TOKEN
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

query = text("SELECT * FROM meta.task")

with engine.connect() as conn:
    result = conn.execute(query, {"id": 1})
    
    for row in result:
        print(row)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
