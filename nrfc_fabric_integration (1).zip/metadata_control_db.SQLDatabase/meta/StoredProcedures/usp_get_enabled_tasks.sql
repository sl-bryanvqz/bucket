
CREATE PROCEDURE [meta].[usp_get_enabled_tasks]
    @stage VARCHAR(500) = NULL,
    @task_name VARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SET @stage = LOWER(NULLIF(LTRIM(RTRIM(@stage)), ''));
    SET @task_name = LOWER(NULLIF(LTRIM(RTRIM(@task_name)), ''));

    WITH stage_filter AS (
        SELECT LTRIM(RTRIM(value)) AS stage
        FROM STRING_SPLIT(@stage, ',')
        WHERE @stage IS NOT NULL
    ),
    task_filter AS (
        SELECT LTRIM(RTRIM(value)) AS task_name
        FROM STRING_SPLIT(@task_name, ',')
        WHERE @task_name IS NOT NULL
    )
    SELECT
        NEWID() AS task_executions_id,
        NEWID() AS lineage_id,
        tm.*
    FROM meta.task_metadata tm
    WHERE tm.enabled = 1
      AND (
            @task_name IS NULL
            OR LOWER(tm.task_name) IN (SELECT task_name FROM task_filter)
          )
      AND (
            @stage IS NULL
            OR LOWER(tm.stage) IN (SELECT stage FROM stage_filter)
            OR (
                '__other__' IN (SELECT stage FROM stage_filter)
                AND LOWER(tm.stage) NOT IN ('taxonomy', 'silver', 'gold')
            )
          )
    ORDER BY
        CASE LOWER(tm.stage)
            WHEN 'taxonomy' THEN 1
            WHEN 'silver' THEN 2
            WHEN 'gold' THEN 3
            ELSE 4
        END,
        tm.task_id;
END;

GO

