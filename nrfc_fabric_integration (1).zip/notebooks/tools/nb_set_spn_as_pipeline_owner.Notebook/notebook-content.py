# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from notebookutils import mssparkutils
import requests
import json

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# fa-canada-non-prod-cmi-cc-01 (Service Principal)
# App ID:
# b87a1751-d2a8-4fbd-ab62-7f72d4d15647
# 
# Service Principal Object ID:
# 655d0637-f35c-4646-bdb7-bfa179c92fce
# 
# ------------------
# 
# NRFC Apps Fabric SQL NonProd (Service Principal)
# App ID:
# ed123509-1f6d-4796-8edc-ad8f5ebc264a
# 
# Service Principal Object ID:
# 6f1b3e40-60d6-4692-82b0-6ff7c4c196ca
# 
# 


# CELL ********************

akv_uri = 'https://kv-can-non-prod-fms-cc.vault.azure.net/'

tenant_id = notebookutils.credentials.getSecret(akv_uri, "fabric-api-sp-tenant-id")
client_id = notebookutils.credentials.getSecret(akv_uri, "fabric-api-sp-client-id")

#tenant_id = 'f8a46a38-2d3d-4672-ae57-34e8f266feb4'

#client_id = 'ed123509-1f6d-4796-8edc-ad8f5ebc264a' # '3ae50bf0-cabd-49d0-8028-31bec3959959'


client_secret = notebookutils.credentials.getSecret(akv_uri, "NRFC-Apps-Fabric-SQL-NonProd")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

client_secret

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# ==========================================
# CONFIGURATION
# ==========================================

workspace_id = "d940d8ab-6c2e-4088-85b8-3335f3287cbc"
pipeline_id = "7788b851-1b34-4c69-b06b-4fed71054691"

#new_pipeline_name = "My Pipeline"
new_description = "Pipeline updated by Service Principal"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ==========================================
# STEP 1 - GET ENTRA ID TOKEN
# ==========================================

token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"

payload = {
    "grant_type": "client_credentials",
    "client_id": client_id,
    "client_secret": client_secret,
    "scope": "https://api.fabric.microsoft.com/.default"
}

response = requests.post(token_url, data=payload)
response.raise_for_status()

access_token = response.json()["access_token"]

print("Access token obtained successfully")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

workspace_id = "<workspace-guid>"

url = f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}"

resp = requests.get(
    url,
    headers={"Authorization": f"Bearer {access_token}"}
)

print(resp.status_code)
print(resp.text)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

headers = {
    "Authorization": f"Bearer {access_token}"
}

url = f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}/items"

response = requests.get(url, headers=headers)
response.raise_for_status()

items = response.json()["value"]

for item in items:
    print(
        f"Name: {item['displayName']} | "
        f"Type: {item['type']} | "
        f"ID: {item['id']}"
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# ==========================================
# STEP 2 - GET EXISTING PIPELINE
# ==========================================

headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

get_url = f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}/items/{pipeline_id}"

pipeline_response = requests.get(get_url, headers=headers)
pipeline_response.raise_for_status()

pipeline = pipeline_response.json()

print("Pipeline retrieved successfully")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************



# ==========================================
# STEP 3 - UPDATE METADATA
# ==========================================

update_payload = {
    "displayName": new_pipeline_name,
    "description": new_description
}

update_url = f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}/items/{pipeline_id}"

update_response = requests.patch(
    update_url,
    headers=headers,
    json=update_payload
)

update_response.raise_for_status()

print("Pipeline metadata updated successfully")
print(update_response.json())


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
