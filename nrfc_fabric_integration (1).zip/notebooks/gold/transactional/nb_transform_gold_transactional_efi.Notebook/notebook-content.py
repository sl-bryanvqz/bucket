# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "87edacb2-3f66-484c-929b-e69785533c31",
# META       "default_lakehouse_name": "lh_canada_global_mds",
# META       "default_lakehouse_workspace_id": "d940d8ab-6c2e-4088-85b8-3335f3287cbc",
# META       "known_lakehouses": [
# META         {
# META           "id": "87edacb2-3f66-484c-929b-e69785533c31"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run nb_transformation_shared_functions

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values used when running this transform notebook alone
if globals().get("run_mode") != "framework":
    print("run_mode: manual")
    target_workspace          = "ws_canada_global_mds_dev"
    target_lakehouse          = "lh_canada_global_mds"
    target_table              = "gold_transactional_efi"
    map_view                  = f"map_{target_table}"
    target_pk                 = ["efi_key"]
    limit_rows_for_debugging  = True
    watermark_filter          = "1=1"

# Pipeline values passed from nb_load_sql_to_lakehouse
else:
    print("run_mode: framework")
    print(f"map_view: {map_view}")
    print(f"target_workspace: {target_workspace}")
    print(f"target_lakehouse: {target_lakehouse}")
    print(f"target_table: {target_table}")
    print(f"target_pk: {target_pk}")
    print(f"limit_rows_for_debugging: {limit_rows_for_debugging}")
    print(f"watermark_filter: {watermark_filter}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Manual fallback values. Parameters overwritten by nb_load_sql_to_lakehouse
spark.sql(f"""
CREATE OR REPLACE TEMP VIEW {map_view} AS
SELECT DISTINCT
    CAST(row_number() OVER (ORDER BY s.company_code, s.cost_center_code) AS BIGINT)            AS efi_key,

    COALESCE(INITCAP(LOWER(NULLIF(TRIM(CAST(s.unit AS STRING)), ''))), 'Unknown')              AS unit,
    COALESCE(NULLIF(TRIM(CAST(s.company_code AS STRING)), ''), 'Unknown')                      AS company_key,
    COALESCE(NULLIF(TRIM(CAST(s.company_region_src AS STRING)), ''), 'Unknown')                AS member_firm_code,
    COALESCE(NULLIF(TRIM(CAST(s.profit_center_code AS STRING)), ''), 'Unknown')                AS profit_center_code,
    COALESCE(NULLIF(TRIM(CAST(s.cost_center_code AS STRING)), ''), 'Unknown')                  AS cost_center_code,
    COALESCE(NULLIF(TRIM(CAST(s.gl_account_code AS STRING)), ''), 'Unknown')                   AS gl_account_code,
    COALESCE(NULLIF(TRIM(CAST(s.fe_code AS STRING)), ''), 'Unknown')                           AS fe_person_number,

    COALESCE(NULLIF(
        REPLACE(TRIM(CAST(s.fe_practice_group_code AS STRING)), '#', 'Unknown'),
        ''), 'Unknown')                                                                        AS fe_practice_group_key,

    COALESCE(NULLIF(TRIM(CAST(s.fe_office_code AS STRING)), ''), 'Unknown')                    AS fe_office_key,
    COALESCE(NULLIF(TRIM(CAST(s.fe_team_code AS STRING)), ''), 'Unknown')                      AS fe_team_key,

    COALESCE(NULLIF(
        CASE
            WHEN TRIM(CAST(s.lead_partner_code AS STRING)) IN ('0', '#') THEN 'Unknown'
            ELSE TRIM(CAST(s.lead_partner_code AS STRING))
        END, ''), 'Unknown')                                                                   AS lead_partner_person_number,

    COALESCE(NULLIF(
        CASE
            WHEN TRIM(CAST(s.lead_partner_practice_group_code AS STRING)) = '#' THEN 'Unknown'
            ELSE TRIM(CAST(s.lead_partner_practice_group_code AS STRING))
        END, ''), 'Unknown')                                                                   AS lead_partner_practice_group_key,

    COALESCE(NULLIF(
        CASE
            WHEN TRIM(CAST(s.lead_partner_office_code AS STRING)) = '#' THEN 'Unknown'
            ELSE TRIM(CAST(s.lead_partner_office_code AS STRING))
        END, ''), 'Unknown')                                                                   AS lead_partner_office_key,

    COALESCE(NULLIF(
        CASE
            WHEN TRIM(CAST(s.lead_partner_team_code AS STRING)) = '#' THEN 'Unknown'
            ELSE TRIM(CAST(s.lead_partner_team_code AS STRING))
        END, ''), 'Unknown')                                                                   AS lead_partner_team_key,

    COALESCE(NULLIF(
        CASE
            WHEN TRIM(CAST(s.matter_code AS STRING)) = '#' THEN 'Unknown'
            ELSE TRIM(CAST(s.matter_code AS STRING))
        END, ''), 'Unknown')                                                                   AS matter_number,

    COALESCE(NULLIF(
        CASE
            WHEN TRIM(CAST(s.vendor_code AS STRING)) = '#' THEN 'Unknown'
            ELSE TRIM(CAST(s.vendor_code AS STRING))
        END, ''), 'Unknown')                                                                   AS vendor_code,

    COALESCE(NULLIF(
        CASE
            WHEN TRIM(CAST(s.document_text AS STRING)) IN ('#', '') THEN 'Unknown'
            ELSE TRIM(CAST(s.document_text AS STRING))
        END, ''), 'Unknown')                                                                   AS document_text,

    COALESCE(
        TO_DATE(NULLIF(TRIM(CAST(s.document_date AS STRING)), ''), 'yyyyMMdd'),
        DATE '1900-01-01')                                                                     AS document_date,

    COALESCE(NULLIF(TRIM(CAST(s.document_number AS STRING)), ''), 'Unknown')                   AS document_number,
    COALESCE(NULLIF(TRIM(CAST(s.document_type_code AS STRING)), ''), 'Unknown')                AS transaction_document_type_key,
    COALESCE(NULLIF(TRIM(CAST(s.posting_period AS STRING)), ''), 'Unknown')                    AS posting_period,

    COALESCE(
        TO_DATE(NULLIF(TRIM(CAST(s.posting_date AS STRING)), ''), 'yyyyMMdd'),
        DATE '1900-01-01')                                                                     AS posting_date,

    COALESCE(NULLIF(TRIM(CAST(s.document_currency_code AS STRING)), ''), 'Unknown')            AS document_currency_code,
    CAST(NULLIF(TRIM(CAST(s.actual_amount_dc AS STRING)), '') AS DOUBLE)                       AS actual_amount_dc,
    COALESCE(NULLIF(TRIM(CAST(s.office_currency_code AS STRING)), ''), 'Unknown')              AS office_currency_code,
    CAST(NULLIF(TRIM(CAST(s.actual_amount_oc AS STRING)), '') AS DOUBLE)                       AS actual_amount_oc,
    COALESCE(NULLIF(TRIM(CAST(s.group_currency_code AS STRING)), ''), 'Unknown')               AS group_currency_code,
    CAST(NULLIF(TRIM(CAST(s.actual_amount_gc AS STRING)), '') AS DOUBLE)                       AS actual_amount_gc,
    CAST(NULLIF(TRIM(CAST(s.budget_amount_gc AS STRING)), '') AS DOUBLE)                       AS budget_amount_gc,
    CAST(NULLIF(TRIM(CAST(s.forecast_amount_gc AS STRING)), '') AS DOUBLE)                     AS forecast_amount_gc,

    COALESCE(
        TO_TIMESTAMP(NULLIF(TRIM(CAST(s.last_update_dt AS STRING)), ''), 'dd/MM/yyyy'),
        current_timestamp())                                                                   AS last_updated_date_utc_at_source

FROM {target_workspace}.{target_lakehouse}.silver_transactional.silver_transactional_efi s
WHERE {watermark_filter}
""")

# Debug output
if limit_rows_for_debugging:
    print(f"Mapped schema for {map_view}")
    spark.table(map_view).printSchema()
    
    print(f"Mapped preview for {map_view}")
    display(spark.table(map_view).limit(1000))

    print(f"Duplicate preview for {map_view}")
    duplicate_count = validate_duplicates(spark.table(map_view), target_pk, target_table)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
